# 只用训练回合拟合尺度

在实践包根目录运行；保留 `lessons/M35/code` 与 `lessons/M37/code` 相对目录。只用 Python 标准库，没有电机调用。

```sh
mkdir -p work
python3 lessons/M37/code/normalize.py /path/to/my-data-package --out work/normalization.json
python3 lessons/M37/code/report_normalization.py /path/to/my-data-package work/normalization.json --field left_shoulder_pan.pos --kind action --out work/shoulder-report
```

把 `/path/to/my-data-package` 换成本人 M35 导出包路径，含 manifest.json 与 data/frames.jsonl；有空格的路径用引号括起。
第一个命令只使用 train，保留12个观察通道和12个目标通道各自的均值、总体方差、原标准差和实际尺度。方差除以帧数，非除以帧数减一。每帧等权，较长回合贡献更多帧。

第二个命令产生 `roundtrip.csv`（逐帧原值、标准分数、还原值、还原差）、`distribution.svg`（12个等宽分箱的帧数图）、`report.json`（来源、分箱边界和精确计数）。浏览器可打开 SVG；不要把柱高当概率密度。默认也只画 train。

核对自己的四帧手算，用 `sample_four.py`，把回合身份和起始帧号换成自己选择的那段：

```sh
python3 lessons/M37/code/sample_four.py /path/to/my-data-package --episode YOUR_TRAIN_EPISODE --start-frame 0 --field left_shoulder_pan.pos --kind action --out work/four-frame-check.json
```

该文件逐行给出偏差、偏差平方、四帧统计下的分数与还原值。它明确只统计这四帧，不能替代全训练 normalization.json；供手算核对后，预测器仍用全训练配置。

教师若需要展示验证分布，可在第二个命令加 `--include-validation`。验证仅应用已保存训练统计，不重新拟合。此时图的横轴范围会容纳两组数，但归一化参数没有改变。脚本不接收 test。

统计规则：原标准差大于 `1e-8` 时直接作尺度，否则尺度设为1并标记 near_constant；原标准差仍保留，绝不谎报“标准差是1”。阈值作用于该通道当前原单位。没有裁剪，因此较远的值可以超过正负1或正负3，且依然可以逆变换。此配置是教学低维基线的配置，并不替代 ACT 官方 processor 的完整配置。

输出文件或目录已存在则拒绝覆盖；为新版本换名字。哈希或统计不一致则回查 M35 数据与训练划分，不删校验。只有明确合成夹具才加 `--allow-synthetic`，该选项不把合成来源改成本人记录。

运行本节数值测试：

```sh
python3 -m unittest discover -s lessons/M37/code -p 'test_*.py' -v
```

测试用临时 synthetic 夹具，不能当作个人实验已完成。
