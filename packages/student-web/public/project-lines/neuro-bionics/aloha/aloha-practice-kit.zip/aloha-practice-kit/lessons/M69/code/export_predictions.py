"""Zero-latent current-frame validation export with saved ACT processors.

One first action per original frame, raw physical target units. This is an offline
imitation metric; it is neither queued rollout success nor a hardware measurement.
"""
import argparse,sys,math
from pathlib import Path
from act_runtime import load_runtime
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M67'/'code'))
from course_contract import *

def validate_rule(rule):
 if rule.get('schema')!='aloha.selection-rule.v1' or rule.get('metric')!='episode_mean_scaled_first_action_L1':raise ValueError('explicit supported predeclared metric required')
 if rule.get('tie_break')!='lower_training_step_then_candidate_id':raise ValueError('predeclare deterministic tie break')
 scales=rule.get('joint_scales')
 if not isinstance(scales,list)or len(scales)!=12 or any(not finite(x)or x<=0 for x in scales):raise ValueError('12 fixed positive comparison scales required; not safety limits')
 if rule.get('action_fields')!=FIELDS or rule.get('action_units')!=UNITS:raise ValueError('selection rule field/unit mismatch')
 if not isinstance(rule.get('candidates'),list)or not rule['candidates'] or len(set(rule['candidates']))!=len(rule['candidates']):raise ValueError('predeclare exact candidate IDs')
 for k in ('validation_view_sha256','split_sha256','registered_at','rationale','validation_view_path','split_manifest_path'):
  if not text(rule.get(k)):raise ValueError('predeclare '+k)
 return rule

def score_rows(rows,scales):
 by_episode={};seen=set()
 for row in rows:
  key=(row['episode_id'],row['frame_index'],row['joint'])
  if key in seen:raise ValueError('duplicate scored identity')
  seen.add(key)
  if row['joint']not in FIELDS:raise ValueError('unknown joint')
  j=FIELDS.index(row['joint'])
  if row['unit']!=UNITS[j]or not all(finite(row[k])for k in ('target','prediction')):raise ValueError('unit or numeric mismatch')
  error=abs(row['prediction']-row['target'])
  scaled=error/scales[j]
  if not finite(error)or not finite(scaled):raise ValueError('error/scale arithmetic overflow')
  by_episode.setdefault(row['episode_id'],[]).append(scaled)
 if not by_episode:raise ValueError('empty validation cannot win')
 try:
  means={e:math.fsum(x/len(v) for x in v)for e,v in by_episode.items()}
  score=math.fsum(x/len(means) for x in means.values())
 except OverflowError as error:raise ValueError('metric aggregation overflow')from error
 if not all(finite(v)for v in [score,*means.values()]):raise ValueError('nonfinite metric')
 return {'score':score,'per_episode_scaled_L1':means,'episodes':len(means),'scalar_pairs':len(rows)}

def validation_rows(view,split):
 if view.get('schema')!='aloha.vision-teaching-view.v1' or view.get('source_kind')not in ('learner_recording','synthetic'):raise ValueError('audited raw-pixel view required')
 if view.get('state_fields')!=VIEW_FIELDS or view.get('action_fields')!=VIEW_FIELDS or view.get('action_semantics')!='teleop_action_processor target':raise ValueError('raw ordered field contract mismatch')
 if not isinstance(view.get('dataset_source'),dict)or not view['dataset_source']:raise ValueError('structured dataset source required')
 expected={r['episode_id']:r for r in split['episodes']if r['split']=='validation'}
 rows=[r for r in view['rows']if r.get('split')=='validation'];seen=set();groups={}
 if {r['episode_id']for r in rows}!=set(expected):raise ValueError('all frozen validation episodes required; test excluded')
 for r in rows:
  eid=r['episode_id'];frame=r['frame_index'];identity=expected[eid]
  if type(frame)is not int or frame<0 or r['attempt_id']!=identity['attempt_id'] or r['native_episode_index']!=identity['native_episode_index']:raise ValueError('original validation identities mismatch')
  if (eid,frame)in seen:raise ValueError('duplicate validation frame')
  seen.add((eid,frame));groups.setdefault(eid,set()).add(frame)
  for k in ('state','action'):
   if not isinstance(r.get(k),list)or len(r[k])!=12 or any(not finite(v)for v in r[k]):raise ValueError('12 finite native values required; no bool')
 for eid,indices in groups.items():
  length=view.get('episode_lengths',{}).get(eid)
  if not positive(length)or indices!=set(range(length))or not text(view.get('episode_length_sources',{}).get(eid)):raise ValueError('complete validation frames and true episode length evidence required')
 return sorted(rows,key=lambda r:(r['episode_id'],r['frame_index']))

def export(view_path,rule_path,manifest_path,artifact_root,checkout,output,device='cpu'):
 import numpy as np,torch
 from PIL import Image
 view_path=Path(view_path);view=read(view_path);rule=validate_rule(read(rule_path));manifest=read(manifest_path);root=local(artifact_root)
 verify_inventory(root,manifest['files'])
 if sha(view_path)!=rule['validation_view_sha256'] or manifest['dataset_source']['split_sha256']!=rule['split_sha256']or manifest['candidate_id']not in rule['candidates']:raise ValueError('rule/data/candidate binding mismatch')
 prov=(root/manifest['pretrained_dir']).parent/'provenance';split=read(prov/'original-splits.json')
 if sha(prov/'original-splits.json')!=rule['split_sha256']:raise ValueError('original split digest mismatch')
 rows=validation_rows(view,split)
 if view['source_kind']=='learner_recording' and manifest.get('source_kind')!='learner_recording':raise ValueError('learner predictions require a learner-trained candidate')
 rt=load_runtime(root/manifest['pretrained_dir'],checkout,device,model_manifest=manifest_path,artifact_root=root)
 contract=view['image_contract']
 if contract.get('color_order')!='RGB'or contract.get('camera_names')!=['front','overhead']:raise ValueError('RGB two-camera contract required')
 pairs=[];traces=[];last_episode=None
 for r in rows:
  if r['episode_id']!=last_episode:rt.reset();last_episode=r['episode_id']
  obs={'observation.state':torch.tensor(r['state'],dtype=torch.float32)};images={}
  for cam,key in zip(['front','overhead'],CAMERAS):
   path=child(view_path.parent,r['cameras'][cam])
   if sha(path)!=r.get('image_sha256',{}).get(cam):raise ValueError('current image digest mismatch')
   with Image.open(path) as im:
    if im.mode!='RGB'or list(im.size)!=contract['original_wh'][cam]:raise ValueError('raw image dimensions/color changed')
    obs[key]=torch.from_numpy(np.array(im,dtype=np.float32).transpose(2,0,1).copy()/255)
   images[cam]={'path':r['cameras'][cam],'sha256':sha(path)}
  predicted=rt.predict_chunk(obs)[0].tolist()  # no label passed to the model
  # Target is read for comparison only AFTER the observation-only call returns.
  for j,joint in enumerate(FIELDS):pairs.append({'episode_id':r['episode_id'],'frame_index':r['frame_index'],'joint':joint,'unit':UNITS[j],'target':r['action'][j],'prediction':predicted[j]})
  traces.append({'episode_id':r['episode_id'],'attempt_id':r['attempt_id'],'frame_index':r['frame_index'],'image_files':images,'prediction_offset':0})
 report={'schema':'aloha.offline-action-pairs.v1','purpose':'development','source_kind':'learner_prediction'if view['source_kind']=='learner_recording'else'synthetic_fixture','dataset_source':view['dataset_source'],'model_manifest_sha256':sha(manifest_path),'validation_view_sha256':sha(view_path),'selection_rule_sha256':sha(rule_path),'candidate_id':manifest['candidate_id'],'training_step':manifest['training_step'],'split_sha256':rule['split_sha256'],'rows':pairs,'input_trace':traces,'metric':score_rows(pairs,rule['joint_scales']),'inference':'eval mode; zero latent; current observation only; first chunk element; saved normalization and denormalization','physical_execution':False,'task_success_claimed':False}
 write_new(output,report);return report
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for k in ('view','rule','manifest','artifact_root','checkout','output'):p.add_argument(k)
 p.add_argument('--device',choices=['cpu','cuda'],default='cpu');a=p.parse_args();export(a.view,a.rule,a.manifest,a.artifact_root,a.checkout,a.output,a.device)
