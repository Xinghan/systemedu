# M38：从本人训练数据得到一行可手算预测

使用完整课程实践包的 `lessons/` 目录，保留 M35、M37、M38 三节的相对位置。Python 使用 M05 已核对的版本；本节脚本只用标准库，不连接机器人。M35 的教学视图不含图像，不替代后续 ACT 的原始数据集。

在实践包根目录运行。把 `/path/to/my-data-package` 换成本人 M35 包的真实路径；`work/` 是自己新建的结果目录：

```sh
mkdir -p work
python3 lessons/M37/code/normalize.py /path/to/my-data-package --out work/normalization.json
python3 lessons/M38/code/make_slice.py /path/to/my-data-package work/normalization.json --field left_shoulder_pan.pos --out work/my-slice.json
python3 lessons/M38/code/scalar_predictor.py work/my-slice.json --weight 0.5 --bias 0.1 --out work/prediction-v1.json
python3 lessons/M38/code/scalar_predictor.py work/my-slice.json --weight 0.6 --bias 0.1 --out work/prediction-v2.json
```

`make_slice.py` 可加 `--episode` 后跟本人训练回合的完整 `episode_id`，不得猜编号。省略时保留全部训练回合。它先复算保存的训练统计，确认来源摘要和字段顺序，再取指定通道；不读取测试划分用于学习。每行保留原数、标准化数、来源键和“复制当前原始状态”的比较值。输入尺与目标尺可不同，比较值在目标尺上计算。

所有输出使用新文件名，已有文件会报错。别删除校验来绕过报错。`--allow-synthetic` 只给合成测试夹具使用，输出来源仍为 synthetic；不把它冒充本人作业。

手算挑一行：`weighted_input = weight × x`，再加 bias 得 prediction。同一组输入、参数与程序应在小数舍入容差内一致。这里初始参数由你选择，程序没有自动训练。目标是 teleop 处理后的上游目标，不是驱动返回或实测位置。
