import copy,json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import optimizers as opt,minibatch
from backprop import loss_gradient
from relu_network import worked_example
class OptimizerTests(unittest.TestCase):
 def test_first_step(self):
  table=opt.worked_table();self.assertAlmostEqual(table[0]['steps'][0]['new'],.8);self.assertAlmostEqual(table[1]['steps'][0]['new'],1-.1*2/2.01);self.assertAlmostEqual(table[2]['steps'][0]['new'],.99-.1*2/2.01)
 def test_three_step_memory(self):
  rows=opt.worked_table()[2]['steps'];self.assertEqual(rows[0]['first_moment'],1);self.assertEqual(rows[0]['second_moment'],2);self.assertEqual(rows[1]['first_moment'],0);self.assertEqual(rows[1]['second_moment'],1.5);self.assertEqual(rows[1]['adaptive_change'],0);self.assertGreater(rows[1]['decay_change'],0);self.assertAlmostEqual(rows[2]['bias_corrected_first'],4/7);self.assertAlmostEqual(rows[2]['bias_corrected_second'],10/7)
 def test_decoupled_not_gradient_l2(self):
  adam=opt.configuration('adam',.1,.5,.5,.01);wrong=opt.scalar_update(1,2+.1,0,0,1,adam)['new'];right=opt.worked_table()[2]['steps'][0]['new'];self.assertGreater(abs(wrong-right),.009)
 def test_update_does_not_mutate(self):
  model=worked_example();state=opt.initialize(model,opt.configuration('adamw'));old=copy.deepcopy((model,state));gradient=loss_gradient([{'x':[2,-1],'y':[1.3,.75]}],model)['gradient'];new,s,t=opt.update(model,gradient,state);self.assertEqual((model,state),old);self.assertEqual(s['step'],1);self.assertNotEqual(new,model)
 def test_resume_exact(self):
  model=worked_example();state=opt.initialize(model,opt.configuration('adamw',.01,weight_decay=.1));rows=[{'x':[2,-1],'y':[1.3,.75]}]
  for _ in range(2):model,state,_=opt.update(model,loss_gradient(rows,model)['gradient'],state)
  saved=json.loads(json.dumps([model,state]));a,sa,_=opt.update(model,loss_gradient(rows,model)['gradient'],state);b,sb,_=opt.update(saved[0],loss_gradient(rows,saved[0])['gradient'],saved[1]);self.assertEqual((a,sa),(b,sb))
 def test_reset_memory_changes_path(self):
  c=opt.configuration('adamw',.1,.5,.5,.01,.1);r1=opt.scalar_update(1,2,0,0,1,c);continued=opt.scalar_update(r1['new'],-1,r1['first_moment'],r1['second_moment'],2,c);restarted=opt.scalar_update(r1['new'],-1,0,0,1,c);self.assertNotEqual(continued['new'],restarted['new'])
 def test_invalid_hyperparameters(self):
  for kwargs in ({'lr':0},{'beta1':1},{'beta2':-1},{'epsilon':0},{'weight_decay':.1},{'lr':True}):
   with self.assertRaises(ValueError):opt.configuration(**kwargs)
class SamplerTests(unittest.TestCase):
 def test_last_small_batch(self):
  state=minibatch.initialize(5,2,17);seen=[]
  for expected in (2,2,1):
   idx,state,meta=minibatch.next_batch(state);seen+=idx;self.assertEqual(len(idx),expected)
  self.assertEqual(sorted(seen),list(range(5)))
 def test_resume_cursor(self):
  state=minibatch.initialize(5,2,17);_,state,_=minibatch.next_batch(state);saved=json.loads(json.dumps(state));self.assertEqual(minibatch.next_batch(state),minibatch.next_batch(saved))
 def test_corrupt_permutation(self):
  s=minibatch.initialize(5,2);s['order'][0]=s['order'][1]
  with self.assertRaises(ValueError):minibatch.next_batch(s)
if __name__=='__main__':unittest.main()
