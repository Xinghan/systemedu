import unittest,tempfile,copy,json
from pathlib import Path
from data_package import load,validate_rows,SEMANTICS,FIELDS
from export_native import extract,write_new
N=FIELDS
C=dict(provenance='synthetic',hardware_revision='synthetic',dataset_source='synthetic:no-native-files',split_policy='synthetic whole episodes',joint_names=N,action_semantics=SEMANTICS,episodes={'0':{'episode_id':'e0','attempt_id':'a0','split':'train'},'1':{'episode_id':'e1','attempt_id':'a1','split':'validation'}})
class Fake:
 features={k:{'names':list(reversed(N))} for k in ('observation.state','action')}
 def __len__(self):return 4
 def __getitem__(self,i):return {'episode_index':i//2,'frame_index':i%2,'observation.state':list(range(12)),'action':list(range(12))}
class PackageTests(unittest.TestCase):
 def test_name_based_order(self):self.assertEqual(extract(Fake(),C)[0]['action'],list(reversed(range(12))))
 def test_roundtrip_and_default_synthetic_rejection(self):
  with tempfile.TemporaryDirectory() as d:
   out=Path(d)/'pack';write_new(out,extract(Fake(),C),C)
   with self.assertRaises(ValueError):load(out)
   m,r=load(out,allow_synthetic=True);self.assertEqual(len(r),2);self.assertFalse(m['image_pixels_exported'])
 def test_test_never_exposed(self):
  c=copy.deepcopy(C);c['episodes']['1']['split']='test'
  with self.assertRaises(ValueError):extract(Fake(),c)
 def test_contract_order_rejected(self):
  c=copy.deepcopy(C);c['joint_names']=N[::-1]
  with self.assertRaises(ValueError):extract(Fake(),c)
 def test_wrong_feature_set(self):
  f=Fake();f.features={'observation.state':{'names':['bad']*12},'action':{'names':N}}
  with self.assertRaises(ValueError):extract(f,C)
 def test_wrong_semantics(self):
  c=copy.deepcopy(C);c['action_semantics']='driver_returned_sent_action'
  with self.assertRaises(ValueError):extract(Fake(),c)
 def test_mutated_hash(self):
  with tempfile.TemporaryDirectory() as d:
   out=Path(d)/'pack';write_new(out,extract(Fake(),C),C);p=out/'data/frames.jsonl';p.write_text(p.read_text()+'\n')
   with self.assertRaisesRegex(ValueError,'digest'):load(out,allow_synthetic=True)
 def test_gap_and_nonfinite(self):
  rows=extract(Fake(),C);rows[1]['frame_index']=3;rows[0]['action'][0]=float('nan');self.assertGreaterEqual(len(validate_rows(rows)),2)
 def test_no_overwrite(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaisesRegex(ValueError,'new directory'):write_new(d,extract(Fake(),C),C)
if __name__=='__main__':unittest.main()
