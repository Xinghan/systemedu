# M67：把预算建立在实际短基准上

从[课程实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)解压，以下命令在实践包根目录执行。只运行Python标准库的预算示例不需要LeRobot；真实benchmark需要按 `docs/ENVIRONMENT.zh.md` 安装固定完整环境，使用你激活环境中的 `python`。四节点代码必须保留 `lessons/M67..M70/code` 的相邻目录关系。

## 先运行透明示例

```sh
python lessons/M67/code/resource_budget.py lessons/M67/code/measurement.synthetic.json lessons/M67/code/budget.synthetic.json budget-demo.json
```

预期 `estimated_required_seconds` 为700，时间、内存、存储和示例预约布尔项为true，`source_kind=synthetic_fixture`。这是虚构候选，用于复算；没有测量你的电脑，也没有真实预约。完整预期在 `expected.synthetic.json`。再次运行须换新输出名，防止覆盖证据。

## 准备真正的数据和配置

1. 完成M33整回合划分与M34/M47原生数据审计；先按M68的README导出物理train-only原生子集。它必须有自己的 `meta/info.json`、`meta/stats.json`，不能把含validation的数据统计复制过来。
2. 复制 `training_request.example.json` 为本人的 `training-request.json`，逐项替换所有REPLACE和示例路径。`checkout`是固定源码目录，`dataset.root`是实际train子集，`split_manifest`是原始M33划分，`split_sha256`填该文件的SHA256；`original_train_indices`填原始train索引；写下实际核对过的原回合到子集回合映射与统计来源。
3. 保留原生12通道顺序、每臂五个degree及一个percent_0_100。`source_kind`应如实填learner_recording或synthetic_fixture。确认两路图像实际尺寸；本工具不偷偷缩成机制例的32像素。
4. batch、chunk与模型宽度由本次实际候选决定，模板值不是推荐性能承诺。CPU可预检；正式GPU预算必须在目标GPU上重测。所有脚本不连接机器人。

```sh
python lessons/M67/code/benchmark.py training-request.json benchmark-a.json
```

预期成功有 `status=measured`、实际样本、三段时长、权重/梯度/优化器字节及设备信息。CUDA峰值与剩余空间只在CUDA运行时有数；CPU对应字段为null。失败写入 `status=failed` 与异常，保留该文件。至少2步预热、3步正式测量；权重随短基准丢弃，不能当M68成品。

## 从实际报告生成资源计划

复制 `budget.synthetic.json` 成新计划，将candidate_id、request_sha256改成实际报告；填写剩余微批步数、可用时长、另外测量或保守估计的启动/保存/验证成本、余量、设备内存预算、存储估计与真实导师预约结果。随后用实际benchmark替代示例重跑预算命令。内存不足或CPU未知时不能把规划通过当GPU容量结论。

时间估计是同配置短样本的90百分位乘剩余步数，再加费用和余量，不是最坏情况上界。改变batch、图像派生版本、块长、精度或网络结构都要生成新请求并实测。串行任务时长相加、峰值取最大；并发作业不适用本规则。浏览器P4只是可保存的规划，不产生训练和预约事实。

## 验证范围

根作者已在固定完整LeRobot上跑过明确synthetic的CPU、image-backed原生小数据短基准。课程没有因此声称视频解码、GPU容量或本人真实数据训练已经完成。`test_contracts.py`是文件与数值负例，运行 `python lessons/M67/code/test_contracts.py`；测试使用合成档案，不替代真实benchmark。
