# M06：离线目标函数

复用M05的Python 3.12环境。下面 `python` 替换为该环境内解释器的实际路径。代码默认左肩增加5；学生任务是改为3，并核对只有预定字段改变。输入与输出的练习范围不构成硬件安全限位。

```text
python controller.py channels-example.json --output normal-v1.json
python -m unittest test_controller.py
```

样例跑通后换本人输入，另存缺失字段、错单位和左肩29三个副本；每次使用新输出名。拒绝不写新目标，磁盘旧文件不能代表本次成功。测试显式传入步长3，所以默认常量修改还须由第一条命令验证。

`map_targets(data,field,step)`返回含input、output、changed_fields的记录，mode始终dry_run，hardware_output为false。本节点不发送串口或网络消息，不连接实体驱动。
