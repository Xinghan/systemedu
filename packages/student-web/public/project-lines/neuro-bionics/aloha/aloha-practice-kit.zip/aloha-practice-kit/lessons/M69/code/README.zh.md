# M69：无未来标签的完整验证与冻结

从[实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)根执行；保留M67–70相邻目录，激活固定完整LeRobot环境。所有操作离线，不连接硬件。输入来自本人M68真实权重与M47原生图像教学视图，M35低维JSONL不能充当图像数据。

## 先冻结比较规则

复制 `selection_rule.example.json`，填实际validation_view_path及SHA、M33原始split路径及SHA、所有候选ID和计划checkpoint总步数、带时区的预先登记时间。逐关节12个尺度必须为正，解释物理单位和选择理由；示例全1不代表硬件限位。规则是在看到本轮比较结果前写下的约定，文件检查不能证明你真的预先登记，导师需保存时间与使用历史。

M47视图必须包含冻结的**全部validation回合**，每个回合有实际episode_length及来源说明、连续0到length−1的原生frame_index、attempt_id、原始episode_id、双图SHA与原生state/action。两候选同时漏掉困难帧也会被拒绝。封存test不能参与。

## 注册每个真实检查点

```sh
python lessons/M69/code/register_candidate.py /ABS/run/checkpoints/ACTUAL/pretrained_model training-request.json receipt-run1 /ABS/artifacts candidate-step200
```

所有ABS、ACTUAL与候选ID须替换。工具绑定成功运行receipt、真实步数、训练请求、原始split、info/stats和所有保存模型/处理器文件，再复制到共同artifacts根。不是用手写manifest给任意权重发通行证。续训产物须使用新receipt中的training-request.json与对应receipt。

## 用唯一推理桥产生配对表

```sh
python lessons/M69/code/export_predictions.py /ABS/validation-view.json selection-rule.json /ABS/artifacts/candidate-step200/model_manifest.json /ABS/artifacts /ABS/lerobot pairs-step200.json --device cpu
python lessons/M69/code/export_predictions.py /ABS/validation-view.json selection-rule.json /ABS/artifacts/candidate-step400/model_manifest.json /ABS/artifacts /ABS/lerobot pairs-step400.json --device cpu
python lessons/M69/code/select_candidate.py selection-rule.json selection.json pairs-step200.json pairs-step400.json
```

视图路径依实际M47导出设置，图像相对路径按其视图根解析；工具校验实际SHA、颜色、尺寸、字段与来源。每帧向Runtime只传当前两图和state，走eval、零潜变量；调用后才配对原生target。保存的postprocessor还原原生degree/percent_0_100，每帧只评分块的第0项，不把未来整块重复计数。

指标为各项绝对误差除预先尺度，先在完整回合内求均值，再将各回合等权平均。示意A的回合误差2、0得到1，B的0.8、0.8得到0.8，选B；这不是本人得分。并列先选较低训练步数，再按候选ID排序。所有候选都须提交，选择器从逐行数据重算，拒绝缺帧、改target、单位或摘要不一致与非有限计算。

## 桥接口与交付边界

`act_runtime.load_runtime(pretrained_dir, checkout, device='cpu', model_manifest=..., artifact_root=...)`严格加载保存权重/处理器；`predict_chunk(observation)`返回CPU块长×12；`reset()`清历史；`select_action(observation)`返回CPU12。`profile_action(observation)`走相同选择路径并返回预处理/推理选择/后处理分段时间与实际model_calls；队列命中时模型调用可以是0，不能把它称一次完整神经前向。输入只能有state及两图，没有action。

输出schema `aloha.offline-action-pairs.v1`供M73复用；同一model_manifest SHA绑定后续网关。selected结果交M70，但原生目标误差不是tracking error，也不能换算成任务成功率。模型卡至少记录版本、数据角色、全部候选、规则、原生单位、选中摘要、未验证GPU/视频/实机等范围。
