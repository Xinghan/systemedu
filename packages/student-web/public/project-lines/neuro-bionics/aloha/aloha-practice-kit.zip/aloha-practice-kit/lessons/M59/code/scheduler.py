"""Offline state-machine scheduler. Explicit teaching failure latch is NOT a driver safety guarantee."""
import argparse,copy,json,math
from pathlib import Path
class ProtocolError(ValueError):pass
class Scheduler:
    def __init__(self,chunk_size,n_action_steps,mode='queue',coefficient=.01,max_observation_age_s=.5):
        if type(chunk_size) is not int or type(n_action_steps) is not int or not 1<=n_action_steps<=chunk_size or mode not in ('queue','ensemble') or (mode=='ensemble' and n_action_steps!=1):raise ValueError('Incompatible mode/chunk/action-steps')
        if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in [coefficient,max_observation_age_s]) or max_observation_age_s<=0:raise ValueError('Finite coefficient and positive age limit required')
        self.k,self.n,self.mode,self.coefficient,self.max_age=chunk_size,n_action_steps,mode,coefficient,max_observation_age_s
        self.episode=-1;self.time=-math.inf;self.reset()
    def reset(self):
        self.episode+=1;self.step=0;self.queue=[];self.history=[];self.observation=None;self.predicted_this_step=False;self.latched=False;self.width=None;self.last_prediction_observation=None
    def event(self,event):
        try:return self._event(event)
        except (KeyError,TypeError,ValueError) as exc:self.latched=True;raise ProtocolError(str(exc)) from exc
    def _event(self,event):
        op=event['op'];now=event['at_s']
        if not isinstance(now,(int,float)) or isinstance(now,bool) or not math.isfinite(now) or now<self.time:raise ProtocolError('Host event time cannot rewind')
        self.time=now
        if op=='reset':self.reset();return {'event':'reset','episode':self.episode,'queue_size':0,'history_size':0}
        if self.latched:raise ProtocolError('Protocol latched; reset after diagnosing failure')
        if op=='observe':
            if self.observation is not None and now<=self.observation:raise ProtocolError('Fresh observation must have a later arrival')
            self.observation=now;return {'event':'observe','episode':self.episode,'step':self.step,'arrival':now}
        if op=='predict':
            if self.observation is None or now-self.observation>self.max_age:raise ProtocolError('No sufficiently recent observation')
            if self.predicted_this_step or (self.mode=='queue' and self.queue):raise ProtocolError('Prediction would overwrite unconsumed queue or duplicate the step')
            actions=event['actions'];width=len(actions[0]) if actions else 0
            if len(actions)!=self.k or not width or any(len(row)!=width or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in row) for row in actions):raise ProtocolError('Finite chunk_size × action_dim required')
            if self.width is not None and width!=self.width:raise ProtocolError('Action width changed within an episode')
            self.width=width
            if self.mode=='ensemble' and self.last_prediction_observation is not None and self.observation<=self.last_prediction_observation:raise ProtocolError('Ensemble mode requires a new observation for each prediction')
            item={'origin':self.step,'observation':self.observation,'arrived':now,'actions':copy.deepcopy(actions)}
            self.last_prediction_observation=self.observation
            self.history.append(item)
            if self.mode=='queue':self.queue=[{'target':self.step+i,'value':row.copy(),'origin':self.step,'observation':self.observation} for i,row in enumerate(actions[:self.n])]
            self.predicted_this_step=True;return {'event':'predict','episode':self.episode,'origin':self.step,'target_indices':list(range(self.step,self.step+self.k))}
        if op!='consume':raise ProtocolError('Unknown operation')
        if self.mode=='queue':
            if not self.queue:raise ProtocolError('Missing chunk')
            row=self.queue[0]
            if row['target']!=self.step or now-row['observation']>self.max_age:raise ProtocolError('Missing index or stale prediction')
            self.queue.pop(0);out=row['value'];origins=[row['origin']];weights=[1.]
        else:
            if not self.predicted_this_step:raise ProtocolError('Ensemble requires a new chunk every consumed step')
            rows=[r for r in self.history if 0<=self.step-r['origin']<self.k]
            if any(now-r['observation']>self.max_age for r in rows):raise ProtocolError('Stale overlapping prediction')
            raw_scores=[-self.coefficient*i for i in range(len(rows))];top=max(raw_scores);raw=[math.exp(s-top) for s in raw_scores];weights=[v/sum(raw) for v in raw]
            out=[sum(w*r['actions'][self.step-r['origin']][j] for w,r in zip(weights,rows)) for j in range(self.width)];origins=[r['origin'] for r in rows]
        result={'event':'consume','episode':self.episode,'target':self.step,'action':out,'origin_indices':origins,'weights':weights}
        self.step+=1;self.predicted_this_step=False;self.history=[r for r in self.history if r['origin']+self.k>self.step]
        return result
def run(data):
    if data.get('provenance') not in ('synthetic','learner_model_output'):raise ValueError('Declare source provenance')
    state=Scheduler(**data['config']);log=[]
    for i,event in enumerate(data['events']):
        try:log.append({'event_index':i,'status':'ok',**state.event(event)})
        except ProtocolError as e:log.append({'event_index':i,'status':'rejected','reason':str(e)})
    return {'provenance':data['provenance'],'hardware_executed':False,'log':log,'boundary':'Teaching protocol rejects stale/missing work. Pinned ACT does not implement these host-time checks itself. Real runtime must use an actually integrated execution gateway and tested stop path.'}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);a=p.parse_args();print(json.dumps(run(json.loads(a.input.read_text())),ensure_ascii=False,indent=2,allow_nan=False))
