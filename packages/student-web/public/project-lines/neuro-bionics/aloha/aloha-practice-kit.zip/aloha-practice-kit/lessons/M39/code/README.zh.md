# M39：逐行与十二通道账单

在实践包根目录运行，保留 `lessons/M35`、`M37`、`M38`、`M39` 的相对位置。输入使用上一节的本人文件，不更改原始数据：

```sh
python3 lessons/M39/code/loss_ledger.py work/prediction-v1.json --out work/loss-v1.json
python3 lessons/M39/code/joint_ledger.py /path/to/my-data-package work/normalization.json work/prediction-v1.json --out work/joints-v1.json
```

第一条命令的 `denominator` 是样本行数。查每行 signed/absolute/squared error，统一为预测减目标；MSE不乘二分之一。

第二条命令目前只有 M38 指定通道来自乘加预测，其余十一通道复制当前原始实测值，明确标为 `copy current observed state; no learned model`。这是逐通道基线账单，绝不是十二关节网络已训练。原始误差分别按每个通道自己的单位报告；总损失仅对目标标准化误差按等帧、等通道计算。夹爪归一化量不改名为度或毫米。

脚本重新检查 M35 来源摘要、M37 训练统计和预测的统计摘要。一个标量切片即便只取一个回合，也必须能按回合、尝试、帧号找回原始训练行。缺失、重复或摘要不符会拒绝，不允许为了报表好看补零。所有结果只在离线文件中，不连接实物。

合成测试夹具须显式 `--allow-synthetic`，来源仍保留 synthetic。实际作业用本人记录且不加该参数。已有输出文件不能覆盖，另存新版本；更正原始标签必须回数据阶段保留修改原因。
