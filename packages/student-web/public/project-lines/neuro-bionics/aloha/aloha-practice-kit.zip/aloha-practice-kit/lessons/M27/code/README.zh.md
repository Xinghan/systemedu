# M27 旁路挂接的可运行小夹具

下载[实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)，进入 `lessons/M27/code/`，运行 `python3 offline_tap.py --kit ../../.. --output synthetic-attempt.jsonl`。输出文件必须不存在。使用标准库和包根的真实 `recording_sidecar.py`，无机器人连接。

预期JSONL有开始、两帧、关闭共4行。第一帧每字段：raw为30、teleop processor为30、robot processor为28、driver returned为22、observed为20；第二帧前三项为31、31、29，而返回22、观测20。名义timestamp为0和1/30秒。主机单调时间与随机attempt_id每次不同，不能写死比较。结束状态为discarded，原因说明这是没有原生数据集的synthetic夹具，不能冒称saved。

夹具是**演示挂接位置**，不是已经修改好的LeRobot记录程序。实际接入必须阅读包内 `docs/SIDECAR_INTEGRATION.zh.md` 和固定revision源文件，按讲义在get_observation返回、两个processor之间、send_action返回和add_frame成功后真正埋点。复制所需12个标准关节字段，而不是整份包含图像的观测；在processor可能修改对象之前做独立快照。

真实记录需要自行创建learner_recording来源、冻结episode_index、成功add_frame后使用writer buffer大小减1确定frame_index；保存成功才以真实数据集引用close saved，重录新attempt_id，失败/丢弃/中断仍保留。不录数据的reset循环不混进这一回合。仅创建RecordingSidecar对象不会自动采集任何调用；get_observation返回时间也不能冒充曝光时间。

离线夹具通过只证明字段机制与文件生命周期，真实源码挂接、相机共同事件与实际采集仍要学生完成并验收。文件存在时拒绝覆盖，保护原始尝试。
