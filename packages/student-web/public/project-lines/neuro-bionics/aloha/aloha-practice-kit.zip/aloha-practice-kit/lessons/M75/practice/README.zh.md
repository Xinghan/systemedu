# M75 实际输入、操作与恢复

从解压后的实践包根目录运行；保留 lessons/M73–M78 的相邻目录，入口通过同包相对路径复用 M74 的唯一审核。Python 3.12 标准库足够运行本批证据/统计工具；真实 ACT 的加载、处理器与设备环境仍沿用 M69–M72 固定实现，不能用本批轻量环境替代。

所有输出新建、不覆盖。空白模板只说明输入字段，不能直接充当真实成绩。synthetic 仅软件夹具，永不性能达标；learner_recording 是来源声明，摘要一致不认证现场真实性。保存整个证据根目录，相对路径随包移动。单独拷贝一个Python文件会丢失跨节点审核依赖。

## 开始与结束书挡

现场设备驱动仍由M72唯一网关承担；本工具没有电机命令。先完成教师现场停止验证，再照冻结首项运行：

```sh
python lessons/M75/code/run_record.py start work/evidence/plan.json --root work/evidence --trial REAL_NEXT_ID --purpose evaluation --operator LOCAL_CODE
```

保存输出start.json路径；将其中run_id、trial_id和observed_versions交给M72日志导出器，按gateway-log-v1合同保留完整原生事件。正常结束也留下真实latched，监督者实际填写停止观察，不能由程序替填。

复制outcome.template.json按真实录像与观察填写，时间带时区。state completed/failed/intervention/estop是不同结果，介入事件offset_s以实际起点秒数记录。自动锁停可无人工事件但不成功。evidence-list.template.json内替换本次视频、日志和唯一观察表路径，再运行：

```sh
python lessons/M75/code/run_record.py close work/evidence/runs/REAL_RUN/start.json --root work/evidence --outcome work/evidence/runs/REAL_RUN/outcome.json --evidence-list work/evidence/runs/REAL_RUN/evidence-list.json
```

实际SHA由程序计算。缺证据、版本更改或日志内容不合格尽可能保留closed中的错误，审核会incomplete；不能覆写或复用同编号重拍成功。Python API start_run(...,purpose=...,operator=...) / close_run(...,evidence_paths=[{kind,path,description}])供M80/81复用。domain_challenge还必须传context_plan_path或CLI --context-plan绑定M78方案。
