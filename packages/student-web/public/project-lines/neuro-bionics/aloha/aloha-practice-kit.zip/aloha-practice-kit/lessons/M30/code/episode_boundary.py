"""Check an exported episode index. Does not parse videos or command devices."""
import argparse,json

def validate(d):
    errors=[]
    for name in ('begin','end_exclusive','total_frames'):
        if type(d.get(name)) is not int or d[name]<0:errors.append(name+' must be a nonnegative integer')
    if errors:return {'valid':False,'errors':errors,'physical_authenticity_verified':False}
    b,e,n=d['begin'],d['end_exclusive'],d['total_frames']
    if not 0<=b<e<=n:errors.append('expected 0 <= begin < end_exclusive <= total_frames')
    if type(d.get('declared_count')) is not int or d['declared_count']!=e-b:errors.append('declared_count does not equal end_exclusive - begin')
    if not isinstance(d.get('attempt_id'),str) or not d['attempt_id'].strip():errors.append('missing attempt_id')
    if d.get('provenance') not in ('synthetic','learner_recording'):errors.append('unknown provenance')
    if not isinstance(d.get('source_ref'),str) or not d['source_ref'].strip():errors.append('missing source_ref')
    if d.get('end_reason') not in ('success','timeout','intervention','stop','failure'):errors.append('unknown end_reason')
    r=d.get('reset_begin')
    if r is not None and (type(r) is not int or r<e or r>n):errors.append('reset_begin must be outside the task interval and within source bounds')
    if d.get('index_space')!='exported_source_sequence':errors.append('declare the source coordinate system')
    return {'valid':not errors,'errors':errors,'count':e-b,'last_included':e-1,'reset_separated':r is None or r>=e,'provenance':d.get('provenance'),'physical_authenticity_verified':False,'video_decoded':False,'hardware_executed':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('index');a=p.parse_args()
    result=validate(json.loads(open(a.index).read()));print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['valid'] else 1)
