// Original removable contact plate; mm. Measure actual interface on your print.
pad_width=undef;
pad_length=undef;
pad_thickness=3;
// Hole centres in local coordinates measured from lower-left corner, e.g. [[x1,y1],[x2,y2]].
hole_centres=undef;
// Derived from your printed fit coupon, not from nominal screw size alone.
tested_hole_d=undef;
minimum_edge_material=2;
$fn=64;
assert(!is_undef(pad_width) && pad_width>0,"Input measured pad_width");
assert(!is_undef(pad_length) && pad_length>0,"Input measured pad_length");
assert(!is_undef(hole_centres) && len(hole_centres)>0,"Input actual measured hole_centres");
assert(!is_undef(tested_hole_d) && tested_hole_d>0,"Input coupon-tested hole diameter");
assert(pad_thickness>0);
for(p=hole_centres) {
    assert(len(p)==2);
    assert(p[0]-tested_hole_d/2>=minimum_edge_material && pad_width-p[0]-tested_hole_d/2>=minimum_edge_material);
    assert(p[1]-tested_hole_d/2>=minimum_edge_material && pad_length-p[1]-tested_hole_d/2>=minimum_edge_material);
}
difference() {
    cube([pad_width,pad_length,pad_thickness]);
    for(p=hole_centres)translate([p[0],p[1],-1])cylinder(h=pad_thickness+2,d=tested_hole_d);
}
// v1 flat pad. Change the contact surface only after checking jaw travel and screw protrusion.
