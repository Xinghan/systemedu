> Module: M05 · hands_on
>
> ### 这一步在通向哪 (北极星)
>
> **我们最终要做出的**: 用本人示范训练一套3D打印双臂，让左手稳住托盘、右手放入插块，并用保留的独立试次检验它。
>
> **这一节你亲手做出的那块积木**: 能在新终端重跑的配置读取程序、日志和环境清单。
>
> **它通向**: 自己修改离线控制器，以及后续数据和训练环境。
>
> **离终点还差几步**: 先完成软件接口，再制造、示范、学习与真实验收。

# 搭好能复现的离线程序环境

## 今天让自己的文件被程序读懂
同一个脚本在新终端突然不能运行，怎样查清它需要哪一个解释器、文件和依赖版本？M03已有十二通道表，M04已有工作区图。今天的成果不是电机动起来，而是你改过的表被程序准确读出；关掉终端后仍能重现，才算掌握了启动方式。

从{{aloha_practice_kit}}下载并解压实践包，查看中文README。包内lessons/M05/code目录提供read_config.py、fingerprint.py和channels-example.json。把三者放入自己命名的工作文件夹，另存本人字段表为channels-mine.json。保留原样例，别把附件内容直接称为本人完成。文件与执行中的程序不是一回事。[[THEORY:m05_t1]]

## 选定解释器，建立独立环境
请导师确认本机有Python 3.12；暂未准备时，按{{python_downloads}}的本机平台说明安装，由导师处理系统权限。只读对应平台这一支。Windows在文件夹地址栏输入powershell打开终端；macOS或Linux打开终端后，用cd进入该文件夹，路径含空格时用引号。先检查版本：

```text
# macOS / Linux
python3.12 --version
python3.12 -m venv .venv
# Windows
py -3.12 --version
py -3.12 -m venv .venv
```

本节点只用Python标准库，没有需要另装的pip包；先不安装完整LeRobot和训练依赖。独立环境像给项目安排一只专用工具盒，记录的是实际使用的解释器，不能只凭桌面图标判断。[[THEORY:m05_t2]]

## 第一次运行，看见十二个字段
使用环境内解释器的完整相对路径，不依赖是否成功激活。下面选本机一支；命令中的脚本名和数据名必须与文件一致。

```text
# macOS / Linux
.venv/bin/python read_config.py channels-mine.json --output read-log.json
.venv/bin/python fingerprint.py > environment.json
# Windows
.venv\Scripts\python.exe read_config.py channels-mine.json --output read-log.json
.venv\Scripts\python.exe fingerprint.py > environment.json
```

打开read-log.json，找到field_count为12，再逐项看名字与单位。程序读得出十二项，还不代表目标合法或安全：本节读取器只做基础结构检查，M06将增加完整契约校验。日志中provenance仍是synthetic，mode是dry_run，程序没有设备接口。

## 改一个值，再找一条错误
将本人表中的left.shoulder_pan从0改为10，保存后重跑，输出应只在该字段反映修改。若结果没变，先检查是否保存、命令输入路径是否指向本人文件，不要随意重装环境。

然后把命令里的输入文件名故意写成不存在的channels-missing.json，保留REJECT错误。恢复正确名字重跑。文件不存在、JSON标点错误、缺少fields是不同原因；读取器会给错误信息，记录完整文本及触发步骤，不只写“电脑坏了”。[[IDEA:m05_animation]]

## 关掉窗口，独立重跑
保存环境清单、本人表、脚本及成功和失败日志。关闭终端，重新进入同一目录，再运行一次。比较两次解释器路径、输入路径和字段结果；新终端的当前目录可能变化，这是最常见的断点之一。

环境清单写实际Python版本与路径、操作系统、外部依赖为空，以及后续LeRobot固定提交b64fe1ed9f11eeac53ee821356d2797601701054。写下这个提交只是预先锁定课程来源，不代表你现在已安装它。

## 把第一次可复现成果带走
请同伴按你的启动说明找到日志中的一个字段。能从新终端重跑并解释一次故障，就拥有了自己的第一套可复现软件入口。若安装仍失败，把错误和平台交给导师，保留M03、M04已有作品，从版本检查处继续，不必重做整节。

下一节会把“能读文件”推进到“能验证输入并计算目标”。先保住今天的小成功，再增加函数和条件；不要因为看见日志而把无动力结果描述成机器人已经执行。
