#!/usr/bin/env python3
"""Prepare a tiny image-bearing ACT batch from M47's reviewed local teaching view.

The original native LeRobot dataset is still needed for full training in M68.
This adapter consumes explicit consecutive frames, not M35's imageless numeric view.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from PIL import Image
from act_step import validate_batch, CAMERAS, STATE, ACTION

JOINTS=["shoulder_pan","shoulder_lift","elbow_flex","wrist_flex","wrist_roll","gripper"]
VIEW_FIELDS=[f"{side}.{joint}" for side in ["left","right"] for joint in JOINTS]
ACT_FIELDS=[f"{side}_{joint}.pos" for side in ["left","right"] for joint in JOINTS]


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(view_path, request_path, output, allow_synthetic=False):
    view_path=Path(view_path);request_path=Path(request_path);output=Path(output)
    if output.exists():raise ValueError("output must be new")
    view=json.loads(view_path.read_text());request=json.loads(request_path.read_text())
    allowed=view.get("source_kind")=="learner_recording" or (allow_synthetic and view.get("source_kind")=="synthetic")
    if view.get("schema")!="aloha.vision-teaching-view.v1" or not allowed:
        raise ValueError("reviewed learner image teaching view required")
    if view.get("action_semantics")!="teleop_action_processor target":raise ValueError("wrong native action meaning")
    if view.get("state_fields")!=VIEW_FIELDS or view.get("action_fields")!=VIEW_FIELDS:
        raise ValueError("explicit ordered M47 field aliases required")
    contract=view["image_contract"]
    if contract.get("camera_names")!=["front","overhead"] or contract.get("color_order")!="RGB":
        raise ValueError("front/overhead RGB contract required")
    if not isinstance(request.get("split_ref"),str) or not request["split_ref"].strip() or "REPLACE" in request["split_ref"]:
        raise ValueError("frozen split reference required")
    lengths=view.get("episode_lengths",{});length_sources=view.get("episode_length_sources",{})
    if not lengths or set(lengths)!=set(length_sources) or any(not isinstance(v,str) or not v.strip() for v in length_sources.values()):
        raise ValueError("M47 view must preserve actual episode_lengths and episode_length_sources")
    k=request["chunk_size"]
    if type(k) is not int or not 1<=k<=100:raise ValueError("chunk_size must be 1..100")
    by_key={};partitions={};attempt_partitions={};episode_attempts={}
    for row in view["rows"]:
        eid=row["episode_id"];frame=row["frame_index"];split=row["split"]
        attempt=row.get('attempt_id')
        if not isinstance(eid,str) or not eid.strip() or not isinstance(attempt,str) or not attempt.strip():
            raise ValueError("nonempty string episode/attempt identities required")
        if type(frame) is not int or frame<0 or split not in ("train","validation"):
            raise ValueError("invalid frame or split")
        if eid in partitions and partitions[eid]!=split:raise ValueError("episode crosses splits")
        if attempt in attempt_partitions and attempt_partitions[attempt]!=split:raise ValueError("attempt crosses splits")
        if eid in episode_attempts and episode_attempts[eid]!=attempt:raise ValueError("episode changes attempt identity")
        attempt_partitions[attempt]=split;episode_attempts[eid]=attempt
        partitions[eid]=split
        if (eid,frame) in by_key:raise ValueError("duplicate frame")
        for name in ("state", "action"):
            values = row.get(name)
            if not isinstance(values, list) or len(values) != 12 or any(
                type(v) not in (int, float) or not math.isfinite(v) for v in values
            ):
                raise ValueError("twelve finite numeric values required; booleans are not joint measurements")
        by_key[eid,frame]=row
    train=[r for r in view["rows"] if r["split"]=="train"]
    if not train:raise ValueError("training view empty")
    stats={}
    for name in ("state","action"):
        a=np.asarray([r[name] for r in train],dtype=np.float32)
        if a.ndim!=2 or a.shape[1]!=12 or not np.isfinite(a).all():raise ValueError("bad training vectors")
        mean=a.mean(0);std=a.std(0);scale=np.where(std>1e-6,std,1)
        stats[name]={"mean":mean.tolist(),"raw_std":std.tolist(),"scale":scale.tolist()}
    arrays={STATE:[],ACTION:[],"action_is_pad":[],**{key:[] for key in CAMERAS}}
    traces=[];seen=set()
    for ask in request["samples"]:
        eid,start=ask["episode_id"],ask["start_frame_index"]
        if (eid,start) in seen:raise ValueError("duplicate requested sample")
        seen.add((eid,start))
        length=lengths.get(eid)
        if type(length) is not int or length<1 or type(start) is not int or not 0<=start<length:
            raise ValueError("invalid start/true native episode length")
        if partitions.get(eid)!="train":raise ValueError("update samples must come from train episodes")
        # A missing exported frame is NOT evidence of episode end.
        needed=list(range(start,min(start+k,length)))
        if any((eid,i) not in by_key for i in needed):raise ValueError("missing consecutive frame: re-export it, do not pad this gap")
        if any(e==eid and f>=length for e,f in by_key):raise ValueError("declared length contradicts exported frame")
        rows=[by_key[eid,i] for i in needed];current=rows[0]
        if not current.get("attempt_id") or any(r.get("attempt_id")!=current["attempt_id"] for r in rows):
            raise ValueError("attempt provenance missing or changed inside chunk")
        act=np.asarray([r["action"] for r in rows],dtype=np.float32)
        padded=np.concatenate([act,np.repeat(act[-1:],k-len(rows),axis=0)])
        arrays[ACTION].append((padded-stats["action"]["mean"])/stats["action"]["scale"])
        arrays[STATE].append((np.asarray(current["state"])-stats["state"]["mean"])/stats["state"]["scale"])
        arrays["action_is_pad"].append([False]*len(rows)+[True]*(k-len(rows)))
        refs={}
        for camera,key in zip(["front","overhead"],CAMERAS):
            path=(view_path.parent/current["cameras"][camera]).resolve()
            if digest(path)!=current.get("image_sha256",{}).get(camera):raise ValueError("image digest mismatch")
            with Image.open(path) as image:
                if image.mode!="RGB" or list(image.size)!=contract["original_wh"][camera]:raise ValueError("image color or raw shape changed")
                image=image.resize((32,32),Image.Resampling.BILINEAR)
                pixels=np.asarray(image,dtype=np.float32).transpose(2,0,1)/255
            arrays[key].append((pixels-np.array([.485,.456,.406])[:,None,None])/np.array([.229,.224,.225])[:,None,None])
            refs[key]=f"{path}#sha256={digest(path)}"
        traces.append({"episode_id":eid,"attempt_id":current["attempt_id"],"observation_frame_index":start,
            "target_frame_indices":needed+[None]*(k-len(rows)),"current_image_refs":refs})
    arrays={key:np.asarray(values,dtype=np.bool_ if key=="action_is_pad" else np.float32) for key,values in arrays.items()}
    preprocessing={"scope":"mechanism batch only, fit selected training view only; not official ACT processor state",
        "view_sha256":digest(view_path),"training_rows":len(train),"training_episodes":sorted({r["episode_id"] for r in train}),
        "state_action_stats":stats,"image_resize_wh":[32,32],"image_resample":"PIL bilinear",
        "image_mean":[.485,.456,.406],"image_std":[.229,.224,.225],
        "view_fields":VIEW_FIELDS,"ACT_fields":ACT_FIELDS,"alias_note":"same order; textual aliases explicitly converted"}
    manifest={"provenance":view["source_kind"],"source_ref":view["dataset_source"],
        "preprocessing_ref":"preprocessing.json","split":"train","split_ref":request["split_ref"],
        "state_field_names":ACT_FIELDS,"action_field_names":ACT_FIELDS,"trace":traces,
        "request_sha256":digest(request_path),"view_sha256":digest(view_path),
        "episode_lengths":lengths,"episode_length_sources":length_sources}
    validate_batch(arrays,manifest)
    output.mkdir(parents=True)
    np.savez(output/"batch.npz",**arrays)
    for name,data in [("manifest",manifest),("preprocessing",preprocessing),("request",request)]:
        (output/(name+".json")).write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")
    return manifest


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("view");p.add_argument("request");p.add_argument("output");p.add_argument("--allow-synthetic",action="store_true")
    a=p.parse_args();print(json.dumps(prepare(a.view,a.request,a.output,a.allow_synthetic),ensure_ascii=False,indent=2))
