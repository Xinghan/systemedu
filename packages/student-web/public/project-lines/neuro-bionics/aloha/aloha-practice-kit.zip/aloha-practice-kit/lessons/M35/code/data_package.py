"""Load the course's low-dimensional teaching export, not a native LeRobot replacement."""
import argparse,hashlib,json,math
from pathlib import Path
SEMANTICS='teleop_processor_action'
JOINTS=('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')
FIELDS=[f'{side}_{joint}.pos' for side in ('left','right') for joint in JOINTS]
UNITS=['degree']*5+['normalized_0_100']+['degree']*5+['normalized_0_100']
def valid_vector(value):return isinstance(value,list) and len(value)==12 and all(type(x) in (int,float) and math.isfinite(x) for x in value)
def validate_rows(rows):
 errors=[];seen=set();episodes={};last={}
 for i,r in enumerate(rows,1):
  for key in ('episode_id','attempt_id'):
   if not isinstance(r.get(key),str) or not r[key]:errors.append(f'line {i}: invalid {key}')
  if type(r.get('frame_index')) is not int or r['frame_index']<0:errors.append(f'line {i}: invalid frame_index')
  if r.get('split') not in ('train','validation','test'):errors.append(f'line {i}: invalid split')
  if r.get('action_semantics')!=SEMANTICS:errors.append(f'line {i}: wrong action semantics')
  for key in ('observation_state','action'):
   if not valid_vector(r.get(key)):errors.append(f'line {i}: {key} must be 12 finite numbers')
  identity=(r.get('episode_id'),r.get('frame_index'))
  if identity in seen:errors.append(f'line {i}: duplicate frame')
  seen.add(identity);eid=r.get('episode_id');role=r.get('split')
  if eid in episodes and episodes[eid]!=(role,r.get('attempt_id')):errors.append(f'line {i}: episode crosses roles or attempts')
  episodes[eid]=(role,r.get('attempt_id'))
  index=r.get('frame_index')
  if type(index) is int:
   if eid in last and index!=last[eid]+1:errors.append(f'line {i}: noncontiguous or reversed frame index')
   elif eid not in last and index!=0:errors.append(f'line {i}: episode must start at frame 0')
   last[eid]=index
 if not rows:errors.append('no frames')
 return errors

def load(folder,split='train',allow_synthetic=False):
 p=Path(folder);m=json.loads((p/'manifest.json').read_text());raw=(p/'data/frames.jsonl').read_bytes()
 if m.get('joint_names')!=FIELDS or m.get('joint_units')!=UNITS:raise ValueError('column order or units differ from the course contract')
 if m.get('schema')!='aloha.teaching-frames.v1':raise ValueError('unsupported teaching schema')
 if m.get('provenance')!='learner_recorded' and not (allow_synthetic and m.get('provenance')=='synthetic'):raise ValueError('learner_recorded required; synthetic is explicit QA only')
 if split not in ('train','validation'):raise ValueError('this learning loader cannot expose the sealed test split')
 if hashlib.sha256(raw).hexdigest()!=m.get('sha256'):raise ValueError('frames digest mismatch')
 rows=[json.loads(line) for line in raw.splitlines() if line.strip()];errors=validate_rows(rows)
 if len(rows)!=m.get('frame_count'):errors.append('frame_count mismatch')
 for key in ('hardware_revision','dataset_source','split_policy'):
  if not m.get(key):errors.append('missing manifest '+key)
 if errors:raise ValueError('; '.join(errors))
 result=[r for r in rows if r['split']==split]
 if not result:raise ValueError('requested split is empty')
 return m,result
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder');p.add_argument('--split',choices=['train','validation'],default='train');p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args();m,rows=load(a.folder,a.split,a.allow_synthetic);print(json.dumps({'loaded_frames':len(rows),'split':a.split,'provenance':m['provenance'],'episode_ids':sorted({r['episode_id'] for r in rows}),'source':m['dataset_source'],'read_only':True},ensure_ascii=False,indent=2))
