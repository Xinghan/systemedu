"""Separate preregistered single-factor challenge; never expands the main denominator."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,argparse,re
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M74/code'))
from evaluation_audit import *
from gateway_log import validate_gateway_log

def register(draft_path,root,output_path):
 d=read(draft_path);p=verify_file(root,d['main_plan_ref']);plan=validate_plan(read(p),root)
 for key in ('factor','unit','measurement_method','interpretation_limits'):text(d.get(key),key)
 for key in ('baseline_value','challenge_value'):number(d.get(key),key)
 if d['baseline_value']==d['challenge_value']:raise ValueError('Declare a changed factor')
 if not isinstance(d.get('held_fixed'),list) or not d['held_fixed']:raise ValueError('Document held-fixed quantities')
 rows=d.get('trials');seen=set()
 if not isinstance(rows,list) or not rows:raise ValueError('Predeclare all extra trials')
 for row in rows:
  tid=text(row.get('trial_id'),'trial_id')
  if not re.fullmatch('[A-Za-z0-9_-]+',tid) or tid in seen or tid in {r['trial_id'] for r in plan['plan']}:raise ValueError('Unique separate challenge IDs required')
  if row.get('condition') not in ('baseline','challenge'):raise ValueError('Condition must be baseline or challenge')
  seen.add(tid)
 d.update(schema='aloha.challenge-plan.v1',registered_at=datetime.now(timezone.utc).isoformat(),evaluation_id=plan['evaluation_id'],source_kind=plan['source_kind'],frozen_versions=plan['frozen_versions'])
 with open(output_path,'x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
 return {'path':str(output_path),'sha256':sha(output_path)}

def report(path,root):
 d=read(path)
 if d.get('schema')!='aloha.challenge-plan.v1':raise ValueError('Register challenge plan before execution')
 plan_path=verify_file(root,d['main_plan_ref']);plan=validate_plan(read(plan_path),root)
 if d['frozen_versions']!=plan['frozen_versions']:raise ValueError('Challenge system differs from main frozen system')
 registered=timestamp(d['registered_at'],'registered_at');runs={};extra=[]
 ids={r['trial_id'] for r in d['trials']}
 for p in (Path(root)/'runs').glob('*/closed.json'):
  r=read(p)
  if r.get('evaluation_id')!=plan['evaluation_id'] or r.get('purpose')!='domain_challenge':continue
  if r['trial_id'] not in ids:extra.append({'path':str(p.relative_to(root)),'trial_id':r['trial_id']});continue
  if r['trial_id'] in runs:raise ValueError('Duplicate challenge trial ID')
  runs[r['trial_id']]=(p,r)
 out={'schema':'aloha.challenge-report.v1','source_kind':d['source_kind'],'challenge_plan_sha256':sha(path),'main_plan_sha256':sha(plan_path),'main_denominator_unchanged':20,'trials':[],'groups':{},'unplanned_extra_runs':extra,'errors':[],'truth_certified':False}
 for item in d['trials']:
  tid=item['trial_id'];issues=[];success=False;record=runs.get(tid)
  if record:
   p,r=record
   try:
    if r.get('version_validation_errors') or r.get('evidence_validation_errors'):raise ValueError('Closed run retains validation errors')
    if r['source_kind']!=d['source_kind'] or r['observed_versions']!=d['frozen_versions']:raise ValueError('Source or frozen versions differ')
    if r['plan_sha256']!=sha(plan_path):raise ValueError('Run bound to a different main plan')
    opened=read(verify_file(root,r['start_record_ref']))
    cp=verify_file(root,r['context_plan_ref'])
    if cp.resolve()!=Path(path).resolve() or opened.get('context_plan_ref')!=r['context_plan_ref']:raise ValueError('Run bound to a different challenge plan')
    for k in ('run_id','trial_id','purpose','source_kind','observed_versions','plan_sha256'):
     if opened[k]!=r[k]:raise ValueError('Start/close mismatch: '+k)
    if timestamp(opened['record_opened_at'],'opened')<registered:raise ValueError('Challenge run precedes preregistration')
    success=validate_outcome(r,plan['time_limit_s']);verify_evidence(root,r['evidence']);verify_outcome_binding(root,r)
    for e in r['evidence']:
     if e['kind']=='gateway_log':validate_gateway_log(contained(root,e['path']),r)
   except (ValueError,KeyError,TypeError,FileNotFoundError,json.JSONDecodeError) as exc:issues.append(str(exc));success=False
  else:issues.append('Predeclared challenge run missing')
  group=out['groups'].setdefault(item['condition'],{'planned':0,'verified':0,'successes':0});group['planned']+=1;group['verified']+=int(not issues);group['successes']+=int(success)
  out['trials'].append({'trial_id':tid,'condition':item['condition'],'success':success,'verified':not issues,'errors':issues,'closed_ref':None if not record else {'path':str(record[0].relative_to(root)),'sha256':sha(record[0])}});out['errors'].extend(tid+': '+i for i in issues)
 out['complete']=not out['errors'];out['conclusion_scope']=d['interpretation_limits'];return out
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan');p.add_argument('--root',required=True);p.add_argument('--output',required=True);p.add_argument('--register',action='store_true');a=p.parse_args();r=register(a.plan,a.root,a.output) if a.register else report(a.plan,a.root)
 if not a.register:
  with open(a.output,'x') as f:json.dump(r,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps(r,ensure_ascii=False,indent=2))
