#!/usr/bin/env python3
"""Export a traceable scalar round-trip table and histogram using frozen training statistics."""
import argparse,csv,hashlib,json,math
from html import escape
from pathlib import Path
from normalize import FIELDS,UNITS,forward,inverse,read_package,verify_config

def histogram(values,edges):
    counts=[0]*(len(edges)-1)
    for x in values:
        i=next((j for j in range(len(counts)) if edges[j]<=x<edges[j+1]),len(counts)-1)
        counts[i]+=1
    return counts

def report(package,normalization,field,kind,include_validation=False,allow_synthetic=False):
    manifest,train=read_package(package,'train',allow_synthetic)
    raw=Path(normalization).read_bytes();config=json.loads(raw);verify_config(config,manifest,train)
    index=FIELDS.index(field);stats=config['statistics'][kind][index];rows=list(train)
    if include_validation:rows+=read_package(package,'validation',allow_synthetic)[1]
    table=[]
    for r in rows:
        x=r[kind][index];z=forward(x,stats);restored=inverse(z,stats)
        table.append(dict(episode_id=r['episode_id'],attempt_id=r['attempt_id'],frame_index=r['frame_index'],split=r['split'],kind=kind,field=field,unit=UNITS[index],raw=x,standardized=z,restored=restored,roundtrip_error=restored-x))
    low=min(r['standardized'] for r in table);high=max(r['standardized'] for r in table)
    if low==high:low-=.5;high+=.5
    edges=[low+(high-low)*i/12 for i in range(13)]
    counts={split:histogram([r['standardized'] for r in table if r['split']==split],edges) for split in ('train','validation')}
    peak=max(1,max(counts['train']+counts['validation']));s=['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="570" viewBox="0 0 1000 570"><rect width="1000" height="570" fill="#FAF9F5"/><g font-family="sans-serif" fill="#191814">']
    s += [f'<text x="65" y="42" font-size="23">{escape(field)} · {escape(kind)}</text>',f'<text x="65" y="73" font-size="15">{escape(manifest["provenance"])} · fixed training mean {stats["mean"]:.6g}, scale {stats["scale"]:.6g}</text>','<text x="65" y="108" font-size="15">Frame counts, not a probability density. Blue: train / orange: validation (if requested).</text>']
    for k in range(5):
        y=450-k*70;s.append(f'<line x1="70" y1="{y}" x2="930" y2="{y}" stroke="#DED7C6"/><text x="58" y="{y+5}" text-anchor="end" font-size="13">{peak*k/4:.3g}</text>')
    width=860/12
    for j in range(12):
        for offset,split,color in [(0,'train','#5d8aa8'),(1,'validation','#D97757')]:
            n=counts[split][j];h=n/peak*280
            s.append(f'<rect x="{70+j*width+offset*width/2+2:.3f}" y="{450-h:.3f}" width="{width/2-4:.3f}" height="{h:.3f}" fill="{color}"/>')
    for j in [0,3,6,9,12]:s.append(f'<text x="{70+j*width:.3f}" y="475" text-anchor="middle" font-size="14">{edges[j]:.4g}</text>')
    s+=['<text x="500" y="511" text-anchor="middle" font-size="18">Standardized value (dimensionless), 12 equal-width bins</text>','<text x="65" y="546" font-size="14">No test data; no clipping; validation never changes the saved mean or scale.</text></g></svg>']
    metadata={'provenance':manifest['provenance'],'source_sha256':manifest['sha256'],'normalization_sha256':hashlib.sha256(raw).hexdigest(),'field':field,'kind':kind,'unit':UNITS[index],'fitted_split':'train','plotted_splits':['train','validation'] if include_validation else ['train'],'bin_edges':edges,'bin_counts':counts,'roundtrip_max_abs_error':max(abs(r['roundtrip_error']) for r in table),'clip':None,'hardware_executed':False}
    return table,''.join(s),metadata

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('--field',required=True,choices=FIELDS);p.add_argument('--kind',choices=['observation_state','action'],default='action');p.add_argument('--include-validation',action='store_true');p.add_argument('--allow-synthetic',action='store_true');p.add_argument('--out',required=True);a=p.parse_args()
    try:
        rows,svg,meta=report(a.package,a.normalization,a.field,a.kind,a.include_validation,a.allow_synthetic)
        out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
        with (out/'roundtrip.csv').open('x',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        (out/'distribution.svg').write_text(svg);(out/'report.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    except (OSError,ValueError,TypeError,KeyError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
