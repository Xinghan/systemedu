import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from backprop import *
from relu_network import worked_example,initialize
class BackpropTests(unittest.TestCase):
 def setUp(self):self.m=worked_example();self.rows=[{'x':[2,-1],'y':[1.3,.75]}]
 def test_two_paths(self):
  r=loss_gradient(self.rows,self.m);t=r['traces'][0];self.assertAlmostEqual(r['loss'],.58);self.assertAlmostEqual(t['hidden_path_contributions'][0][0],1);self.assertAlmostEqual(t['hidden_path_contributions'][0][1],-.1);self.assertAlmostEqual(t['hidden_sum'][0],.9);self.assertAlmostEqual(r['gradient']['w1'][0][0],1.8);self.assertAlmostEqual(r['gradient']['w1'][0][1],-.9)
 def test_negative_gate(self):
  r=loss_gradient(self.rows,self.m);self.assertEqual(r['gradient']['w1'][1],[0,0]);self.assertEqual(r['gradient']['b1'][1],0);self.assertAlmostEqual(r['traces'][0]['hidden_sum'][1],-.9)
 def test_finite_differences_all(self):
  r=loss_gradient(self.rows,self.m)
  for p in parameters(self.m):self.assertAlmostEqual(perturbation_check(self.rows,self.m,p,1e-4)['central_difference'],get(r['gradient'],p),places=7)
 def test_batch_mean(self):
  a=loss_gradient(self.rows,self.m);b=loss_gradient(self.rows*3,self.m)
  for p in parameters(self.m):self.assertAlmostEqual(get(a['gradient'],p),get(b['gradient'],p))
 def test_no_parameter_mutation(self):
  original=copy.deepcopy(self.m);perturbation_check(self.rows,self.m,('w1',0,0),.001);self.assertEqual(self.m,original)
 def test_fault_detectable(self):
  wrong=loss_gradient(self.rows,self.m,1)['gradient']['w1'][0][0];fd=perturbation_check(self.rows,self.m,('w1',0,0),.001)['central_difference'];self.assertAlmostEqual(wrong,2);self.assertFalse(close(wrong,fd))
 def test_kink_not_certified(self):
  self.m['b1'][0]=-2;probe=perturbation_check(self.rows,self.m,('w1',0,0),.001);self.assertFalse(probe['eligible']);self.assertTrue(probe['branch_crossings'])
 def test_large_step_crossing(self):
  probe=perturbation_check(self.rows,self.m,('w1',0,0),2);self.assertFalse(probe['eligible']);self.assertGreater(probe['plus_loss'],0)
 def test_zero_input_does_not_move_gate(self):
  self.rows[0]['x']=[0,0];self.m['b1'][0]=0;probe=perturbation_check(self.rows,self.m,('w1',0,0),.001);self.assertTrue(probe['eligible']);self.assertEqual(probe['central_difference'],0)
 def test_invalid_input(self):
  for eps in (0,-1,True,float('inf')):
   with self.assertRaises(ValueError):perturbation_check(self.rows,self.m,('w1',0,0),eps)
  with self.assertRaises(ValueError):loss_gradient([],self.m)
class GraphTests(unittest.TestCase):
 def setUp(self):
  from game_graph_check import evaluate
  self.evaluate=evaluate;self.sources={'x':2.,'g1':1.,'g2':-.4,'edge1':1.,'edge2':.25,'gate':1.}
 def test_free_graph_runs(self):
  p='left = mul(g1,edge1)\nright = mul(g2,edge2)\ntotal = add(left,right)\nthrough = mul(total,gate)\nresult = mul(through,x)'
  self.assertAlmostEqual(self.evaluate(p,self.sources,'result')[0],1.8);self.sources['g2']=-.8;self.assertAlmostEqual(self.evaluate(p,self.sources,'result')[0],1.6)
 def test_forward_reference_rejected(self):
  with self.assertRaises(ValueError):self.evaluate('a = mul(a,x)',self.sources,'a')
 def test_duplicate_sources_rejected(self):
  with self.assertRaises(ValueError):self.evaluate('x = const(1)',self.sources,'x')
 def test_nonfinite_constant_rejected(self):
  with self.assertRaises(ValueError):self.evaluate('a = const(inf)',self.sources,'a')
if __name__=='__main__':unittest.main()
