# M28 本人记录空表

下载[课程实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)，解压后进入 `lessons/M28/practice/`。此处是空白学习模板，预填的名称是任务结构，所有实际结果均待本人填写，不是synthetic测试输出，更不是实测成绩。复制模板为新文件，保留原始照片/日志及文件摘要，完成者和导师分别记录自己的核验范围。

逐项找回M19–M27的真实前作，再记录同一attempt的完整遥操作证据。state只能在有证据后填写complete、不满足写not_met、资料缺失写incomplete，纯数字版本写digital_prototype。此表是前作索引，另外保存原生数据、旁路、连续录像、配置及全部尝试清单。成功仅证明本阶段人工遥操作，不能写成ACT自主成功。
