"""Plan only among measured, versioned candidates; never interpolate unseen performance."""
import argparse,json,math
from course_contract import finite,positive,read,write_new

def assess(measurement,plan):
 if measurement.get('schema')!='aloha.resource-measurement.v1'or measurement.get('status')not in ('measured','synthetic_example'):raise ValueError('successful measurement or explicitly synthetic example required')
 if measurement.get('status')=='synthetic_example'and measurement.get('source_kind')!='synthetic_fixture':raise ValueError('synthetic example must remain labelled')
 for k in ('remaining_steps','available_seconds','startup_save_validation_seconds','contingency_seconds','memory_budget_bytes','memory_margin_bytes','storage_budget_bytes','storage_required_estimate_bytes'):
  v=plan.get(k)
  if not finite(v)or v<0:raise ValueError('nonnegative finite resource budget required: '+k)
 if not positive(plan['remaining_steps']):raise ValueError('positive remaining microbatch steps required')
 if plan.get('candidate_id')!=measurement.get('candidate_id')or plan.get('request_sha256')!=measurement.get('request_sha256'):raise ValueError('plan and measured candidate version differ')
 duration=measurement['timing']['total_s']['p90_s'];peak=measurement['memory']['cuda_peak_reserved_bytes']
 if not finite(duration)or duration<=0:raise ValueError('valid measured p90 required')
 estimate=plan['remaining_steps']*duration+plan['startup_save_validation_seconds']+plan['contingency_seconds']
 if not finite(estimate):raise ValueError('time estimate overflow')
 known=finite(peak)and peak>=0
 if known and not finite(peak+plan['memory_margin_bytes']):raise ValueError('memory sum overflow')
 return {'candidate_id':measurement['candidate_id'],'source_kind':measurement['source_kind'],'estimated_required_seconds':estimate,'time_fits':estimate<=plan['available_seconds'],'memory_check_available':known,'memory_fits':(peak+plan['memory_margin_bytes']<=plan['memory_budget_bytes'])if known else None,'storage_estimate_fits':plan['storage_required_estimate_bytes']<=plan['storage_budget_bytes'],'reservation_confirmed':plan.get('mentor_reservation_confirmed')is True,'planning_ready':estimate<=plan['available_seconds']and known and peak+plan['memory_margin_bytes']<=plan['memory_budget_bytes']and plan['storage_required_estimate_bytes']<=plan['storage_budget_bytes']and plan.get('mentor_reservation_confirmed')is True,'limits':'p90×remaining steps is an estimate for this identical configuration, not a runtime bound; reserved-memory peak is process-local and cannot predict other jobs. Storage remains an explicit estimate. CPU result has no GPU capacity claim.'}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('measurement');p.add_argument('plan');p.add_argument('output');a=p.parse_args();r=assess(read(a.measurement),read(a.plan));write_new(a.output,r);print(json.dumps(r,ensure_ascii=False,indent=2))
