"""Scalar two-layer ReLU reverse pass; path products sum before the local gate."""
import copy,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M42/code'))
from relu_network import forward,validate_network
from linear_layer import finite
KEYS=('w1','b1','w2','b2')
def zeros(model):return {key:[[0.]*len(row) for row in model[key]] if key.startswith('w') else [0.]*len(model[key]) for key in KEYS}
def parameters(model):
 for key in KEYS:
  for j,row in enumerate(model[key]):
   if key.startswith('w'):
    for i in range(len(row)):yield key,j,i
   else:yield key,j
def get(model,path):
 value=model
 for part in path:value=value[part]
 return value
def set_value(model,path,value):
 target=model
 for part in path[:-1]:target=target[part]
 target[path[-1]]=finite(value)
def loss_gradient(rows,model,omit_output=None):
 ni,nh,no=validate_network(model)
 if not isinstance(rows,list) or not rows:raise ValueError('Nonempty rows required')
 if omit_output is not None and (type(omit_output) is not int or not 0<=omit_output<no):raise ValueError('Fault output index invalid')
 count=len(rows)*no;grad=zeros(model);traces=[];squares=[]
 for row in rows:
  if not isinstance(row['y'],list) or len(row['y'])!=no:raise ValueError('Target size differs')
  t=forward(row['x'],model);y=[finite(v) for v in row['y']];errors=[finite(p-v) for p,v in zip(t['prediction'],y)]
  squares.extend(finite(e*e) for e in errors);gp=[finite(2*e/count) for e in errors]
  paths=[[finite(gp[k]*model['w2'][k][j]) for k in range(no)] for j in range(nh)]
  upstream=[finite(math.fsum(v for k,v in enumerate(contributions) if k!=omit_output)) for contributions in paths]
  gate=[1. if z>0 else 0. for z in t['preactivation']];gz=[finite(v*g) for v,g in zip(upstream,gate)]
  for k in range(no):
   grad['b2'][k]+=gp[k]
   for j in range(nh):grad['w2'][k][j]+=finite(gp[k]*t['activation'][j])
  for j in range(nh):
   grad['b1'][j]+=gz[j]
   for i in range(ni):grad['w1'][j][i]+=finite(gz[j]*row['x'][i])
  traces.append({'forward':t,'target':y,'error':errors,'output_signal':gp,'hidden_path_contributions':paths,'hidden_sum':upstream,'relu_local_factor':gate,'preactivation_signal':gz,'zero_preactivation_indices':[j for j,z in enumerate(t['preactivation']) if z==0]})
 for path in parameters(model):finite(get(grad,path))
 return {'loss':finite(math.fsum(squares)/count),'gradient':grad,'traces':traces,'denominator':count,'fault_omitted_output':omit_output,'relu_at_zero':'implementation convention 0; a mathematical kink is not certified by this convention'}
def perturbation_check(rows,model,path,epsilon):
 epsilon=finite(epsilon)
 if epsilon<=0:raise ValueError('epsilon must be positive')
 if tuple(path) not in set(parameters(model)):raise ValueError('Unknown parameter path')
 original=get(model,path);plus=copy.deepcopy(model);minus=copy.deepcopy(model);set_value(plus,path,original+epsilon);set_value(minus,path,original-epsilon)
 a=loss_gradient(rows,model);b=loss_gradient(rows,plus);c=loss_gradient(rows,minus);crossings=[]
 if path[0] in ('w1','b1'):
  j=path[1]
  for n,(t,tp,tm) in enumerate(zip(a['traces'],b['traces'],c['traces'])):
   z=t['forward']['preactivation'][j];zp=tp['forward']['preactivation'][j];zm=tm['forward']['preactivation'][j]
   if (z==0 and zp!=zm) or min(zp,zm)<=0<=max(zp,zm) and zp!=zm:crossings.append({'row':n,'hidden':j,'minus_z':zm,'base_z':z,'plus_z':zp})
 return {'parameter':list(path),'epsilon':epsilon,'base_parameter':original,'plus_parameter':get(plus,path),'minus_parameter':get(minus,path),'plus_loss':b['loss'],'minus_loss':c['loss'],'central_difference':finite((b['loss']-c['loss'])/(2*epsilon)),'branch_crossings':crossings,'eligible':not crossings and get(plus,path)!=get(minus,path)}
def autograd_reference(rows,model):
 import torch
 p={key:torch.tensor(model[key],dtype=torch.float64,requires_grad=True) for key in KEYS}
 x=torch.tensor([r['x'] for r in rows],dtype=torch.float64);y=torch.tensor([r['y'] for r in rows],dtype=torch.float64)
 hidden=torch.relu(x@p['w1'].T+p['b1']);prediction=hidden@p['w2'].T+p['b2'];loss=((prediction-y)**2).mean();loss.backward()
 return {'loss':float(loss.detach()),'gradient':{key:p[key].grad.tolist() for key in KEYS},'torch_version':torch.__version__,'dtype':'float64','reduction':'all frame-output cells mean; no half'}
def close(a,b,atol=1e-7,rtol=1e-5):return abs(a-b)<=atol+rtol*max(abs(a),abs(b))
def check(rows,model,epsilons=(.001,.0001,.00001),omit_output=None):
 epsilons=[finite(v) for v in epsilons]
 if not epsilons or len(epsilons)>6 or any(v<=0 for v in epsilons):raise ValueError('One to six positive epsilons required')
 explicit=loss_gradient(rows,model,omit_output);auto=autograd_reference(rows,model);results=[]
 for path in parameters(model):
  a=get(explicit['gradient'],path);b=get(auto['gradient'],path);probes=[]
  for eps in epsilons:
   probe=perturbation_check(rows,model,path,eps);probe['matches_explicit']=probe['eligible'] and close(a,probe['central_difference']);probe['absolute_difference']=abs(a-probe['central_difference']);probes.append(probe)
  eligible=[p for p in probes if p['eligible']];agreement=close(a,b)
  status='pass' if agreement and eligible and all(p['matches_explicit'] for p in eligible) else ('inconclusive_branch' if agreement and not eligible else 'mismatch')
  results.append({'parameter':list(path),'explicit':a,'autograd':b,'explicit_autograd_match':agreement,'probes':probes,'status':status})
 return {'loss':explicit['loss'],'denominator':explicit['denominator'],'explicit':explicit,'autograd':auto,'comparisons':results,'all_checked_parameters_pass':all(r['status']=='pass' for r in results),'tolerance':{'atol':1e-7,'rtol':1e-5,'rule':'abs(a-b) <= atol + rtol*max(abs(a),abs(b))'},'note':'Ineligible kink-crossing probes are retained, not certified. Agreement checks this graph at these inputs/parameters only.'}
