# M64：重建与加权目标

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M64/code/objective.py lessons/M64/code/synthetic.json M64-result.json
```

输入 prediction/target 为B×K×D，action_is_pad为B×K布尔，另给 beta 与kl_batch_mean。只计有效步×动作维，拒绝全padding。fixture numerator=9, denominator=6, L1=1.5；beta=.1、KL≈1.65342641，总目标≈1.66534264。输出还含联合表的条件、边缘、下界与两类KL数值核对。可审计本人同一步前向快照；输入KL必须已按潜在维求和、批次平均，不可混入另一轮模型。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
