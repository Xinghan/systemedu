"""Pure offline mapping probes. Port names are symbolic; no driver imports."""
import argparse,json,math
from pathlib import Path

def route(config, row):
    if set(row)!=set(config) or {v['source'] for v in config.values()}!=set(row):
        raise ValueError('Explicit one-to-one source mapping required')
    if any(v['sign'] not in (-1,1) for v in config.values()):
        raise ValueError('Only declared +/- direction in this teaching fixture')
    if any(not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) for v in row.values()):
        raise ValueError('Finite input required')
    return {dst:row[spec['source']]*spec['sign'] for dst,spec in config.items()}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);a=p.parse_args()
    data=json.loads(a.input.read_text())
    if data.get('provenance') not in ('synthetic','learner_log_replay'):
        p.error('Declare synthetic or learner_log_replay')
    print(json.dumps({'provenance':data['provenance'],'hardware_executed':False,
        'config':data['config'],'trials':[{'input':row,'output':route(data['config'],row)} for row in data['probes']]},indent=2))
