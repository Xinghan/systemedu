# ALOHA 启发双臂课程 · 学生实践包

适用 10–12 岁学生与导师。目标是学生制作两只 SO-101 leader、两只 follower，在桌面上由左臂稳住自制托盘、右臂放入轻小打印块，并用本人示范训练 ACT。它借鉴 ALOHA 的遥操作与模仿学习方法，不是原版 ALOHA 硬件复刻。

**完整课程有 82 个节点、11 个阶段。实践包包含逐课代码、制作文件、记录模板和验收工具；学生需要亲自完成打印、装配、测量、示范采集、ACT 训练与实机试验。包内没有学生示范、学生训练权重或真实成功率证据。** `examples/` 和 `expected/` 全是明确标注的 synthetic 教学数据。

## 1. 先跑通离线练习

解压到自己的普通文件夹，在终端进入该文件夹。这里用 Python 3.12 或更高版本，不用 pip、不接电机、不联网：

```sh
python3 -m unittest discover -s tests -v
python3 run_examples.py --output my-first-run --check-expected
```

第二条命令要求新目录，避免覆盖之前的证据；重跑时改为 `my-second-run`。结果应为 `examples_passed: 13`，`hardware_executed: false`。`verification/` 保存制作时真实运行的日志，`expected/` 保存每项示例的完整预期 JSON。

| 要练的内容 | 独立命令 | 应观察到的结果 |
|---|---|---|
| 十二个关节字段 | `python3 course_cli.py fields examples/state.json` | 左右各 6 个字段，夹爪单位为 normalized_0_100，其余 degree |
| 采样与漏帧 | `python3 course_cli.py sampling examples/sampling.json` | 平均 7.5 Hz；最长间隔 0.2 s，并非每个间隔相同 |
| 位置与相对目标 | `python3 course_cli.py limits examples/limits.json` | 首关节 120 先裁到 30，再输出 2；夹爪 50→52 |
| 时间同步 | `python3 course_cli.py sync examples/sync.json` | 第二行画面来自动作之后，被标 future_information |
| 整回合划分 | `python3 course_cli.py split examples/episode_index.json --source-dir examples/episodes --output-dir my-split` | 不把一段回合拆到两组；C 批次固定测试；被剔除回合仍保留原文件和理由 |
| 真正梯度更新 | `python3 course_cli.py toy-train examples/toy_train.json` | 初始 MSE=5，梯度 w=-3、b=-4，一步后 w=0.3、b=0.4、MSE=2.825 |
| 动作块时间集成 | `python3 course_cli.py ensemble examples/chunks.json` | 当前动作 [20,30]；尚未产生的未来块不参与 |
| 完整试次统计 | `python3 course_cli.py evaluate examples/evaluation.json` | 1/4=25%；失败、人工介入和超时均在分母 |

每项练习复制 JSON 到自己的工作目录，只改变一个量，先手算再运行。时间单位为秒；字段数值不能夹带字符串、NaN 或 Infinity。修改后把假设、手算、输出和发现写到 `templates/experiment-log.md`。程序做的是计算与结构审查，不能判定学习掌握或机械安全。

`split` 复制的是课程 JSONL 教学文件，**不是** LeRobot 视频/Parquet 数据迁移器。真实数据按第 5 步调用官方拆分工具。采样表不等于曝光时间；同步工具要求输入已经测定的时钟偏移，不能靠调整偏移掩盖真实延迟。

## 2. 准备和制作四臂工位

先读 [硬件与现场步骤](docs/HARDWARE.zh.md) 和 [CAD 说明](cad/README.zh.md)。成人负责热端、首次供电极性、固定可靠性和可实际切断动力的位置；学生负责测量、设计、文件、数据和解释。调整接线或结构时断动力。任务只使用轻小、钝边打印块。

四臂结构使用固定版本的 SO101 官方打印件；本包新增试配片、托盘、指垫、轻块和相机接口板。接口参数必须从自己的实际打印件与标准件测量，未填写时 OpenSCAD 会报错。先试片、后主结构，每一版保留 CAD、STL、切片工程和试配记录。不要购买复杂金属整机来代替这些制作任务。

完成标志：四臂/四端口标签可一一对应；每只臂的电机 ID、型号、减速比与校准文件均有记录；导师能实际停止动力；单关节方向与单位逐个核对；两臂交叠区域、线缆、桌面固定、夹持与相机视野有测量证据。未达到这些条件，继续离线练习。

## 3. 固定软件环境

[ENVIRONMENT.zh.md](docs/ENVIRONMENT.zh.md) 给出固定源码与上游依赖锁安装步骤。LeRobot 固定为 `b64fe1ed9f11eeac53ee821356d2797601701054`；官方文档有时仍展示旧接口，因此本包以该 commit 的源代码字段为准。

本 revision：`lerobot-record` 用 leader 示教录制；上游另有 `lerobot-rollout`，但本课程正式自主执行必须走 **M72 的 ACT → 执行网关 → 双臂驱动路径**。根目录的 rollout 命令生成器仅用于认识上游接口，不作为本课程验收入口。不能把旧教程的 `lerobot-record --policy.path=...` 直接复制进来。双臂配置名是 `bi_so_follower` / `bi_so_leader`，左右字段分别位于 `left_arm_config` / `right_arm_config`。

我们显式启用 `use_degrees=true`：每臂 5 个关节为度，夹爪仍是校准后的 0–100 量，不是度或毫米。`max_relative_target` 是目标与**当次实测位置**之间的最大差；本包要求每个关节各填一个值。它既不是“每秒最大速度”，也不负责绝对空间范围、两臂碰撞或夹持力。根目录离线 `limits` 算例不会连接驱动。正式执行由 M72 接入 `execution_gateway.py`，使用本人已测限制；现场空间隔离、停机和监督仍需实际检查，不能把离线 PASS 当作实机验证。

## 4. 生成并审阅录制命令

复制 `templates/act_config.json` 为自己的 `workstation-v1.json`。填四端口、相机索引、实测限制、唯一 ID 和本地绝对路径。相机固定命名 `front`、`overhead`；相机分辨率、帧率、左右映射和校准版本在训练/部署时保持一致。模板故意不能直接运行；synthetic 示例内的设备路径也是不存在的。

```sh
python3 act_commands.py record workstation-v1.json > record-command.json
```

生成器只输出 JSON，其中 `shell_preview` 是导师审阅后在已安装 LeRobot 的终端**手动**执行的命令。读取或生成 JSON 不会启动机器人。执行原生命令才会连接设备、可能校准并使设备运动。先检查本机 `lerobot-record --help` 与固定版本一致，再在成人可停机的位置由单臂/单关节逐步联调。
本地录制显式关闭 `dataset.push_to_hub`，不需登录 Hugging Face。每次真实采集用一个新目录和新版本名；`no_stamp=true` 让数据标识可追溯，因此命名不重复由学生负责。先做一次录制并核对回放的实际画面、动作字段、时间戳、夹爪和左右侧，再采正式示范。原生数据的 action 是 teleop_action_processor 输出，语义位置在 robot_action_processor 和驱动约束之前；它不等于驱动最终发送值，更不等于实测到达位置。原生 timestamp 是 frame_index/fps 名义网格，不是曝光或真实采集时间。另存绑定 episode/frame 的单调时钟 sidecar、处理器目标、send_action 返回值及实测状态，注明到达时间不等于曝光时间。

将失败、掉帧、空夹和急停记录到回合索引。训练可以按事先规则筛选示范，但保留原始数据与剔除理由。官方录制界面的左箭头可能删除当前回合；正式验收不能用它删除失败。影像默认留在学生私有目录；未经明确选择不上传。

## 5. 按节点接起真实学习与训练

`lessons/Mxx/` 保存该节点的 `plan.md`、`assignment.md` 与实际需要的 `code/`、`practice/` 或 `files/`。代码通过相邻节点复用已学实现；保留整个包的目录结构，不要只拷贝一个 Python 文件。每次使用新的输出目录，保留原件和失败日志。

| 阶段 | 本人要交付的作品 | 实际入口 |
|---|---|---|
| M01–M18 | 任务接口、试配片、四臂打印装配与工位 | 逐课实践目录、`cad/`、硬件说明 |
| M19–M28 | 几何/标定、字段方向、遥操作与时间同步记录 | 逐课代码及 `recording_sidecar.py` |
| M29–M35 | 本人原生数据、整回合划分、可追溯学习数据包 | M33 划分审计与官方分片、M34 原生读取、M35 包 |
| M36–M46 | 从基线到显式反传、优化、验证选择的可复跑小策略 | M41–M45 实际训练代码、M46 总装交付 |
| M47–M55 | 真实像素、特征、注意力与视觉机制档案 | 各节点计算工具，M55 阶段交付 |
| M56–M66 | 动作块、时序、后验/KL、真实 ACT 学习步 | 各节点机制与固定 ACT 源码检查 |
| M67–M70 | 实测资源、本人正式 ACT、选版与可重载部署包 | 下文训练路径 |
| M71–M78 | 无动力时序、网关执行、完整二十试次与边界分析 | 下文执行与验收路径 |
| M79–M82 | 有依据的修订、发布、第三人交接与答辩 | 对应节点的实践说明与审核工具 |

先完成 M33 的原始整回合划分，不让同一尝试或关联采集批次跨组。正式训练需要物理分开的原生训练子库：

```sh
python3 act_commands.py split-lerobot workstation-v1.json --split your-split-manifest.json > split-command.json
```

导师审阅后执行生成的固定版官方分片命令。检查每组实际回合数、原→新索引、训练统计文件摘要；新训练组从零重编号，其统计只来自训练组。保留原始数据及分片映射。`course_cli.py split` 处理的教学 JSONL 不能代替原生 LeRobot 视频/Parquet 分片。

正式 ACT 路径使用 `lessons/M67/code/training_request.example.json` 填写本人配置与来源。依次阅读各节点代码说明：

1. M67 `benchmark.py` 实际读取数据并训练短基准，再由 `resource_budget.py` 规划资源。记录真实图像尺寸，不把机制例子的低分辨率当正式需求。
2. M68 `training_run.py train` 先生成命令，审阅后加 `--execute` 实际调用固定训练器。保存每次请求、收据、日志、检查点及恢复状态。恢复用 `resume`，保留源检查点，使用新的收据与生成的新请求。
3. M69 `register_candidate.py` 登记每个真实候选；先冻结比较规则，再由 `export_predictions.py` 用当前观察预测，最后由 `select_candidate.py` 比较全部验证候选。它加载真实 ACT 和保存的前后处理器，最终测试仍封存。
4. M70 `reload_bundle.py package` 接收选版、模型清单、实际环境和接口上下文，复制可搬运部署包；`smoke` 在新进程实际加载本人模型。当前观察不能含未来动作标签。

完整参数、输入模板与恢复方法见相应 `lessons/Mxx/code/` 说明。示意步数、批次和网络尺寸不保证收敛，正式设置依据本人数据、资源实测和预定验证规则。根目录旧的 `act_commands.py train` 和 `validate_act.py` 是补充接口工具，不替代 M68–M70 的来源、选版与交付要求。

本次制作已在固定的完整 LeRobot 安装中实际完成小型 CPU 合成训练：原生图像数据读取、训练、检查点保存、恢复、验证选版、保存处理器重载及新进程推理。证据见 `verification/root-full-lerobot.json`。这只验证软件衔接；不是学生正式训练，也未验证 GPU 性能、完整训练收敛、真实相机或机器人。

## 6. 通过网关执行，再完成全部验收

先做 M71：机械臂不接动力，读取实际 USB 相机并结合本人已保存的状态快照，测读取、预处理、推理与后处理/记录耗时。状态快照不是实时编码器读数。默认 follower `connect()` 会配置并使能电机，不能在这一环节调用后声称“无动力”。离线时序也不能代表电机响应或相机曝光时刻。

再做 M72：按该节点实践说明，将已选 ACT 接入课程执行网关与实际双臂驱动。先完成限制、超时、停止和现场监督检查，再进行低速、轻载、短时开发试验。代码日志记录策略请求、网关处理与驱动返回；停止函数返回不能代替现场观察。成人能实际切断动力，结构或接线调整时断动力。

正式试次按下面的唯一证据路径执行：

- M73 用开发条件诊断，失败与修改分别保留。
- M74 `freeze_plan.py` 冻结二十个预定条件、随机顺序、阈值和模型/硬件/配置/划分/软件五类摘要。直接保留 M69 原始模型清单与相对候选目录，不能重包另一清单冒充同一模型摘要。
- M75 `run_record.py` 为每次试验先创建开始记录；M72 执行入口使用同一 run/trial 身份与冻结版本。实际结束后关联连续视频、网关日志和结果说明，保存关闭记录。
- M76 `assemble_evaluation.py` 汇总全部二十项。16 次成功加 4 次缺失仍不完整；失败、人工介入和超时都保留。全部实际执行且证据齐全后，再判性能门槛。
- M77 `wilson_report.py` 分析有限试次的不确定性；M78 将新条件挑战单列，不混进原验收分母。
- M79 记录单项修订和新版本；M80 发布完整交付，M81 由另一人实际按说明接手，M82 解释自己的贡献、来源及未解决问题。

每个命令的完整参数见该节点 `practice/README.zh.md` 或 `code/README.zh.md` / `code/README.md`。`templates/evaluation-plan.json` 与根目录 `course_cli.py evaluate` 只用于早期计数练习，不是正式二十试次审核。正式完整性检查复用 M74 合同，不能只填几个成功计数就判定通过。

任务门槛是课程工程目标，仍需样机与试教检验。哈希校验只比较字节，不认证影像真实性；导师须检查现场和本人工作。合成夹具始终注明 synthetic，不能拿来申报实机成功。

## 7. 带走自己的工程作品

交付包括 CAD/STL/切片与实配记录、工位与标定、本人示范数据索引、划分、真实训练和恢复记录、候选模型与处理器、模型卡、执行网关配置、全部试次、失败分析和第三人交接记录。课程平台的提交不等于这些大文件已自动上传；权重和视频保存在本人批准的存储位置，提交实际索引与可核对摘要。

`files.sha256` 用于校验本实践包。`sources.json`、[版本差异说明](docs/UPSTREAM_VERIFICATION.zh.md) 与 `verification/` 说明来源和实际验证范围；上游源码快照保留原始许可。学生应分别说明引用、自己的设计、亲手采集、训练和测试，不把完整上游工程重新署名为原创。

## 可逐项核算的学习机制

`python learning_mechanics.py --demo` 输出明确标为 synthetic 的训练统计、两层 MLP 梯度、AdamW 状态、多头之前的单头注意力、潜变量重参数化、KL 和带填充动作的 L1 例子。`--mlp-data 本人片段.json` 支持注明来源的本人数据，不能把示例输出当本人训练结果。`tests/test_learning_mechanics.py` 用数值梯度和恢复状态检验计算。它是机制练习，不是完整 ACT、执行网关或真实机器人性能证明。

录制时必须参照 [固定版录制契约](docs/RECORDING_CONTRACT.zh.md)，分别保留两次 processor 处理结果，不把它们合成一个字段。
