#!/usr/bin/env python3
"""Package prior small-policy evidence and reproduce its gradient/training/validation path offline."""
import argparse,csv,hashlib,importlib.metadata,json,math,platform,shutil,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M45/code'))
from select_checkpoint import load_view,load_model,identity,evaluate,sha
from selection import decide

def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def resolve_input(base,value):
 if not isinstance(value,str) or not value.strip():raise ValueError('Expected a nonempty input path')
 p=(base/value).resolve()
 if not p.exists():raise ValueError('Missing input: '+str(p))
 return p
def inside(root,value):
 if not isinstance(value,str) or not value or Path(value).is_absolute():raise ValueError('Bundle path must be relative')
 path=(root/value).resolve()
 if not path.is_relative_to(root.resolve()):raise ValueError('Bundle path escapes root')
 return path
def copy_item(source,target):
 if source.is_dir():shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__','.DS_Store'))
 elif source.is_file():target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 else:raise ValueError('Input is not a regular file or directory')
def inventory(root):
 return [{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'bundle-manifest.json' and '__pycache__' not in p.parts]
def verify_bundle(root):
 root=Path(root).resolve();manifest=json.loads((root/'bundle-manifest.json').read_text())
 if not isinstance(manifest,dict) or manifest.get('schema')!='aloha.small-policy-bundle.v1' or not isinstance(manifest.get('files'),list):raise ValueError('Invalid bundle manifest')
 seen=set()
 for item in manifest['files']:
  if not isinstance(item,dict) or item.get('path') in seen:raise ValueError('Invalid/duplicate inventory entry')
  seen.add(item['path']);path=inside(root,item['path'])
  if not path.is_file() or path.stat().st_size!=item['bytes'] or sha(path)!=item['sha256']:raise ValueError('Bundle file differs: '+item['path'])
 for required in ('project.json','data/package/manifest.json','data/package/data/frames.jsonl','data/normalization.json','inputs/initial-model/model.json','inputs/reference-selection/selection.json','lessons/M43/code/gradient_check.py','lessons/M45/code/select_checkpoint.py'):
  if required not in seen:raise ValueError('Manifest omits a required project input: '+required)
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'bundle-manifest.json' and '__pycache__' not in p.parts}
 if actual!=seen:raise ValueError('Unlisted or missing files; preserve the frozen bundle and put new work outside it')
 return manifest

def pack(spec_file,output,allow_synthetic=False,lock_file=None):
 spec_path=Path(spec_file).resolve();spec=json.loads(spec_path.read_text());base=spec_path.parent
 if not isinstance(spec,dict) or spec.get('schema')!='aloha.small-policy-project.v1':raise ValueError('Use the supplied project specification schema')
 paths={k:resolve_input(base,spec.get(k)) for k in ('package','normalization','initial_model','selection_run','limitations')}
 if not paths['limitations'].is_file() or not paths['limitations'].read_text().strip():raise ValueError('Write a nonempty personal limitations card')
 train=load_view(paths['package'],paths['normalization'],'train',allow_synthetic);model,meta=load_model(paths['initial_model'],train)
 if meta.get('training_status')!='initialized_untrained':raise ValueError('Initial model must be the M42 untrained model')
 selection_dir=paths['selection_run'];selection=json.loads((selection_dir/'selection.json').read_text());protocol=json.loads((selection_dir/'plan.json').read_text())
 if selection.get('schema')!='aloha.validation-selection.v1' or selection.get('source')!=identity(train) or protocol.get('source')!=identity(train):raise ValueError('Selection source contract differs')
 if selection.get('status') not in ('budget_complete','early_stopped_at_declared_patience') or type(selection.get('completed_updates')) is not int or selection['completed_updates']<1:raise ValueError('Repair incomplete/failed selection attempt before capstone acceptance')
 if selection.get('plan_sha256')!=sha(selection_dir/'plan.json') or selection.get('initial_model_sha256')!=meta['checkpoint_sha256']:raise ValueError('Selection plan/initial model binding differs')
 selected=inside(selection_dir,selection.get('selected_directory'));selected_model,selected_meta=load_model(selected,train)
 if selection.get('selected_model_sha256')!=selected_meta['checkpoint_sha256']:raise ValueError('Selected parameter binding differs')
 records=[]
 with (selection_dir/'curves.csv').open(newline='') as f:
  for r in csv.DictReader(f):records.append({'step':int(r['step']),'train_mse':float(r['train_mse']),'validation_mse':float(r['validation_mse'])})
 decision=decide(records,protocol['rule'])
 if decision!=selection.get('selection'):raise ValueError('Selection rule and curves disagree')
 actual=evaluate(selected,train,load_view(paths['package'],paths['normalization'],'validation',allow_synthetic))
 if not math.isclose(actual['reports']['validation']['standardized_mse_all_cells'],decision['selected_validation_mse'],rel_tol=1e-12,abs_tol=1e-12):raise ValueError('Selected model does not reproduce its reported validation score')
 entries=spec.get('evidence');required={'M36','M38','M39','M40','M41','M43','M44'}
 if not isinstance(entries,list) or len(entries)!=len(required) or {e.get('module_id') for e in entries if isinstance(e,dict)}!=required:raise ValueError('Index exactly M36/M38/M39/M40/M41/M43/M44 prior artifacts; M37/M42/M45 are included automatically')
 evidence=[]
 for item in entries:
  src=resolve_input(base,item.get('path'));note=item.get('description')
  if not isinstance(note,str) or not note.strip():raise ValueError('Describe each prior artifact, not just its filename')
  evidence.append((item['module_id'],src,note))
 gradient_dir=next(p for mid,p,n in evidence if mid=='M43');gradient=json.loads((gradient_dir/'gradient-check.json').read_text())
 if gradient.get('source')!=identity(train) or gradient.get('parameter_checkpoint_sha256')!=meta['checkpoint_sha256'] or gradient.get('all_checked_parameters_pass') is not True or gradient.get('fault') is not None:raise ValueError('M43 evidence must be the successful complete check of this initial model and source')
 frame=gradient['frame']
 if len([r for r in train['rows'] if r['episode_id']==frame['episode_id'] and r['frame_index']==frame['frame_index']])!=1:raise ValueError('Gradient evidence must identify exactly one train frame')
 out=Path(output).resolve()
 if out.exists():raise FileExistsError('Choose a new bundle directory')
 source_root=Path(__file__).resolve().parents[2];default_root=source_root.parent
 lock=Path(lock_file or default_root/'research/lerobot/uv.lock')
 if not lock.is_file():raise ValueError('Provide the fixed official uv.lock')
 # Never create a recursive copy by placing the bundle inside one of its source folders.
 for p in [paths['package'],paths['initial_model'],paths['selection_run']]+[p for _,p,_ in evidence]:
  if p.is_dir() and out.is_relative_to(p):raise ValueError('Bundle directory must be outside every copied input directory')
 out.mkdir(parents=True);(out/'data/package/data').mkdir(parents=True);(out/'inputs').mkdir();(out/'evidence').mkdir();(out/'research/lerobot').mkdir(parents=True)
 shutil.copy2(paths['package']/'manifest.json',out/'data/package/manifest.json');shutil.copy2(paths['package']/'data/frames.jsonl',out/'data/package/data/frames.jsonl');shutil.copy2(paths['normalization'],out/'data/normalization.json');copy_item(paths['initial_model'],out/'inputs/initial-model');copy_item(selection_dir,out/'inputs/reference-selection');shutil.copy2(paths['limitations'],out/'limitations.md');shutil.copy2(lock,out/'research/lerobot/uv.lock')
 index=[]
 for mid,src,note in evidence:
  target=out/'evidence'/mid/src.name;target.parent.mkdir(parents=True,exist_ok=True);copy_item(src,target);index.append({'module_id':mid,'path':target.relative_to(out).as_posix(),'description':note,'validation':'existence, bytes and declared relationship; peer still reads content'})
 index.extend([{'module_id':'M37','path':'data/normalization.json','description':'Training-fitted normalization; source and statistics rechecked by loader'},{'module_id':'M42','path':'inputs/initial-model','description':'Initial network and full forward trace'},{'module_id':'M45','path':'inputs/reference-selection','description':'All selection segments, evaluations, plan and selected real weights'}]);index.sort(key=lambda e:e['module_id']);dump(out/'evidence-index.json',index)
 for mid in ['M35']+[f'M{i:02d}' for i in range(36,47)]:
  source=source_root/mid/'code'
  if not source.is_dir():raise ValueError('Required course code missing: '+mid)
  copy_item(source,out/'lessons'/mid/'code')
 docs=default_root/'docs/ENVIRONMENT.zh.md'
 if not docs.is_file():docs=default_root/'practice-kit/docs/ENVIRONMENT.zh.md'
 if docs.is_file():copy_item(docs,out/'docs/ENVIRONMENT.zh.md')
 project={'schema':'aloha.small-policy-reproduce.v1','source':identity(train),'gradient_frame':{k:frame[k] for k in ('episode_id','frame_index')},'reference_plan':'inputs/reference-selection/plan.json','reference_selection':'inputs/reference-selection/selection.json','reference_curves':'inputs/reference-selection/curves.csv','initial_model':'inputs/initial-model','package':'data/package','normalization':'data/normalization.json','limitations':'limitations.md','scope':'12-state ReLU baseline only; no images, ACT, hardware or final test metric','evidence_status':'assembled; peer explanation and separate-environment run remain required'};dump(out/'project.json',project)
 (out/'REPRODUCE.zh.md').write_text('''# 在新目录复跑本人小策略

先读 docs/ENVIRONMENT.zh.md，按固定版本安装已有环境；本包没有自动安装或联网操作。保留本人 data 与 inputs，不把它们替换为公开示意数据。进入本包根目录后运行：

```sh
python lessons/M46/code/baseline_project.py verify .
python lessons/M46/code/baseline_project.py reproduce . --out ../small-policy-rerun-01
```

输出为新的梯度核验、按原计划训练/验证、环境与比较报告。脚本只做离线计算，不连接机器人。先检查完整日志与状态，再解释结果；同机临时目录不叫第二台机器验证。跨环境可能有舍入差，报告保留预声明的绝对/相对容差，不追认未发生的位级一致。

evidence-index.json把M36–45前作接起来；文件存在和散列匹配只能说明包内字节，不能自动证明每份手算与实物记录真实。由本人和同伴沿一帧说明输入、预测、损失、梯度、更新与所选文件。limitations.md保留本人能力边界。完整测试仍封存，低误差不代表闭环操作成功。
''')
 manifest={'schema':'aloha.small-policy-bundle.v1','source':identity(train),'files':inventory(out),'status':'assembled_not_peer_accepted','network_execution':False,'test_used_for_metrics':False};dump(out/'bundle-manifest.json',manifest);verify_bundle(out)
 return {'status':'assembled_not_peer_accepted','bundle':str(out),'files':len(manifest['files']),'provenance':train['provenance'],'selected_step':decision['selected_step']}

def reproduce(bundle,output,allow_synthetic=False,atol=1e-9,rtol=1e-7):
 if any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in (atol,rtol)):raise ValueError('Declare nonnegative finite tolerances')
 root=Path(bundle).resolve();manifest=verify_bundle(root);project=json.loads((root/'project.json').read_text());plan=json.loads(inside(root,project['reference_plan']).read_text());out=Path(output).resolve()
 if out.exists() or out.is_relative_to(root):raise ValueError('Choose a new output directory outside the frozen bundle')
 out.mkdir(parents=True);logs=[]
 dump(out/'reproduction-plan.json',{'schema':'aloha.small-policy-rerun-plan.v1','bundle_manifest_sha256':sha(root/'bundle-manifest.json'),'atol':atol,'rtol':rtol,'written_before_subprocesses':True,'source':project['source']})
 def command(name,args):
  process=subprocess.run([sys.executable]+[str(a) for a in args],cwd=root,capture_output=True,text=True)
  (out/(name+'.stdout.txt')).write_text(process.stdout);(out/(name+'.stderr.txt')).write_text(process.stderr);logs.append({'name':name,'returncode':process.returncode,'argv':[str(a) for a in args]});return process.returncode
 common=[inside(root,project[k]) for k in ('package','normalization','initial_model')];extra=['--allow-synthetic'] if allow_synthetic else []
 frame=project['gradient_frame'];gradient_code=root/'lessons/M43/code/gradient_check.py';rc=command('gradient',[gradient_code,*common,'--out',out/'gradient','--episode',frame['episode_id'],'--frame',frame['frame_index'],*extra])
 status='gradient_requires_review';selection_rc=None
 if rc==0:
  rule=plan['rule'];cfg=plan['optimizer'];selection_rc=command('selection',[root/'lessons/M45/code/select_checkpoint.py',*common,'--out',out/'selection','--attempt-id','reproduction-of-'+plan['attempt_id'][:50],'--attempt-number',plan['self_reported_attempt_number'],'--max-steps',rule['max_steps'],'--every',rule['evaluate_every_steps'],'--patience',rule['patience_events'],'--min-delta',rule['min_delta'],'--optimizer',cfg['kind'],'--lr',cfg['lr'],'--weight-decay',cfg['weight_decay'],'--batch-size',plan['batch_size'],'--seed',plan['seed'],'--lock-file',root/'research/lerobot/uv.lock',*extra]);status='training_requires_review' if selection_rc else 'completed_finite_run'
 comparison=None
 if status=='completed_finite_run':
  def curves(path):
   with path.open(newline='') as f:return [{'step':int(r['step']),**{k:float(r[k]) for k in ('train_mse','validation_mse')}} for r in csv.DictReader(f)]
  old=curves(inside(root,project['reference_curves']));new=curves(out/'selection/curves.csv');same_steps=[r['step'] for r in old]==[r['step'] for r in new];differences=[]
  if same_steps:
   for a,b in zip(old,new):
    for key in ('train_mse','validation_mse'):
     bound=atol+rtol*max(abs(a[key]),abs(b[key]));differences.append({'step':a['step'],'metric':key,'reference':a[key],'reproduced':b[key],'absolute_difference':abs(a[key]-b[key]),'bound':bound,'within_tolerance':math.isfinite(b[key]) and abs(a[key]-b[key])<=bound})
  old_selection=json.loads(inside(root,project['reference_selection']).read_text());new_selection=json.loads((out/'selection/selection.json').read_text());same_choice=old_selection['selection']['selected_step']==new_selection['selection']['selected_step']
  comparison={'same_observed_steps':same_steps,'same_selected_step':same_choice,'reference_selected_step':old_selection['selection']['selected_step'],'reproduced_selected_step':new_selection['selection']['selected_step'],'differences':differences,'all_within_tolerance':same_steps and all(r['within_tolerance'] for r in differences),'note':'Different close candidates may require human review; no claim of cross-platform bitwise identity.'}
  if not comparison['all_within_tolerance'] or not same_choice:status='completed_finite_run_difference_requires_review'
 report={'schema':'aloha.small-policy-reproduction.v1','status':status,'source':project['source'],'bundle_manifest_sha256':sha(root/'bundle-manifest.json'),'reproduction_plan_sha256':sha(out/'reproduction-plan.json'),'tolerances_declared_before_comparison':{'atol':atol,'rtol':rtol},'commands':logs,'comparison':comparison,'environment':{'python':sys.version,'platform':platform.platform(),'packages':{k:importlib.metadata.version(k) for k in ('torch','safetensors')}},'hardware_executed':False,'test_used_for_metrics':False,'peer_acceptance':'human still checks explanation and whether this is a genuinely separate environment'};dump(out/'reproduction.json',report)
 return report
def main():
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 a=sub.add_parser('pack');a.add_argument('spec');a.add_argument('--out',required=True);a.add_argument('--lock-file');a.add_argument('--allow-synthetic',action='store_true')
 a=sub.add_parser('verify');a.add_argument('bundle')
 a=sub.add_parser('reproduce');a.add_argument('bundle');a.add_argument('--out',required=True);a.add_argument('--atol',type=float,default=1e-9);a.add_argument('--rtol',type=float,default=1e-7);a.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
 try:
  if a.command=='pack':r=pack(a.spec,a.out,a.allow_synthetic,a.lock_file)
  elif a.command=='verify':m=verify_bundle(a.bundle);r={'status':'listed_file_digests_match','files':len(m['files']),'does_not_authenticate_learner_or_hardware':True}
  else:r=reproduce(a.bundle,a.out,a.allow_synthetic,a.atol,a.rtol)
  print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if a.command!='reproduce' or r['status']=='completed_finite_run' else 1
 except (OSError,ValueError,KeyError,TypeError,ImportError,OverflowError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':raise SystemExit(main())
