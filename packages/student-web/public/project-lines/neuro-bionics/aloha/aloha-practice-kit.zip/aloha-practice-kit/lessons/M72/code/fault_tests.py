"""Offline fault injection into the actual course ExecutionGateway. No drivers.
All timestamps, joint states and send callbacks here are synthetic fixtures.
"""
import argparse,json,sys,math
from pathlib import Path
P=Path(__file__).resolve();KIT=next((p for p in (P.parents[3]/'practice-kit',P.parents[3])if(p/'execution_gateway.py').is_file()),None)
if KIT is None:raise RuntimeError('Use the complete practice-kit')
sys.path.insert(0,str(KIT));from execution_gateway import ExecutionGateway,Bound,RejectedCommand

def run_case(fault):
 moment=[10.];sent=[];stops=[]
 def clock():moment[0]+=.001;return moment[0]
 def send(target):
  sent.append(dict(target))
  if fault=='partial_send':raise OSError('synthetic right write failed; left may have received')
  return target
 def stop():
  stops.append('attempted')
  if fault=='stop_callback':raise OSError('synthetic serial stop unavailable')
 g=ExecutionGateway({'joint':Bound(0,60,2,10)},.1,send,stop,clock,('front','overhead'))
 g.arm_after_manual_checks(stop_test_reference='synthetic-only',configuration_reference='synthetic-only',clear_workspace=True)
 err=None;recovery_rejected=False
 try:
  t=clock();g.submit({'joint':10},{'joint':10},sequence=0,observation_arrival_s=t,camera_arrival_s={'front':t,'overhead':t},source='policy',communication_ok=True)
  t=clock();targets={'joint':float('nan')if fault=='nonfinite'else 10.};measured={'joint':10.};cams={'front':t,'overhead':t-(1 if fault=='stale_camera'else 0)}
  if fault=='missing_field':targets={}
  g.submit(targets,measured,sequence=0 if fault=='repeat_sequence'else 1,observation_arrival_s=t,camera_arrival_s=cams,source='unknown'if fault=='unknown_source'else'policy',communication_ok=False if fault=='communication'else True)
 except RejectedCommand as exc:err=str(exc)
 if g.state!='latched':
  try:g.trip('planned end of synthetic fixture')
  except RejectedCommand:pass
 try:
  t=clock();g.submit({'joint':10},{'joint':10},sequence=2,observation_arrival_s=t,camera_arrival_s={'front':t,'overhead':t},source='policy',communication_ok=True)
 except RejectedCommand:recovery_rejected=True
 expected=2 if fault in ('normal','stop_callback')else 1
 assert len(sent)==expected and g.state=='latched'and recovery_rejected and len(stops)==1
 if fault=='stop_callback':assert not g.events[-1]['stop_callback_returned']
 return {'fault':fault,'status':'pass','source_kind':'synthetic_fixture','events':g.events,'send_callback_calls':len(sent),'stop_callback_calls':len(stops),'auto_recovery_rejected':recovery_rejected,'caught_error':err,'physical_stop_observed':False,'partial_send_semantics':'callback entry may have a physical effect before throwing; this fixture opens no hardware'}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True);a=p.parse_args()
 report={'schema':'aloha.gateway-fault-report.v1','source_kind':'synthetic_fixture','hardware_opened':False,'cases':[run_case(x)for x in ('normal','stale_camera','communication','nonfinite','missing_field','repeat_sequence','unknown_source','partial_send','stop_callback')]}
 with Path(a.output).open('x')as f:json.dump(report,f,indent=2,allow_nan=False)
 print('PASS: 9 software cases; no hardware or physical-stop certification')
if __name__=='__main__':main()
