"""One supervised ACT -> ExecutionGateway -> pinned BiSOFollower entry.

Importing this file never opens a device. CLI `run` opens hardware only after
explicit local stop-test and supervisor records match the exact current files.
This is a teaching guard, not an independent hardware watchdog. A blocked process
or failed serial stop still requires the trained supervisor's physical cutoff.
"""
import argparse,sys,time,json,uuid,math
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve();LESSONS=HERE.parents[2]
sys.path.insert(0,str(LESSONS/'M67/code'));sys.path.insert(0,str(LESSONS/'M69/code'));sys.path.insert(0,str(LESSONS/'M71/code'))
# Authored tree versus packaged lessons/M72/code layout.
KIT=next((p for p in (HERE.parents[3]/'practice-kit',HERE.parents[3]) if (p/'execution_gateway.py').is_file()),None)
if KIT is None:raise RuntimeError('Run from the complete practice-kit with execution_gateway.py')
sys.path.insert(0,str(KIT))
from execution_gateway import ExecutionGateway,Bound,RejectedCommand
from course_contract import FIELDS,UNITS,finite,text,read,sha,child,verify_inventory,write_new
from act_runtime import load_runtime
from host_observation import camera_snapshot,observation_tensors,camera_configs

def utc():return datetime.now(timezone.utc).isoformat()
def require(ok,message):
 if not ok:raise ValueError(message)

def validate_config(config):
 require(config.get('schema')=='aloha.deployment-config.v1','deployment schema required')
 require(config.get('action_fields')==FIELDS and config.get('action_units')==UNITS,'exact native mixed-unit field order required')
 require(config.get('action_semantics')=='teleop_action_processor target','original action semantics required')
 require(set(config['bounds'])==set(FIELDS),'all twelve measured bounds required')
 bounds={}
 for key,row in config['bounds'].items():
  require(set(row)=={'minimum','maximum','relative_to_measured','command_rate_per_second'},'explicit measured bounds/rate required')
  require(finite(row['command_rate_per_second'])and row['command_rate_per_second']>0,'positive approved rate required')
  b=Bound(**row);b.validate();bounds[key]=b
 for key in ('max_age_s','period_s'):
  require(finite(config.get(key))and config[key]>0,'positive '+key+' required')
 require(type(config.get('max_steps'))is int and config['max_steps']>0,'finite run length required')
 require(text(config.get('hardware_revision')),'hardware revision required')
 r=config['robot'];require(set(r)=={'id','calibration_dir','left_port','right_port'},'explicit robot ID, ports and calibration path required')
 require(all(text(v) for v in r.values()) and r['left_port']!=r['right_port'],'nonempty distinct ports required')
 require(Path(r['calibration_dir']).is_absolute(),'absolute calibration directory required')
 require(set(config['cameras'])=={'front','overhead'},'two camera names required')
 return bounds

def check_context(root,config_path,model_path,hardware_path,*,start_path=None,attempt_id=None,operator=None):
 root=Path(root).resolve();config_path=Path(config_path).resolve();model_path=Path(model_path).resolve();hardware_path=Path(hardware_path).resolve()
 require(all(p.is_relative_to(root) for p in (config_path,model_path,hardware_path)),'version files must be inside artifact root')
 config=read(config_path);validate_config(config);model=read(model_path);hardware=read(hardware_path)
 require(model.get('schema')=='aloha.act-model-manifest.v1' and model.get('source_kind')=='learner_recording','physical entry needs original learner-trained model manifest')
 verify_inventory(root,model['files']);verify_inventory(root,hardware['files'])
 calibration=Path(config['robot']['calibration_dir']).resolve()
 require(calibration.is_relative_to(root),'calibration files must be retained inside artifact root')
 known={str(child(root,r['path'])) for r in hardware['files']}
 for side in ('left','right'):
  require(str(calibration/(config['robot']['id']+'_'+side+'.json'))in known,'hardware inventory must bind both actual calibration files')
 versions={'model_manifest_sha256':sha(model_path),'hardware_manifest_sha256':sha(hardware_path),'config_sha256':sha(config_path)}
 if start_path is not None:
  start_path=Path(start_path).resolve();require(start_path.is_relative_to(root),'start outside artifact root')
  start=read(start_path)
  require(start.get('schema')=='aloha.execution-record.v1'and start.get('status')=='open'and start.get('source_kind')=='learner_recording','original open learner start required')
  require(not start_path.with_name('closed.json').exists(),'this run already closed')
  sys.path.insert(0,str(LESSONS/'M74/code'))
  from evaluation_audit import actual_versions
  actual,_=actual_versions(root,start['version_artifacts'])
  require(actual==start['observed_versions']and all(actual[k]==v for k,v in versions.items()),'five current version hashes differ from M75 start')
  require(sha(child(root,start['plan_path']))==start['plan_sha256'],'plan changed after start')
  return config,dict(start,start_record_ref={'path':str(start_path.relative_to(root)),'sha256':sha(start_path)})
 require(text(attempt_id)and text(operator),'development attempt and supervisor/operator required')
 return config,{'schema':'aloha.deployment-development.v1','run_id':uuid.uuid4().hex,'trial_id':attempt_id,'purpose':'development','operator':operator,'source_kind':'learner_recording','observed_versions':versions,'opened_at':utc()}

def verify_authorization(root,context,stop_path,approval_path):
 stop=read(stop_path);a=read(approval_path);v=context['observed_versions']
 for obj in (stop,a):
  require(obj.get('hardware_manifest_sha256')==v['hardware_manifest_sha256']and obj.get('config_sha256')==v['config_sha256'],'on-site record differs from current hardware/config')
  require(text(obj.get('supervisor'))and text(obj.get('observed_at')),'human observer/date required')
 require(stop.get('schema')=='aloha.on-site-stop-test.v1'and stop.get('supervisor_observed_stop')is True,'complete actual on-site stop test first')
 require(text(stop.get('test_method'))and text(stop.get('recovery_check')),'retain test method and deliberate recovery check')
 require(isinstance(stop.get('evidence'),list)and stop['evidence'],'on-site raw evidence inventory required');verify_inventory(root,stop['evidence'])
 require(a.get('schema')=='aloha.supervised-run-approval.v1' and a.get('run_id')==context['run_id'],'approval must identify this run')
 require(a.get('stop_test_sha256')==sha(stop_path),'approval must bind the exact stop test')
 for key in ('workspace_clear','rest_supports_ready','physical_cutoff_accessible','leader_task_input_disabled','connection_may_enable_torque_understood'):
  require(a.get(key)is True,'explicit supervisor check missing: '+key)
 return {'stop_test_reference':str(stop_path)+'#sha256='+sha(stop_path),'configuration_reference':'sha256='+v['config_sha256']}

class PinnedHardware:
 """Explicit real driver adapter. No invented simultaneous action or exposure."""
 def __init__(self,config):
  from lerobot.robots.bi_so_follower.config_bi_so_follower import BiSOFollowerConfig
  from lerobot.robots.so_follower.config_so_follower import SOFollowerConfig
  from lerobot.robots.utils import make_robot_from_config
  r=config['robot'];arms={}
  for side in ('left','right'):
   relative={key.removeprefix(side+'_').removesuffix('.pos'):row['relative_to_measured']for key,row in config['bounds'].items()if key.startswith(side+'_')}
   arms[side]=SOFollowerConfig(port=r[side+'_port'],use_degrees=True,disable_torque_on_disconnect=True,max_relative_target=relative)
  c=BiSOFollowerConfig(id=r['id'],calibration_dir=Path(r['calibration_dir']),left_arm_config=arms['left'],right_arm_config=arms['right'],cameras=camera_configs(config['cameras']))
  self.robot=make_robot_from_config(c);self.arms=[self.robot.left_arm,self.robot.right_arm]
 def connect(self):
  # Pinned arm.connect/configure can enable torque. Never use this in M71.
  # Calibration must already exist; do not trigger interactive recalibration.
  for arm in self.arms:
   require(bool(arm.calibration),'existing calibration file required')
  for arm in self.arms:arm.bus.connect()
  for arm in self.arms:
   require(arm.is_calibrated,'motor calibration differs from retained file; stop and recalibrate separately')
  for arm in self.arms:
   for camera in arm.cameras.values():camera.connect()
  for arm in self.arms:arm.configure()
 def observe(self):
  state={};arrivals={}
  for side,arm in zip(('left','right'),self.arms):
   values=arm.bus.sync_read('Present_Position',num_retry=arm.config.num_read_retries);arrivals[side]=time.perf_counter()
   state.update({side+'_'+k+'.pos':v for k,v in values.items()})
  frames={};stamps={}
  for name in ('front','overhead'):frames[name],stamps[name]=camera_snapshot(self.robot.cameras[name])
  return observation_tensors(state,frames),state,min(arrivals.values()),stamps,arrivals
 def send(self,action):return self.robot.send_action(action)
 def stop(self):
  errors=[]
  for side,arm in zip(('left','right'),self.arms):
   try:
    if arm.bus.is_connected:arm.bus.disable_torque()
   except Exception as exc:errors.append(side+': '+repr(exc))
  if errors:raise RuntimeError('; '.join(errors))
 def close(self):
  errors=[]
  # Each bus/camera closes independently even after partial connection failure.
  for side,arm in zip(('left','right'),self.arms):
   try:
    if arm.bus.is_connected:arm.bus.disconnect(disable_torque=True)
   except Exception as exc:errors.append(side+': '+repr(exc))
   for camera in arm.cameras.values():
    try:
     if camera.is_connected:camera.disconnect()
    except Exception as exc:errors.append('camera: '+repr(exc))
  return errors

def execute(runtime,hardware,config,context,references,output,*,clock=time.perf_counter,sleeper=time.sleep):
 """Actual loop; injectable boundaries permit software fault tests, not certification.
 Output folder must be new. Final human observation is added by `attest`, never
 assigned True automatically. All normal and exceptional exits retain raw events.
 """
 output=Path(output);output.mkdir(parents=True,exist_ok=False)
 require(runtime.model_manifest_sha256==context['observed_versions']['model_manifest_sha256'],'runtime differs from bound model')
 gateway=ExecutionGateway(validate_config(config),config['max_age_s'],hardware.send,hardware.stop,clock=clock,required_cameras=('front','overhead'))
 trace=[];error=None;cleanup=[];began=utc()
 write_new(output/'context.json',context)
 try:
  runtime.reset();hardware.connect();gateway.arm_after_manual_checks(**references,clear_workspace=True)
  with(output/'events-prefix.jsonl').open('x')as f:f.write(json.dumps(gateway.events[-1],allow_nan=False)+'\n')
  for sequence in range(config['max_steps']):
   begin=clock();obs,measured,arrived,camera_arrivals,arm_arrivals=hardware.observe()
   action,timing=runtime.profile_action(obs,clock=clock);values=action.tolist()
   require(len(values)==12 and all(finite(x)for x in values),'invalid policy action')
   event=gateway.submit(dict(zip(FIELDS,values)),measured,sequence=sequence,observation_arrival_s=arrived,camera_arrival_s=camera_arrivals,source='policy',communication_ok=True)
   trace.append({'sequence':sequence,'state_arrivals_s':arm_arrivals,'camera_arrivals_s':camera_arrivals,'policy_timing':timing,'loop_s':clock()-begin,'gateway_event_index':len(gateway.events)-1})
   # Persist every finished native event: a crash still retains the prefix.
   with(output/'events-prefix.jsonl').open('a')as f:f.write(json.dumps(event,allow_nan=False)+'\n');f.flush()
   sleeper(max(0,config['period_s']-(clock()-begin)))
 except BaseException as exc:error=type(exc).__name__+': '+str(exc)
 finally:
  if not gateway.events or gateway.events[-1].get('event')!='latched':
   try:gateway.trip(error or 'planned end of run')
   except RejectedCommand:pass
  if not gateway.events[-1].get('stop_callback_returned')and error is None:error='StopCallbackFailure: software stop did not return; physical observation still required'
  cleanup=hardware.close()
  wrapper={'schema':'aloha.gateway-log.v1','run_id':context['run_id'],'attempt_id':context['trial_id'],'policy_artifact_sha256':runtime.model_manifest_sha256,'hardware_manifest_sha256':context['observed_versions']['hardware_manifest_sha256'],'hardware_revision':config['hardware_revision'],'source_kind':'learner_policy_execution' if context['source_kind']=='learner_recording'else'synthetic_fixture','events':gateway.events,'termination':{'reason':error or 'planned end of run','gateway_event_index':len(gateway.events)-1,'supervisor_observed_stop':False,'note':'PENDING: supervisor must record actual physical observation; callback return is insufficient'},'clock':{'monotonic_scope':'one_process','wall_time_source':'host_clock','wall_started_at':began},'cleanup_errors':cleanup,'error':error}
  write_new(output/'gateway.raw.json',wrapper);write_new(output/'timing.json',trace)
 return wrapper

def attest(raw_path,observation_path,output):
 """Combine immutable raw events with a separately authored human observation."""
 raw=read(raw_path);obs=read(observation_path)
 require(obs.get('schema')=='aloha.stop-observation.v1'and obs.get('run_id')==raw['run_id'],'human observation must identify this run')
 require(obs.get('raw_gateway_sha256')==sha(raw_path),'human observation must bind exact raw events')
 require(type(obs.get('supervisor_observed_stop'))is bool and text(obs.get('supervisor'))and text(obs.get('note')),'explicit observer, boolean and note required')
 raw['termination']['supervisor_observed_stop']=obs['supervisor_observed_stop'];raw['termination']['note']=obs['note'];raw['stop_observation_ref']={'path':str(Path(observation_path).resolve()),'sha256':sha(observation_path)};raw['raw_gateway_sha256']=sha(raw_path)
 write_new(output,raw);return raw

def main():
 p=argparse.ArgumentParser(description=__doc__);subs=p.add_subparsers(dest='command',required=True)
 a=subs.add_parser('prepare')
 for key in ('root','config','manifest','hardware','output'):a.add_argument('--'+key,required=True)
 a.add_argument('--start');a.add_argument('--attempt');a.add_argument('--operator')
 a=subs.add_parser('run')
 for key in ('root','config','manifest','hardware','context','pretrained','checkout','stop-test','approval','output'):a.add_argument('--'+key,required=True)
 a.add_argument('--device',choices=['cpu','cuda'],default='cpu');a.add_argument('--start')
 a=subs.add_parser('attest')
 for key in ('raw','observation','output'):a.add_argument('--'+key,required=True)
 a=p.parse_args()
 if a.command=='attest':attest(a.raw,a.observation,a.output);return
 if a.command=='prepare':
  _,context=check_context(a.root,a.config,a.manifest,a.hardware,start_path=a.start,attempt_id=a.attempt,operator=a.operator);write_new(a.output,context);print(context['run_id']);return
 context=read(a.context)
 config,current=check_context(a.root,a.config,a.manifest,a.hardware,start_path=a.start,attempt_id=context['trial_id'],operator=context['operator'])
 require(current['observed_versions']==context['observed_versions'],'versions changed after preparation')
 if a.start:require(current['run_id']==context['run_id'],'another M75 run supplied')
 else:require(context.get('schema')=='aloha.deployment-development.v1'and context.get('purpose')=='development','formal run requires original --start')
 refs=verify_authorization(a.root,context,a.stop_test,a.approval)
 runtime=load_runtime(a.pretrained,a.checkout,a.device,model_manifest=a.manifest,artifact_root=a.root)
 hardware=PinnedHardware(config)
 result=execute(runtime,hardware,config,context,refs,a.output)
 print(json.dumps({'run_id':context['run_id'],'raw':str(Path(a.output)/'gateway.raw.json'),'error':result['error'],'physical_stop_observation':'pending'},ensure_ascii=False))
 if result['error']or result['cleanup_errors']:raise SystemExit(2)
if __name__=='__main__':main()
