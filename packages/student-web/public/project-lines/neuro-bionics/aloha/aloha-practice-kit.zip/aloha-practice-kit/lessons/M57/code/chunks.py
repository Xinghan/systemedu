"""Build traceable within-episode chunks from an explicit exported JSON manifest.
Images remain references to CURRENT observation files; this tool does not decode them.
"""
import argparse,json,math,sys
from pathlib import Path
def finite_row(row,width):
    return isinstance(row,list) and len(row)==width and all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in row)
def make_batch(data,requests,length):
    if data.get('provenance') not in ('synthetic','learner_recording') or not data.get('source_ref'):raise ValueError('Declare provenance and source_ref')
    fields=data['action_fields'];state_fields=data['state_fields']
    if not fields or len(fields)!=len(set(fields)) or not state_fields or len(state_fields)!=len(set(state_fields)):raise ValueError('Explicit unique fields required')
    if type(length) is not int or length<1 or not requests:raise ValueError('Positive chunk and nonempty batch required')
    episodes={}
    for ep in data['episodes']:
        eid=ep['episode_id']
        if not isinstance(eid,str) or not eid or eid in episodes or not ep.get('source_ref') or not ep['frames'] or ep.get('complete_episode') is not True:raise ValueError('Unique nonempty complete episodes with source required; missing export rows are not episode end')
        frames=ep['frames']
        for i,r in enumerate(frames):
            if r['frame_index']!=i or not finite_row(r['action'],len(fields)) or not finite_row(r['observation_state'],len(state_fields)):raise ValueError('Contiguous frame indices and finite fixed-width fields required')
        episodes[eid]=ep
    output=[]
    for req in requests:
        ep=episodes[req['episode_id']];s=req['start']
        if type(s) is not int or not 0<=s<len(ep['frames']):raise ValueError('Start outside episode')
        current=ep['frames'][s];actions=[];mask=[];trace=[]
        for offset in range(length):
            index=s+offset;pad=index>=len(ep['frames']);origin=min(index,len(ep['frames'])-1)
            actions.append(ep['frames'][origin]['action'].copy());mask.append(pad)
            trace.append({'chunk_offset':offset,'source_episode':ep['episode_id'],'source_frame':origin,'is_pad':pad,'requested_frame':index,'valid_label':not pad})
        output.append({'episode_id':ep['episode_id'],'current_frame':s,'source_ref':ep['source_ref'],'observation_state':current['observation_state'].copy(),'current_image_refs':current.get('image_refs',{}),'actions':actions,'action_is_pad':mask,'trace':trace})
    return {'provenance':data['provenance'],'source_ref':data['source_ref'],'shape':[len(output),length,len(fields)],'action_fields':fields,'state_fields':state_fields,'batch':output,'hardware_executed':False,'boundary':'Teaching manifest slice. Padding repeats the final label but is excluded by mask. Does not decode cameras, normalize data, or replace native LeRobotDataset.'}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('--request',action='append',required=True,help='episode_id:start; repeat for a batch');p.add_argument('--length',type=int,required=True);a=p.parse_args();requests=[]
    for req in a.request:
        eid,start=req.rsplit(':',1);requests.append({'episode_id':eid,'start':int(start)})
    print(json.dumps(make_batch(json.loads(a.input.read_text()),requests,a.length),ensure_ascii=False,indent=2,allow_nan=False))
