import copy
import json
from pathlib import Path
import unittest
from controller import map_targets,validate

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.data=json.loads(Path(__file__).with_name('channels-example.json').read_text())
    def test_single_change_and_input_unchanged(self):
        before=copy.deepcopy(self.data)
        result=map_targets(self.data,step=3)
        self.assertEqual(result['changed_fields'],['left.shoulder_pan'])
        self.assertEqual(result['output']['fields'][0]['value'],3)
        self.assertEqual(self.data,before)
        self.assertFalse(result['hardware_output'])
    def test_missing(self):
        self.data['fields'].pop()
        with self.assertRaises(ValueError):map_targets(self.data)
    def test_wrong_unit(self):
        self.data['fields'][5]['unit']='deg'
        with self.assertRaises(ValueError):map_targets(self.data)
    def test_invalid_types_duplicates_and_numbers(self):
        for value in (True,'10',float('nan'),float('inf')):
            data=copy.deepcopy(self.data);data['fields'][0]['value']=value
            with self.subTest(value=value),self.assertRaises(ValueError):validate(data)
        self.data['fields'][1]['name']=self.data['fields'][0]['name']
        with self.assertRaises(ValueError):validate(self.data)
    def test_output_out_of_range(self):
        self.data['fields'][0]['value']=29
        with self.assertRaises(ValueError):map_targets(self.data,step=5)

if __name__=='__main__':unittest.main()
