# 标签索引练习

示例三行全是合成叙事，不是机器人实测。复制CSV到自己的目录，替换来源、身份、事件与证据。无标签可明确写none；未保存原生回合可在episode_index写not_saved并在理由中说明，不伪造编号。

```sh
python check_index.py episode-index.synthetic.csv
python -m unittest test_check_index.py -v
```

检查器不修改任何原始文件，不打开视频，也不证明标签正确。它只检查字段、身份唯一性和本节教学选择规则。当前规则要求候选为已复核、完整、成功、观察范围内无介入；这不是所有学习任务通用规则。若研究恢复策略，应另建任务与筛选版本。

CSV的训练候选不是train/validation/test划分，也不是模型成功率。来源、证据和标签字典仍需同伴复核。空值不能默认成为无人帮助或成功。

`episode_index` 为非负整数文本，或未保存尝试的 `not_saved`。未保存尝试保留档案但不能成为候选；检查失败时不返回可直接使用的候选清单。`none_observed` 仅表示声明观察视角内未观察到，不证明所有盲区均无介入。
