# M42：把一帧送过隐藏层

这是前向计算练习。新网络只是初始化，**没有训练**；M41 已训练模型仅列为旧基线参考，不能据此比较两种结构的训练后优劣。固定数值与绝对值例子标为 constructed synthetic，不冒充学习成果。程序不发送机器人命令。

在实践包根目录，继承 `docs/ENVIRONMENT.zh.md` 的固定训练环境，以及 M35 教学 JSONL 包、M37 normalization.json、M41 输出文件夹。M05 的标准库环境还不足以保存 safetensors；这里沿用 M41 已通过导入核验的环境，不另装未固定版本。

```sh
python -c "import torch, safetensors; print(torch.__version__, safetensors.__version__)"
python lessons/M42/code/forward_trace.py work/M35/package work/M37/normalization.json work/M41/linear --hidden 4 --seed 23 --out work/M42/forward-v1
```

路径替换为本人前作。默认选第一帧 train；需要另一帧时同时添加 `--episode 本人episode标识 --frame 该帧整数索引`。validation 与 test 不可选。输出目录必须尚不存在。

- `relu_network.py`：两次明确逐项乘加，中间逐项保留正数、非正数变零，输出层不再截零。
- `forward-trace.json`：输入、第一层逐项乘积、开关前数值、开关后激活、第二层乘积、预测与来源帧；同一参数去掉开关的对照也保留。
- `forward-trace.svg`：用本人选定帧数值直接绘制隐藏激活与全部输出表；浏览器打开，与 JSON 同源，不是机器人照片。
- `hidden-activations.csv`：逐个隐藏单元检查正负与激活；某帧为零不等于该单元对所有样本无用。
- `predictions.csv`：本帧目标、初始化网络、相同权重无开关、M41 旧训练基线。四列身份不能混淆。
- `model.safetensors` / `model.json`：初始参数及轴/来源/归一化身份，重新加载后核验前向完全一致。此处状态为 initialized_untrained。
- `synthetic-expressivity.json`：完整手算例与三个绝对值点，是构造出的表达能力反例，没有训练过程。
- `environment.json`：实际运行版本与代码摘要，并关联 M41 环境文件。随机种子只控制本代码的初始化，不保证跨版本/设备的完整训练都一致。

十二输入、四隐藏、十二输出共有48+4+48+12=112个参数。隐藏通道是计算中间值，不是新增四个物理关节。独立小随机权重与隐藏偏置0.05是本课选择，不称最佳初始化；输出偏置零，输出可为负标准分数。

先复算小例：输入2、−1；隐藏开关前2.2、−2；开关后2.2、0；最终2.3、0.35。保持全部权重，只去掉开关，结果3.3、−1.65。再复算本人轨迹的一条隐藏值和一条输出，记录字段与误差范围。源摘要冲突回前作匹配版本，缺环境回根文档，目录已存在另起名字。不要通过改名或删除旧证据绕过来源检查。
