"""M79: preserve V1 file identities and trace a single main revision."""
from evidence_files import read,inventory,references,text,run_cli

IMPACTS={'hardware','calibration','demonstrations','dataset','statistics','model','deployment','evaluation'}

def audit_revision(document,artifact_root):
    d=read(document)
    if d.get('schema')!='aloha.revision.v1':raise ValueError('Wrong revision schema')
    if d.get('source_kind') not in ('synthetic','learner_recording'):raise ValueError('Explicit source kind required')
    old=d['old_version'];new=d['new_version']
    if text(old['id'],'old version')==text(new['id'],'new version'):raise ValueError('Revision must have a new version ID')
    files=inventory(artifact_root,d['files'])
    references(old['archive_evidence'],files,'V1 archive')
    references(d['failure_observation']['evidence'],files,'failure observation')
    text(d['failure_observation']['observed'],'observed event');text(d['failure_observation']['hypothesis'],'hypothesis')
    change=d['main_change'];text(change['before'],'before');text(change['after'],'after');text(change['reason'],'reason')
    if change['before']==change['after']:raise ValueError('Main change is identical')
    references(change['evidence'],files,'change evidence')
    impacts=d['impacts']
    if {x['area'] for x in impacts}!=IMPACTS or len(impacts)!=len(IMPACTS):raise ValueError('All eight impact decisions required exactly once')
    pending=[]
    for x in impacts:
        if x['decision'] not in ('updated','checked_reuse','not_affected','pending'):raise ValueError('Unknown impact decision')
        text(x['reason'],'impact reason')
        if x['decision']=='pending':pending.append(x['area'])
        else:references(x['evidence'],files,x['area'])
    seen=set(d['seen_test_refs'])
    if not seen or any(not isinstance(x,str) or not x for x in seen):raise ValueError('Record seen test references')
    e=d['new_evaluation'];state=e['state']
    if state not in ('not_started','partial','complete'):raise ValueError('Unknown evaluation state')
    if state=='not_started':text(e['resume_next'],'resume next step')
    else:
        text(e['evaluation_id'],'new evaluation ID')
        if e['evaluation_id']==old['evaluation_id']:raise ValueError('Cannot reuse V1 evaluation ID')
        fresh=e['sealed_test_refs']
        if not isinstance(fresh,list) or not fresh or any(not isinstance(x,str) or not x for x in fresh):raise ValueError('Fresh test references required')
        if seen.intersection(fresh):raise ValueError('Seen test is development history, not fresh independent evidence')
        references(e['independence_evidence'],files,'independence process')
        references(e['evaluation_evidence'],files,'new evaluation')
    if state=='complete' and pending:raise ValueError('Complete evaluation claimed with unresolved dependency impacts')
    text(d['resume']['last_completed'],'last completed');text(d['resume']['next_step'],'next step')
    return {'structural_complete':True,'source_kind':d['source_kind'],'revision_state':state,'pending_impacts':pending,'version':new['id'],'performance_accepted':None,'errors':[],'truth_certified':False,'limits':'Checks declared IDs, files and relationships only. Freshness and causality require the recorded human review; no performance conclusion is inferred.'}

if __name__=='__main__':run_cli(audit_revision)
