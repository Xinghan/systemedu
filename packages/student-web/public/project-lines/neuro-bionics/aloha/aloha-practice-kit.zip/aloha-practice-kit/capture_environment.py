#!/usr/bin/env python3
"""Record local environment metadata only. No credential/env-variable collection."""
import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
from pathlib import Path
import platform
import sys

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output');a=p.parse_args();out=Path(a.output)
    if out.exists():p.error('Use a new file')
    packages=sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions()],key=lambda x:x['name'].lower())
    data={'captured_at':datetime.now(timezone.utc).isoformat(),'python':sys.version,'implementation':platform.python_implementation(),
          'platform':platform.platform(),'machine':platform.machine(),'packages':packages,
          'manual_fields':{'lerobot_git_rev_parse_HEAD':None,'SO_ARM100_revision':None,'gpu_model':None,'gpu_driver':None,'ffmpeg_version':None,'calibration_file_hashes':None},
          'note':'Package versions from this interpreter. Fill manual fields from actual local checks. No claim that hardware or GPU worked.'}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(out)
if __name__=='__main__':main()
