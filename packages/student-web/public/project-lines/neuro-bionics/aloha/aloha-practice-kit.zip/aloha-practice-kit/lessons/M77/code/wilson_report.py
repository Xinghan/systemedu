"""Explicit scalar Wilson derivation; real evaluation remains tied to its audit."""
from pathlib import Path
import sys,json,math,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M74/code'))
from evaluation_audit import audit_evaluation,read,sha

def wilson(k,n,z=1.96):
 if type(n) is not int or n<=0 or type(k) is not int or not 0<=k<=n:raise ValueError('Integer 0 <= successes <= positive n required')
 if type(z) not in (int,float) or not math.isfinite(z) or z<=0:raise ValueError('Positive finite z required')
 try:
  phat=k/n;A=n+z*z;B=-(2*n*phat+z*z);C=n*phat*phat
  if not all(math.isfinite(v) for v in (phat,A,B,C)):raise ValueError('Wilson coefficients overflow')
  centre=-(B/A)/2;square=centre*centre-C/A
 except OverflowError as exc:raise ValueError('Wilson numeric range exceeded') from exc
 if not all(math.isfinite(v) for v in (centre,square)):raise ValueError('Wilson completion of square overflow')
 if square < -1e-12:raise ValueError('Negative squared half-width')
 half=math.sqrt(max(0,square));lo=max(0,centre-half);hi=min(1,centre+half)
 if not all(math.isfinite(v) for v in (half,lo,hi)):raise ValueError('Wilson bounds overflow')
 return dict(k=k,n=n,sample_proportion=phat,z=z,A=A,B=B,C=C,centre=centre,squared_half_width=max(0,square),half_width=half,lower=lo,upper=hi,method='Wilson score inversion, normal approximation',assumptions=['Fixed n before results','Approximately independent Bernoulli outcomes','Common success probability within the modeled group'],not_a_guarantee=True)

def report(path,root):
 audited=audit_evaluation(path,root)
 if not audited['complete']:raise ValueError('Complete evidence required before final statistics: '+'; '.join(audited['errors']))
 d=read(path);conditions={}
 for row in audited['trials']:
  group=conditions.setdefault(row['condition'],{'k':0,'n':0});group['n']+=1;group['k']+=int(row['outcome']=='success')
 return {'schema':'aloha.wilson-report.v1','source_kind':d['source_kind'],'evaluation_sha256':sha(path),'overall':wilson(audited['successes'],20),'conditions':{key:wilson(**value) for key,value in conditions.items()},'interpretation':'If conditions are heterogeneous or runs correlated, intervals are sensitivity summaries under stated assumptions; no population guarantee or multiple-comparison test.','real_robot_truth_certified':False}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('evaluation');p.add_argument('--root',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=report(a.evaluation,a.root)
 with open(a.output,'x') as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
