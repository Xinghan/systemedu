# M44：小批更新、优化器记忆与精确续跑

继承 M35 本人包、M37 统计、M42 初始网络与 M43 已核验的梯度实现。先保留 M43 本人手推和正常/故障报告，才用这些方向训练。沿根 `docs/ENVIRONMENT.zh.md` 固定环境；输出保存实际运行版本和原始 `research/lerobot/uv.lock`，不称完整ACT/硬件已验证。

在实践包根目录，先用 SGD；路径替换为本人前作：

```sh
python lessons/M44/code/train_minibatch.py work/M35/package work/M37/normalization.json work/M42/forward-v1 --optimizer sgd --lr 0.01 --batch-size 8 --seed 17 --steps 20 --checkpoint-every 5 --out work/M44/sgd
```

batch-size 不可超过训练帧数；少于8帧就明确改小。每批新建梯度账本，按实际帧数乘12平均；最后不足一整批的样本照样使用。每个epoch从train索引无放回打乱，epoch只表示遍历一轮，不是一次更新。相关帧的小批噪声不等于独立的新试次；验证/test不参与训练或换尺。

从相同 M42 初始模型另起 AdamW 实验，不接在刚才SGD末尾冒充公平起点：

```sh
python lessons/M44/code/train_minibatch.py work/M35/package work/M37/normalization.json work/M42/forward-v1 --optimizer adamw --lr 0.01 --weight-decay 0.01 --batch-size 8 --seed 17 --steps 10 --checkpoint-every 5 --out work/M44/adamw-part1
python lessons/M44/code/train_minibatch.py work/M35/package work/M37/normalization.json work/M44/adamw-part1/checkpoints/step-000010 --resume --steps 10 --checkpoint-every 5 --out work/M44/adamw-part2
```

`--steps` 在恢复时表示**再进行多少次更新**。恢复继承保存的优化器种类、步长、双矩、计步、批大小、seed、实际顺序和游标；如果显式提供冲突选项就拒绝。为检验自己环境，另从同一个M42模型连续跑20步，与10+10恢复比较全部参数、优化器和采样状态。课程作者的软件夹具已核验，不代替本人文件。

默认 Adam/AdamW β1=0.9、β2=0.999、epsilon=1e-8。本课 AdamW 明确对**所有参数包括偏置**实施衰减，是透明演示策略；真实ACT参数分组以其配置为准。本工具 SGD 和 Adam 不加衰减，避免把耦合L2与AdamW概念混名。

- `optimizers.py`：原梯度更新一阶和平方移动平均，按当前计步校正；分母是校正平方平均的平方根加epsilon。AdamW独立减去旧参数乘步长乘衰减量，不把它塞进梯度记忆。
- `minibatch.py`：保存epoch、真实当前排列和cursor。下一轮按seed+epoch创建排列；不是只保存一个seed就声称恢复了任意断点。
- `checkpoints/step-N/model.safetensors` 与 `model.json`：模型参数与尺度/来源身份。
- 同目录 `training-state.json`：优化器双矩与计步、采样状态、完整更新历史、计算代码摘要。恢复校验来源、形状、非负平方平均及计步/游标一致。
- `first-update.json`：本次第一步所有参数的原值、梯度、双矩、校正、分母、梯度项、衰减项与新值，供本人选一项手算。
- `worked-optimizer-table.json`：固定梯度2、−1、1的三步示意，β均0.5、步长0.1、epsilon0.01、AdamW衰减0.1；是便于手算的公开设定，**不是默认值或本人训练结果**。
- `train-loss.csv`：每批更新前后在同一批上的均方损失；相邻行换了批次，不能把波动全部解释成模型退步。
- `checkpoints.json`、`latest.json`、`run.json`、`environment.json`：保存版本目录、状态与实际环境。M45将以固定完整train/validation再评各checkpoint。

异常候选更新不会提交：模型、优化器、采样游标同时保持最后有效状态，`run.json`保留失败批次与原因。恢复不是自动保证收敛；同一软件算术下逐值一致也不是跨机器/版本承诺。无需重新开放最终test来判断本节是否完成，更不能把低维ReLU模型称为完整视觉ACT策略。
