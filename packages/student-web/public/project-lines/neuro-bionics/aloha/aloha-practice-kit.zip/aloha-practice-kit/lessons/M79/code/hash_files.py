"""Print real relative file references; never create a success claim."""
import argparse,json
from evidence_files import contained,sha
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('paths',nargs='+');a=p.parse_args()
 print(json.dumps([{'id':'REPLACE_WITH_STABLE_ID','path':x,'sha256':sha(contained(a.root,x)),'kind':'REPLACE_WITH_EVIDENCE_KIND'} for x in a.paths],ensure_ascii=False,indent=2))
