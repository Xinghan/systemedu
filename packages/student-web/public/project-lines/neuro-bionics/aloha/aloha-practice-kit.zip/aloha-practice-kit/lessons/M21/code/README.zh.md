# M21 五轴局部坐标链

下载[实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)，进入 `lessons/M21/code/`。Python 3 标准库即可，所有操作离线且无设备连接。

运行 `python3 serial_fk.py synthetic-model.json --angles 0 0 0 0 0`。预期工具点 `[180,0,40] mm`，第五轴心 `[150,0,40]`。再运行 `python3 serial_fk.py synthetic-model.json --angles 90 0 0 0 0`，预期工具点约 `[0,180,40]`；极小浮点数视为数值零。

运行 `python3 serial_fk.py synthetic-model.json --scan > synthetic-cloud.json`，会产生243个离散候选点。这里所有长度、轴向与正负90度范围都是抽象合成夹具，**不是 SO101 安装尺寸或允许范围**。扫描既不证明连续可达，也不检查碰撞。

本人模型复制另存，`provenance` 写 `learner_measured`，用真实来源填写：世界到基座固定变换、五轴依序的名字/局部轴向/方向符号/零位/范围/固定安装变换，最后是工具参考点。单位统一。固定变换采用列坐标约定 `Trans * Rz * Ry * Rx`，作用到一个点时从右边开始；各关节先接固定安装，再接有效关节旋转。完整形式见本理论 K5。未知参数不能写0替代；先测量、确认约定再运行。

脚本可分析真实测量建立的模型，但模型准确性必须由本人独立非共面姿态验证。换附件应更新工具点；夹爪开合不塞进五关节角列表。输入超范围、缺少五轴或非有限数字会报错。若终端将报错重定向到输出文件，先检查退出状态，不能把空文件视为成功点云。
