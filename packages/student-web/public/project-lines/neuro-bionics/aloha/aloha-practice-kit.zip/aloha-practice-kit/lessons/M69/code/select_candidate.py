"""Select ONLY the predeclared candidates from complete matching validation reports."""
import argparse,json
from pathlib import Path
from export_predictions import validate_rule,score_rows,validation_rows
from course_contract import *

def select(rule_path,report_paths,output):
 rule=validate_rule(read(rule_path));reports=[read(p)for p in report_paths];ids=[r.get('candidate_id')for r in reports]
 if len(ids)!=len(set(ids))or set(ids)!=set(rule['candidates']):raise ValueError('all and only predeclared candidate reports required')
 view_path=local(rule['validation_view_path']);split_path=local(rule['split_manifest_path'])
 if sha(view_path)!=rule['validation_view_sha256']or sha(split_path)!=rule['split_sha256']:raise ValueError('frozen view or split bytes changed')
 expected_rows=validation_rows(read(view_path),read(split_path))
 reference={(r['episode_id'],r['frame_index'],FIELDS[j],UNITS[j],r['action'][j])for r in expected_rows for j in range(12)}
 scored=[]
 for path,r in zip(report_paths,reports):
  if r.get('schema')!='aloha.offline-action-pairs.v1'or r.get('purpose')!='development':raise ValueError('development report required')
  if r.get('selection_rule_sha256')!=sha(rule_path)or r.get('validation_view_sha256')!=rule['validation_view_sha256']or r.get('split_sha256')!=rule['split_sha256']:raise ValueError('rule or validation version differs')
  keys={(x['episode_id'],x['frame_index'],x['joint'],x['unit'],x['target'])for x in r['rows']}
  if keys!=reference:raise ValueError('different validation targets across candidates')
  byframe={}
  for row in r['rows']:byframe.setdefault((row['episode_id'],row['frame_index']),set()).add(row['joint'])
  if not byframe or any(fields!=set(FIELDS)for fields in byframe.values()):raise ValueError('incomplete twelve-channel prediction')
  metric=score_rows(r['rows'],rule['joint_scales'])
  step=rule.get('training_steps',{}).get(r['candidate_id'])
  if not positive(step)or r.get('training_step')!=step:raise ValueError('candidate training step differs from predeclared tie break')
  scored.append({'candidate_id':r['candidate_id'],'score':metric['score'],'training_step':step,'model_manifest_sha256':r['model_manifest_sha256'],'prediction_report_sha256':sha(path),'source_kind':r['source_kind']})
 scored.sort(key=lambda r:(r['score'],r['training_step'],r['candidate_id']))
 result={'schema':'aloha.selection-result.v1','selection_rule_sha256':sha(rule_path),'ranking':scored,'selected':scored[0],'final_test_used':False,'hardware_success_inferred':False,'note':'This freezes an offline deployment candidate. Any later data/statistics/weights/processor change creates a new version and invalidates this selection.'}
 write_new(output,result);return result
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('rule');p.add_argument('output');p.add_argument('reports',nargs='+');a=p.parse_args();print(json.dumps(select(a.rule,a.reports,a.output),ensure_ascii=False,indent=2))
