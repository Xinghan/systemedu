# M07：实际进程时钟，合成目标

用M05已确认的Python解释器运行：

```text
python sample_clock.py --period 0.25 --count 9 --output quarter.csv
python sample_clock.py --period 0.10 --count 9 --output tenth.csv
python sample_clock.py --period 0.10 --count 9 --work-ms 160 --output slow.csv
```

period单位秒，work-ms单位毫秒。index与nominal_s来自序号和设置；actual_elapsed_s来自perf_counter。第一行interval_s为空，九行只有八个首尾间隔。synthetic_target是课程生成的数，不能称传感器数据。实际时钟是进程取时事件，不是相机曝光或电机响应。

慢处理不丢行，而在落后时尽快继续。保留CSV原数，以自己的观察解释差异。若需要重跑，请使用新文件名。
