"""Read-only collection coverage from explicit cells and attempt evidence."""
import argparse,csv,json

def coverage(config,rows):
    errors=[];cells=config.get('cells',{});seen=set();provenance=set()
    if not cells:errors.append('declare cells and their known/unknown status')
    counts={c:{'attempts':0,'candidates':0,'attempt_ids':[]} for c in cells}
    for c,meta in cells.items():
        if meta.get('role') not in ('development','sealed_test'):errors.append(f'{c}: invalid role')
        if meta.get('status') not in ('known','unknown'):errors.append(f'{c}: invalid status')
        if not meta.get('boundary'):errors.append(f'{c}: missing boundary')
    for i,r in enumerate(rows,2):
        for key in ('attempt_id','cell','batch_id','date','operator','hardware_revision','training_candidate','evidence_ref','provenance'):
            if not r.get(key,'').strip():errors.append(f'row {i}: missing {key}')
        aid=r.get('attempt_id');c=r.get('cell');prov=r.get('provenance')
        if aid in seen:errors.append(f'row {i}: duplicate attempt_id')
        seen.add(aid);provenance.add(prov)
        if prov not in ('synthetic','learner_recording'):errors.append(f'row {i}: invalid provenance')
        if r.get('training_candidate') not in ('yes','no'):errors.append(f'row {i}: invalid candidate')
        if c not in cells:errors.append(f'row {i}: undeclared cell');continue
        meta=cells[c]
        if meta.get('role')!='development':errors.append(f'row {i}: sealed test conditions cannot join development collection')
        if meta.get('status')!='known':errors.append(f'row {i}: a recorded cell cannot remain unknown')
        counts[c]['attempts']+=1;counts[c]['candidates']+=r.get('training_candidate')=='yes';counts[c]['attempt_ids'].append(aid)
    if len(provenance)>1:errors.append('do not combine synthetic and learner records in one coverage claim')
    result={c:{**counts[c],'role':m.get('role'),'status':m.get('status'),'boundary':m.get('boundary')} for c,m in cells.items()}
    for c,m in cells.items():
        if m.get('status')=='unknown':result[c].update(attempts=None,candidates=None)
    return {'valid':not errors,'errors':errors,'coverage':result if not errors else None,'source_files_modified':False,'model_success_rate':None,'labels_semantically_verified':False,'provenance':next(iter(provenance)) if len(provenance)==1 else None}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('cells_json');p.add_argument('attempts_csv');a=p.parse_args()
    with open(a.cells_json) as f:c=json.load(f)
    with open(a.attempts_csv,newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    out=coverage(c,rows);print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(0 if out['valid'] else 1)
