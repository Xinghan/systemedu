"""Decode selected development episodes offline; never execute robot actions."""
import argparse,json,math,os
from pathlib import Path
import torch
JOINTS=('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')
FIELDS=[f'{side}_{joint}.pos' for side in ('left','right') for joint in JOINTS]
CAMERAS=('observation.images.front','observation.images.overhead')
def audit_frames(frames,fps,features,expected_count):
 errors=[];last={};count=0;decoded_bytes=0;examples=[]
 if not math.isfinite(fps) or fps<=0:return {'valid':False,'errors':['positive finite FPS required']}
 for key in ('observation.state','action'):
  if features.get(key,{}).get('names')!=FIELDS:errors.append(key+': unexpected column names/order')
 try:
  for row in frames:
   count+=1;ep=int(row['episode_index'].item());index=int(row['frame_index'].item());timestamp=float(row['timestamp'].item())
   if ep<0 or index<0:errors.append(f'frame {count}: negative identity')
   expected=last.get(ep,-1)+1
   if index!=expected:errors.append(f'episode {ep}: expected frame {expected}, found {index}')
   last[ep]=index
   if not math.isfinite(timestamp) or abs(timestamp-index/fps)>1e-4:errors.append(f'{ep}/{index}: nominal timestamp differs from frame/fps')
   for key in ('observation.state','action'):
    tensor=row[key]
    if tuple(tensor.shape)!=(12,) or not torch.isfinite(tensor).all():errors.append(f'{ep}/{index}: invalid {key} shape or finite values');continue
    for g in (5,11):
     if not 0<=float(tensor[g])<=100:errors.append(f'{ep}/{index}: gripper normalized range violated in {key}')
   for camera in CAMERAS:
    image=row[camera]
    if image.ndim!=3 or image.shape[0]!=3 or min(image.shape)<=0:errors.append(f'{ep}/{index}: invalid RGB CHW '+camera);continue
    if not torch.isfinite(image).all() or float(image.min())<0 or float(image.max())>1:errors.append(f'{ep}/{index}: float RGB range violated '+camera)
    decoded_bytes+=image.numel()*image.element_size()
   if len(examples)<3:examples.append({'episode':ep,'frame':index,'nominal_timestamp_s':timestamp})
 except Exception as exc:errors.append('decode/read failed: '+type(exc).__name__+': '+str(exc))
 if count!=expected_count:errors.append(f'expected {expected_count} frames, decoded {count}')
 if count==0:errors.append('empty selection')
 return {'valid':not errors,'errors':errors,'decoded_frames':count,'episode_frame_counts':{str(k):v+1 for k,v in last.items()},'summed_decoded_image_bytes':decoded_bytes,'peak_RAM_not_measured':True,'examples':examples,'timestamp_contract':'nominal frame_index/fps, not arrival/exposure','physical_synchronization_verified':False,'semantic_task_labels_verified':False}

def audit_sidecar(rows):
 errors=[];frames=[];last=-1;last_t=None;episode=None
 if not isinstance(rows,list) or not rows or any(not isinstance(r,dict) for r in rows):
  return {'valid':False,'errors':['nonempty sidecar object rows required']}
 first,closed=rows[0],rows[-1];aid=first.get('attempt_id')
 if first.get('event')!='attempt_started':errors.append('missing attempt_started')
 if not isinstance(aid,str) or not aid.strip():errors.append('nonempty attempt ID required')
 if first.get('joint_fields')!=FIELDS:errors.append('sidecar joint field order mismatch')
 provenance=first.get('provenance',{})
 if not isinstance(provenance,dict) or provenance.get('kind') not in ('synthetic','learner_recording') or not provenance.get('source'):errors.append('explicit recording provenance required')
 for r in rows[1:-1]:
  if r.get('event')!='frame':errors.append('unexpected interior event');continue
  frames.append(r);index=r.get('frame_index');ep=r.get('episode_index')
  if type(index) is not int or index!=last+1:errors.append('missing/duplicate/reversed sidecar frame')
  if type(index) is int:last=index
  if type(ep) is not int or ep<0:errors.append('nonnegative integer episode required')
  if episode is not None and ep!=episode:errors.append('mixed episode indices')
  episode=ep
  fps=r.get('nominal_fps');ts=r.get('nominal_timestamp_s')
  if type(fps) not in (int,float) or not math.isfinite(fps) or fps<=0:errors.append('invalid nominal FPS')
  elif type(ts) not in (int,float) or not math.isfinite(ts) or type(index) is not int or abs(ts-index/fps)>1e-6:errors.append('nominal time mismatch')
  for key in ('raw_teleop_action','teleop_processor_action','robot_processor_action_to_send','driver_returned_sent_action','observed_state'):
   payload=r.get(key)
   if not isinstance(payload,dict) or set(payload)!=set(FIELDS) or any(type(v) not in (int,float) or not math.isfinite(v) for v in payload.values()):errors.append('invalid five-stage payload: '+key)
  values=[r.get(k) for k in ('monotonic_observation_arrival','monotonic_send_start','monotonic_send_end')]
  if any(type(x) not in (int,float) or not math.isfinite(x) for x in values):errors.append('missing/nonfinite host clock');continue
  if values!=sorted(values) or (last_t is not None and values[0]<=last_t):errors.append('nonmonotonic host clock or wrong clock domain')
  last_t=values[-1]
 if any(r.get('attempt_id')!=aid for r in rows):errors.append('mixed attempt IDs')
 if closed.get('event')!='attempt_closed':errors.append('missing attempt_closed')
 if closed.get('disposition')!='saved':errors.append('attempt not saved; retain archive but not completed source')
 if type(closed.get('frame_count')) is not int or closed['frame_count']!=len(frames):errors.append('close count mismatch')
 if type(closed.get('episode_index')) is not int or closed['episode_index']!=episode:errors.append('close episode mismatch')
 ref=closed.get('native_dataset_reference')
 if not isinstance(ref,str) or not ref.strip():errors.append('missing saved dataset version reference')
 if not frames:errors.append('no instrumented frames')
 return {'valid':not errors,'errors':errors,'attempt_id':aid,'episode_index':episode,'frame_count':len(frames),'native_dataset_reference':ref,'provenance':provenance,'sensor_exposure_times_known':False,'camera_to_camera_skew_verified':False}

def join_evidence(native,sidecar,*,episode,attempt_id,dataset_reference,source_root,repo_id):
 """Bind two independently checked files to a declared saved recording version.
 This verifies references, not authenticity. The version reference should identify
 the frozen file-inventory digest, not just a mutable folder name.
 """
 result=dict(native);errors=list(native.get('errors',[]));result['sidecar']=sidecar
 if sidecar.get('valid') is not True:errors.append('sidecar audit incomplete or failed')
 if type(episode) is not int or episode<0:errors.append('one approved episode index required')
 counts=native.get('episode_frame_counts',{})
 if set(counts)!={str(episode)}:errors.append('native selection differs from approved episode')
 if sidecar.get('episode_index')!=episode:errors.append('native/sidecar episode mismatch')
 if sidecar.get('frame_count')!=counts.get(str(episode)):errors.append('native/sidecar frame count mismatch')
 if not isinstance(attempt_id,str) or not attempt_id.strip() or sidecar.get('attempt_id')!=attempt_id:errors.append('saved attempt ID mismatch')
 if not isinstance(dataset_reference,str) or not dataset_reference.strip() or sidecar.get('native_dataset_reference')!=dataset_reference:errors.append('saved dataset version reference mismatch')
 if native.get('valid') is not True:errors.append('native decode incomplete or failed')
 result.update(valid=not errors,errors=errors,source_dataset={'root':str(Path(source_root).resolve()),'repo_id':repo_id,'version_reference':dataset_reference},cross_source_verified=not errors,authenticity_verified=False)
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--repo-id',required=True);p.add_argument('--episode',required=True,type=int,help='one approved development native index');p.add_argument('--sidecar',required=True);p.add_argument('--attempt-id',required=True);p.add_argument('--dataset-reference',required=True,help='saved immutable version reference from M30 close record and file inventory');a=p.parse_args();root=Path(a.root)
 if not (root/'meta/info.json').is_file():raise SystemExit('local dataset absent; no download')
 os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1'
 from lerobot.datasets.lerobot_dataset import LeRobotDataset
 dataset=LeRobotDataset(a.repo_id,root=root,episodes=[a.episode],download_videos=False)
 native=audit_frames((dataset[i] for i in range(len(dataset))),float(dataset.fps),dataset.features,len(dataset))
 sidecar=audit_sidecar([json.loads(x) for x in Path(a.sidecar).read_text().splitlines() if x.strip()])
 result=join_evidence(native,sidecar,episode=a.episode,attempt_id=a.attempt_id,dataset_reference=a.dataset_reference,source_root=root,repo_id=a.repo_id)
 print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False));raise SystemExit(0 if result['valid'] else 1)
