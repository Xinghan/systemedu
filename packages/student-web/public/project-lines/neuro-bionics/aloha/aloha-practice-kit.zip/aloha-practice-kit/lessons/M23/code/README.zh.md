# M23 跟踪响应分析

下载[实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)并进入 `lessons/M23/code/`，运行：

`python3 response.py synthetic.csv --provenance synthetic --max-gap-s 0.15 --output example-response.json`

脚本同时生成 JSON 与 `example-response.svg`。示例目标先为20度，随后跳到22度；观测为20、20.6、21.5、22.2、22度，间隔0.1秒。预期有限差分速度依次是null、6、9、7、负2度/秒；目标减观测依次为0、1.4、0.5、负0.2、0度。图中连线只是连接离散样本，不能证明两样本间的真实轨迹。

真实日志转换成相同CSV列 `monotonic_s,target,observed,unit`，保留原文件、字段来源、配置和转换说明，再用 `--provenance learner_recording` 分析。target应明确来自哪个处理阶段，不能混用原生action、robot处理后目标与驱动返回。时间来自统一主机单调时钟的实际采样时刻，不能把名义frame/fps伪作实测时间。此工具不推断相机曝光，也不自动判定稳定或通过。

输出必须使用新文件名，已有JSON或SVG会拒绝覆盖。重复/倒序时间、非有限数与混合单位应报错。真实样本间隔不齐时，速度按每行实际时间差计算。显式的 `--max-gap-s` 决定绘图何时断线，并写入JSON的max_connect_gap_s；它是显示阈值，不是设备安全限值。超过阈值的前后点仍保留，图上不画连接线。本示例取0.15秒，若把第三行实际时间改成1000.28而不改后面的顺序，应观察断线；不要插入假样本补齐。此工具能分析真实导出数据，完全不驱动硬件。
