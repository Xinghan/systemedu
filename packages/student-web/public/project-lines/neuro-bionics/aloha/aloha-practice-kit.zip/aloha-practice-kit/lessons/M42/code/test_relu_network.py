import copy,unittest
from relu_network import initialize,forward,worked_example,absolute_value_example
class ReLUTests(unittest.TestCase):
    def test_full_worked_forward(self):
        r=forward([2,-1],worked_example());self.assertEqual(r['preactivation'],[2.2,-2]);self.assertEqual(r['activation'],[2.2,0]);self.assertEqual(r['active_positive'],[True,False])
        self.assertAlmostEqual(r['prediction'][0],2.3);self.assertAlmostEqual(r['prediction'][1],.35)
    def test_identity_comparison_reuses_weights_and_changes_values(self):
        r=forward([2,-1],worked_example(),False)
        self.assertEqual(r['activation'],[2.2,-2]);self.assertAlmostEqual(r['prediction'][0],3.3);self.assertAlmostEqual(r['prediction'][1],-1.65)
    def test_constructed_absolute_value_and_affine_counterexample(self):
        values=[absolute_value_example(x)['prediction'] for x in (-1,0,1)];self.assertEqual(values,[1,0,1])
        self.assertNotEqual(values[1],(values[0]+values[2])/2)
    def test_final_output_is_not_relu_clipped(self):
        m=worked_example();m['b2']=[-100,-100];self.assertTrue(all(v<0 for v in forward([2,-1],m)['prediction']))
    def test_parameters_unchanged_by_different_samples(self):
        m=initialize();before=copy.deepcopy(m);a=forward([0]*12,m);b=forward([1]*12,m)
        self.assertEqual(m,before);self.assertNotEqual(a['preactivation'],b['preactivation'])
    def test_seed_reproducibility_and_no_identical_hidden_rows(self):
        a=initialize(seed=23);self.assertEqual(a,initialize(seed=23));self.assertNotEqual(a,initialize(seed=24));self.assertNotEqual(a['w1'][0],a['w1'][1])
    def test_zero_preactivation_is_zero_output_without_derivative_claim(self):
        m=worked_example();m['w1']=[[0,0],[0,0]];m['b1']=[0,0];r=forward([2,-1],m)
        self.assertEqual(r['activation'],[0,0]);self.assertEqual(r['active_positive'],[False,False]);self.assertEqual(r['prediction'],[.1,-.2])
    def test_contract_failures(self):
        with self.assertRaises(ValueError):forward([1],worked_example())
        with self.assertRaises(ValueError):forward([True,1],worked_example())
        bad=worked_example();bad['w2']=[[1],[2]]
        with self.assertRaises(ValueError):forward([2,-1],bad)
        with self.assertRaises(ValueError):initialize(hidden=0)
if __name__=='__main__':unittest.main()
