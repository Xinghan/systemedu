"""Inspect a trusted local teaching tensor file, with weights_only loading.
Does not import or contact robot hardware. Use --path a.b to inspect a saved key.
"""
import argparse,json,torch
from vision_course import serialize
p=argparse.ArgumentParser(description=__doc__);p.add_argument('file');p.add_argument('--path',default='');p.add_argument('--values',action='store_true');a=p.parse_args();v=torch.load(a.file,weights_only=True,map_location='cpu')
for key in a.path.split('.') if a.path else []:v=v[int(key)] if isinstance(v,(list,tuple)) else v[key]
def describe(x):
    if isinstance(x,torch.Tensor):return {'shape':list(x.shape),'dtype':str(x.dtype),'values':serialize(x) if a.values else 'add --values to print values'}
    if isinstance(x,dict):return {k:describe(y) for k,y in x.items()}
    if isinstance(x,(list,tuple)):return [describe(y) for y in x]
    return x
print(json.dumps(describe(v),ensure_ascii=False,indent=2))
