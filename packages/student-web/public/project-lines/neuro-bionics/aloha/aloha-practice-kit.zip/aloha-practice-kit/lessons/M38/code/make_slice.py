#!/usr/bin/env python3
"""Export a traceable train-only scalar view through the verified M35/M37 interface."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M37/code'))
from normalize import FIELDS,forward,read_package,verify_config

def make(package,normalization,field,episode=None,allow_synthetic=False):
    manifest,rows=read_package(package,'train',allow_synthetic)
    raw=Path(normalization).read_bytes();config=json.loads(raw)
    verify_config(config,manifest,rows)
    index=FIELDS.index(field);xs=config['statistics']['observation_state'][index];ys=config['statistics']['action'][index]
    selected=[r for r in rows if episode is None or r['episode_id']==episode]
    if not selected:raise ValueError('No training rows in this episode')
    return {'provenance':{'kind':manifest['provenance'],'dataset_source':manifest['dataset_source'],'frames_sha256':manifest['sha256']},
            'feature':{'field':field,'semantics':'observation_state','unit':'standardized','mean':xs['mean'],'scale':xs['scale']},
            'target':{'field':field,'semantics':'teleop_processor_action','unit':'standardized','mean':ys['mean'],'scale':ys['scale']},
            'normalization_sha256':hashlib.sha256(raw).hexdigest(),
            'rows':[{'episode_id':r['episode_id'],'attempt_id':r['attempt_id'],'frame_index':r['frame_index'],'split':'train',
                     'raw_observation':r['observation_state'][index],'raw_action':r['action'][index],
                     'x':forward(r['observation_state'][index],xs),'target':forward(r['action'][index],ys),
                     'copy_current_state_prediction':forward(r['observation_state'][index],ys)} for r in selected]}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('--field',choices=FIELDS,required=True)
    p.add_argument('--episode');p.add_argument('--out',required=True);p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
    try:
        result=make(a.package,a.normalization,a.field,a.episode,a.allow_synthetic)
        with Path(a.out).open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
        print('Saved',len(result['rows']),'training frames; no hardware command')
    except (OSError,ValueError,TypeError,KeyError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
