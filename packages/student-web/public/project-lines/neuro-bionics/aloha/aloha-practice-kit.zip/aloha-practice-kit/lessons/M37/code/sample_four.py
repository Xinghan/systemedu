#!/usr/bin/env python3
"""Expose every scalar calculation for four consecutive training frames."""
import argparse,json
from pathlib import Path
from normalize import FIELDS,UNITS,read_package,statistics,forward,inverse

def calculate(package,episode,start,field,kind,allow_synthetic=False):
    manifest,train=read_package(package,'train',allow_synthetic);j=FIELDS.index(field)
    rows=[r for r in train if r['episode_id']==episode and start<=r['frame_index']<start+4]
    if len(rows)!=4 or {r['frame_index'] for r in rows}!=set(range(start,start+4)):
        raise ValueError('Choose four existing consecutive frames from one training episode')
    rows.sort(key=lambda r:r['frame_index']);s=statistics([r[kind][j] for r in rows]);table=[]
    for r in rows:
        x=r[kind][j];d=x-s['mean'];z=forward(x,s)
        table.append({'episode_id':r['episode_id'],'attempt_id':r['attempt_id'],'frame_index':r['frame_index'],'raw':x,'deviation':d,'squared_deviation':d*d,'standardized_by_four_frame_stats':z,'restored':inverse(z,s)})
    return {'provenance':manifest['provenance'],'source_sha256':manifest['sha256'],'scope':'Four-frame arithmetic check only; NOT the full-training normalization configuration','kind':kind,'field':field,'unit':UNITS[j],'statistics_of_these_four_only':s,'rows':table,'hardware_executed':False}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('--episode',required=True);p.add_argument('--start-frame',type=int,required=True);p.add_argument('--field',choices=FIELDS,required=True);p.add_argument('--kind',choices=['observation_state','action'],default='action');p.add_argument('--allow-synthetic',action='store_true');p.add_argument('--out',required=True);a=p.parse_args()
    try:
        if a.start_frame<0:raise ValueError('Nonnegative start frame required')
        d=calculate(a.package,a.episode,a.start_frame,a.field,a.kind,a.allow_synthetic)
        with Path(a.out).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    except (OSError,ValueError,TypeError,KeyError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
