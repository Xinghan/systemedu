import copy
import json
from pathlib import Path
from station import run_station

here=Path(__file__).parent
task=json.loads((here/'task-spec-example.json').read_text())
workspace=json.loads((here/'workspace-example.json').read_text())
baseline=json.loads((here/'channels-example.json').read_text())
cases=[]
for name in ['normal','missing','out_of_range','wrong_mode']:
    t=copy.deepcopy(task);q=copy.deepcopy(baseline)
    if name=='missing':q['fields'].pop()
    if name=='out_of_range':q['fields'][0]['value']=29
    if name=='wrong_mode':t['mode']='hardware'
    try:
        result=run_station(t,workspace,q)
        correct=name=='normal' and result['changed_fields']==['left.shoulder_pan'] and not result['hardware_output']
        cases.append({'case':name,'expected':'accept' if name=='normal' else 'reject','actual':'accept','case_check':correct,'result':result})
    except ValueError as exc:
        correct=name!='normal'
        cases.append({'case':name,'expected':'reject','actual':'reject','case_check':correct,'message':str(exc)})
report={'provenance':'synthetic_inputs_with_measured_process_clock','hardware_exercised':False,'cases':cases,'all_cases_matched_expectation':all(c['case_check'] for c in cases)}
(here/'selfcheck-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['all_cases_matched_expectation'] else 1)
