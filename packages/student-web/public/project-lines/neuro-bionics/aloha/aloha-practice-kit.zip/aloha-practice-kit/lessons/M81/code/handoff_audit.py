"""M81: trace nine stage artifacts, five outcomes, and a fresh operator record."""
import sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'M79'/'code'));sys.path.insert(0,str(BASE/'M80'/'code'))
from evidence_files import read,inventory,verify_file,references,text,run_cli
from release_audit import audit_release,verify_run_binding
STAGES={'M08','M18','M28','M35','M46','M55','M66','M70','M80'}
OUTCOMES={'FO1','FO2','FO3','FO4','FO5'}

def audit_handoff(document,artifact_root,release_checker=None):
    d=read(document)
    if d.get('schema')!='aloha.handoff.v1':raise ValueError('Wrong handoff schema')
    files=inventory(artifact_root,d['files'])
    for key,wanted in [('stages',STAGES),('outcomes',OUTCOMES)]:
        rows=d[key]
        if len(rows)!=len(wanted) or {r['id'] for r in rows}!=wanted:raise ValueError(f'Incomplete/duplicate {key}')
        for row in rows:
            references(row['source_evidence'],files,'source '+row['id']);references(row['checked_evidence'],files,'check '+row['id']);text(row['limits'],'limits')
    roles=d['roles'];author=text(roles['author'],'author');operator=text(roles['operator'],'operator');text(roles['mentor'],'mentor')
    if author==operator:raise ValueError('Operator must be distinct from author')
    if roles.get('operator_wrote_instructions') is not False:raise ValueError('Declare whether operator wrote the instructions')
    release_path=verify_file(artifact_root,files[d['release_evidence']])
    released=(release_checker or audit_release)(release_path,artifact_root)
    if not released['structural_complete']:raise ValueError('Release structure incomplete')
    checks=d['checks']
    if set(checks)!={'fabrication','environment','native_data_read','training_to_weights','new_run'}:raise ValueError('Five real handoff checks required')
    pending=[]
    for name,check in checks.items():
        if check['status'] not in ('completed','not_completed'):raise ValueError('Unknown handoff check status')
        text(check['observation'],'check observation')
        if check['status']=='not_completed':pending.append(name)
        else:references(check['evidence'],files,name)
    new=read(verify_file(artifact_root,files[d['new_run_evidence']]))
    text(new['run_id'],'handoff run identity')
    if new['purpose']!='independent_handoff':raise ValueError('Handoff run must remain separate from main evaluation')
    if new['observed_versions']!=released['frozen_versions']:raise ValueError('Handoff uses a different frozen version')
    if new['operator']!=operator:raise ValueError('Run operator mismatch')
    if new['status'] not in ('completed','failed','intervention','estop','not_executed'):raise ValueError('Unknown new run status')
    if new['status']=='not_executed' and checks['new_run']['status']=='completed':raise ValueError('Cannot mark an unexecuted run complete')
    if checks['new_run']['status']=='completed':
        kinds={files[i]['kind'] for i in checks['new_run']['evidence']}
        if not {'video','gateway_log','outcome_note'}.issubset(kinds):raise ValueError('Executed handoff needs video, gateway_log and outcome_note')
    if new.get('source_kind')!=released['source_kind']:raise ValueError('New run and release provenance differ')
    if new['status']!='not_executed':
        verify_run_binding(new,artifact_root,files,checks['new_run']['evidence'],versions=released['frozen_versions'],source_kind=released['source_kind'],purpose='independent_handoff',operator=operator)
    references(d['help_log_evidence'],files,'help log');references(d['operator_feedback'],files,'operator feedback')
    return {'structural_complete':not pending,'pending_checks':pending,'operator':operator,'source_kind':released['source_kind'],'performance_status':released['performance_status'],'handoff_run_status':new['status'],'truth_certified':False,'errors':[],'limits':'A recorded failed run can complete the engineering handoff, not task performance. Independence, fabrication and observations require human review.'}

if __name__=='__main__':run_cli(audit_handoff)
