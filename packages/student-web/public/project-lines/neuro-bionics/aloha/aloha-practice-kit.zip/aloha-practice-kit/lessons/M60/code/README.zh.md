# M60：按回合比较示范差异

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M60/code/diversity.py lessons/M60/code/synthetic.csv --edges 0 2 4 --provenance synthetic
```

CSV 必须有 episode_id,group,channel,value,unit,source_ref，同回合/组/通道只取一个明确摘要，不能把相邻帧当独立示范。--edges严格递增且覆盖所有数值，最后区间包含右端点；各区间份额除宽度得到密度。fixture四个回合数值1,1,3,3，mean=2，population variance=1；两等宽区间份额各0.5、density各0.25。本人CSV用 --provenance learner_recording，来源与同条件分组仍需人工核对。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
