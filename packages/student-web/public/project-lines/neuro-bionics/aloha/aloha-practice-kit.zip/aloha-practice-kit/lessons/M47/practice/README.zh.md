# M47 实际代码入口与证据

从解压后的实践包根目录运行命令；这里的 `lessons/Mxx/code` 与包根通用工具不同。所有M48–55入口会定位同包 `lessons/M47/code`，不要只复制一份run.py离开目录结构。

完整原生图像导出需先由导师按包根 `docs/ENVIRONMENT.zh.md` 安装固定LeRobot环境。纯机制代码可另建隔离Python 3.12环境，安装M47目录的 `requirements-cpu-verified.txt`。这些依赖已在macOS arm64 CPU做作者合成QA，不等于所有系统或完整LeRobot已安装验证。正式ACT GPU环境另按课程后续资源评估。

```sh
python3.12 -m venv .venv-vision
source .venv-vision/bin/activate
python -m pip install -r lessons/M47/practice/requirements-cpu-verified.txt
```

本人运行不加 `--allow-synthetic`。该开关只给明确标为synthetic的软件夹具使用，不能让合成文件变成真实作业。先用少量开发行，测试回合始终封存；同一原始回合不能跨组，重命名复制的来源仍需人工审计。

## 本节执行

```sh
python lessons/M47/code/run.py --manifest work/vision/manifest.json --row 20 --col 20 --output work/M47-v1
```

输入路径需换成本人已审核文件，输出必须是新版本目录。程序不导入设备驱动，不发送硬件动作。

## 应得到什么

window.json逐项窗口/核/乘积与库值；edge_maps.pt保留两幅响应图。

JSON可直接打开阅读；可信本地.pt文件可使用：

```sh
python lessons/M47/code/inspect_tensor.py work/M48-v1/features.pt
python lessons/M47/code/inspect_tensor.py work/M50-v1/tokens.pt --path tokens --values
```

将示例文件/键替换为当前输出。不要把不可信来源的二进制文件当课程权重运行。

## 对照与恢复

窗口中心需处于缩小后内部区域；色彩与尺寸拒绝只检查声明，不自动识别被冒名图片。差255倍先查缩放，符号不同先查翻核和通道。

本目录 `worksheet.csv` 是空白记录表，不预填任何本人测量或成功数据。讲义、作业中的示意数字保持synthetic性质；正式提交用本人原始日志、来源和实际运行结果替换。

## 从原生数据导出图像视图

复制 `native-export-contract.template.json` 到work目录，按原生 `meta/info.json` 的实际feature names核对十二映射。模板点号别名对应left/right字段；原生名字不同时逐项改映射，不改变课程顺序。相机键按M14真实身份核对。填写dataset_source，保留元数据文件摘要与M33整回合划分文件。

`episodes` 的键是原生整数episode_index字符串，值按 `episode-entry.example.json` 填写真实episode_id、attempt_id、train或validation、selected frame_indices、原生完整episode_length及长度来源。至少包含分属不同完整回合的train和validation；绝不能加入封存test。模板空episodes会拒绝，不能直接运行当真数据。

在完整固定LeRobot环境（不是仅安装上面四个库的轻环境）运行：

```sh
python lessons/M47/code/export_native_images.py --root /PATH/TO/ORIGINAL_DATASET --repo-id LOCAL_REPO_ID --contract work/native-contract.json --output work/vision
```

程序使用本地已有原始dataset，无图像变换，禁止在线自动下载；它扫描被选择的完整开发回合，核对所有frame_index为0到真实长度减1，只保存要求的少量帧。缺帧报错，不当回合尾部。输出PNG为解码RGB经四舍五入后的八位派生视图，原视频继续用于正式ACT；manifest保留episode_lengths与episode_length_sources，后续chunk不能把稀疏选帧当连续数据。

作者只在fake tensor rows核验映射、RGB、长度、封存拒绝与PNG落盘，未实际安装完整LeRobot decoder读取本人设备数据。导师首次真实导出必须核对一个回合/帧的两图、状态和目标，保留原生环境日志；若适配失败，先处理环境或数据契约，不能换无关图片与零标签通过。
