"""Pinned camera adapter. Arrival is a host timestamp, never exposure time.

The camera's frame and timestamp are copied under the SAME pinned-driver lock.
No robot is created by this module. A disconnected servo state cannot be read;
M71 supplies a separately identified frozen learner development state instead.
"""
import sys, math, time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M67/code'))
from course_contract import FIELDS, CAMERAS, UNITS, finite, read, sha, child, text

def camera_snapshot(camera, *, clock=time.perf_counter):
 if camera.thread is None or not camera.thread.is_alive():raise ValueError('camera read thread is not alive')
 with camera.frame_lock:
  frame=camera.latest_frame; stamp=camera.latest_timestamp
  if frame is None or not finite(stamp):raise ValueError('camera has no paired frame/arrival')
  frame=frame.copy()
 now=clock()
 if not finite(now) or stamp>now:raise ValueError('invalid same-process arrival timestamp')
 return frame,float(stamp)

def observation_tensors(state,frames):
 import torch,numpy as np
 if not isinstance(state,dict) or set(state)!=set(FIELDS) or any(not finite(v)for v in state.values()):raise ValueError('exact twelve finite native state fields required')
 if set(frames)!={'front','overhead'}:raise ValueError('both named camera frames required')
 out={'observation.state':torch.tensor([state[k]for k in FIELDS],dtype=torch.float32)}
 for name,array in frames.items():
  if not isinstance(array,np.ndarray) or array.dtype!=np.uint8 or array.ndim!=3 or array.shape[2]!=3:raise ValueError('unresized RGB uint8 HWC camera data required')
  out['observation.images.'+name]=torch.from_numpy(array.copy()).permute(2,0,1).float()/255
 return out

def camera_configs(config):
 from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig
 from lerobot.cameras.configs import ColorMode
 if set(config)!= {'front','overhead'}:raise ValueError('front and overhead configuration required')
 result={}
 for name,row in config.items():
  if set(row)!={'index','width','height','fps'} or type(row['index'])is not int or row['index']<0:raise ValueError('explicit numeric USB index/size/fps required')
  if any(type(row[k])is not int or row[k]<=0 for k in ('width','height','fps')):raise ValueError('positive camera dimensions/fps required')
  result[name]=OpenCVCameraConfig(index_or_path=row['index'],width=row['width'],height=row['height'],fps=row['fps'],color_mode=ColorMode.RGB)
 if config['front']['index']==config['overhead']['index']:raise ValueError('distinct USB cameras required')
 return result

def load_state(view_path,episode_id,frame_index):
 """State originates in the same SHA-checked learner view used by M47/M69.

 Load only a declared development split and retain provenance; this is NOT
 a live arm measurement. The full view loader also checks image byte hashes.
 """
 sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M47/code'))
 from vision_course import load_manifest
 # Load native JSON rows to preserve original non-image state and metadata.
 raw=read(view_path)
 rows=[r for r in raw['rows']if r['episode_id']==episode_id and r['frame_index']==frame_index]
 if len(rows)!=1:raise ValueError('choose exactly one original frame')
 row=rows[0]
 if row['split']not in ('train','validation'):raise ValueError('test states are not for deployment tuning')
 load_manifest(view_path,split=row['split'])
 if raw.get('source_kind')!='learner_recording':raise ValueError('M71 requires learner development state, not synthetic performance')
 from course_contract import VIEW_FIELDS
 values=row['state']
 if isinstance(values,dict):values=[values[k]for k in VIEW_FIELDS]
 if len(values)!=12 or any(not finite(x)for x in values):raise ValueError('state must have twelve native finite values')
 return dict(zip(FIELDS,values)),{'kind':'frozen_learner_development_state','view_path':str(Path(view_path).resolve()),'view_sha256':sha(view_path),'episode_id':episode_id,'frame_index':frame_index,'attempt_id':row['attempt_id'],'split':row['split'],'dataset_source':raw['dataset_source'],'live_state':False}
