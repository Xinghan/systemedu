import json
from pathlib import Path
import tempfile
import unittest
from recording_sidecar import RecordingSidecar, audit


class SidecarTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)/'attempt.jsonl'
        self.writer = RecordingSidecar(self.path, {'kind':'synthetic','source':'unit test'},
                                       required_joint_fields=['joint'])

    def tearDown(self):
        if not self.writer._closed:
            self.writer.close_attempt(disposition='interrupted', reason='test teardown')
        self.tmp.cleanup()

    def row(self, **changes):
        args = dict(episode_index=3, frame_index=0, nominal_fps=30,
                    monotonic_observation_arrival=100, monotonic_send_start=100.02,
                    monotonic_send_end=100.03, raw_teleop_action={'joint':30},
                    teleop_processor_action={'joint':30}, robot_processor_action_to_send={'joint':28},
                    driver_returned_sent_action={'joint':22}, observed_state={'joint':20})
        args.update(changes)
        return self.writer.append_frame(**args)

    def test_semantics_remain_separate_and_nominal_is_not_actual(self):
        row = self.row()
        self.assertEqual(row['nominal_timestamp_s'], 0)
        self.assertEqual(row['monotonic_observation_arrival'], 100)
        self.assertEqual(row['teleop_processor_action']['joint'], 30)
        self.assertEqual(row['driver_returned_sent_action']['joint'], 22)
        self.writer.close_attempt(disposition='saved', native_dataset_reference='synthetic-version')
        self.assertEqual(audit(self.path)['frames'], 1)

    def test_new_attempt_does_not_overwrite(self):
        with self.assertRaises(FileExistsError):
            RecordingSidecar(self.path, {'kind':'synthetic','source':'unit test'}, required_joint_fields=['joint'])

    def test_gap_duplicate_and_clock_reversal(self):
        with self.assertRaises(ValueError): self.row(frame_index=1)
        with self.assertRaises(ValueError): self.row(monotonic_send_start=99)
        self.row()
        with self.assertRaises(ValueError): self.row()

    def test_incomplete_attempt_is_not_claimed_saved(self):
        self.row()
        self.assertEqual(audit(self.path)['disposition'], 'incomplete')
        with self.assertRaises(ValueError): self.writer.close_attempt(disposition='saved')


if __name__ == '__main__': unittest.main()
