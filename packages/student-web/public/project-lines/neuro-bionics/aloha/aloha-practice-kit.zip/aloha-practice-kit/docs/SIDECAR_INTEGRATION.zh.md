# 把旁路记录挂到真正的采集循环

先读 `RECORDING_CONTRACT.zh.md`。`recording_sidecar.py` 提供真实可运行的写入器，**导入模块并不自动修改 LeRobot**。以下是固定源码中的挂接顺序；节点 M27 要由学生在自己的固定版本分支中实际加入，并在无动力环境检查。

## 固定五个值和三个主机时间

在 `src/lerobot/scripts/lerobot_record.py` 的 `record_loop` 中，`obs = robot.get_observation()` 返回后记录 `time.perf_counter()`。这叫观察到达，不叫相机曝光。保留示教原值 `act`、`act_processed_teleop`、`robot_action_to_send`。在 `robot.send_action` 前后各记录一次同一时钟，并保留返回的 `_sent_action`。所有字典应在相应位置复制，避免后续 processor 原地修改。

`dataset.add_frame(frame)` 成功后，从 `dataset.writer.episode_buffer['size'] - 1` 取得刚存入的帧号；本回合身份使用进入录制段时的 `dataset.num_episodes`。使用写入器时从 observation 中只取实际关节字段，不能把整张图像转成数值列表塞进 JSONL。各相机刷新与到达埋点可另外保存，但没有驱动提供的曝光信息就不能标曝光时间。

```python
# 在一个新的录制尝试开始时创建；文件必须是新路径。
tap = RecordingSidecar(
    'my-attempt-001.jsonl',
    {'kind': 'learner_recording', 'source': 'my-station/v1'},
    required_joint_fields=joint_fields,
)
# 在上面所述位置拿到真实变量后调用，不用示例值代替。
tap.append_frame(
    episode_index=recording_episode_index,
    frame_index=dataset.writer.episode_buffer['size'] - 1,
    nominal_fps=fps,
    monotonic_observation_arrival=observation_arrival,
    monotonic_send_start=send_start,
    monotonic_send_end=send_end,
    raw_teleop_action=raw_action_copy,
    teleop_processor_action=teleop_processed_copy,
    robot_processor_action_to_send=robot_processed_copy,
    driver_returned_sent_action=sent_action_copy,
    observed_state={key: obs[key] for key in joint_fields},
)
```

上述片段是挂接位置说明，变量要由循环里的真实调用赋值，不是可独立运行的完整记录器。M27 的无动力实现必须把它们接全，再尝试一条会触发驱动限幅的离线样本，验证原生 action 和返回 sent 值可以不同。默认 Identity processor 的相同数值不代表字段可以合并。

## 回合保存、重录和异常

每次重录都创建独立文件和新的 attempt_id；原生回合编号可能复用，因此仅以 episode/frame 连接会混淆两次尝试。原生回合保存成功后，才用 `close_attempt(disposition='saved', native_dataset_reference='实际版本与回合')` 记录对应关系。重录放弃用 `discarded`，异常用 `interrupted`，并写原因；文件保留不删除。进程崩溃来不及写结尾时，审计结果应是 incomplete，不猜测它已经保存。

旁路落盘也消耗时间。用实际机器比较开启前后的循环延迟，记录写盘开销；不能为了追求帧率悄悄丢掉失败记录。正式采集前检查原生数据和旁路每个保存回合、帧号、尝试身份的一一关联。
