"""Assemble closed evaluation records without mixing separate-purpose runs."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M74/code'))
from evaluation_audit import read,sha,audit_evaluation

def assemble_evaluation(plan_path,artifact_root,output_path):
 root=Path(artifact_root).resolve();p=Path(plan_path).resolve()
 if not p.is_relative_to(root):raise ValueError('Plan must be within artifact root')
 plan=read(p);rows=[];separate=[]
 for record in sorted((root/'runs').glob('*/closed.json')):
  row=read(record)
  if row.get('evaluation_id')!=plan['evaluation_id']:continue
  if row.get('purpose')!='evaluation':separate.append({'run_id':row.get('run_id'),'purpose':row.get('purpose'),'path':str(record.relative_to(root))});continue
  row['run_record_ref']={'path':str(record.relative_to(root)),'sha256':sha(record)};rows.append(row)
 order={r['trial_id']:r['order'] for r in plan['plan']};rows.sort(key=lambda r:order.get(r.get('trial_id'),999))
 d={k:plan[k] for k in ('evaluation_id','source_kind','time_limit_s','acceptance_threshold','frozen_versions','plan')}
 d.update(schema='aloha.independent-evaluation.v1',provenance='Assembled from retained closed runs; file checks do not certify physical truth',created_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),plan_path=str(p.relative_to(root)),plan_sha256=sha(p),results=rows,separate_runs=separate)
 with open(output_path,'x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
 return audit_evaluation(output_path,root)

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('plan');p.add_argument('--root',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=assemble_evaluation(a.plan,a.root,a.output);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['complete'] else 2)
