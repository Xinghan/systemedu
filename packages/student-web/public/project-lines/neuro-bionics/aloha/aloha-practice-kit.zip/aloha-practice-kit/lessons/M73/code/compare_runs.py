"""Compare frozen-model offline predictions with development gateway traces.
No device access. Command-before-observation differences are NOT tracking errors.
"""
from pathlib import Path
import argparse,json,math,hashlib

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def finite(x):return type(x) in (int,float) and math.isfinite(x)
def compare(offline_path,gateway_path):
 d=read(offline_path);g=read(gateway_path)
 if d.get('schema')!='aloha.offline-action-pairs.v1':raise ValueError('Expected explicit offline action-pairs schema')
 if d.get('purpose')!='development' or d.get('source_kind') not in ('learner_prediction','synthetic_fixture'):raise ValueError('Development predictions with explicit source required')
 if not isinstance(d.get('dataset_source'),dict) or not d['dataset_source']:raise ValueError('Dataset source required')
 if not isinstance(d.get('model_manifest_sha256'),str) or len(d['model_manifest_sha256'])!=64:raise ValueError('Frozen model manifest SHA required')
 if g.get('schema')!='aloha.gateway-log.v1' or g.get('policy_artifact_sha256')!=d['model_manifest_sha256']:raise ValueError('Development traces must refer to the same frozen model')
 expected='learner_policy_execution' if d['source_kind']=='learner_prediction' else 'synthetic_fixture'
 if g.get('source_kind')!=expected:raise ValueError('Source types differ')
 groups={};seen=set()
 rows=d.get('rows')
 if not isinstance(rows,list) or not rows:raise ValueError('No prediction pairs')
 for row in rows:
  for key in ('episode_id','joint','unit'):
   if not isinstance(row.get(key),str) or not row[key].strip():raise ValueError('Nonempty '+key+' required')
  if type(row.get('frame_index')) is not int or row['frame_index']<0:raise ValueError('Invalid frame index')
  if not all(finite(row.get(k)) for k in ('target','prediction')):raise ValueError('Finite target and prediction required')
  key=(row['episode_id'],row['frame_index'],row['joint'])
  if key in seen:raise ValueError('Duplicate prediction pair')
  seen.add(key);group=groups.setdefault(row['joint'],{'unit':row['unit'],'errors':[]})
  if group['unit']!=row['unit']:raise ValueError('Mixed units for a joint')
  error=row['prediction']-row['target']
  if not finite(error) or not finite(error*error):raise ValueError('Residual or squared residual overflow')
  group['errors'].append(error)
 metrics={k:{'n':len(v['errors']),'unit':v['unit'],'mae':sum(abs(e) for e in v['errors'])/len(v['errors']),'mse':sum(e*e for e in v['errors'])/len(v['errors']),'mse_unit':v['unit']+' squared'} for k,v in groups.items()}
 if any(not finite(row[key]) for row in metrics.values() for key in ('mae','mse')):raise ValueError('Metric accumulation overflow')
 events=g.get('events')
 if not isinstance(events,list) or any(not isinstance(e,dict) for e in events):raise ValueError('Invalid native gateway events')
 commands=[];last=-1;last_time=None
 for e in events:
  if e.get('event')!='command':continue
  if e.get('source')!='policy' or type(e.get('sequence')) is not int or e['sequence']<=last:raise ValueError('Policy source and increasing sequence required')
  now=e.get('monotonic_send_end')
  if not finite(now) or (last_time is not None and now<=last_time):raise ValueError('Invalid one-process time')
  keys=set(e.get('requested',{}))
  if not keys:raise ValueError('Empty command')
  for kind in ('requested','observed_state','gateway_target','driver_returned_sent_action'):
   if set(e.get(kind,{}))!=keys or any(not finite(x) for x in e[kind].values()):raise ValueError('Inconsistent command fields')
  if any(not finite(e['gateway_target'][k]-e['requested'][k]) or not finite(e['driver_returned_sent_action'][k]-e['gateway_target'][k]) for k in keys):raise ValueError('Command difference overflow')
  if last_time is not None and not finite(now-last_time):raise ValueError('Time interval overflow')
  commands.append({'sequence':e['sequence'],'monotonic_send_end':now,'interval_since_previous_s':None if last_time is None else now-last_time,'constraint_delta':{k:e['gateway_target'][k]-e['requested'][k] for k in keys},'driver_return_delta':{k:e['driver_returned_sent_action'][k]-e['gateway_target'][k] for k in keys},'measured_before_command':e['observed_state'],'tracking_error':None})
  last=e['sequence'];last_time=now
 if not commands:raise ValueError('No policy commands to compare')
 return {'schema':'aloha.development-comparison.v1','source_kind':d['source_kind'],'input_sha256':{'offline':sha(offline_path),'gateway':sha(gateway_path)},'model_manifest_sha256':d['model_manifest_sha256'],'dataset_source':d['dataset_source'],'per_joint':metrics,'command_trace':commands,'limits':['No automatic causal attribution','Driver return is not a measured state','No video alignment inferred','No final-test tuning authorized']}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('offline');p.add_argument('gateway');p.add_argument('--output',required=True);a=p.parse_args();r=compare(a.offline,a.gateway)
 with open(a.output,'x') as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
