#!/usr/bin/env python3
"""Transparent offline scalar predictor. No robot connection or training hidden here."""
import argparse
import json
import math
from pathlib import Path

def finite(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError('Expected a finite number (not a boolean)')
    return float(value)

def predict(data, weight, bias):
    weight, bias = finite(weight), finite(bias)
    if data.get('provenance', {}).get('kind') not in ('synthetic', 'learner_recorded'):
        raise ValueError('Explicit provenance.kind required')
    if not data.get('feature') or not data.get('target') or not data.get('normalization_sha256'):
        raise ValueError('Feature, target and normalization hash required')
    rows = data['rows']
    if not isinstance(rows, list) or not rows:
        raise ValueError('Nonempty rows required')
    answer=[]
    for row in rows:
        if row.get('split') != 'train':
            raise ValueError('M38 works only on the training slice; leave other splits sealed')
        if not isinstance(row.get('episode_id'),str) or not row['episode_id']:raise ValueError('episode_id required')
        if type(row.get('frame_index')) is not int or row['frame_index']<0:raise ValueError('Invalid frame_index')
        if not isinstance(row.get('attempt_id'), str) or not row['attempt_id']:
            raise ValueError('attempt_id required')
        x, target = finite(row['x']), finite(row['target'])
        product=weight*x; predicted=finite(product+bias)
        answer.append({**row,'weighted_input':product,'prediction':predicted,'signed_error':predicted-target})
    return {**data,'model':'scalar affine; offline educational baseline; not ACT',
            'weight':weight,'bias':bias,'rows':answer,'hardware_command':False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('slice');p.add_argument('--weight',type=float,required=True);p.add_argument('--bias',type=float,required=True)
    p.add_argument('--out',required=True);a=p.parse_args()
    try:
        result=predict(json.loads(Path(a.slice).read_text()),a.weight,a.bias)
        with Path(a.out).open('x') as f: json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    except (ValueError,KeyError,TypeError,OSError) as e: p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
