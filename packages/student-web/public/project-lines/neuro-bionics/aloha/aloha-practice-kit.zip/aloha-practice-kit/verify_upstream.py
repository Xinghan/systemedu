#!/usr/bin/env python3
"""AST checks against downloaded pinned source; not a full upstream runtime test."""
import ast
import json
from pathlib import Path
from pprint import pformat
from types import SimpleNamespace
ROOT=Path(__file__).parent/'research'/'lerobot'
CHECKS={
 'src/lerobot/scripts/lerobot_edit_dataset.py':{'EditDatasetConfig':{'repo_id','root','new_root','operation','push_to_hub'},'SplitConfig':{'splits'}},
 'src/lerobot/robots/bi_so_follower/config_bi_so_follower.py':{'BiSOFollowerConfig':{'left_arm_config','right_arm_config','cameras'}},
 'src/lerobot/teleoperators/bi_so_leader/config_bi_so_leader.py':{'BiSOLeaderConfig':{'left_arm_config','right_arm_config'}},
 'src/lerobot/robots/so_follower/config_so_follower.py':{'SOFollowerConfig':{'port','use_degrees','max_relative_target','disable_torque_on_disconnect'}},
 'src/lerobot/configs/dataset.py':{'DatasetRecordConfig':{'repo_id','single_task','root','fps','episode_time_s','reset_time_s','num_episodes','push_to_hub','private','no_stamp'}},
 'src/lerobot/configs/default.py':{'DatasetConfig':{'repo_id','root','episodes','eval_split'},'WandBConfig':{'enable'}},
 'src/lerobot/configs/train.py':{'TrainPipelineConfig':{'dataset','policy','output_dir','steps','batch_size','num_workers','seed','wandb'}},
 'src/lerobot/policies/act/configuration_act.py':{'ACTConfig':{'chunk_size','n_action_steps','temporal_ensemble_coeff','pretrained_backbone_weights'}},
 'src/lerobot/rollout/configs.py':{'RolloutConfig':{'policy','robot','dataset','device','fps','inference','strategy','interpolation_multiplier'},'EpisodicStrategyConfig':{'reset_to_initial_position'}},
}
def run():
 rows=[]
 for path,classes in CHECKS.items():
  tree=ast.parse((ROOT/path).read_text())
  for cls,expected in classes.items():
   node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
   actual={n.target.id for n in node.body if isinstance(n,ast.AnnAssign)}
   assert expected<=actual,(path,cls,expected-actual)
   rows.append({'file':path,'class':cls,'fields_checked':sorted(expected),'status':'PASS'})
 tree=ast.parse((ROOT/'src/lerobot/robots/utils.py').read_text())
 func=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='ensure_safe_goal_position')
 namespace={'logger':SimpleNamespace(warning=lambda *_:None),'pformat':pformat}
 exec(compile(ast.Module(body=[func],type_ignores=[]),'official_extracted_function','exec'),namespace)
 result=namespace['ensure_safe_goal_position']({'shoulder_pan':(120,10),'gripper':(-20,50)},{'shoulder_pan':2.0,'gripper':3.0})
 assert result=={'shoulder_pan':12.0,'gripper':47.0}
 rows.append({'check':'execute exact upstream relative-position clipping function with mocked logger','status':'PASS','result':result})
 return {'scope':'Pinned-source AST fields plus isolated clipping function. No drivers, full CLI parser, GPU or hardware invoked.','checks':rows}
if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False,indent=2))
