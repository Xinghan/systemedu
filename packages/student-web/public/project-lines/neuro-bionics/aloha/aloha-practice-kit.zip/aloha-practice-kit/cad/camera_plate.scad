// Original flat camera/support adapter. All mating dimensions must be measured.
plate_x=undef; plate_y=undef; thickness=4;
// List of [x,y,diameter] for camera and support interfaces, measured and fit-tested.
mount_holes=undef;
$fn=64;
assert(!is_undef(plate_x) && plate_x>0 && !is_undef(plate_y) && plate_y>0);
assert(!is_undef(mount_holes) && len(mount_holes)>0);
for(p=mount_holes)assert(len(p)==3 && p[2]>0 && p[0]>p[2]/2+2 && p[1]>p[2]/2+2 && plate_x-p[0]>p[2]/2+2 && plate_y-p[1]>p[2]/2+2);
difference(){cube([plate_x,plate_y,thickness]);for(p=mount_holes)translate([p[0],p[1],-1])cylinder(h=thickness+2,d=p[2]);}
