#!/usr/bin/env python3
"""Auditable masked L1 + beta KL arithmetic, and a finite joint-table ELBO example."""
import argparse
import json
import math
from pathlib import Path


def table_example():
    # Rows are z=0/1. Columns are target event A/not-A. Sum of all cells is one.
    joint=[[.4,.1],[.1,.4]]
    q=[.6,.4]
    prior=[sum(row) for row in joint]
    evidence=sum(row[0] for row in joint)
    likelihood=[row[0]/p for row,p in zip(joint,prior)]
    posterior=[row[0]/evidence for row in joint]
    recon=sum(w*math.log(l) for w,l in zip(q,likelihood))
    kl_prior=sum(w*math.log(w/p) for w,p in zip(q,prior))
    kl_true=sum(w*math.log(w/p) for w,p in zip(q,posterior))
    return {"provenance":"synthetic","joint":joint,"q":q,"prior":prior,"p_A":evidence,
        "p_A_given_z":likelihood,"p_z_given_A":posterior,"E_q_log_likelihood":recon,
        "KL_q_to_prior":kl_prior,"ELBO":recon-kl_prior,"log_evidence":math.log(evidence),
        "gap_KL_q_to_true_posterior":kl_true,"identity_residual":math.log(evidence)-(recon-kl_prior)-kl_true,
        "scope":"finite two-by-two teaching table; ACT actions are continuous, so their likelihoods are densities"}


def objective(data):
    if data.get("provenance") not in ("synthetic","learner_recording") or not data.get("source_ref"):
        raise ValueError("provenance/source_ref required")
    pred,target,mask=data["prediction"],data["target"],data["action_is_pad"]
    if not pred or len(pred)!=len(target) or len(pred)!=len(mask) or not pred[0] or not pred[0][0]:
        raise ValueError("nonempty equal batch required")
    k,d=len(pred[0]),len(pred[0][0]);numerator=0.;steps=0;per=[]
    for pseq,tseq,mseq in zip(pred,target,mask):
        if len(pseq)!=k or len(tseq)!=k or len(mseq)!=k:raise ValueError("ragged chunk")
        for prow,trow,pad in zip(pseq,tseq,mseq):
            if type(pad) is not bool or len(prow)!=d or len(trow)!=d:raise ValueError("bad dimensions/mask")
            if not all(type(v) in (int,float) and math.isfinite(v) for v in [*prow,*trow]):raise ValueError("nonfinite target/prediction")
            errors=[abs(p-t) for p,t in zip(prow,trow)]
            per.append({"errors":errors,"pad":pad,"included_sum":0 if pad else sum(errors)})
            if not pad:numerator+=sum(errors);steps+=1
    if steps==0:raise ValueError("all-padding batch cannot be a useful training batch")
    beta,kl=data["beta"],data["kl_mean_batch"]
    if not all(type(v) in (int,float) and math.isfinite(v) and v>=0 for v in (beta,kl)):
        raise ValueError("nonnegative finite beta and KL required")
    denom=steps*d;l1=numerator/denom
    if not all(math.isfinite(v) for v in (numerator,l1,beta*kl,l1+beta*kl)):
        raise ValueError("objective reduction exceeds finite numerical range")
    return {"provenance":data["provenance"],"source_ref":data["source_ref"],"rows":per,
        "valid_steps":steps,"action_dim":d,"l1_numerator":numerator,"l1_denominator":denom,
        "l1":l1,"beta":beta,"kl_mean_batch":kl,"weighted_kl":beta*kl,"total":l1+beta*kl,
        "table_example":table_example(),"scope":"transparent arithmetic, not a substitute for real ACT gradient training"}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("input");p.add_argument("output")
    a=p.parse_args();result=objective(json.loads(Path(a.input).read_text()))
    with Path(a.output).open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write("\n")
