# M52 实际代码入口与证据

从解压后的实践包根目录运行命令；这里的 `lessons/Mxx/code` 与包根通用工具不同。所有M48–55入口会定位同包 `lessons/M47/code`，不要只复制一份run.py离开目录结构。

完整原生图像导出需先由导师按包根 `docs/ENVIRONMENT.zh.md` 安装固定LeRobot环境。纯机制代码可另建隔离Python 3.12环境，安装M47目录的 `requirements-cpu-verified.txt`。这些依赖已在macOS arm64 CPU做作者合成QA，不等于所有系统或完整LeRobot已安装验证。正式ACT GPU环境另按课程后续资源评估。

```sh
python3.12 -m venv .venv-vision
source .venv-vision/bin/activate
python -m pip install -r lessons/M47/practice/requirements-cpu-verified.txt
```

本人运行不加 `--allow-synthetic`。该开关只给明确标为synthetic的软件夹具使用，不能让合成文件变成真实作业。先用少量开发行，测试回合始终封存；同一原始回合不能跨组，重命名复制的来源仍需人工审计。

## 本节执行

```sh
python lessons/M52/code/run.py --input work/M51-v1/fixture.pt --output work/M52-v1
```

输入路径需换成本人已审核文件，输出必须是新版本目录。程序不导入设备驱动，不发送硬件动作。

## 应得到什么

gradient-check.json；逐参数透明回传/差分/自动求导及故障版本误差。

JSON可直接打开阅读；可信本地.pt文件可使用：

```sh
python lessons/M47/code/inspect_tensor.py work/M48-v1/features.pt
python lessons/M47/code/inspect_tensor.py work/M50-v1/tokens.pt --path tokens --values
```

将示例文件/键替换为当前输出。不要把不可信来源的二进制文件当课程权重运行。

## 对照与恢复

fault_detected为false可能是退化样本，保留后另选开发片段；不手改报告。当前损失是半平方和，别与均方损失漏掉归约因子地比较。

本目录 `worksheet.csv` 是空白记录表，不预填任何本人测量或成功数据。讲义、作业中的示意数字保持synthetic性质；正式提交用本人原始日志、来源和实际运行结果替换。
