# M56：队列时间图

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M56/code/timeline.py lessons/M56/code/synthetic.json
```

输入 JSON 必须声明 nominal_fps、chunk_size、n_action_steps、temporal_ensemble_coeff 与严格递增的同域 decision_monotonic_s。脚本给每步记录 prediction_origin_index 和片段偏移。夹具应得到来源步0、0、2、2、4；夹具时间戳的相邻间隔为0.11、0.13、0.10、0.12秒。保存输出后按 actual 时间与来源步绘图；不能将工具重建的调度当作实际原生控制日志。可用于本人测得时间的离线配置推演，实际使用了哪个模型输出仍需原始调用记录。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
