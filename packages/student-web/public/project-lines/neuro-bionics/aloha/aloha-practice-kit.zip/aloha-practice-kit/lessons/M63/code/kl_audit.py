#!/usr/bin/env python3
"""Diagonal Gaussian KL to standard normal: sum latent dimensions, mean batch."""
import argparse
import json
import math
from pathlib import Path


def audit(data):
    if data.get("provenance") not in ("synthetic","learner_recording") or not data.get("source_ref"):
        raise ValueError("provenance/source_ref required")
    means,lvs=data["mu"],data["log_variance"]
    if not means or len(means)!=len(lvs) or not means[0]:
        raise ValueError("nonempty matching B x latent lists required")
    width=len(means[0]);terms=[]
    for mrow,lrow in zip(means,lvs):
        if len(mrow)!=width or len(lrow)!=width:raise ValueError("ragged posterior")
        row=[]
        for mean,lv in zip(mrow,lrow):
            if not all(type(v) in (float,int) and math.isfinite(v) for v in (mean,lv)):
                raise ValueError("finite numeric posterior required")
            variance=math.exp(lv)
            # expm1 improves cancellation near zero log variance.
            value=.5*(mean*mean+math.expm1(lv)-lv)
            if variance<=0 or not math.isfinite(variance) or not math.isfinite(value):
                raise ValueError("posterior variance or KL outside finite numerical range")
            row.append({"mu":mean,"log_variance":lv,"variance":variance,
                "mean_square":mean*mean,"variance_minus_one_minus_log":math.expm1(lv)-lv,"kl":value})
        terms.append(row)
    totals=[sum(x["kl"] for x in row) for row in terms]
    if not all(math.isfinite(v) for v in totals) or not math.isfinite(sum(totals)):
        raise ValueError("KL reduction overflow")
    return {"provenance":data["provenance"],"source_ref":data["source_ref"],"terms":terms,
        "sum_latent_per_sample":totals,"mean_batch":sum(totals)/len(totals),
        "unit":"nats (natural logarithm)","scope":"posterior versus fixed standard normal; not KL to the true conditional posterior, not a motion safety score"}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("input");p.add_argument("output")
    a=p.parse_args();result=audit(json.loads(Path(a.input).read_text()))
    with Path(a.output).open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write("\n")
