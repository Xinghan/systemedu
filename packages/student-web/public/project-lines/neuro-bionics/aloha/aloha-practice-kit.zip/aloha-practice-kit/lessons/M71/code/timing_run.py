"""M71: live USB images + explicitly frozen learner state -> ACT -> JSONL sink.

Never imports a robot, motor bus, or execution driver. Physical arm power stays
DISCONNECTED. Host acquisition timing is not exposure-to-motor timing.
"""
import argparse,sys,time,json,csv,math,statistics
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M69/code'))
from act_runtime import load_runtime
from host_observation import *

def summarize(rows,period_s):
 if not rows or not finite(period_s) or period_s<=0:raise ValueError('rows and positive period required')
 out={}
 for field in ('acquire_s','tensorize_s','preprocess_s','inference_s','postprocess_s','offline_write_s','loop_s','oldest_camera_age_s'):
  xs=sorted(r[field] for r in rows)
  if any(not finite(x)or x<0 for x in xs):raise ValueError('finite nonnegative timings required')
  mean=statistics.fmean(xs)
  if not math.isfinite(mean):raise ValueError('timing mean overflow')
  out[field]={'mean_s':mean,'max_s':xs[-1],'p95_nearest_rank_s':xs[math.ceil(.95*len(xs))-1]}
 out['over_budget']=sum(r['loop_s']>period_s for r in rows)
 out['model_forward_steps']=sum(r['policy_model_calls']>0 for r in rows);out['queue_only_steps']=sum(r['policy_model_calls']==0 for r in rows)
 return out

def measure(runtime,cameras,state,output,*,samples,period_s,clock=time.perf_counter,sleeper=time.sleep):
 """Injectable software boundary used by QA, real CLI supplies USB cameras."""
 if type(samples)is not int or samples<3 or not finite(period_s)or period_s<=0:raise ValueError('at least three samples and positive period')
 output=Path(output);output.mkdir(parents=True,exist_ok=False);rows=[];runtime.reset()
 with (output/'offline-actions.jsonl').open('x')as sink:
  for i in range(samples):
   start=clock();frames={};stamps={}
   for name,camera in cameras.items():
    # Block for a new host frame, then copy a consistent latest pair.
    camera.read();frames[name],stamps[name]=camera_snapshot(camera,clock=clock)
   acquired=clock();obs=observation_tensors(state,frames);tensorized=clock();action,parts=runtime.profile_action(obs,clock=clock)
   values=action.tolist()
   if len(values)!=12 or any(not finite(x)for x in values):raise ValueError('invalid native action output')
   before=clock();record={'sequence':i,'source':'policy','destination':'offline_jsonl_only','action_fields':FIELDS,'action_units':UNITS,'action_semantics':'teleop_action_processor target','requested':dict(zip(FIELDS,values)),'camera_host_arrivals_s':stamps,'frozen_state':True}
   sink.write(json.dumps(record,allow_nan=False)+'\n');sink.flush();end=clock()
   row={'sequence':i,'acquire_s':acquired-start,'tensorize_s':tensorized-acquired,**parts,'offline_write_s':end-before,'loop_s':end-start,'oldest_camera_age_s':end-min(stamps.values()),'front_arrival_s':stamps['front'],'overhead_arrival_s':stamps['overhead']}
   rows.append(row);sleeper(max(0,period_s-(clock()-start)))
 summary=summarize(rows,period_s)
 with(output/'timing.csv').open('x',newline='')as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 # Standalone scientific timeline, exact first 30 recorded rows, no invented values.
 plot_rows=rows[:30];scale=780/max(period_s,max(r['loop_s'] for r in plot_rows));h=100+24*len(plot_rows)
 svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="{h}" viewBox="0 0 1100 {h}"><rect width="1100" height="{h}" fill="#fff"/><text x="20" y="25" font-family="sans-serif" font-size="18">Measured host loop to offline sink — not motor latency</text>']
 for i,r in enumerate(plot_rows):
  y=60+24*i;svg.append(f'<text x="20" y="{y+13}" font-size="12">{r["sequence"]}: {r["loop_s"]*1000:.2f} ms</text><rect x="180" y="{y}" width="{r["loop_s"]*scale:.3f}" height="16" fill="#2563eb"/>')
 svg.append(f'<path d="M {180+period_s*scale} 42 V {h-10}" stroke="#b91c1c" stroke-dasharray="4 4"/><text x="180" y="45" font-size="12">Dashed line: planned period {period_s*1000:.2f} ms</text></svg>');(output/'timeline.svg').write_text(''.join(svg))
 return rows,summary

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('pretrained','checkout','manifest','artifact-root','view','episode','cameras','output'):p.add_argument('--'+key,required=True)
 p.add_argument('--frame',type=int,required=True);p.add_argument('--samples',type=int,default=100);p.add_argument('--period-s',type=float,required=True);p.add_argument('--device',choices=['cpu','cuda'],default='cpu');a=p.parse_args()
 if read(a.manifest).get('source_kind')!='learner_recording':raise ValueError('student M71 CLI requires original learner-trained model provenance')
 runtime=load_runtime(a.pretrained,a.checkout,a.device,model_manifest=a.manifest,artifact_root=a.artifact_root);state,origin=load_state(a.view,a.episode,a.frame)
 from lerobot.cameras.opencv.camera_opencv import OpenCVCamera
 cameras={n:OpenCVCamera(c)for n,c in camera_configs(read(a.cameras)).items()};connected=[]
 try:
  for camera in cameras.values():camera.connect();connected.append(camera)
  rows,summary=measure(runtime,cameras,state,a.output,samples=a.samples,period_s=a.period_s)
  report={'schema':'aloha.host-timing.v1','source_kind':'learner_recording','model_manifest_sha256':runtime.model_manifest_sha256,'camera_config_sha256':sha(a.cameras),'state_source':origin,'samples':len(rows),'period_s':a.period_s,'summary':summary,'physical_motor_commands':0,'hardware_latency_measured':False,'camera_timestamp_meaning':'host after capture/postprocess in this process, not exposure','warmup_policy':'first call retained and marked by sequence; compare model-call versus queue-only groups'}
  from course_contract import write_new
  write_new(Path(a.output)/'report.json',report);print(json.dumps(report,ensure_ascii=False,allow_nan=False,indent=2))
 finally:
  for camera in reversed(connected):camera.disconnect()
if __name__=='__main__':main()
