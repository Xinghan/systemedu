"""Lesson entry points. All outputs are offline; no device is imported or called."""
import argparse
from pathlib import Path
import json
import math
import torch
from torch.nn import functional as F
import torchvision
from vision_course import *


def base_record(data):
    return dict(source_kind=data['source_kind'],dataset_source=data['dataset_source'],manifest_sha256=data['manifest_sha256'],image_contract=data['contract'],evidence=data['evidence'],hardware_output=False,torch_version=str(torch.__version__),torchvision_version=str(torchvision.__version__))


def step47(args,data,out):
    trace,edge=conv_window(data['pixels'],args.row,args.col)
    blurred=F.avg_pool2d(data['pixels'][0,0][None],3,stride=1,padding=1)[0]
    blur_trace,blur_edge=conv_window(blurred[None,None],args.row,args.col)
    report=base_record(data)|dict(window=trace,blurred_window=blur_trace,mean_abs_response=edge.abs().mean().item(),blurred_mean_abs_response=blur_edge.abs().mean().item(),diagnostic_scope='This edge response is not a universal blur score; low-texture images can also respond weakly.')
    write_json(out/'window.json',report);torch.save(dict(edge=edge,blurred_edge=blur_edge),out/'edge_maps.pt')


def step48(args,data,out):
    torch.manual_seed(48);backbone=build_backbone(args.weights)
    for p in backbone.parameters():p.requires_grad_(False)
    images=data['images'];b,c,_,h,w=images.shape;x=images.reshape(b*c,3,h,w)
    with torch.no_grad():
        backbone.eval();layers=backbone(x);backbone.train();train_layers=backbone(x)
    frozen=[n for n,m in backbone.named_modules() if m.__class__.__name__=='FrozenBatchNorm2d']
    stats_before={n:v.clone() for n,v in backbone.named_buffers() if 'running_' in n}
    with torch.no_grad():backbone(x*2)
    stats_unchanged=all(torch.equal(v,dict(backbone.named_buffers())[n]) for n,v in stats_before.items())
    # Recompute the first residual addition explicitly using the same saved modules.
    with torch.no_grad():
        z=backbone.maxpool(backbone.relu(backbone.bn1(backbone.conv1(x))))
        block=backbone.layer1[0];branch=block.bn2(block.conv2(block.relu(block.bn1(block.conv1(z)))))
        identity=z if block.downsample is None else block.downsample(z)
        recomputed=F.relu(branch+identity);actual=block(z)
    feat=layers['feature_map'].reshape(b,c,512,*layers['feature_map'].shape[-2:]);stats=training_stats(data)
    report=base_record(data)|dict(backbone='resnet18',pretrained_weights=args.weights,backbone_role='generic visual features, not a learned robot task policy',layers={k:list(v.shape) for k,v in layers.items()},frozen_batch_norm_layers=frozen,frozen_stats_unchanged=stats_unchanged,train_eval_max_difference=max((layers[k]-train_layers[k]).abs().max().item() for k in layers),residual=dict(branch_shape=list(branch.shape),identity_shape=list(identity.shape),max_recompute_error=(recomputed-actual).abs().max().item()),all_backbone_parameters_frozen=True)
    write_json(out/'backbone-report.json',report)
    torch.save(dict(feature_maps=feat,state=data['state'],stats=stats,metadata=report),out/'features.pt')
    torch.save(dict(state_dict=backbone.state_dict(),weights_name=args.weights,report=report),out/'backbone.pt')


def step49(args,data,out):
    if not args.input:raise ValueError('M49 requires --input M48-output/backbone.pt')
    saved=torch.load(args.input,weights_only=True,map_location='cpu');model=build_backbone('none');model.load_state_dict(saved['state_dict']);model.eval()
    pixels=data['pixels'][0:1].clone();h,w=pixels.shape[-2:]
    if not args.rectangle:raise ValueError('Define --rectangle x0 y0 x1 y1 after writing the hypothesis')
    x0,y0,x1,y1=args.rectangle
    if not (0<=x0<x1<=w and 0<=y0<y1<=h):raise ValueError('Mask rectangle outside resized image')
    masked=pixels.clone();ci=['front','overhead'].index(args.camera);masked[0,ci,:,y0:y1,x0:x1]=args.fill
    mean=torch.tensor(MEAN)[None,None,:,None,None];std=torch.tensor(STD)[None,None,:,None,None]
    with torch.no_grad():
        baseline=model(((pixels-mean)/std).flatten(0,1))['feature_map'];changed=model(((masked-mean)/std).flatten(0,1))['feature_map']
    report=base_record(data)|dict(hypothesis=args.hypothesis,intervention=dict(camera=args.camera,rectangle=[x0,y0,x1,y1],fill_rgb_0_1=args.fill),backbone_sha256=sha256(args.input),weights_name=saved['weights_name'],feature_mean_abs_change=(changed-baseline).abs().mean().item(),feature_max_abs_change=(changed-baseline).abs().max().item(),conclusion_scope='Change in this intervention is not proof of object understanding or a causal interpretation of an attention heat map.')
    if not args.hypothesis.strip():raise ValueError('Write --hypothesis before running the intervention')
    write_json(out/'intervention.json',report);torch.save(dict(baseline=baseline,changed=changed),out/'feature-comparison.pt')


def step50(args,data,out):
    if not args.input:raise ValueError('M50 requires --input M48-output/features.pt')
    saved=torch.load(args.input,weights_only=True,map_location='cpu');maps=saved['feature_maps'];torch.manual_seed(50)
    projection=nn.Conv2d(maps.shape[2],8,1);b,c,d,h,w=maps.shape
    projected=projection(maps.reshape(b*c,d,h,w)).reshape(b,c,8,h,w)
    visual,pos,index=tokens_from_maps(projected,['front','overhead']);state_projection=nn.Linear(12,8)
    state=state_projection(normalize(saved['state'],saved['stats']['state'])).unsqueeze(1)
    state_pos=torch.zeros(1,8);tokens=torch.cat([state,visual],1);position=torch.cat([state_pos,pos],0)[None]
    index=[dict(token=0,kind='state',fields=FIELDS)]+[dict(x,token=x['token']+1) for x in index]
    # Token order by itself does not encode position. A joint permutation is equivariant.
    torch.manual_seed(500);fusion=Fusion(8,2).eval();permutation=torch.arange(tokens.shape[1]-1,-1,-1)
    with torch.no_grad():
        reference=fusion(tokens,position);joint=fusion(tokens[:,permutation],position[:,permutation]);mispaired=fusion(tokens[:,permutation],position)
    report=saved['metadata']|dict(input_shape=list(maps.shape),projected_shape=list(projected.shape),token_shape=list(tokens.shape),position_shape=list(position.shape),source_index=index,projection_role='seeded debug adapter, not trained robot policy',camera_id_embedding=False,joint_permutation_max_error=(joint-reference[:,permutation]).abs().max().item(),mispaired_permutation_max_error=(mispaired-reference[:,permutation]).abs().max().item())
    write_json(out/'token-ledger.json',report)
    torch.save(dict(tokens=tokens.detach(),position=position,index=index,metadata=report,projection_state=projection.state_dict(),state_projection=state_projection.state_dict()),out/'tokens.pt')


def fixture_from_tokens(path):
    saved=torch.load(path,weights_only=True,map_location='cpu');visual=saved['tokens'][0,1:];channels=visual.var(0,unbiased=False).topk(2).indices;selected=torch.tensor([0,len(visual)//2,len(visual)-1]);raw=visual[selected][:,channels].double();scale=max(1.,raw.abs().max().item());x=raw/scale
    if x.shape!=(3,2):raise ValueError('Need at least three visual tokens with two channels')
    # Explicit projection tables. Saved values are the debugging parameters, not ACT weights.
    return dict(xq=x[0],xkv=x,wq=torch.tensor([[.5,.1],[-.2,.3]],dtype=torch.float64),wk=torch.tensor([[.4,-.1],[.2,.6]],dtype=torch.float64),wv=torch.tensor([[1.,.2],[-.1,.7]],dtype=torch.float64),target=torch.tensor([.1,-.2],dtype=torch.float64),metadata=saved['metadata'],selected_visual_token_indices=(selected+1).tolist(),selected_feature_channels=channels.tolist(),raw_features=raw,debug_common_scale=scale)


def step51(args,data,out):
    if not args.input:raise ValueError('M51 requires --input M50-output/tokens.pt')
    fixture=fixture_from_tokens(args.input);xq,xkv,wq,wk,wv,target=[fixture[k] for k in ['xq','xkv','wq','wk','wv','target']]
    q=xq@wq;k=xkv@wk;v=xkv@wv;trace=attention_trace(q,k,v)
    library=F.scaled_dot_product_attention(q[None,None,None],k[None,None],v[None,None],dropout_p=0).reshape(-1)
    scores=trace['scores'];shifted_weights=torch.softmax(scores+1000,0)
    report=fixture['metadata']|dict(debug_fixture=True,selected_visual_token_indices=fixture['selected_visual_token_indices'],selected_feature_channels=fixture['selected_feature_channels'],raw_features=fixture['raw_features'],debug_common_scale=fixture['debug_common_scale'],xq=xq,xkv=xkv,wq=wq,wk=wk,wv=wv,q=q,k=k,v=v,trace=trace,weight_sum=trace['weights'].sum(),library_max_error=(library-trace['output']).abs().max(),shift_invariance_max_error=(shifted_weights-trace['weights']).abs().max(),claim='These are normalized reading weights, not object-existence probabilities.')
    write_json(out/'attention-table.json',serialize(report));torch.save(fixture,out/'fixture.pt')


def step52(args,data,out):
    if not args.input:raise ValueError('M52 requires --input M51-output/fixture.pt')
    f=torch.load(args.input,weights_only=True,map_location='cpu');keys=['xq','xkv','wq','wk','wv','target'];values=[f[k] for k in keys]
    manual=attention_loss_and_grads(*values);wrong=attention_loss_and_grads(*values,fault=True)
    epsilon=1e-5;entries=[]
    for name in ['wq','wk','wv']:
        parameter=f[name]
        for row in range(parameter.shape[0]):
            for col in range(parameter.shape[1]):
                plus={k:v.clone() for k,v in zip(keys,values)};minus={k:v.clone() for k,v in zip(keys,values)}
                plus[name][row,col]+=epsilon;minus[name][row,col]-=epsilon
                num=(attention_loss_and_grads(*[plus[k] for k in keys])['loss']-attention_loss_and_grads(*[minus[k] for k in keys])['loss'])/(2*epsilon)
                exact=manual[name+'_grad'][row,col];fault=wrong[name+'_grad'][row,col]
                entries.append(dict(parameter=name,row=row,col=col,analytic=exact.item(),finite_difference=num.item(),abs_error=abs(exact-num).item(),fault_value=fault.item(),fault_abs_error=abs(fault-num).item()))
    differentiable=[v.clone().requires_grad_(True) for v in values];autoloss=attention_loss_and_grads(*differentiable)['loss'];autoloss.backward()
    auto={name:(differentiable[keys.index(name)].grad-manual[name+'_grad']).abs().max().item() for name in ['wq','wk','wv']}
    report=f['metadata']|dict(epsilon=epsilon,loss=manual['loss'],trace=manual,entries=entries,autograd_max_errors=auto,fault_detected=max(e['fault_abs_error'] for e in entries)>1e-8,fault='Removed the off-diagonal shared-denominator contribution. V gradient is unchanged; Q/K gradients can be wrong. If fault_detected is false, choose a less degenerate real sample and retain this result.',scope='one small real-feature-derived debugging fixture; not proof of every ACT gradient')
    write_json(out/'gradient-check.json',serialize(report))


def step53(args,data,out):
    if not args.input:raise ValueError('M53 requires --input M50-output/tokens.pt')
    saved=torch.load(args.input,weights_only=True,map_location='cpu');tokens=saved['tokens'];pos=saved['position'];torch.manual_seed(53);model=Fusion(8,2).eval();mask=torch.zeros(tokens.shape[:2],dtype=torch.bool)
    with torch.no_grad():fused=model(tokens,pos,mask)
    # Compare the exact independent projection tables with PyTorch MultiheadAttention.
    mha=nn.MultiheadAttention(8,2,dropout=0,batch_first=True)
    with torch.no_grad():
        mha.in_proj_weight.copy_(torch.cat([model.attn.q.weight,model.attn.k.weight,model.attn.v.weight]));mha.in_proj_bias.copy_(torch.cat([model.attn.q.bias,model.attn.k.bias,model.attn.v.bias]));mha.out_proj.load_state_dict(model.attn.out.state_dict())
        lib,_=mha(tokens+pos,tokens+pos,tokens,key_padding_mask=mask,average_attn_weights=False)
    first=model.trace['first_residual'][0,0];mean=first.mean();variance=(first-mean).square().mean();manual=(first-mean)/torch.sqrt(variance+model.norm1.eps)*model.norm1.weight+model.norm1.bias
    report=saved['metadata']|dict(heads=2,hidden_dim=8,head_dim=4,head_shapes={k:list(v.shape) for k,v in model.attn.trace.items()},library_attention_max_error=(lib-model.trace['read']).abs().max().item(),layer_norm=dict(values=first,mean=mean,population_variance=variance,epsilon=model.norm1.eps,manual=manual,library=model.trace['first_norm'][0,0],max_error=(manual-model.trace['first_norm'][0,0]).abs().max()),dropout=0,trace=model.trace)
    write_json(out/'fusion-trace.json',serialize(report));torch.save(dict(fused=fused,position=pos,mask=mask,index=saved['index'],metadata=saved['metadata'],fusion_state=model.state_dict()),out/'fusion.pt')


def step54(args,data,out):
    if not args.input:raise ValueError('M54 requires --input M53-output/fusion.pt')
    saved=torch.load(args.input,weights_only=True,map_location='cpu');torch.manual_seed(54);model=ActionDecoder(8,2,1).eval()
    with torch.no_grad():
        baseline=model(saved['fused'],saved['position'],saved['mask']);mask=saved['mask'].clone();mask[:,0]=True;without_state=model(saved['fused'],saved['position'],mask)
    report=saved['metadata']|dict(output=baseline,output_shape=list(baseline.shape),fields=FIELDS,regression=True,query_count=1,initial_decoder_content='zero tensor plus learned query position only in Q/K',without_state_key_output=without_state,max_change=(without_state-baseline).abs().max(),caveat='State information may already be present in fused visual tokens. This masks only the decoder state key, not every causal state path.',hardware_output=False,weights_trained_for_robot=False)
    write_json(out/'decoder-trace.json',serialize(report));torch.save(dict(state_dict=model.state_dict(),metadata=report),out/'decoder.pt')


def step55(args,data,out):
    validation=load_manifest(args.manifest,'validation',args.allow_synthetic);stats=training_stats(data);torch.manual_seed(55);model=TinyVisionPolicy(8,2);optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=0)
    train_state=normalize(data['state'],stats['state']);target=normalize(data['action'],stats['action']);validation_state=normalize(validation['state'],stats['state']);val_target=normalize(validation['action'],stats['action'])
    history=[];gradient_norms={}
    for step in range(args.steps+1):
        model.train();prediction=model(data['images'],train_state);loss=F.mse_loss(prediction,target)
        if step in [0,args.steps] or step%10==0:
            model.eval()
            with torch.no_grad():vl=F.mse_loss(model(validation['images'],validation_state),val_target)
            history.append(dict(step=step,train_loss=loss.item(),validation_loss=vl.item()))
        if step==args.steps:break
        model.train();optimizer.zero_grad();loss.backward()
        if step==0:gradient_norms={name:sum((p.grad.square().sum().item() if p.grad is not None else 0) for p in module.parameters())**.5 for name,module in [('visual',model.visual),('state_projection',model.state_projection),('fusion',model.fusion),('decoder',model.decoder)]}
        optimizer.step()
    model.eval()
    with torch.no_grad():reference=model(data['images'],train_state);final_trace=serialize(model.trace);real_units=denormalize(reference,stats['action'])
    checkpoint=dict(model_state=model.state_dict(),optimizer_state=optimizer.state_dict(),config=dict(dim=8,heads=2),stats=stats,image_contract=data['contract'],state_fields=FIELDS,action_fields=FIELDS,source_kind=data['source_kind'],dataset_source=data['dataset_source'],train_manifest_sha256=data['manifest_sha256'],steps=args.steps,model_kind='teaching TinyVisionPolicy; not full ACT',hardware_output=False)
    torch.save(checkpoint,out/'checkpoint.pt')
    restored=torch.load(out/'checkpoint.pt',weights_only=True,map_location='cpu');reloaded=TinyVisionPolicy(**restored['config']);reloaded.load_state_dict(restored['model_state']);reloaded.eval()
    with torch.no_grad():again=reloaded(data['images'],normalize(data['state'],restored['stats']['state']))
    report=base_record(data)|dict(model_kind=checkpoint['model_kind'],history=history,first_step_gradient_norms=gradient_norms,prediction_original_units=real_units,checkpoint_sha256=sha256(out/'checkpoint.pt'),reload_max_error=(reference-again).abs().max(),training_statistics=stats,validation_evidence=validation['evidence'],validation_usage='development, not reserved final test',test_rows_loaded=False,trace=final_trace)
    write_json(out/'training-report.json',serialize(report))


def main(default_step=None):
    parser=argparse.ArgumentParser(description=__doc__)
    if default_step is None:parser.add_argument('step',type=int,choices=range(47,56))
    parser.add_argument('--manifest',type=Path);parser.add_argument('--input',type=Path);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--allow-synthetic',action='store_true');parser.add_argument('--weights',choices=['none','IMAGENET1K_V1'],default='IMAGENET1K_V1')
    parser.add_argument('--row',type=int,default=2);parser.add_argument('--col',type=int,default=2);parser.add_argument('--rectangle',nargs=4,type=int);parser.add_argument('--camera',choices=['front','overhead'],default='front');parser.add_argument('--fill',type=float,default=0);parser.add_argument('--hypothesis',default='')
    parser.add_argument('--steps',type=int,default=100);parser.add_argument('--lr',type=float,default=.003)
    args=parser.parse_args();step=default_step or args.step
    if args.steps<1 or args.lr<=0 or not math.isfinite(args.lr) or not 0<=args.fill<=1:parser.error('Invalid numeric configuration')
    if args.output.exists() and any(args.output.iterdir()):parser.error('Output must be empty/new; preserve earlier attempts')
    args.output.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1)
    data=None
    if step in [47,48,49,55]:
        if args.manifest is None:parser.error('This step needs --manifest')
        data=load_manifest(args.manifest,'train',args.allow_synthetic)
    elif args.input:
        source=torch.load(args.input,weights_only=True,map_location='cpu')['metadata']['source_kind']
        if source=='synthetic' and not args.allow_synthetic:parser.error('Synthetic input requires --allow-synthetic')
    globals()['step'+str(step)](args,data,args.output)
    print(json.dumps(dict(step=step,output=str(args.output.resolve()),hardware_output=False),ensure_ascii=False))


if __name__=='__main__':main()
