import copy
import json
import math
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import course_cli as c
from act_commands import generate
ROOT=Path(__file__).resolve().parents[1]
def fixture(name):return c.read_json(ROOT/'examples'/name)

class TeachingMath(unittest.TestCase):
    def test_fields_units(self):
        result=c.fields(fixture('state.json'))
        self.assertEqual(len(result['fields']),12)
        self.assertEqual(result['fields'][5]['unit'],'normalized_0_100')
        self.assertEqual(result['fields'][0]['unit'],'degree')
    def test_missing_field_rejected(self):
        data=fixture('state.json');data['state'].pop(c.FIELDS[0])
        with self.assertRaises(ValueError):c.fields(data)
    def test_sampling(self):
        r=c.sampling(fixture('sampling.json'));self.assertAlmostEqual(r['mean_rate_hz'],7.5)
    def test_duplicate_time(self):
        with self.assertRaises(ValueError):c.sampling({'timestamps_s':[0,0],'provenance':'test'})
    def test_absolute_and_relative_limits(self):
        r=c.limits(fixture('limits.json'));self.assertEqual(r['rows'][0]['after_absolute_clip'],30)
        self.assertEqual(r['rows'][0]['dry_run_target'],2);self.assertEqual(r['rows'][5]['dry_run_target'],52)
    def test_present_outside_rejected(self):
        d=fixture('limits.json');d['present'][c.FIELDS[0]]=100
        with self.assertRaises(ValueError):c.limits(d)
    def test_nan_rejected(self):
        with self.assertRaises(ValueError):c.number(float('nan'))
    def test_negative_limit_rejected(self):
        d=fixture('limits.json');d['limits'][c.FIELDS[0]]['max_delta']=-1
        with self.assertRaises(ValueError):c.limits(d)
    def test_future_image_detected(self):
        r=c.sync_audit(fixture('sync.json'));self.assertFalse(r['passes_declared_checks']);self.assertEqual(r['findings'][0]['kind'],'future_information')
    def test_gradient_update(self):
        r=c.toy_train(fixture('toy_train.json'))['history']
        self.assertEqual(r[0]['train_mse'],5);self.assertEqual(r[0]['gradient_w'],-3);self.assertEqual(r[0]['gradient_b'],-4)
        self.assertAlmostEqual(r[1]['w'],.3);self.assertAlmostEqual(r[1]['b'],.4)
        self.assertAlmostEqual(r[1]['train_mse'],2.825);self.assertLess(r[-1]['train_mse'],r[0]['train_mse'])
    def test_ensemble_oldest_weight(self):
        r=c.ensemble(fixture('chunks.json'));self.assertAlmostEqual(r['candidates'][0]['weight'],2/3)
        self.assertEqual(len(r['candidates']),2);self.assertAlmostEqual(r['ensembled_action'][0],20)
        self.assertAlmostEqual(r['ensembled_action'][1],30)
    def test_uniform_ensemble(self):
        d=fixture('chunks.json');d['coefficient']=0
        self.assertEqual(c.ensemble(d)['ensembled_action'],[25,35])
    def test_no_available_chunk(self):
        d=fixture('chunks.json');d['target_step']=99
        with self.assertRaises(ValueError):c.ensemble(d)

class Evidence(unittest.TestCase):
    def test_whole_episode_and_batch_split(self):
        d=fixture('episode_index.json')
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'out';r=c.split_episodes(d,ROOT/'examples'/'episodes',out)
            indices=r['lerobot_episode_indices'];self.assertFalse(set(indices['train'])&set(indices['validation']))
            self.assertEqual(indices['test'],[4,5]);self.assertEqual(r['excluded_from_learning'][0]['episode_index'],1)
            for ep in r['episodes']:
                before=(ROOT/'examples'/'episodes'/f"{ep['episode_index']}.jsonl").read_bytes()
                after=(out/ep['split']/f"episode_{ep['episode_index']:06d}.jsonl").read_bytes()
                self.assertEqual(before,after)
            with self.assertRaises(ValueError):c.split_episodes(d,ROOT/'examples'/'episodes',out)
    def test_mixed_episode_rejected(self):
        d=fixture('episode_index.json');d['episodes'][0]['file']='1.jsonl'
        with tempfile.TemporaryDirectory()as tmp:
            with self.assertRaises(ValueError):c.split_episodes(d,ROOT/'examples'/'episodes',Path(tmp)/'out')
    def test_path_escape_rejected(self):
        d=fixture('episode_index.json');d['episodes'][0]['file']='../../README.zh.md'
        with tempfile.TemporaryDirectory()as tmp:
            with self.assertRaises(ValueError):c.split_episodes(d,ROOT/'examples'/'episodes',Path(tmp)/'out')
    def test_all_failures_in_denominator(self):
        r=c.evaluate(fixture('evaluation.json'));self.assertEqual(r['planned_trials'],4);self.assertEqual(r['successes'],1);self.assertEqual(r['success_rate'],.25)
    def test_missing_record_incomplete(self):
        d=fixture('evaluation.json');d['results'].pop();r=c.evaluate(d)
        self.assertFalse(r['complete']);self.assertEqual(r['planned_trials'],4);self.assertEqual(r['trials'][-1]['reason'],'missing_record')
    def test_duplicate_trial_rejected(self):
        d=fixture('evaluation.json');d['results'].append(d['results'][0])
        with self.assertRaises(ValueError):c.evaluate(d)

class Commands(unittest.TestCase):
    def config(self):return fixture('act_config.synthetic.json')
    def split(self):return {'lerobot_episode_indices':{'train':[0,2],'validation':[3],'test':[4,5]}}
    def test_record_no_policy_or_upload(self):
        argv=generate(self.config(),'record')['argv'];self.assertEqual(argv[0],'lerobot-record')
        self.assertIn('--dataset.push_to_hub=false',argv);self.assertIn('--dataset.no_stamp=true',argv)
        self.assertFalse(any(x.startswith('--policy') for x in argv))
    def test_train_only_train_indices(self):
        argv=generate(self.config(),'train',self.split())['argv']
        self.assertIn('--dataset.episodes=[0,1]',argv);self.assertIn('--policy.push_to_hub=false',argv)
        self.assertIn('--dataset.repo_id=local/course_demo_v1_train',argv)
    def test_physical_split_reindex(self):
        r=generate(self.config(),'split-lerobot',self.split())
        self.assertEqual(r['argv'][0],'lerobot-edit-dataset');self.assertEqual(r['reindex_map']['train'],{'0':0,'2':1})
    def test_rollout_separate_single_trial(self):
        argv=generate(self.config(),'rollout')['argv'];self.assertEqual(argv[0],'lerobot-rollout')
        self.assertIn('--dataset.num_episodes=1',argv);self.assertIn('--strategy.reset_to_initial_position=false',argv)
        self.assertFalse(any(x.startswith('--teleop')for x in argv))
    def test_template_must_be_filled(self):
        with self.assertRaises(ValueError):generate(c.read_json(ROOT/'templates'/'act_config.json'),'record')
    def test_duplicate_port(self):
        d=self.config();d['ports']['right_follower']=d['ports']['left_follower']
        with self.assertRaises(ValueError):generate(d,'record')
    def test_temporal_requires_single_step(self):
        d=self.config();d['train']['n_action_steps']=2
        with self.assertRaises(ValueError):generate(d,'train',self.split())
    def test_overlapping_split(self):
        d=self.split();d['lerobot_episode_indices']['validation']=[0]
        with self.assertRaises(ValueError):generate(self.config(),'train',d)

if __name__=='__main__':unittest.main()
