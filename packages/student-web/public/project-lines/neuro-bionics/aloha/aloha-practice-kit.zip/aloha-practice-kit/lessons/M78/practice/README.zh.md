# M78 实际输入、操作与恢复

从解压后的实践包根目录运行；保留 lessons/M73–M78 的相邻目录，入口通过同包相对路径复用 M74 的唯一审核。Python 3.12 标准库足够运行本批证据/统计工具；真实 ACT 的加载、处理器与设备环境仍沿用 M69–M72 固定实现，不能用本批轻量环境替代。

所有输出新建、不覆盖。空白模板只说明输入字段，不能直接充当真实成绩。synthetic 仅软件夹具，永不性能达标；learner_recording 是来源声明，摘要一致不认证现场真实性。保存整个证据根目录，相对路径随包移动。单独拷贝一个Python文件会丢失跨节点审核依赖。

## 先注册独立挑战计划

复制challenge-draft.template.json，填主计划实际SHA、一个因素与两个量值、单位、测量方法、固定项、解释范围和全部额外trial_id。baseline与challenge可预先安排，编号不得复用主验收。先注册再开现场回合：

```sh
python lessons/M78/code/challenge_report.py work/evidence/challenge-draft.json --register --root work/evidence --output work/evidence/challenge-plan.json
python lessons/M75/code/run_record.py start work/evidence/plan.json --root work/evidence --trial CHALLENGE_ID --purpose domain_challenge --operator LOCAL_CODE --context-plan work/evidence/challenge-plan.json
```

M75 start保存挑战原件的字节摘要。之后改因素、量值、次数或文件排版都会使旧记录绑定失效。任务动作仍走现场网关，不因挑战放宽物理范围。结束依M75 close保存三类实际证据。

```sh
python lessons/M78/code/challenge_report.py work/evidence/challenge-plan.json --root work/evidence --output work/evidence/challenge-report.json
```

缺少预定项明确不完整，额外未列入的回合另列；主分母固定仍20。报告不自动认证单因素干预或真实现场。若基准来自较早时段，明确时间/磨损混杂；新的探索只支持实际测过范围。改变模型或夹具属于M79新版本，不回填旧成绩。
