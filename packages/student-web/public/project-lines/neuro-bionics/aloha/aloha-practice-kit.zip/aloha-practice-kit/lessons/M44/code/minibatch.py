"""Reproducible, no-replacement within-epoch sampler with an explicit cursor."""
import random
def initialize(count,batch_size,seed=17):
 if type(count) is not int or count<1 or type(batch_size) is not int or not 1<=batch_size<=count or type(seed) is not int:raise ValueError('Valid count, batch size and integer seed required')
 order=list(range(count));random.Random(seed).shuffle(order)
 return {'schema':'aloha.minibatch.v1','count':count,'batch_size':batch_size,'seed':seed,'epoch':0,'cursor':0,'order':order,'shuffle_rule':'Python Random(seed+epoch) permutation; save actual current order/cursor; no dropped last batch'}
def validate(state,count):
 if not isinstance(state,dict) or state.get('schema')!='aloha.minibatch.v1' or state.get('count')!=count:raise ValueError('Sampler count/schema differs')
 if type(state.get('batch_size')) is not int or not 1<=state['batch_size']<=count or type(state.get('seed')) is not int or type(state.get('epoch')) is not int or state['epoch']<0 or type(state.get('cursor')) is not int or not 0<=state['cursor']<=count:raise ValueError('Invalid sampler cursor')
 if not isinstance(state.get('order'),list) or any(type(v) is not int for v in state['order']) or sorted(state['order'])!=list(range(count)):raise ValueError('Sampler order is not a permutation')
 if state.get('shuffle_rule')!=initialize(count,state['batch_size'],state['seed'])['shuffle_rule']:raise ValueError('Sampler rule changed')
 expected=list(range(count));random.Random(state['seed']+state['epoch']).shuffle(expected)
 if state['order']!=expected:raise ValueError('Saved permutation differs from declared epoch/seed')
def next_batch(state):
 validate(state,state['count']);s={**state,'order':list(state['order'])}
 if s['cursor']==s['count']:
  s['epoch']+=1;s['cursor']=0;s['order']=list(range(s['count']));random.Random(s['seed']+s['epoch']).shuffle(s['order'])
 start=s['cursor'];end=min(start+s['batch_size'],s['count']);indices=s['order'][start:end];s['cursor']=end
 return indices,s,{'epoch':s['epoch'],'start_cursor':start,'end_cursor':end,'count':len(indices),'indices':indices}
