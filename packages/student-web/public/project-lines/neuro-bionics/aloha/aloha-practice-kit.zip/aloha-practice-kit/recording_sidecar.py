"""Append-only records for learner-added instrumentation of pinned LeRobot.

Creating this writer does not instrument LeRobot: place append_frame at the
documented call site. Arrival timestamps are not sensor exposure timestamps.
"""
import hashlib
import json
import math
from pathlib import Path
import uuid

ACTION_FIELDS = ('raw_teleop_action', 'teleop_processor_action',
                 'robot_processor_action_to_send', 'driver_returned_sent_action', 'observed_state')


def scalar(value):
    if hasattr(value, 'item'):
        value = value.item()
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError('Sidecar numeric values must be finite scalars')
    return float(value)


class RecordingSidecar:
    def __init__(self, path, provenance, *, required_joint_fields):
        if provenance.get('kind') not in ('synthetic', 'learner_recording') or not provenance.get('source'):
            raise ValueError('Name the actual recording source, or explicitly identify synthetic data')
        fields = tuple(required_joint_fields)
        if not fields or len(fields) != len(set(fields)):
            raise ValueError('Explicit ordered joint-field list required')
        self.fields, self.provenance = fields, dict(provenance)
        self.attempt_id = uuid.uuid4().hex
        self._stream = Path(path).open('x', encoding='utf-8')
        self._last_index = -1
        self._episode = None
        self._last_time = None
        self._closed = False
        self._write({'event': 'attempt_started', 'attempt_id': self.attempt_id,
                     'provenance': self.provenance, 'joint_fields': fields,
                     'timestamp_contract': 'monotonic host arrival; not exposure'})

    def _write(self, row):
        self._stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+'\n')
        self._stream.flush()

    def append_frame(self, *, episode_index, frame_index, nominal_fps,
                     monotonic_observation_arrival, monotonic_send_start, monotonic_send_end,
                     **values):
        if self._closed:
            raise ValueError('Sidecar is closed')
        if type(episode_index) is not int or episode_index < 0 or type(frame_index) is not int or frame_index < 0:
            raise ValueError('Episode and frame indices must be nonnegative integers')
        if self._episode is not None and episode_index != self._episode:
            raise ValueError('Start a new sidecar attempt for another episode')
        if frame_index != self._last_index + 1:
            raise ValueError('Missing or duplicate frame: retain this failed attempt and start a new one')
        fps = scalar(nominal_fps)
        if fps <= 0:
            raise ValueError('FPS must be positive')
        times = [scalar(x) for x in (monotonic_observation_arrival, monotonic_send_start, monotonic_send_end)]
        if times != sorted(times) or (self._last_time is not None and times[0] <= self._last_time):
            raise ValueError('Nonmonotonic instrumentation or mismatched clock domains')
        if set(values) != set(ACTION_FIELDS):
            raise ValueError('Keep all five distinct action/state positions')
        payload = {}
        for name, mapping in values.items():
            if set(mapping) != set(self.fields):
                raise ValueError(f'{name}: missing or extra joint fields')
            payload[name] = {key: scalar(mapping[key]) for key in self.fields}
        row = {'event': 'frame', 'attempt_id': self.attempt_id,
               'episode_index': episode_index, 'frame_index': frame_index,
               'nominal_timestamp_s': frame_index/fps, 'nominal_fps': fps,
               'monotonic_observation_arrival': times[0], 'monotonic_send_start': times[1],
               'monotonic_send_end': times[2], **payload}
        self._write(row)
        self._episode, self._last_index, self._last_time = episode_index, frame_index, times[2]
        return row

    def close_attempt(self, *, disposition, native_dataset_reference='', reason=''):
        if self._closed:
            raise ValueError('Attempt already closed')
        if disposition not in ('saved', 'discarded', 'interrupted'):
            raise ValueError('Explicit attempt disposition required')
        if disposition == 'saved' and not native_dataset_reference:
            raise ValueError('Saved attempt must point to the actual saved dataset version')
        if disposition != 'saved' and not reason:
            raise ValueError('Retain the reason for an unsuccessful attempt')
        self._write({'event': 'attempt_closed', 'attempt_id': self.attempt_id,
                     'episode_index': self._episode, 'frame_count': self._last_index+1,
                     'disposition': disposition, 'native_dataset_reference': native_dataset_reference,
                     'reason': reason})
        self._stream.close()
        self._closed = True


def audit(path):
    raw = Path(path).read_bytes()
    rows = [json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    frames = [r for r in rows if r.get('event') == 'frame']
    closed = rows[-1].get('event') == 'attempt_closed' if rows else False
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'frames': len(frames),
            'has_close_record': closed, 'disposition': rows[-1].get('disposition') if closed else 'incomplete',
            'source': rows[0].get('provenance') if rows else None,
            'note': 'This checks record structure, not the truth of physical motion or sensor exposure.'}

