"""Copy one real local ACT checkpoint plus provenance into a new auditable candidate."""
import argparse,shutil,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M67'/'code'))
from course_contract import *

def register(pretrained,request_path,receipt,artifact_root,name):
 pretrained=local(pretrained);req=validate_request(read(request_path));receipt=local(receipt);root=local(artifact_root)
 if not text(name)or Path(name).name!=name:raise ValueError('single new candidate folder name required')
 dest=root/name
 if dest.exists():raise ValueError('candidate already exists')
 run=read(receipt/'result.json');command=read(receipt/'command.json')
 if run.get('returncode')!=0 or run.get('request_sha256')!=sha(request_path)or command.get('request_sha256')!=sha(request_path)or run.get('log_sha256')!=sha(receipt/'stdout-stderr.log')or run.get('command_sha256')!=sha(receipt/'command.json'):raise ValueError('training receipt/request/log binding failed')
 output=local(req['training']['output_dir'])
 if not pretrained.is_relative_to(output/'checkpoints')or pretrained.name!='pretrained_model':raise ValueError('checkpoint not from this recorded training run')
 for f in ('config.json','model.safetensors','train_config.json','policy_preprocessor.json','policy_postprocessor.json'):
  if not(pretrained/f).is_file():raise ValueError('formal checkpoint missing '+f)
 cfg=read(pretrained/'config.json');tcfg=read(pretrained/'train_config.json')
 if cfg.get('type')!='act' or tcfg.get('dataset',{}).get('root')!=req['dataset']['root']:raise ValueError('checkpoint architecture/data mismatch')
 if any(cfg.get(k)!=v for k,v in req['policy'].items()):raise ValueError('checkpoint policy differs from the recorded training request')
 for metadata_name,digest in command.get('dataset_files_sha256',{}).items():
  if sha(Path(req['dataset']['root'])/'meta'/metadata_name)!=digest:raise ValueError('training metadata changed after launch')
 if set(command.get('dataset_files_sha256',{}))!={'info.json','stats.json'}:raise ValueError('training launch metadata snapshot absent')
 # Copy all processor state sidecars too, not only their JSON recipes.
 training_step=read(pretrained.parent/'training_state'/'training_step.json')['step']
 if not positive(training_step)or training_step>req['training']['steps']:raise ValueError('checkpoint step not from declared run range')
 if command.get('resume'):
  verify_inventory(local(command['source_checkpoint']),command['resume_inventory'])
  if training_step<=command['saved_step']:raise ValueError('checkpoint predates this resume execution')
 dest.mkdir();shutil.copytree(pretrained,dest/'pretrained_model');prov=dest/'provenance';prov.mkdir()
 for source,target in [(Path(request_path),'training-request.json'),(Path(req['dataset']['split_manifest']),'original-splits.json'),(receipt/'command.json','command.json'),(receipt/'result.json','result.json'),(receipt/'stdout-stderr.log','stdout-stderr.log'),(pretrained.parent/'training_state'/'training_step.json','training_step.json'),(Path(req['dataset']['root'])/'meta'/'info.json','train-info.json'),(Path(req['dataset']['root'])/'meta'/'stats.json','train-stats.json')]:shutil.copy2(source,prov/target)
 files=[{'path':str((dest/r['path']).relative_to(root)),'sha256':r['sha256']}for r in inventory(dest)]
 m={'schema':'aloha.act-model-manifest.v1','lerobot_revision':REVISION,'candidate_id':name,'training_configuration_id':req['candidate_id'],'training_step':training_step,'source_kind':req['source_kind'],'dataset_source':{'source_dataset':req['dataset']['source_dataset'],'train_root':req['dataset']['root'],'split_sha256':req['dataset']['split_sha256']},'pretrained_dir':str((dest/'pretrained_model').relative_to(root)),'files':files,'action_fields':FIELDS,'action_units':UNITS,'action_semantics':'teleop_action_processor target','state_fields':FIELDS,'camera_keys':CAMERAS,'chunk_size':cfg['chunk_size'],'n_action_steps':cfg['n_action_steps'],'temporal_ensemble_coeff':cfg.get('temporal_ensemble_coeff'),'hardware_revision':None,'task_success_claimed':False}
 write_new(dest/'model_manifest.json',m);return m
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('pretrained','request','receipt','artifact_root','name'):p.add_argument(key)
 a=p.parse_args();print(json.dumps(register(a.pretrained,a.request,a.receipt,a.artifact_root,a.name),ensure_ascii=False,indent=2))
