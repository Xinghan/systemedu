"""Shared local-file contracts for M67–M70; no device or network operations."""
import hashlib,json,math,os,subprocess,sys
from pathlib import Path
REVISION='b64fe1ed9f11eeac53ee821356d2797601701054'
FIELDS=[f'{side}_{joint}.pos' for side in ('left','right') for joint in ('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')]
VIEW_FIELDS=[f'{side}.{joint}' for side in ('left','right') for joint in ('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')]
CAMERAS=['observation.images.front','observation.images.overhead']
UNITS=['degree']*5+['percent_0_100']+['degree']*5+['percent_0_100']
def read(path):return json.loads(Path(path).read_text())
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def write_new(path,data):
 with Path(path).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def finite(x):return type(x) in (int,float) and math.isfinite(x)
def text(x):return isinstance(x,str) and bool(x.strip()) and not any(t in x.upper()for t in ('REPLACE','TODO','<','>'))
def positive(x):return type(x)is int and x>0
def local(path):
 p=Path(path)
 if not p.is_absolute() or not p.exists():raise ValueError('existing absolute local path required')
 return p.resolve()
def child(root,rel):
 if not isinstance(rel,str) or Path(rel).is_absolute():raise ValueError('relative artifact path required')
 root=Path(root).resolve();p=(root/rel).resolve()
 if not p.is_relative_to(root) or not p.is_file():raise ValueError('artifact absent or outside root')
 return p

def check_checkout(checkout):
 p=local(checkout)
 if subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()!=REVISION:raise ValueError('wrong LeRobot revision')
 if subprocess.run(['git','-C',str(p),'diff','--quiet','HEAD','--','src/lerobot']).returncode:raise ValueError('tracked LeRobot source differs from revision')
 # Offline must be set before importing Hub-dependent packages.
 os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1';os.environ['WANDB_MODE']='disabled'
 import lerobot
 paths=[Path(x).resolve() for x in getattr(lerobot,'__path__',[])]
 if not paths or not all(x.is_relative_to(p/'src'/'lerobot') for x in paths):raise ValueError('imported LeRobot is not this pinned checkout; activate editable fixed environment')
 return p

def validate_request(doc,*,files=True):
 if doc.get('schema')!='aloha.training-request.v1' or doc.get('lerobot_revision')!=REVISION:raise ValueError('wrong request schema/revision')
 if doc.get('action_fields')!=FIELDS or doc.get('action_units')!=UNITS or doc.get('action_semantics')!='teleop_action_processor target':raise ValueError('explicit native target order and mixed units required')
 if doc.get('source_kind') not in ('learner_recording','synthetic_fixture'):raise ValueError('declare source_kind')
 if not text(doc.get('candidate_id')):raise ValueError('candidate_id required')
 ds=doc['dataset'];p=doc['policy'];t=doc['training']
 if not all(text(ds.get(k))for k in ('root','repo_id','source_dataset','split_manifest','split_sha256','subset_audit_note')):raise ValueError('dataset origin, split digest and subset/statistics audit required')
 if not isinstance(ds.get('original_train_indices'),list) or not ds['original_train_indices'] or any(type(i)is not int or i<0 for i in ds['original_train_indices']) or len(set(ds['original_train_indices']))!=len(ds['original_train_indices']):raise ValueError('original train episode indices required')
 if p.get('device') not in ('cpu','cuda'):raise ValueError('this measured bridge supports cpu/cuda only; no guessed MPS memory')
 required={'chunk_size','n_action_steps','temporal_ensemble_coeff','dim_model','n_heads','dim_feedforward','n_encoder_layers','n_decoder_layers','n_vae_encoder_layers','latent_dim','dropout','kl_weight','optimizer_lr','optimizer_lr_backbone','optimizer_weight_decay','device'}
 if set(p)!=required:raise ValueError('explicit fixed ACT fields required; unknown fields rejected')
 for k in ('chunk_size','n_action_steps','dim_model','n_heads','dim_feedforward','n_encoder_layers','n_decoder_layers','n_vae_encoder_layers','latent_dim'):
  if not positive(p[k]):raise ValueError('positive policy sizes required')
 if p['dim_model']%p['n_heads'] or p['n_action_steps']>p['chunk_size']:raise ValueError('head divisibility or action/chunk mismatch')
 c=p['temporal_ensemble_coeff']
 if c is not None and (not finite(c) or p['n_action_steps']!=1):raise ValueError('ensemble requires finite coefficient and one action step')
 if not finite(p['dropout']) or not 0<=p['dropout']<1:raise ValueError('dropout range')
 for k in ('kl_weight','optimizer_lr','optimizer_lr_backbone','optimizer_weight_decay'):
  if not finite(p[k]) or p[k]<0:raise ValueError('invalid scalar policy setting')
 if not p['optimizer_lr'] or not p['optimizer_lr_backbone']:raise ValueError('learning rates must be positive')
 for k in ('batch_size','steps','save_freq','log_freq','warmup_steps','measure_steps'):
  if not positive(t.get(k)):raise ValueError('positive training counts required')
 if t['measure_steps']<3 or t['warmup_steps']<2:raise ValueError('at least 2 warmup and 3 measured steps')
 if type(t.get('seed'))is not int or t['seed']<0:raise ValueError('nonnegative seed required')
 if not text(t.get('output_dir')) or not Path(t['output_dir']).is_absolute():raise ValueError('absolute new output directory required')
 if files:
  root=local(ds['root']);split=local(ds['split_manifest'])
  if sha(split)!=ds['split_sha256']:raise ValueError('split manifest digest mismatch')
  # Audit original identities, not merely a user-typed list of split labels.
  sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M33'/'code'))
  from audit_split import audit
  raw=read(split);a=audit(raw)
  if not a['valid'] or a['source_dataset']!=ds['source_dataset'] or sorted(a['lerobot_episode_indices']['train'])!=sorted(ds['original_train_indices']):raise ValueError('frozen original split identity mismatch')
  info=read(root/'meta'/'info.json')
  if info['total_episodes']!=len(ds['original_train_indices']):raise ValueError('use physically separated train-only subset, reindexed from zero')
  for key in ('observation.state','action'):
   if info['features'][key].get('names')!=FIELDS:raise ValueError('native ordered 12 fields must match course contract')
  cams=[info['features'][k]['shape'] for k in CAMERAS]
  if cams[0]!=cams[1] or len(cams[0])!=3:raise ValueError('two equal-size RGB camera shapes required')
  if not (root/'meta'/'stats.json').is_file():raise ValueError('train-only statistics file absent')
 return doc

def official_config(request):
 validate_request(request)
 from lerobot.configs.train import TrainPipelineConfig
 from lerobot.configs.default import DatasetConfig
 from lerobot.policies.act.configuration_act import ACTConfig
 p=ACTConfig(**request['policy'],pretrained_backbone_weights=None,push_to_hub=False)
 ds=request['dataset'];t=request['training']
 cfg=TrainPipelineConfig(dataset=DatasetConfig(repo_id=ds['repo_id'],root=ds['root'],episodes=list(range(len(ds['original_train_indices']))),eval_split=0.0),policy=p,output_dir=Path(t['output_dir']),batch_size=t['batch_size'],steps=t['steps'],num_workers=0,seed=t['seed'],save_freq=t['save_freq'],log_freq=t['log_freq'],env_eval_freq=0)
 cfg.optimizer=p.get_optimizer_preset();cfg.scheduler=p.get_scheduler_preset()
 return cfg

def inventory(root):
 root=Path(root);return [{'path':str(p.relative_to(root)),'sha256':sha(p)}for p in sorted(root.rglob('*'))if p.is_file()]
def verify_inventory(root,items):
 if not isinstance(items,list)or not items:raise ValueError('nonempty inventory required')
 seen=set()
 for row in items:
  if row['path'] in seen:raise ValueError('duplicate inventory path')
  seen.add(row['path'])
  if sha(child(root,row['path']))!=row['sha256']:raise ValueError('artifact digest mismatch')
 return True
