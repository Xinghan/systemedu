# M71：真实主机计时，动力断开

本包从根目录运行。代码实际路径 `lessons/M71/code/`，不是本practice子目录。先激活M67–M70固定LeRobot环境，再检查帮助：

```sh
python lessons/M71/code/timing_run.py --help
```

只连接两个独立USB相机。**不要实例化SOFollower或调用它的connect**；固定版connect/configure可能使能力矩。本脚本没有机械臂驱动对象，也没有任何电机输出。两只follower保持动力断开；相机来自真实桌面，状态来自本人已录开发回合，两者不宣称同步。

## 实際输入

- `--pretrained`：M70包内选定候选的原pretrained_model绝对目录。
- `--manifest`：M69原始 `aloha.act-model-manifest.v1` JSON，保持原字节。
- `--artifact-root`：相应证据根；候选相对结构不变，不能用generic inventory再包一层模型清单。
- `--checkout`：固定LeRobot checkout；代码会核HEAD、源文件与实际import路径。
- `--view`：M47导出的本人原生图像教学视图（schema=aloha.vision-teaching-view.v1），不是M35无图JSONL。工具通过其既有加载器审计来源、拆分与图片字节，仅取所选行的原生state。
- `--episode`/`--frame`：本人训练或验证回合的唯一行，保留attempt；独立test拒绝。
- `--cameras`：本目录cameras.template.json填好后的绝对文件；front/overhead对应真实USB编号，RGB宽高必须与保存模型一致。不可改成32×32机制练习尺寸。
- `--period-s`：事前计划周期，来自M71测量设计；不是通用安全阈值。
- `--samples`：完整记录轮数，最少3；先小样核接口，再自己决定有意义的观测长度。

示例中的大写路径词必须换成本人真实绝对路径；数值是命令语法示意，不是实机推荐配置：

```sh
python lessons/M71/code/timing_run.py \
  --pretrained PRETRAINED_ABSOLUTE --manifest ORIGINAL_MODEL_MANIFEST_ABSOLUTE \
  --artifact-root ARTIFACT_ROOT_ABSOLUTE --checkout FIXED_CHECKOUT_ABSOLUTE \
  --view LEARNER_VIEW_ABSOLUTE --episode YOUR_DEVELOPMENT_EPISODE --frame 0 \
  --cameras CAMERAS_ABSOLUTE --samples 100 --period-s 0.05 \
  --device cpu --output NEW_MEASUREMENT_DIRECTORY
```

## 输出与分析

- `offline-actions.jsonl`：策略原生请求，明确destination=offline_jsonl_only；十二字段、混合单位和两路主机到达时刻。
- `timing.csv`：取图acquire、像素转张量tensorize、保存处理器preprocess、选择动作inference、postprocess、写文件offline_write、完整loop及最老主机帧龄。**inference_s是select_action阶段**，policy_model_calls=0时为队列步，不叫完整前向。分项未包含全部调度、复制等开销，所以不能声称简单分项之和就是总loop。
- `timeline.svg`：从真实CSV前30轮画出完整loop长度和计划周期虚线；不是曝光至电机的延迟图。SVG可在浏览器打开、截图为PNG供作业。
- `report.json`：真实模型/相机文件摘要、状态快照出处、均值/最大/最近秩p95、超期数及模型/队列分组数。它不认证任务成功。

请填写interface-audit.csv，逐关节比较M22批准范围、相对幅度和实际原请求；手算至少一个越界或不过界样本。冻结状态不是真实当前位置，不能因此计算“实机安全步长”。报告可得出需要进一步处理瓶颈；没有统一及格毫秒数。

程序异常时目录中的已写JSONL保留；可能尚无完整CSV/report，这是未完成记录。修复后使用新目录。相机驱动断开只处理USB摄像头，不暗中操作臂动力。此工具未在作者侧接实际USB相机；作者QA只对真实ACT和合成相机边界进行CPU软件验证，学生实际设备测量必须另交。
