#!/usr/bin/env python3
"""Expose every scalar prediction error and its mean. Never executes a robot."""
import argparse
import json
import math
from pathlib import Path

def ledger(data):
    if not isinstance(data.get('rows'),list) or not data['rows']:raise ValueError('Nonempty rows required')
    lines=[]
    for r in data['rows']:
        p,t=r['prediction'],r['target']
        if any(type(v) not in (int,float) or not math.isfinite(v) for v in (p,t)):raise ValueError('Nonfinite prediction or target')
        e=p-t
        if not math.isfinite(e*e):raise ValueError('Squared error overflow')
        lines.append({**r,'signed_error':e,'absolute_error':abs(e),'squared_error':e*e})
    n=len(lines)
    return {'provenance':data['provenance'],'feature':data['feature'],'target':data['target'],
            'normalization_sha256':data['normalization_sha256'],'denominator':n,'rows':lines,
            'mean_signed_error':sum(r['signed_error'] for r in lines)/n,
            'mae':sum(r['absolute_error'] for r in lines)/n,
            'mse':sum(r['squared_error'] for r in lines)/n,
            'scope':'One declared channel, equally weighted frames, normalized units; not task success'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('predictions');p.add_argument('--out',required=True);a=p.parse_args()
    try:
        result=ledger(json.loads(Path(a.predictions).read_text()))
        with Path(a.out).open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    except (ValueError,KeyError,TypeError,OSError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
