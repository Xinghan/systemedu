import json,tempfile,unittest
from pathlib import Path
from baseline_project import inside,inventory
class PortableProjectTests(unittest.TestCase):
 def test_relative_paths_inside(self):
  root=Path('/tmp/example').resolve();self.assertEqual(inside(root,'data/frame.json'),root/'data/frame.json')
  for value in ('../escape','/absolute',''):
   with self.assertRaises(ValueError):inside(root,value)
 def test_inventory_hashes_nested_manifest(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);(root/'evidence').mkdir();(root/'evidence/bundle-manifest.json').write_text('nested evidence');(root/'bundle-manifest.json').write_text('self');(root/'file.txt').write_text('before');a=inventory(root);self.assertEqual(len(a),2);(root/'file.txt').write_text('after');b=inventory(root);self.assertNotEqual(next(v['sha256'] for v in a if v['path']=='file.txt'),next(v['sha256'] for v in b if v['path']=='file.txt'))
if __name__=='__main__':unittest.main()
