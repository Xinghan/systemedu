# 本版源码核验

课程正式自主执行使用 `lessons/M72/code/deploy_gateway.py`，将 ACT、网关、驱动与 M75 记录接在一起。下文 rollout 是上游接口核对，不是绕过 M72 的课堂运行指令。

核对日期：2026-09-22。LeRobot commit 为 `b64fe1ed9f11eeac53ee821356d2797601701054`，SO-ARM100 commit 为 `eecbe3e0a9ebb23e25ad7b2759b03884c6660903`。真实 URL、文件 SHA-256、验证范围保存在 `sources.json`，源码快照保留许可。

| 项目 | 在固定源码中核对到的行为 | 本包如何处理 |
|---|---|---|
| 双臂类型 | bi_so_follower / bi_so_leader，各有左右嵌套配置 | 每只臂独立端口，四端口不能重复 |
| 校准 ID | 双臂 robot.id 派生为 `<id>_left` 与 `<id>_right` | 单臂先校准时使用对应 ID，保留原校准文件 |
| 动作字段 | left_ / right_ 前缀，末尾 .pos；左右 send_action 顺序调用 | 不声称左右硬件完全同时接收；保留时间测量 |
| 相机 | 顶层 cameras 名称不加左右前缀；臂内 cameras 会加前缀 | 本包只用顶层 front / overhead，避免同名混淆 |
| 单位 | use_degrees=true 控制 5 个身体关节为度，gripper 始终 RANGE_0_100 | 参数显式设置，不把夹爪标成毫米 |
| 相对目标 | 目标与 sync_read 得到的当前值作差，再逐关节裁剪 | 键用 shoulder_pan 等，不带 left_ 或 .pos；不宣称速度、力或碰撞控制 |
| record | 必须有 teleop；无 policy 配置字段 | 只用于本人遥操作数据 |
| rollout | 独立 lerobot-rollout；episodic 策略可保存回合 | 单次试验单目录、关闭自动归位、没有 leader 接入 |
| 数据命名 | DatasetRecordConfig 默认加时间戳 | 显式 no_stamp=true，要求学生管理唯一版本名 |
| 上传默认值 | DatasetRecordConfig.push_to_hub 默认 true | 生成器强制 false，同时 private=true 作为将来人工改动时的显式设置 |
| 真实拆分 | 官方 split_dataset 完整复制并重编号，汇总各组回合统计 | 先实际拆分，训练从 train 目录读取，保存编号映射 |
| ACT | chunk_size / n_action_steps；时间集成时后者必须 1 | 生成器先检查约束 |
| 时间集成 | exp(-coefficient × rank)，rank=0 是最旧预测 | 教学算例按这一约定，不默认“越新权重越大” |
| ACT 推理 | eval 时潜变量为零；未来动作不作为推理输入 | 验证脚本只向 predict_action_chunk 传 observation 字段 |

已实际执行：本包标准库测试、所有离线示例、Python 编译检查、固定源 AST 字段检查；从官方函数 AST 提取 `ensure_safe_goal_position`，只替换 logger 后运行一个正/负裁剪算例。结果在 `verification/`。

没有执行：完整 LeRobot 命令行解析/安装、视频解码、ACT 训练/真实 checkpoint 推理、OpenSCAD 渲染、打印、相机或电机连接、机械限位/承重/碰撞检查。这些仍需目标机器和学生工位验证。固定源字段存在不代表任意平台原生命令必然成功。

特别注意：通用教程 `il_robots` 的旧部署示例与同 revision 的脚本存在不同步；本包部署参数以 `scripts/lerobot_rollout.py`、`rollout/configs.py` 为准。升级时重新核对这张表，不能只把 commit 字符串换掉。
