"""Actual process timestamps of synthetic values; not camera exposure times."""
import argparse
import csv
import math
from pathlib import Path
import time

def sample(period_s=0.25,count=9,work_ms=0):
    if not math.isfinite(period_s) or period_s<=0 or count<2 or not math.isfinite(work_ms) or work_ms<0:
        raise ValueError('period须为有限正数，count至少2，work-ms非负且有限')
    start=time.perf_counter();rows=[]
    for index in range(count):
        deadline=start+index*period_s
        time.sleep(max(0,deadline-time.perf_counter()))
        actual=time.perf_counter()-start
        previous=rows[-1]['actual_elapsed_s'] if rows else None
        rows.append({'index':index,'nominal_s':index*period_s,'actual_elapsed_s':actual,
                     'interval_s':'' if previous is None else actual-previous,
                     'late_s':actual-index*period_s,'synthetic_target':index*3,
                     'value_provenance':'synthetic','clock_provenance':'measured_process_clock'})
        if work_ms:time.sleep(work_ms/1000)
    return rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--period',type=float,default=.25)
    p.add_argument('--count',type=int,default=9);p.add_argument('--work-ms',type=float,default=0)
    p.add_argument('--output',type=Path,default=Path('clock.csv'));a=p.parse_args()
    rows=sample(a.period,a.count,a.work_ms)
    with a.output.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    elapsed=rows[-1]['actual_elapsed_s']-rows[0]['actual_elapsed_s']
    print(f'{len(rows)}行，{len(rows)-1}个间隔；观察频率约{(len(rows)-1)/elapsed:.3f} Hz')
    print('数值为synthetic；时间是本进程实测，不是相机曝光或电机响应时间。')

if __name__=='__main__':main()
