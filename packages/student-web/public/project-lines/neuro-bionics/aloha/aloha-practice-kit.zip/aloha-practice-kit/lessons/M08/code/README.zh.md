# M08：无动力工位接口

本包复用M06控制器和M07时间概念；没有真实设备接口。先在本目录用M05的解释器运行：

```text
python selfcheck.py
python station.py --output station-example-result.json
```

自检实际运行正常、缺失、输出越界、错误模式四个案例，并写 `selfcheck-result.json`。这些是示例接口测试，不能替代个人输入或实机验收。

再建立个人 `station-v1/code`、`inputs`、`evidence`。将本目录代码和M06本人控制器放入code，将个人任务、空间、字段JSON放入inputs。在code目录运行：

```text
python station.py --task ../inputs/task.json --workspace ../inputs/workspace.json --channels ../inputs/channels.json --output ../evidence/normal-v1.json
```

任务来源可写learner_specification，个人实际测绘写learner_measurement，离线目标仍为synthetic。样例文件保持synthetic。mode必须dry_run；任何hardware模式均被拒绝。集成显式步长3，若个人改变该规则，需要同步预期和说明。

输出记录输入文件路径、各输入来源、目标前后和实际进程耗时。程序只核对工作区格式与毫米单位，不计算机器人路径，也不判断插块任务是否实体成功。保留正常和拒绝证据，用独立输出名防止误读旧日志。
