"""Planar FK, never a device controller. All dimensions must share one unit."""
import argparse
import json
import math
from pathlib import Path


def fk(lengths, angles_deg):
    if len(lengths) != 2 or len(angles_deg) != 2:
        raise ValueError('Two lengths and two relative angles required')
    values = lengths + angles_deg
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in values):
        raise ValueError('Finite numeric values required')
    if min(lengths) <= 0:
        raise ValueError('Lengths must be positive')
    a, b = map(math.radians, angles_deg)
    elbow = [lengths[0]*math.cos(a), lengths[0]*math.sin(a)]
    tip = [elbow[0]+lengths[1]*math.cos(a+b), elbow[1]+lengths[1]*math.sin(a+b)]
    return {'elbow': elbow, 'tip': tip}


def run(data):
    if data.get('provenance') not in ('synthetic', 'learner_recording') or not data.get('unit'):
        raise ValueError('Explicit provenance and dimension unit required')
    result = fk(data['lengths'], data['angles_deg'])
    result.update(provenance=data['provenance'], unit=data['unit'], hardware_executed=False)
    if 'measured_tip' in data:
        if len(data['measured_tip']) != 2 or not all(math.isfinite(x) for x in data['measured_tip']):
            raise ValueError('Two finite measured coordinates required')
        result['error_vector_measured_minus_predicted'] = [m-p for m,p in zip(data['measured_tip'], result['tip'])]
        result['error_distance'] = math.dist(data['measured_tip'], result['tip'])
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    args = parser.parse_args()
    print(json.dumps(run(json.loads(args.input.read_text())), ensure_ascii=False, indent=2, allow_nan=False))
