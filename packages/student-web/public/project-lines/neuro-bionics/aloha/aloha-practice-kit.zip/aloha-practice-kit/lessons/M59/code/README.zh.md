# M59：可执行调度事件程序

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M59/code/scheduler.py lessons/M59/code/synthetic.json
```

JSON 指定模式、chunk_size、n_action_steps、coefficient、max_observation_age_s 与 events。每个事件依次执行observe、predict、consume或reset，输出每项接受/拒绝及状态。fixture先集成输出1，再输出约11.333333，reset后consume被拒绝；拒绝属于预期故障探针而非脚本损坏。可以为本人配置写离线事件回归，不能连接电机。观察陈旧拒绝与故障锁存是课程额外约束，原生ACT没有因此自动获得安全保证。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
