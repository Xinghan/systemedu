#!/usr/bin/env python3
"""Recompute a browser graph export; never trust exported answers as torch evidence."""
import argparse,json,math,re,sys
from pathlib import Path
from backprop import loss_gradient,autograd_reference,perturbation_check,close
from relu_network import worked_example
def evaluate(program,sources,output):
 if not isinstance(program,str) or len(program)>4000:raise ValueError('Program too large')
 lines=[v.strip() for v in program.splitlines() if v.strip() and not v.strip().startswith('#')]
 if len(lines)>12:raise ValueError('At most 12 nodes')
 values=dict(sources);nodes=[]
 for line in lines:
  m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_]*)\s*=\s*(mul|add|const)\(([^()]*)\)',line)
  if not m:raise ValueError('Invalid syntax: '+line)
  name,op,args=m.groups()
  if name in values or name in ('__proto__','prototype','constructor') or len(name)>18:raise ValueError('Duplicate/reserved/long name')
  ins=[v.strip() for v in args.split(',')]
  if op=='const':
   if len(ins)!=1 or not ins[0]:raise ValueError('One constant required')
   value=float(ins[0])
   if not math.isfinite(value) or abs(value)>1e5:raise ValueError('Invalid constant')
   ins=[]
  else:
   if len(ins)!=2 or any(v not in values for v in ins):raise ValueError('Unknown upstream reference')
   value=values[ins[0]]*values[ins[1]] if op=='mul' else values[ins[0]]+values[ins[1]]
  if not math.isfinite(value) or abs(value)>1e10:raise ValueError('Invalid intermediate value')
  values[name]=value;nodes.append({'id':name,'op':op,'inputs':ins,'value':value})
 if output not in values:raise ValueError('Unknown output')
 return values[output],nodes
def verify(payload):
 if not isinstance(payload,dict) or payload.get('schema')!='aloha.reverse-graph.v1' or payload.get('provenance')!='synthetic':raise ValueError('Expected synthetic browser graph export')
 current=payload['current'];c=current['config']
 for key in ('x1','x2','a','y1','y2','epsilon'):
  value=c[key]
  if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('Finite numbers required')
  if not (1e-9<=value<=2 if key=='epsilon' else -5<=value<=5):raise ValueError('Value outside browser contract')
 model=worked_example();model['w1'][0][0]=c['a'];rows=[{'x':[c['x1'],c['x2']],'y':[c['y1'],c['y2']]}]
 explicit=loss_gradient(rows,model);t=explicit['traces'][0];sources={'x':c['x1'],'g1':t['output_signal'][0],'g2':t['output_signal'][1],'edge1':1.,'edge2':.25,'gate':t['relu_local_factor'][0]}
 result,nodes=evaluate(current['program'],sources,current['output']);auto=autograd_reference(rows,model);probe=perturbation_check(rows,model,('w1',0,0),c['epsilon']);truth=auto['gradient']['w1'][0][0]
 status='inconclusive_branch' if not probe['eligible'] else ('pass' if close(result,truth) and close(result,probe['central_difference']) else 'mismatch')
 return {'schema':'aloha.reverse-graph-torch-check.v1','provenance':'synthetic','status':status,'constructed':result,'sources_recomputed':sources,'nodes_recomputed':nodes,'torch_gradient':truth,'torch_version':auto['torch_version'],'finite_probe':probe,'loss':explicit['loss'],'exported_answers_trusted':False,'hardware_command':False}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('export');p.add_argument('--out',required=True);a=p.parse_args()
 try:
  source=Path(a.export)
  if source.stat().st_size>2_000_000:raise ValueError('Export exceeds 2 MB')
  r=verify(json.loads(source.read_text()))
  with Path(a.out).open('x') as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
  print(json.dumps(r,ensure_ascii=False));return 0 if r['status']=='pass' else 1
 except (OSError,ValueError,KeyError,TypeError,ImportError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':raise SystemExit(main())
