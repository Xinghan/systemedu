import unittest,copy,tempfile
from pathlib import Path
import torch
from audit_native import audit_frames,audit_sidecar,join_evidence,FIELDS,CAMERAS
from file_inventory import inventory,compare
F={k:{'names':FIELDS} for k in ('observation.state','action')}
def rows():return [dict(episode_index=torch.tensor(0),frame_index=torch.tensor(i),timestamp=torch.tensor(i/30),**{'observation.state':torch.zeros(12),'action':torch.zeros(12),**{c:torch.ones(3,4,5)*.5 for c in CAMERAS}}) for i in range(3)]
def side(n=1):
 r=[{'event':'attempt_started','attempt_id':'a','joint_fields':FIELDS,'provenance':{'kind':'synthetic','source':'unit fixture'}}]
 for i in range(n):
  row={'event':'frame','attempt_id':'a','episode_index':0,'frame_index':i,'nominal_fps':30,'nominal_timestamp_s':i/30,'monotonic_observation_arrival':10+i,'monotonic_send_start':10.1+i,'monotonic_send_end':10.2+i}
  for key in ('raw_teleop_action','teleop_processor_action','robot_processor_action_to_send','driver_returned_sent_action','observed_state'):row[key]={k:0 for k in FIELDS}
  r.append(row)
 return r+[{'event':'attempt_closed','attempt_id':'a','episode_index':0,'disposition':'saved','frame_count':n,'native_dataset_reference':'synthetic:v1'}]
def joined(s=None,**kw):
 args=dict(episode=0,attempt_id='a',dataset_reference='synthetic:v1',source_root='/synthetic',repo_id='synthetic/data');args.update(kw)
 return join_evidence(audit_frames(rows(),30,F,3),audit_sidecar(side(3) if s is None else s),**args)
class AuditTests(unittest.TestCase):
 def test_valid_decoded(self):
  r=audit_frames(rows(),30,F,3);self.assertTrue(r['valid']);self.assertEqual(r['summed_decoded_image_bytes'],3*2*3*4*5*4);self.assertFalse(r['physical_synchronization_verified'])
 def test_missing_frame(self):self.assertFalse(audit_frames(rows()[1:],30,F,3)['valid'])
 def test_bad_field(self):
  r=rows();r[0]['action'][0]=float('nan');self.assertFalse(audit_frames(r,30,F,3)['valid'])
 def test_bad_image(self):
  r=rows();r[0][CAMERAS[0]]=torch.ones(3,4,5)*2;self.assertFalse(audit_frames(r,30,F,3)['valid'])
 def test_decode_exception(self):
  def broken():yield rows()[0];raise RuntimeError('synthetic decoder failure')
  self.assertFalse(audit_frames(broken(),30,F,3)['valid'])
 def test_sidecar_clock(self):
  self.assertTrue(audit_sidecar(side())['valid']);r=side();r[1]['monotonic_send_end']=9;self.assertFalse(audit_sidecar(r)['valid'])
 def test_sidecar_incomplete(self):self.assertFalse(audit_sidecar(side()[:-1])['valid'])
 def test_file_change_detected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x';p.write_bytes(b'a');before=inventory(d);self.assertTrue(compare(before,before)['valid']);p.write_bytes(b'b');self.assertFalse(compare(inventory(d),before)['valid'])
 def test_matching_sources_pass(self):self.assertTrue(joined()['valid'])
 def test_count_mismatch_rejected(self):self.assertFalse(joined(side(1))['valid'])
 def test_other_saved_version_rejected(self):self.assertFalse(joined(dataset_reference='other:v2')['valid'])
 def test_other_attempt_rejected(self):self.assertFalse(joined(attempt_id='other')['valid'])
 def test_wrong_selected_episode(self):self.assertFalse(joined(episode=999)['valid'])
 def test_close_episode_mismatch(self):
  r=side(3);r[-1]['episode_index']=999;self.assertFalse(joined(r)['valid'])
 def test_missing_field_payload(self):
  r=side(3);del r[1]['observed_state'];self.assertFalse(joined(r)['valid'])
 def test_empty_attempt_rejected(self):
  r=side(3)
  for row in r:row['attempt_id']=''
  self.assertFalse(joined(r)['valid'])
 def test_interior_event_rejected(self):
  r=side(3);r.insert(1,dict(r[0]));self.assertFalse(joined(r)['valid'])
if __name__=='__main__':unittest.main()
