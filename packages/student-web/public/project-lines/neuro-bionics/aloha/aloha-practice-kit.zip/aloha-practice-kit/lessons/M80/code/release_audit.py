"""M80 release binding. Reuses M74's frozen-plan evaluation audit."""
import sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'M79'/'code'))
from evidence_files import read,inventory,verify_file,references,text,run_cli

VERSION_KEYS={'model_manifest_sha256':'model_manifest','hardware_manifest_sha256':'hardware_manifest','config_sha256':'config','dataset_split_manifest_sha256':'dataset_split_manifest','software_manifest_sha256':'software_manifest'}

def verify_run_binding(run,artifact_root,files,evidence_ids,*,versions,source_kind,purpose,operator=None):
    """Verify real M75 bookends and their exact file bindings, not evidence content truth."""
    sys.path.insert(0,str(BASE/'M74'/'code'))
    from evaluation_audit import validate_plan,validate_outcome,verify_evidence,verify_outcome_binding
    from gateway_log import validate_gateway_log
    if run.get('schema')!='aloha.execution-record.v1':raise ValueError('M75 execution record required')
    if run.get('version_validation_errors')!=[] or run.get('evidence_validation_errors')!=[]:
        raise ValueError('Closed run retains missing evidence or version verification errors')
    if run.get('purpose')!=purpose or run.get('source_kind')!=source_kind or run.get('observed_versions')!=versions:
        raise ValueError('Closed run purpose, provenance or versions disagree')
    if operator is not None and run.get('operator')!=operator:raise ValueError('Run operator mismatch')
    opened=read(verify_file(artifact_root,run['start_record_ref']))
    if opened.get('schema')!='aloha.execution-record.v1' or opened.get('status')!='open':raise ValueError('Original M75 open record required')
    for key in ('run_id','evaluation_id','trial_id','purpose','operator','source_kind','observed_versions','plan_path','plan_sha256','version_artifacts'):
        if run.get(key)!=opened.get(key):raise ValueError('Start/close identity mismatch: '+key)
    plan=validate_plan(read(verify_file(artifact_root,{'path':run['plan_path'],'sha256':run['plan_sha256']})),artifact_root)
    if plan['frozen_versions']!=versions or plan['source_kind']!=source_kind or plan['evaluation_id']!=run['evaluation_id']:
        raise ValueError('Run plan differs from release versions or provenance')
    validate_outcome(run,plan['time_limit_s'])
    verify_evidence(artifact_root,run['evidence'])
    for evidence in run['evidence']:
        if evidence['kind']=='gateway_log':validate_gateway_log(verify_file(artifact_root,evidence),run)
    references(evidence_ids,files,'bound run evidence')
    def identities(rows):
        values=[(r['kind'],r['path'],r['sha256']) for r in rows]
        if len(values)!=len(set(values)):raise ValueError('Duplicate run evidence binding')
        return set(values)
    if identities(run['evidence'])!=identities([files[i] for i in evidence_ids]):
        raise ValueError('Selected evidence differs from the closed run evidence')
    verify_outcome_binding(artifact_root,run)
    return run

def audit_release(document,artifact_root,evaluator=None):
    d=read(document)
    if d.get('schema')!='aloha.release.v1':raise ValueError('Wrong release schema')
    text(d['release_id'],'release identity')
    if d.get('source_kind') not in ('synthetic','learner_recording'):raise ValueError('Explicit source kind required')
    files=inventory(artifact_root,d['files']);versions={}
    for key,slot in VERSION_KEYS.items():
        fid=d['bindings'][slot]
        if fid not in files:raise ValueError(f'Missing binding {slot}')
        versions[key]=files[fid]['sha256']
        # Manifests hold artifact-root-relative paths; config is a leaf file.
        if slot.endswith('_manifest'):
            manifest=read(verify_file(artifact_root,files[fid]))
            leaves=manifest['files']
            if not isinstance(leaves,list) or not leaves:raise ValueError('Nonempty manifest files required')
            seen=set()
            for leaf in leaves:
                if leaf['path'] in seen:raise ValueError('Duplicate manifest path')
                seen.add(leaf['path']);verify_file(artifact_root,leaf)
    if versions!=d['frozen_versions']:raise ValueError('Declared release versions do not match actual files')
    evaluation=read(verify_file(artifact_root,files[d['evaluation_evidence']]))
    if evaluation['frozen_versions']!=versions:raise ValueError('Release and evaluation versions disagree')
    if evaluation['source_kind']!=d['source_kind']:raise ValueError('Evaluation provenance differs from release')
    if evaluator is None:
        sys.path.insert(0,str(BASE/'M74'/'code'))
        try:from evaluation_audit import audit_evaluation
        except ImportError as e:raise ValueError('M74 evaluation_audit.py required; do not substitute count-only legacy evaluate') from e
        evaluator=audit_evaluation
    report=evaluator(str(verify_file(artifact_root,files[d['evaluation_evidence']])),str(artifact_root))
    if type(report.get('complete')) is not bool or type(report.get('accepted')) is not bool:raise ValueError('Invalid M74 audit response')
    if report['accepted'] and not report['complete']:raise ValueError('M74 cannot accept an incomplete evaluation')
    run=read(verify_file(artifact_root,files[d['smoke_run']['metadata_evidence']]))
    text(run['run_id'],'smoke run identity')
    if run['run_id']!=d['smoke_run']['run_id']:raise ValueError('Smoke run identity mismatch')
    if run['observed_versions']!=versions or run['source_kind']!=d['source_kind']:raise ValueError('Smoke run version or provenance mismatch')
    if run['purpose']!='release_smoke':raise ValueError('Smoke must stay separate from frozen main evaluation')
    if run['status'] not in ('completed','failed','intervention','estop'):raise ValueError('No executed smoke run status')
    refs=d['smoke_run']['evidence'];references(refs,files,'smoke run')
    kinds={files[i]['kind'] for i in refs}
    if not {'video','gateway_log','outcome_note'}.issubset(kinds):raise ValueError('Smoke evidence needs video, gateway_log and outcome_note')
    verify_run_binding(run,artifact_root,files,refs,versions=versions,source_kind=d['source_kind'],purpose='release_smoke')
    references(d['gateway_physical_checks'],files,'physical stop and gateway checks')
    # A structurally valid engineering release may retain incomplete/failed performance.
    decision='incomplete' if not report['complete'] else 'passed' if report['accepted'] else 'failed'
    return {'structural_complete':True,'release_id':d['release_id'],'source_kind':d['source_kind'],'frozen_versions':versions,'evaluation':report,'evaluation_decision':decision,'performance_status':decision if d['source_kind']=='learner_recording' else 'synthetic_only','performance_accepted':report['accepted'] and report['complete'] and d['source_kind']=='learner_recording','truth_certified':False,'errors':[],'limits':'Synthetic fixtures never certify learner performance. File checks do not certify physical construction, actual stop behavior or video content.'}

if __name__=='__main__':run_cli(audit_release)
