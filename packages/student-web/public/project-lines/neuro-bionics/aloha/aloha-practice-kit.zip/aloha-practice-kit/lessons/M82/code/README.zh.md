# M82：贡献与主张引用检查

```sh
python lessons/M82/code/claims_audit.py my-project/claims.json --root my-project --output my-project/claims-check-01.json
```

填写 `claims.template.json`。`files` 使用M79的实际文件与摘要格式；`sources` 分别记录 ALOHA、SO-101、LeRobot 的来源、固定版本与使用方式，设计与软件附 `license_evidence` 引用实际许可文件。来源方法的文献引用与要分发代码/素材的许可不是同一项；若同时分发材料，需要另外核对实际材料许可。

每条 `claims` 包含唯一id、statement、scope、own_work、limits、evidence及source_ids。程序能发现缺字段和无效引用，不能自动判断一句话是否过度或贡献是否原创。请同伴从主张现场打开原文件，人工核对动词与证据。

`counterexample` 保存 observed、unknown 与原证据；`next_question` 分开 change、prediction、refuting_result 和 fresh_test_plan。`questions_record` 引用实际问答与待查项。

输出明确 `legal_approval: false` 与 `originality_scored: false`。这是文件关系检查，不是法律意见、原创评奖或机构认证。课堂可本地完成，不要求注册账号和公开儿童影像。报告采用新文件名，旧问答和修订历史继续保留。
