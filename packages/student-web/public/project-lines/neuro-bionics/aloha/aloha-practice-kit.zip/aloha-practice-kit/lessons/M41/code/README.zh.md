# M41 · 全部关节的多输入、多输出线性基线

数值前向、梯度和更新在 `linear_layer.py` 逐项写出，只需标准库；没有把训练藏在库调用后。保存/加载使用官方 `safetensors` 与 PyTorch CPU，不调用电机。使用已按实践包根 `docs/ENVIRONMENT.zh.md` 固定的 LeRobot 训练环境（锁内 torch 2.11.0、safetensors 0.8.0）；先检查两包导入，不能把M05标准库环境当作完整训练环境。

在实践包根运行，保留 lessons/M35、M37、M41 的相对目录：

```sh
python -c "import torch, safetensors; print(torch.__version__, safetensors.__version__)"
python lessons/M41/code/linear_baseline.py work/teaching-package work/normalization.json --rate 0.2 --steps 100 --out work/linear-v1
```

默认 `--lock-file` 指向包内固定官方 `research/lerobot/uv.lock`。若项目另有经记录的锁文件，显式传入路径；保存真实文件摘要，不编造“锁定成功”。输出环境记录只说明当前离线数学与权重I/O环境，不声称完整相机、GPU或实机环境已经通过。

十二输入是按M03/M35字段次序的 `observation_state`；十二输出预测 `teleop_processor_action`。各列用M37各自训练统计换尺。输入和目标尺度不同，输出还原只用目标统计。不把目标解释为实测位置，也不把这个无图像仿射模型称为ACT。

系数布局是 `weight[output][input]`：每条输出先拿对应一行系数，与十二输入对应相乘求和，再加这一输出的偏置。参数共144个权重加12个偏置。批次只是多张样本卡，不增加参数。12×12转置后形状仍相同，所以不能只看尺寸；用非对称小例和字段名核对每个乘积。两输入三输出的小例能让错误转置变成可见的尺寸不合。

损失是所有帧、所有输出格子的平方误差平均，分母为 `frame_count * 12`，无二分之一系数。单个连接方向是对应输出误差乘2、再乘对应输入，最后按同一分母汇总。偏置不用乘输入。所有方向先从旧参数算好，再一起更新；不使用autograd、动量或权重衰减。

本单层仿射模型从全零参数开始是有效的固定起点，**不能把这个初始化规则直接用于下节隐藏层网络**。默认全批100次只是练习安排，不保证达到某误差。异常停止原因在training.json保留，有限超阈值点不删除；非有限更新拒绝，保存最后有效参数。输出目录必须全新。

validation在训练结束后只评一次，不参与梯度、不改变归一化、不用于本脚本选步长或停止点。若看结果后继续反复改模型，这些回合已是开发材料，不能再声称未知最终测试；后续M45再明确选模协议。本加载接口拒绝test。

输出文件：

- `model.safetensors`：float64权重[12,12]与偏置[12]；加载后逐值核验与内存一致。
- `model.json`：输入/输出含义、轴顺序、字段、单位、源数据与归一化SHA、权重SHA和训练状态。
- `weight-table.csv` / `bias-table.csv`：带完整字段名的参数表，便于定位连接。
- `forward-trace.json`：本人第一训练帧十二条输出的每个乘积、和、偏置、预测与身份，手算一条输出。
- `metrics.json`：train与validation全部十二通道的原单位MAE/MSE及标准分数MSE；原单位不跨通道求平均。
- `train-loss.csv` / `training.json`：从step0起的实际更新轨迹、口径和停止原因。
- `environment.json` / `upstream-uv.lock`：实际Python/平台/依赖、代码与上游锁摘要，保存版本信息。

示意手算：输入2与−1；输出第一行系数0.5、−1，偏置0.2，得到2.2；第二行系数1、0.25，偏置−0.1，得到1.65。若目标为1.2、2.65，误差为1、−1，两个输出的平方平均为1。第一行两连接方向为2、−1，第二行为−2、1，偏置方向1、−1；这里分母为2。它只帮助核算，不能代替本人十二输入轨迹。

```sh
python -m unittest discover -s lessons/M41/code -p 'test_*.py' -v
```

单元测试采用synthetic数字；必须另外完成本人数据前向手算与可追溯运行。保留所有通道报告，不只截图最好的一列。
