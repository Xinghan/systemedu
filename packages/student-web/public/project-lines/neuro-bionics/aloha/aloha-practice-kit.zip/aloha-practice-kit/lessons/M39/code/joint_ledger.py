#!/usr/bin/env python3
"""Audit one declared scalar predictor plus eleven explicitly labeled copy-state baselines."""
import argparse,hashlib,json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M37/code'))
from normalize import FIELDS,UNITS,forward,inverse,read_package,verify_config

def summarize(errors):
    if not errors:raise ValueError('No errors')
    n=len(errors)
    return {'n':n,'mean_signed':math.fsum(errors)/n,'mae':math.fsum(abs(e) for e in errors)/n,
            'mse':math.fsum(e*e for e in errors)/n}

def audit(package,normalization,predictions,allow_synthetic=False):
    manifest,train=read_package(package,'train',allow_synthetic)
    raw=Path(normalization).read_bytes();stats=json.loads(raw);verify_config(stats,manifest,train)
    data=json.loads(Path(predictions).read_text())
    if data['normalization_sha256']!=hashlib.sha256(raw).hexdigest():raise ValueError('Scalar predictions used another normalization')
    if data['provenance']['frames_sha256']!=manifest['sha256'] or data['provenance']['kind']!=manifest['provenance']:raise ValueError('Prediction source differs')
    if data['feature']['field']!=data['target']['field'] or data['target']['semantics']!='teleop_processor_action':raise ValueError('Expected same-channel scalar experiment')
    selected=FIELDS.index(data['target']['field']);index={(r['episode_id'],r['attempt_id'],r['frame_index']):r for r in train}
    details=[];seen=set()
    for p in data['rows']:
        key=(p['episode_id'],p['attempt_id'],p['frame_index'])
        if key in seen:raise ValueError('Duplicate scalar row')
        seen.add(key);r=index[key]
        if p['split']!='train':raise ValueError('Scalar slice is not train')
        if type(p['prediction']) not in (int,float) or not math.isfinite(p['prediction']):raise ValueError('Prediction must be a finite number, not a boolean')
        pred=float(p['prediction'])
        out=list(r['observation_state'])
        out[selected]=inverse(pred,stats['statistics']['action'][selected])
        errors=[a-b for a,b in zip(out,r['action'])]
        norm=[e/stats['statistics']['action'][j]['scale'] for j,e in enumerate(errors)]
        details.append({'episode_id':key[0],'attempt_id':key[1],'frame_index':key[2],
                        'raw_prediction':out,'raw_target':r['action'],'raw_signed_error':errors,'normalized_signed_error':norm})
    per=[]
    for j,name in enumerate(FIELDS):
        per.append({'field':name,'unit':UNITS[j],
                    'predictor':'M38 scalar' if j==selected else 'copy current observed state; no learned model',
                    'physical':summarize([r['raw_signed_error'][j] for r in details]),
                    'standardized':summarize([r['normalized_signed_error'][j] for r in details])})
    return {'provenance':manifest['provenance'],'source_sha256':manifest['sha256'],
            'normalization_sha256':data['normalization_sha256'],'scope':'Offline training slice; only one channel uses M38 scalar, other eleven are copy-state baselines',
            'aggregation':'equal weight for each frame-channel cell; physical units NEVER averaged across channels',
            'selected_field':FIELDS[selected],'per_channel':per,
            'normalized_all_channels':summarize([e for r in details for e in r['normalized_signed_error']]),
            'rows':details,'task_success_assessed':False,'hardware_executed':False}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('predictions')
    p.add_argument('--out',required=True);p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
    try:
        result=audit(a.package,a.normalization,a.predictions,a.allow_synthetic)
        with Path(a.out).open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    except (OSError,ValueError,KeyError,TypeError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
