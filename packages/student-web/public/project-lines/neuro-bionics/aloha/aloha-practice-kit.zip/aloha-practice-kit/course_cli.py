#!/usr/bin/env python3
"""Offline teaching tools. No networking, subprocesses, serial ports, or motor drivers."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys

JOINTS = ('shoulder_pan', 'shoulder_lift', 'elbow_flex', 'wrist_flex', 'wrist_roll', 'gripper')
FIELDS = tuple(f'{side}_{j}.pos' for side in ('left', 'right') for j in JOINTS)

def number(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x):
        raise ValueError(f'Expected finite number, got {x!r}')
    return float(x)

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def exact_fields(obj, expected=FIELDS):
    if set(obj) != set(expected):
        raise ValueError(f'Field mismatch: missing={sorted(set(expected)-set(obj))}; extra={sorted(set(obj)-set(expected))}')

def fields(data):
    exact_fields(data['state'])
    return {'provenance': data['provenance'], 'fields': [
        {'index': i, 'field': k, 'value': number(data['state'][k]),
         'unit': 'normalized_0_100' if 'gripper' in k else 'degree'} for i,k in enumerate(FIELDS)],
        'note': 'Explicit use_degrees=true. Gripper is not degrees or millimetres. Verify dataset feature-name order.'}

def sampling(data):
    t = list(map(number, data['timestamps_s']))
    if len(t) < 2: raise ValueError('Need at least two timestamps')
    dt = [b-a for a,b in zip(t,t[1:])]
    if min(dt) <= 0: raise ValueError('Timestamps must strictly increase')
    mean = statistics.mean(dt)
    return {'provenance': data['provenance'], 'intervals_s': dt, 'mean_period_s': mean,
            'mean_rate_hz': 1/mean, 'max_interval_s': max(dt),
            'population_jitter_s': statistics.pstdev(dt)}

def limits(data):
    for name in ('present','target','limits'): exact_fields(data[name])
    rows=[]
    for key in FIELDS:
        present,target=number(data['present'][key]),number(data['target'][key])
        lo,hi,cap=map(number,(data['limits'][key]['min'], data['limits'][key]['max'],data['limits'][key]['max_delta']))
        if lo >= hi or cap <= 0: raise ValueError(f'Invalid bounds: {key}')
        if not lo <= present <= hi: raise ValueError(f'Present position already outside approved interval: {key}')
        bounded=max(lo,min(hi,target))
        sent=present+max(-cap,min(cap,bounded-present))
        rows.append({'field':key,'requested':target,'after_absolute_clip':bounded,'dry_run_target':sent,
                     'clipped':not math.isclose(sent,target)})
    return {'provenance':data['provenance'],'dry_run_only':True,'rows':rows,
            'note':'Teaching absolute limits + measured-position delta. LeRobot max_relative_target alone does not implement these absolute intervals, speed limits or collision avoidance.'}

def sync_audit(data):
    offset=number(data['image_clock_offset_s'])
    maximum=number(data['max_age_s'])
    if maximum < 0: raise ValueError('max_age_s must be nonnegative')
    rows=data['rows']; previous={}; findings=[]; ages=[]
    if not rows: raise ValueError('Empty synchronization table')
    for i,row in enumerate(rows):
        values={key:number(row[key]) for key in ('state_time_s','image_capture_time_s','action_time_s')}
        values['image_capture_time_s'] += offset
        for key,val in values.items():
            if key in previous and val <= previous[key]: findings.append({'row':i,'kind':'non_increasing','stream':key})
            previous[key]=val
        action=values['action_time_s']
        for key in ('state_time_s','image_capture_time_s'):
            age=action-values[key]; ages.append(age)
            if age < -1e-9: findings.append({'row':i,'kind':'future_information','stream':key,'age_s':age})
            elif age > maximum: findings.append({'row':i,'kind':'stale_input','stream':key,'age_s':age})
    return {'provenance':data['provenance'],'passes_declared_checks':not findings,
            'max_age_s':max(ages),'findings':findings,
            'note':'Clock offset must come from measured clock alignment; these timestamps do not prove sensor exposure timing.'}

def split_episodes(data, source_dir, output_dir, seed=7):
    """Copy whole JSONL episodes and write LeRobot indices; never split frames."""
    source_dir=Path(source_dir).resolve(); output_dir=Path(output_dir)
    if output_dir.exists(): raise ValueError('Output must be a new directory; previous evidence is never overwritten')
    episodes=data['episodes']; ids=[e['episode_index'] for e in episodes]
    if not episodes or len(set(ids))!=len(ids): raise ValueError('Empty or duplicated episode index')
    if any(type(i) is not int or i<0 for i in ids): raise ValueError('Episode indices must be nonnegative integers')
    batches={e['batch'] for e in episodes}; tests=set(data['reserved_test_batches'])
    if not tests or not tests <= batches: raise ValueError('Reserve existing test batches before splitting')
    remaining=sorted(batches-tests);random.Random(seed).shuffle(remaining)
    n=data['validation_batch_count']
    if type(n) is not int or not 1<=n<len(remaining):raise ValueError('Need at least one train, validation and test batch')
    validation=set(remaining[:n]); assignments={}; payloads=[]; excluded=[]
    for e in episodes:
        if type(e['accepted_for_learning']) is not bool: raise ValueError('accepted_for_learning must be boolean')
        group='test' if e['batch'] in tests else 'validation' if e['batch'] in validation else 'train'
        assignments[e['batch']]=group
        path=(source_dir/e['file']).resolve()
        if not path.is_relative_to(source_dir):raise ValueError('Episode path leaves source directory')
        raw=path.read_bytes(); lines=[json.loads(line) for line in raw.decode().splitlines() if line.strip()]
        if not lines or any(row['episode_index']!=e['episode_index'] for row in lines):raise ValueError('Mixed or empty episode file')
        times=[number(row['timestamp_s']) for row in lines]
        if any(b<=a for a,b in zip(times,times[1:])):raise ValueError('Non-increasing episode time')
        if not e['accepted_for_learning']:
            if not e.get('exclusion_reason'):raise ValueError('Rejected episode needs an explicit reason')
            excluded.append({'episode_index':e['episode_index'],'reason':e['exclusion_reason'],'assigned_split':group})
        payloads.append((e,group,raw,hashlib.sha256(raw).hexdigest()))
    if any(not any(group==name and e['accepted_for_learning'] for e,group,_,_ in payloads)
           for name in ('train','validation')):
        raise ValueError('No accepted learning episodes in a split; revise collection before copying')
    output_dir.mkdir(parents=True)
    report={'provenance':data['provenance'],'seed':seed,'batch_assignments':assignments,'episodes':[],
            'lerobot_episode_indices':{'train':[],'validation':[],'test':[]},'excluded_from_learning':excluded}
    for e,group,raw,digest in payloads:
        target=output_dir/group/f"episode_{e['episode_index']:06d}.jsonl";target.parent.mkdir(exist_ok=True);target.write_bytes(raw)
        report['episodes'].append({'episode_index':e['episode_index'],'split':group,'sha256':digest,'copied_rows':len(raw.splitlines())})
        # Test evidence is always retained, including unsuccessful trials.
        if group=='test' or e['accepted_for_learning']:report['lerobot_episode_indices'][group].append(e['episode_index'])
    for key in report['lerobot_episode_indices']:report['lerobot_episode_indices'][key].sort()
    (output_dir/'manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report

def mse(rows,w,b):
    if not rows:raise ValueError('Empty dataset')
    return sum((w*number(row['x'])+b-number(row['y']))**2 for row in rows)/len(rows)

def toy_train(data):
    train,valid=data['train'],data['validation'];w=number(data['initial_w']);b=number(data['initial_b'])
    lr=number(data['learning_rate']);steps=data['steps']
    if lr<=0 or type(steps)is not int or not 1<=steps<=100000:raise ValueError('Invalid learning rate or steps')
    mse(train,w,b);mse(valid,w,b);history=[];best=None
    for step in range(steps+1):
        row={'step':step,'w':w,'b':b,'train_mse':mse(train,w,b),'validation_mse':mse(valid,w,b)}
        if not all(math.isfinite(v) for v in row.values()):raise ValueError('Training diverged; choose a smaller rate')
        if best is None or row['validation_mse']<best['validation_mse']:best=row.copy()
        if step<steps:
            errors=[w*number(r['x'])+b-number(r['y']) for r in train]
            dw=2*sum(e*number(r['x']) for e,r in zip(errors,train))/len(train);db=2*sum(errors)/len(train)
            row.update(gradient_w=dw,gradient_b=db);w-=lr*dw;b-=lr*db
        history.append(row)
    return {'provenance':data['provenance'],'model':'y = w*x + b (teaching model, NOT ACT)',
            'history':history,'selected_by_validation':best}

def ensemble(data):
    target=data['target_step']; coeff=number(data['coefficient'])
    if type(target)is not int or target<0:raise ValueError('target_step must be a nonnegative integer')
    chunks=sorted(data['chunks'],key=lambda x:x['start_step'])
    starts=[x['start_step'] for x in chunks]
    if len(set(starts))!=len(starts) or any(type(x)is not int or x<0 for x in starts):raise ValueError('Invalid chunk start steps')
    candidates=[]
    for chunk in chunks:
        index=target-chunk['start_step']
        if 0<=index<len(chunk['actions']):candidates.append({'start_step':chunk['start_step'],'action':list(map(number,chunk['actions'][index]))})
    if not candidates or not candidates[0]['action']:raise ValueError('No available prediction covers target')
    dim=len(candidates[0]['action'])
    if any(len(c['action'])!=dim for c in candidates):raise ValueError('Mismatched action dimensions')
    # Stable softmax; rank zero is the oldest prediction, matching pinned LeRobot ACT.
    logits=[-coeff*i for i in range(len(candidates))];shift=max(logits);raw=[math.exp(v-shift) for v in logits];total=sum(raw)
    for c,w in zip(candidates,raw):c['weight']=w/total
    action=[sum(c['weight']*c['action'][i] for c in candidates) for i in range(dim)]
    return {'provenance':data['provenance'],'target_step':target,'candidates':candidates,'ensembled_action':action,
            'note':'Positive coefficient favours older predictions in this pinned LeRobot implementation. Future-created chunks are excluded.'}

def evaluate(data):
    plan=data['plan'];trial_ids=[p['trial_id'] for p in plan];results=data['results'];result_ids=[r['trial_id'] for r in results]
    if not plan or len(set(trial_ids))!=len(trial_ids) or len(set(result_ids))!=len(result_ids):raise ValueError('Empty plan or duplicate trial IDs')
    if not set(result_ids)<=set(trial_ids):raise ValueError('Unplanned trial')
    maximum=number(data['time_limit_s']);by_id={r['trial_id']:r for r in results};rows=[]
    if maximum<=0:raise ValueError('time_limit_s must be positive')
    for p in plan:
        r=by_id.get(p['trial_id'])
        if r is None:rows.append({'trial_id':p['trial_id'],'condition':p['condition'],'success':False,'reason':'missing_record'});continue
        if r['status'] not in ('completed','failed','intervention','estop'):raise ValueError('Unknown trial status')
        for key in ('tray_held','block_in_tray','human_intervention'):
            if type(r[key])is not bool:raise ValueError('Outcome flags must be booleans')
        seconds=number(r['duration_s'])
        if seconds<0:raise ValueError('Negative trial duration')
        success=r['status']=='completed' and r['tray_held'] and r['block_in_tray'] and not r['human_intervention'] and seconds<=maximum
        if not success and not r.get('failure_reason'):raise ValueError('Every unsuccessful trial needs a failure reason')
        rows.append({'trial_id':p['trial_id'],'condition':p['condition'],'success':success,'duration_s':seconds,
                     'reason':'completed' if success else r['failure_reason']})
    successes=sum(r['success'] for r in rows);n=len(plan);p=successes/n;z=1.96
    centre=(p+z*z/(2*n))/(1+z*z/n);half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return {'provenance':data['provenance'],'planned_trials':n,'recorded_trials':len(results),'complete':len(results)==n,
            'successes':successes,'success_rate':p,'wilson_95_interval':[max(0,centre-half),min(1,centre+half)],'trials':rows,
            'note':'All planned trials remain in denominator. Missing results prevent final acceptance. Interval assumes Bernoulli sampling; it is not a general reliability guarantee.'}

def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    for name in ('fields','sampling','limits','sync','toy-train','ensemble','evaluate'):
        p=sub.add_parser(name);p.add_argument('input')
    p=sub.add_parser('split');p.add_argument('input');p.add_argument('--source-dir',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--seed',type=int,default=7)
    args=parser.parse_args()
    try:
        data=read_json(args.input)
        if args.command=='split':result=split_episodes(data,args.source_dir,args.output_dir,args.seed)
        else:result={'fields':fields,'sampling':sampling,'limits':limits,'sync':sync_audit,'toy-train':toy_train,'ensemble':ensemble,'evaluate':evaluate}[args.command](data)
        print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    except (ValueError,KeyError,TypeError,OSError) as e:parser.exit(2,f'ERROR: {e}\n')

if __name__=='__main__':main()
