from pathlib import Path
import json
S={'type':'string','minLength':1};H={'type':'string','pattern':'^[a-f0-9]{64}$'}
def obj(props,required=None):return {'type':'object','properties':props,'required':required or list(props),'additionalProperties':True}
versions=obj({k:H for k in ['model_manifest_sha256','hardware_manifest_sha256','config_sha256','dataset_split_manifest_sha256','software_manifest_sha256']})
evidence=obj({'kind':{'enum':['video','gateway_log','outcome_note','other']},'path':S,'sha256':H,'description':S})
intervention=obj({'offset_s':{'type':'number','minimum':0},'actor_role':S,'action':S,'reason':S})
plan=obj({'trial_id':S,'order':{'type':'integer','minimum':1,'maximum':20},'condition':S,'initial_setup':S,'planned_status':{'const':'planned'},'sealed_test_ref':S,'evidence_requirements':{'type':'array','items':S,'minItems':3,'uniqueItems':True}})
result=obj({'trial_id':S,'status':{'enum':['completed','failed','intervention','estop']},'started_at':S,'ended_at':S,'duration_s':{'type':'number','minimum':0},'tray_held':{'type':'boolean'},'block_in_tray':{'type':'boolean'},'human_intervention':{'type':'boolean'},'failure_reason':{'type':'string'},'observed_versions':versions,'evidence':{'type':'array','items':evidence},'interventions':{'type':'array','items':intervention},'notes':{'type':'string'}})
threshold=obj({'minimum_successes':{'type':'integer','minimum':0,'maximum':20},'maximum_interventions':{'type':'integer','minimum':0,'maximum':20},'maximum_estops':{'type':'integer','minimum':0,'maximum':20},'required_conditions':{'type':'array','items':{'enum':['all_planned_trials_executed','all_evidence_verified','frozen_versions_match']},'minItems':3,'maxItems':3,'uniqueItems':True}})
schema=obj({'schema':{'const':'aloha.independent-evaluation.v1'},'evaluation_id':S,'source_kind':{'enum':['learner_recording','synthetic']},'provenance':S,'created_at':S,'time_limit_s':{'type':'number','exclusiveMinimum':0},'plan_path':S,'plan_sha256':H,'acceptance_threshold':threshold,'frozen_versions':versions,'plan':{'type':'array','minItems':20,'maxItems':20,'items':plan},'results':{'type':'array','maxItems':20,'items':result}})
schema.update({'$schema':'https://json-schema.org/draft/2020-12/schema','title':'ALOHA independent evaluation v1','description':'Structural validation only. Cross-row references, evidence existence, file hashes, completeness and outcome require audit. Missing results must remain incomplete.'})
Path(__file__).with_name('evaluation-v1.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
