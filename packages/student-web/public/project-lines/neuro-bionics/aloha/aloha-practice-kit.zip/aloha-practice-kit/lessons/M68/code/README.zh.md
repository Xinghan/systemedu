# M68：真正调用固定官方训练器

先激活 `docs/ENVIRONMENT.zh.md` 对应环境，命令在[实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)根目录执行。`training_run.py`默认只生成可审查命令；加 `--execute` 会实际使用本机计算资源进行训练。它不打开电机或相机，不上传数据，不要求学生Hub账号。

## 把原始划分变成原生train子集

沿M33生成的 `original-splits.json`，从实践包 `examples/act_config.synthetic.json` 复制为 `act-config.json`，将全部虚构值改为自己的原生root、split_root、repo_id、固定版本与已测配置，并把provenance改成本人来源说明。示例并非已验证硬件配置。split_root须是原root之外的新目录。先用生成器：

```sh
python act_commands.py split-lerobot act-config.json --split original-splits.json > split-command.json
```

审查输出的argv/shell_preview，再在已激活环境执行该精确命令。固定官方入口是 `lerobot-edit-dataset`，操作为split，`operation.splits`是原始train/validation/test的**完整索引列表**，push_to_hub=false。这是实际文件操作；生成JSON本身不会建立子集。

在产生的 `split_root/train` 核查 `meta/info.json`、`meta/stats.json` 与原回合映射。原回合0、2、5会在train子集重新编号0、1、2；训练root和索引必须配套。保存原始划分及其SHA、官方输出和对子集统计的人工核查说明。禁止复用全数据stats，禁止把validation/test并回train。以上示例索引不是你的数据。

## 生成、运行、检查

按M67填写并短基准验证 `training-request.json`。正式 `output_dir` 必须尚不存在；不要用短基准权重代替正式运行。

```sh
python lessons/M68/code/training_run.py train training-request.json reviewed-command.json
python lessons/M68/code/training_run.py train training-request.json receipt-run1 --execute
```

两行是不同输出：第一行生成文件，第二行创建新的receipt目录并真正调用官方训练CLI。保存command.json、stdout-stderr.log、result.json。成功返回码不等于任务效果；检查数据/版本/配置/实际步数、有限loss和梯度。失败会保留日志与返回码，修复后用新输出路径。训练中的weights、processor配置与旁状态在实际输出目录 `checkpoints/<实际步号>/pretrained_model`；相邻 `training_state` 包含完整恢复状态。以实际目录为准，不按示例猜补零位数。

## 完整断点恢复

只有model.safetensors不能叫完整恢复。确认config、train_config、处理器状态、optimizer、rng、training_step等文件齐全，并保持同数据、batch、架构、精度和单进程设置。总步数由4恢复到6时写6，不写2。

```sh
python lessons/M68/code/training_run.py resume /ABS/actual/checkpoint/pretrained_model training-request.json 6 receipt-resume-review
python lessons/M68/code/training_run.py resume /ABS/actual/checkpoint/pretrained_model training-request.json 6 receipt-resume-run --execute
```

`/ABS/...`必须改成实际路径；示例总步数6仅解释语义。第一行保存审查文件，不训练；第二行用另一个新目录保存更新后的training-request.json与新日志。M69注册续训checkpoint时必须传**续训receipt里的新请求与新receipt**。旧请求仍保留来源，不能拿旧4步请求伪称新6步来自旧运行。

## 已执行与待完成

根作者在固定完整包上实际执行合成image-backed、CPU四步训练及4→6续训并保存检查点；这证明所测接口链可执行，不是本人正式长训、GPU、视频或实机成功。学生必须提交本人真实train回合、实际权重及全部运行证据，失败也留下。后续M69只用开发验证回合选版，封存测试继续不打开。
