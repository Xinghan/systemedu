#!/usr/bin/env python3
"""Check a learner train frame using explicit paths, finite differences and torch autograd."""
import argparse,csv,hashlib,json,platform,sys
from pathlib import Path
from backprop import check,loss_gradient,KEYS
from network_artifact import load,sha
from dataset_view import load_view,FIELDS
from linear_baseline import identity
def dump(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def run(package,norm,folder,out,episode=None,frame=None,inject_fault=False,allow_synthetic=False):
 view=load_view(package,norm,'train',allow_synthetic);model,meta=load(folder,view)
 if (episode is None)!=(frame is None):raise ValueError('episode and frame must be selected together')
 if episode is None:
  trace=json.loads((Path(folder)/'forward-trace.json').read_text())
  if trace.get('source')!=identity(view):raise ValueError('M42 trace source differs')
  episode=trace['frame']['episode_id'];frame=trace['frame']['frame_index']
 rows=[r for r in view['rows'] if r['episode_id']==episode and r['frame_index']==frame]
 if len(rows)!=1:raise ValueError('Select exactly one train frame')
 row=rows[0];truth=loss_gradient(rows,model);omit=None;fault=None
 if inject_fault:
  trace=truth['traces'][0];candidates=[(abs(value*row['x'][i]),k,j,i) for j,paths in enumerate(trace['hidden_path_contributions']) if trace['relu_local_factor'][j] for k,value in enumerate(paths) for i in range(len(row['x']))]
  if not candidates or max(candidates)[0]==0:raise ValueError('This frame has no observable hidden weight path to omit; choose another train frame')
  _,omit,j,i=max(candidates);fault={'type':'omit_one_output_contribution_in_hidden_reverse_pass','output_index':omit,'guaranteed_affected_weight':['w1',j,i],'forward_unchanged':True}
 report=check(rows,model,omit_output=omit);report.update({'source':identity(view),'frame':{k:row[k] for k in ('episode_id','attempt_id','frame_index')},'parameter_checkpoint_sha256':meta['checkpoint_sha256'],'training_status':meta['training_status'],'fault':fault,'hardware_command':False,'parameters_updated':False,'validation_opened':False,'test_opened':False})
 p=Path(out);p.mkdir(parents=True,exist_ok=False);dump(p/'gradient-check.json',report)
 with (p/'comparisons.csv').open('x',newline='') as f:
  writer=csv.writer(f);writer.writerow(['parameter','explicit','autograd','epsilon','finite_difference','branch_eligible','abs_error','status'])
  for r in report['comparisons']:
   for probe in r['probes']:writer.writerow(['.'.join(map(str,r['parameter'])),r['explicit'],r['autograd'],probe['epsilon'],probe['central_difference'],probe['eligible'],probe['absolute_difference'],r['status']])
 trace=truth['traces'][0];paths=[]
 for j,terms in enumerate(trace['hidden_path_contributions']):
  paths.append({'hidden_index':j,'preactivation':trace['forward']['preactivation'][j],'gate_factor':trace['relu_local_factor'][j],'output_paths':[{'field':FIELDS[k],'output_error':trace['error'][k],'output_signal':trace['output_signal'][k],'outgoing_weight':model['w2'][k][j],'contribution':value} for k,value in enumerate(terms)],'sum_before_gate':trace['hidden_sum'][j],'after_gate':trace['preactivation_signal'][j],'input_connections':[{'input_field':FIELDS[i],'input_value':x,'weight_gradient':truth['gradient']['w1'][j][i]} for i,x in enumerate(row['x'])]})
 dump(p/'hand-trace.json',{'meaning':'correct explicit routes, including all output branches; compare fault report separately','frame':report['frame'],'denominator':truth['denominator'],'paths':paths})
 dump(p/'environment.json',{'python':sys.version,'platform':platform.platform(),'torch':report['autograd']['torch_version'],'dtype':'float64','code_sha256':{name:sha(Path(__file__).with_name(name)) for name in ('backprop.py','gradient_check.py')},'model_json_sha256':sha(Path(folder)/'model.json')})
 summary={'provenance':view['provenance'],'frame':report['frame'],'parameters_checked':len(report['comparisons']),'passed':sum(v['status']=='pass' for v in report['comparisons']),'mismatched':sum(v['status']=='mismatch' for v in report['comparisons']),'inconclusive':sum(v['status']=='inconclusive_branch' for v in report['comparisons']),'all_pass':report['all_checked_parameters_pass'],'fault':fault,'parameters_updated':False};dump(p/'summary.json',summary);return summary
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('network');p.add_argument('--out',required=True);p.add_argument('--episode');p.add_argument('--frame',type=int);p.add_argument('--inject-fault',action='store_true');p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
 try:
  r=run(a.package,a.normalization,a.network,a.out,a.episode,a.frame,a.inject_fault,a.allow_synthetic);print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['all_pass'] else 1
 except (OSError,ValueError,KeyError,TypeError,ImportError,OverflowError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':raise SystemExit(main())
