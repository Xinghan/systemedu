"""Create a new hashed index from a learner-authored package mapping; no upload."""
import argparse,json,hashlib
from pathlib import Path
from inspect_package import inside

def create(root,draft,out):
 root=Path(root).resolve();draft=Path(draft).resolve();out=Path(out).resolve()
 if not out.is_relative_to(root):raise ValueError('index must be saved inside package root')
 if out.exists():raise ValueError('new index path required; preserve the previous version')
 index=json.loads(draft.read_text())
 if index.get('schema')!='aloha.local-package.v1':raise ValueError('fill the package mapping schema first')
 files={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError('symbolic links must be resolved and copied explicitly before packaging')
  if not p.is_file() or p.resolve() in (draft,out):continue
  h=hashlib.sha256()
  with p.open('rb') as f:
   while data:=f.read(1024*1024):h.update(data)
  files[str(p.relative_to(root))]=h.hexdigest()
 index['files']=files;out.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');return len(files)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--draft',required=True);p.add_argument('--out',required=True);a=p.parse_args();print(json.dumps({'files_indexed':create(a.root,a.draft,a.out),'next':'run inspect_package.py; indexing alone is not acceptance'}))
