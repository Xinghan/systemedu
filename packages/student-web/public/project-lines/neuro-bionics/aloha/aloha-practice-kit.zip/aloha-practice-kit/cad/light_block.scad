// Original small rounded teaching object. Weigh the actual print; infill changes mass.
length=18; width=18; height=12; radius=2;
$fn=32;
assert(min(length,width,height)>2*radius);
minkowski(){cube([length-2*radius,width-2*radius,height-2*radius]);sphere(r=radius);}
