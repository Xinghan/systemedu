# 固定版录制契约

适用于 LeRobot b64fe1ed9f11eeac53ee821356d2797601701054。这里根据代码读取，不根据已过时的注释猜测字段。

## 动作链的五个不同位置

1. raw_teleop_action：示教器读到的意图。
2. teleop_processor_action：teleop_action_processor 输出；默认 Identity。固定版原生数据集 action 保存的正是这一项 action_values。
3. robot_processor_action_to_send：robot_action_processor 输出，作为 robot.send_action 的参数。可能与上一项不同。
4. driver_returned_sent_action：robot.send_action 返回值；驱动可按 max_relative_target 等约束改变目标。原生记录循环丢弃此返回值，没有把它存成原生 action。
5. observed_state：传感器读到的位置，不表示已经到达上述目标。

离线例：teleop 目标30度、robot processor 改为28度，当前实测20度、max_relative_target为2度，则驱动目标可能22度。原生action仍为30度。这些数字只是示例，不是通用安全限值。ACT学习原生action时，训练和部署必须保持这一目标语义，执行约束仍在下游。

## 两套时间

原生 timestamp = frame_index / fps，是预定名义网格。不能据此证明相机没有丢帧、真实帧龄或左右动作同步。旁路用同一进程的 monotonic/perf_counter 记录观察到达、send开始/结束，并用 episode_index 和 frame_index 关联；相机驱动提供的真实曝光时间若存在，需另带时钟域与来源，否则只称到达时间。

M27完成最小sidecar埋点与无动力运行，M28集成，M29解析审计并固定schema。事件写盘失败、缺帧、停止都保留。实践包提供离线例与契约，不应声称仅运行原生录制命令已自动生成旁路；具体埋点和现场验证是该节点交付的一部分。真实采集前必须在固定源码调用位置核查一次。
