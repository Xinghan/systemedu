from pathlib import Path
import json
R=Path(__file__).parent
p=R/'evaluation-v1.schema.json';s=json.loads(p.read_text());H={'type':'string','pattern':'^[a-f0-9]{64}$'};S={'type':'string','minLength':1};ref={'type':'object','properties':{'path':S,'sha256':H},'required':['path','sha256']};res=s['properties']['results']['items'];extra={'run_id':S,'purpose':{'const':'evaluation'},'source_kind':{'enum':['learner_recording','synthetic']},'run_record_ref':ref,'start_record_ref':ref}
res['properties'].update(extra);res['required']=list(dict.fromkeys(res['required']+list(extra)))
s['description']='Structural validation only. Use M74 audit_evaluation for actual file bytes, native gateway contents, unique observation binding, retained start/close records and full 20-trial completeness.'
p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
props={k:s['properties'][k] for k in ['evaluation_id','source_kind','time_limit_s','acceptance_threshold','frozen_versions','plan']};props.update(schema={'const':'aloha.independent-plan.v1'},registered_at=S,version_artifacts={'type':'object','properties':{k:S for k in ['model_manifest','hardware_manifest','config','dataset_split_manifest','software_manifest']},'required':['model_manifest','hardware_manifest','config','dataset_split_manifest','software_manifest'],'additionalProperties':False})
(R/'frozen-plan-v1.schema.json').write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','properties':props,'required':list(props),'description':'Freeze actual bytes with M74 freeze_plan, then preserve this separate plan file unchanged.'},ensure_ascii=False,indent=2)+'\n')
p=R/'evaluation-v1.md';t=p.read_text().replace('此API实现与反例将在M74作者包交付，不因本说明存在就声称已执行真实验收。','此API实现与反例已交付M74作者包并经合成文件测试；没有声称真实学生或硬件已执行验收。');t+='''

## 实际运行绑定补充

单独plan.json还必须含source_kind及version_artifacts五个路径入口。它们是证据根目录的相对路径，模型/硬件/划分/软件清单的files数组为非空[{path,sha256}]，全部叶文件重新核对；不要求额外id字段。M74 make_inventory.py可从实际文件建立字节清单，内容真实性仍需人审。

每个results含run_id、purpose=evaluation、source_kind、run_record_ref与start_record_ref。run_record_ref引用M75不可覆盖的closed，closed引用原start；身份、冻结计划摘要和实际五类版本绑定。M75 close遇到版本或证据缺失会尽可能保存错误数组；这些错误不能由汇总工具抹去。

观察证据恰好一份outcome_note，M74 verify_outcome_binding(root,run)核其状态、起止时间、duration、托盘/插块/人工flags、失败原因及介入数组与closed一致。原生gateway_log由gateway-log-v1.md规定；validate_gateway_log(path,run)检查run/trial/模型与硬件SHA、policy来源、单次arm、递增命令与最终latched。没有实际policy命令的启用前拒绝仍保存，但不冒充证据完整的物理任务。

M75 start_run(plan_path,artifact_root,trial_id,purpose='evaluation',operator='local_operator',context_plan_path=None)与close_run(run_path,artifact_root,outcome_path,evidence_paths)只读写证据，不发电机命令。release_smoke与independent_handoff另列，后者保存本地operator代号。domain_challenge必须额外context_plan_path，start保存其字节摘要；M78挑战报告核对该绑定，防看过结果后改因素、量值或次数。

truth_certified始终false。synthetic结果永不accepted；测试代码有显式以合成字节验证“声明为learner_recording”的条件分支，不能把分支返回值报告为真实验收。主验收完整性与性能达标分开，所有未执行和未核验位置保留。
''';p.write_text(t)
for mid in ['M74','M75']:
 for name in ['evaluation-v1.md','gateway-log-v1.md','evaluation-v1.schema.json','frozen-plan-v1.schema.json']:(R.parent/'authored'/mid/'practice'/name).write_text((R/name).read_text())
