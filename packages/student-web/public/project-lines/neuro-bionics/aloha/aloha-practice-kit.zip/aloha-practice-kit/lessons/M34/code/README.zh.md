# M34 · 读取本人原生数据

本工具只读文件，不向机械臂发动作。标准库 `file_inventory.py` 可在 Python 3.12 直接运行；`audit_native.py` 使用 M14/M16 按根目录 docs/ENVIRONMENT.zh.md 安装的完整固定 LeRobot 环境。仅有课程摘录源码或最小 torch 数学环境不等于完成安装。

先激活对应环境，运行 `python -m unittest -v`。本节测试用小型 synthetic 张量，验证检查器遇到缺帧、NaN、解码异常、时钟倒退时会拒绝，不代表本人视频已经验证。

## 文件与摘要

把下列大写路径替换为本人路径，报告放到被检查目录之外：

```sh
python file_inventory.py /ABS/PATH/LOCAL_PACKAGE > /ABS/PATH/AUDITS/files-v1.json
python file_inventory.py /ABS/PATH/COPIED_PACKAGE --expected /ABS/PATH/AUDITS/files-v1.json
```

不要把输出报告写回被扫描目录而意外改变下一次比较。符号链接会列未审计，先明确复制需要的目标文件。摘要一致只表示约定字节相同。

## 解码本人批准的开发回合

```sh
python audit_native.py --root /ABS/PATH/NATIVE_DATASET --repo-id local/course_demo_v1 --episode 0 --sidecar /ABS/PATH/ATTEMPT_SIDECAR.jsonl --attempt-id REPLACE_SAVED_ATTEMPT_ID --dataset-reference REPLACE_FROZEN_VERSION_REFERENCE > /ABS/PATH/AUDITS/read-episode-0.json
```

这里的0只是命令占位示例，必须按M33已批准的开发回合清单替换；repo-id也用本人原生库身份。先一回合配一份对应sidecar，核对attempt_id、原始dataset版本及frame_index，保存逐回合报告。用另一数据集的同号回合不能代替。实际读取默认float RGB，通道CHW、范围0到1；改成uint8时须整体修改合同，不能混用本检测。

指定回合的每一帧实际访问时才触发解码。脚本使用本地root且关闭Hub访问，不自动补下载缺文件。读取异常留在报告；返回码非零先排错。本验收入口必须提供sidecar、保存的attempt_id和不可变数据版本引用；缺少任一项就不会通过。版本引用来自M30关闭记录，应关联本次冻结文件清单的摘要，不只是可变目录名。程序核对原生回合、sidecar回合、关闭记录回合、帧数、尝试身份与版本引用；即使双方各自可读，关联不一致仍失败。主机时钟的顺序通过不证明相机曝光或双相机同步；根目录 docs/SIDECAR_INTEGRATION.zh.md 说明插桩位置和边界。

报告中的summed_decoded_image_bytes是处理过的像素字节总量，绝非峰值RAM测量。审计只检查具体格式与部分范围，未认证视频真实性、标签或物理关节安全限值。不要为了通过把缺失值补0、删除失败片段或排序伪造原始时间。

## 另一环境

复制完整来源包，先比对摘要，再按固定环境实际读取同一回合。保存OS/Python/依赖、命令和输出；新venv只能声称环境重建，第二台电脑才能说明该电脑读取结果。不要声称已验证未试的平台。默认本地私有，不要求上传。
