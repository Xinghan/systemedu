# M62：重参数化与固定噪声扰动

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M62/code/reparameterize.py lessons/M62/code/synthetic.json M62-result.json
```

输入 mean、log_variance、epsilon、n_samples、seed、finite_difference_step，可给 teaching_target。本夹具均值1、方差4、噪声−0.5，样本0；固定噪声中心差分对均值约1、对log_variance约−0.5。另用两万次独立噪声估计均值方差，结果允许抽样波动。半平方教学损失仅用于链式影响核对，不是ACT损失。可输入本人后验某一维参数做数值审计，不能由一维抽样图声称真实策略质量。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
