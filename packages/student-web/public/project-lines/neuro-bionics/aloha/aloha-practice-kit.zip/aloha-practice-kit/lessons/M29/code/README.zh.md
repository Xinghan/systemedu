# 一帧字段检查

先运行 `python inspect_frame.py sample.synthetic.json`。这是明确标为synthetic的示意记录，没有机器人或相机证据。

自己的记录需保持同一JSON schema，逐项从M27的sidecar和原生数据读取，不猜填缺项。field_order取本课程双臂约定顺序；如果实际采集的features顺序不同，按字段名显式导出到该顺序，并保存映射，不能只改表头。原生action必须来自teleop处理后目标。夹爪单位normalized_0_100不代表毫米。

运行 `python -m unittest discover -s . -p 'test_*.py'` 可复现缺字段、换顺序、标签替换和时钟/单位混用的检查。结构通过不能证明来源真实或实机达标，仍需打开原始片段复查。
