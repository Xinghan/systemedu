"""Read a teaching contract. No device imports or hardware output."""
import argparse
import json
import pathlib
import platform
import sys

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=pathlib.Path)
    parser.add_argument('--output', type=pathlib.Path, default=pathlib.Path('read-log.json'))
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding='utf-8'))
        rows = data['fields']
        if not isinstance(rows, list):
            raise ValueError('fields必须是一列记录')
        result = {'mode':'dry_run','provenance':'synthetic',
                  'input_path':str(args.input.resolve()),'python':platform.python_version(),
                  'executable':sys.executable,'field_count':len(rows),'fields':rows}
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
        print(f'读入 {len(rows)} 个字段；日志：{args.output.resolve()}；无硬件输出')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f'REJECT: {exc}',file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
