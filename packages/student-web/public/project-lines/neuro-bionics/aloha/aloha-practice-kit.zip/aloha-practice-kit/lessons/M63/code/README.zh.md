# M63：逐维KL账单

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M63/code/kl_audit.py lessons/M63/code/synthetic.json M63-result.json
```

输入字段 mu 与 log_variance，均为批次×潜在维的二维数表；provenance/source_ref保留来源。输出每维、每样本和批次平均。fixture两样本KL为约1.30685281944和2，批次平均约1.65342640972。可直接读取M61/66保存的posterior.json；程序采用expm1减少接近零时相消误差。所有参数必须有限，方差溢出不应静默当作有效结果。不能把KL接近零叫任务成功。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
