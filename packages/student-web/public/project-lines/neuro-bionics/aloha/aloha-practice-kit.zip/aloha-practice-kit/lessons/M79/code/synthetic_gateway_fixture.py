"""Software fixtures only: these booleans/events are NOT observed robot behavior."""
def synthetic_gateway(run):
    if run['source_kind']!='synthetic':raise ValueError('This fixture only accepts explicit synthetic runs')
    values={'synthetic_test_joint':0.0}
    return {
        'schema':'aloha.gateway-log.v1','source_kind':'synthetic_fixture',
        'run_id':run['run_id'],'attempt_id':run['trial_id'],
        'policy_artifact_sha256':run['observed_versions']['model_manifest_sha256'],
        'hardware_manifest_sha256':run['observed_versions']['hardware_manifest_sha256'],
        'hardware_revision':'SYNTHETIC SOFTWARE FIXTURE — NO HARDWARE',
        'events':[
            {'event':'manual_arm','stop_test_reference':'SYNTHETIC only','configuration_reference':'SYNTHETIC only'},
            {'event':'command','source':'policy','sequence':0,'monotonic_send_end':1.0,
             'requested':dict(values),'observed_state':dict(values),'gateway_target':dict(values),'driver_returned_sent_action':dict(values)},
            {'event':'latched','reason':'SYNTHETIC end','stop_callback_returned':True}],
        'termination':{'reason':'SYNTHETIC end','gateway_event_index':2,'supervisor_observed_stop':True,
                       'note':'Synthetic booleans exercise schema checks only. No person observed a robot stopping.'}}
