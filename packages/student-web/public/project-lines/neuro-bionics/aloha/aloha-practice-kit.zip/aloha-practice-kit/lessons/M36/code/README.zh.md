# M36 · 固定回放命令与证据

固定 LeRobot 提交：`b64fe1ed9f11eeac53ee821356d2797601701054`。命令生成器只用标准库，完全不导入 LeRobot 或打开设备。实际官方 replay 命令会使双臂动作，由导师完成现场审查后手动执行。

本节承接 M22 的真实停止检查、M26 的空间间隙和 M28 的已验收工位。它不是 M72 的策略首次上电：这里使用早期开发阶段已确认低速、轻物体、固定工位的本人示教回合，测试场景保持封存。缺任何现场证据时先补前作，不把模拟图替代真实基线。

保留实践包 `act_commands.py`、`course_cli.py`、`lessons/M33/code` 和本目录的相对位置。在包根目录准备已填写的 `student-act-config.json`、M33原始 `splits.json` 和本节review模板副本。注意split清单不是split-audit报告，因为本脚本会重新审计完整关联身份。

```sh
python3 lessons/M36/code/replay_command.py student-act-config.json lessons/M33/code/splits.json work/replay-review.json --out work/replay-command.json
```

输出包含待审阅 argv、shell_preview、固定提交、来源和实际使用的data fps。脚本只接受train回合，并使用M33在原始未重排库中的native_episode_index；不能直接拿train分片的新索引去查原始库。review中的native_dataset_root须对应配置原始根目录，导师还要核对source_dataset身份确实指向它。metadata只证明文件合同一致，不证明学生填的现场证据真实。

导师在已安装固定版本的环境先检查 `lerobot-replay --help`，逐项核对源码中的nested `left_arm_config` / `right_arm_config` 参数，不能照源码开头旧示例的left_arm_port猜参数。原生库必须已经完整在本地，预览命令设HF_HUB_OFFLINE与HF_DATASETS_OFFLINE为1，禁止为缺数据悄悄联网补录。这里读取原始带图像的LeRobot库，不把M35教学JSONL直接喂给replay。

**实际执行前**：核对首帧目标与当前姿态、左右字段和角度单位；复用导师已实测的每关节相对限制与断电停止；确认所有开发摆放都在M26允许区域，不为制造失败把物体移进碰撞范围。源码没有首目标平滑过渡或自动回到初始姿态。导师通过原来已经验收的方式就位，不用本节脚本强跳到首帧。

**速度边界**：本提交使用数据集的fps调度。配置虽然定义dataset.fps，但replay正文不使用这个覆盖值，所以命令生成器不提供“调低fps就安全变慢”的假功能。选择前期已低速验证的录制回合；需要更慢则回到受控示教重新采集，不改变原件。相对目标限制不是速度保证，也可能令实际轨迹偏离记录目标。

replay按action字段名恢复固定目标，默认动作处理器是Identity；每帧仍读观察，驱动仍使用当前位置做相对限制，舵机也有底层反馈。但它不根据新的物体图像选择任务动作。本命令刻意不启用机器人相机，另用独立连续录像保留证据。官方replay不记录本次回合，且丢弃send_action返回值，所以不能把原始action文件说成本次实测轨迹或实际发送日志。

每个预先列出的开发条件记录：trial_id、源回合、软件/工位版本、摆放坐标与单位、开始/结束、观察到的失败位置、是否介入、连续视频地址。观察顺序应包含完整就位—动作—结果，不只截成功一瞬。没执行的条件写incomplete；执行中因风险停止则保留aborted及原因。保持开发试次与最终20次独立检验分开。

单元测试全用临时synthetic元数据，不是实机回放：

```sh
python3 -m unittest discover -s lessons/M36/code -p 'test_*.py' -v
```
