#!/usr/bin/env python3
"""Run actual ACT eval information-path checks; no motor execution."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"M66"/"code"))
from act_step import dependencies,validate_batch,isolated_policy,installed_policy,CAMERAS,STATE,ACTION,sha


def audit(batch_path,manifest_path,output,isolated_source=None,checkout=None):
    np,torch=dependencies();torch.set_num_threads(1)
    arrays=dict(np.load(batch_path,allow_pickle=False));manifest=json.loads(Path(manifest_path).read_text())
    _,k=validate_batch(arrays,manifest);torch.manual_seed(31)
    policy,backend=isolated_policy(isolated_source,k) if isolated_source else installed_policy(k,checkout)
    observed={key:torch.from_numpy(arrays[key].copy()).float() for key in [STATE,*CAMERAS]}
    calls=[];latents=[];model_calls=[]
    hs=[policy.model.vae_encoder.register_forward_hook(lambda *args:calls.append(1)),
        policy.model.encoder_latent_input_proj.register_forward_pre_hook(lambda mod,args:latents.append(args[0].detach().clone())),
        policy.model.register_forward_hook(lambda *args:model_calls.append(1))]
    clean=policy.predict_action_chunk(observed)
    poison={**observed,ACTION:torch.full_like(torch.from_numpy(arrays[ACTION]),999),
        "action_is_pad":~torch.from_numpy(arrays["action_is_pad"])}
    dirty=policy.predict_action_chunk(poison)
    equal=torch.equal(clean,dirty);zero=all(torch.count_nonzero(x)==0 for x in latents)
    # Separate queue test: current helper config uses one action per prediction.
    policy.reset();policy.select_action(observed);policy.select_action(observed)
    for h in hs:h.remove()
    if calls or not equal or not zero or len(latents)!=4 or len(model_calls)!=4:
        raise RuntimeError("evaluation information contract failed: expected four actual zero-latent model calls")
    result={"provenance":manifest["provenance"],"source_ref":manifest["source_ref"],
        "input_sha256":sha(batch_path),"backend":backend,"observed_keys":list(observed),
        "future_label_poison_max_abs_difference":float((clean-dirty).abs().max()),"posterior_calls":len(calls),
        "all_latent_inputs_zero":bool(zero),"policy_model_calls":len(model_calls),"n_action_steps":1,
        "pass":True,"scope":"information-path and tiny-model execution only; no tested robot performance or deployment permission"}
    with Path(output).open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("batch");p.add_argument("manifest");p.add_argument("output")
    g=p.add_mutually_exclusive_group(required=True);g.add_argument("--isolated-source");g.add_argument("--checkout")
    a=p.parse_args();print(json.dumps(audit(a.batch,a.manifest,a.output,a.isolated_source,a.checkout),ensure_ascii=False,indent=2))
