import copy
import json
from pathlib import Path
import unittest
from inspect_frame import inspect

class FrameTests(unittest.TestCase):
    def setUp(self):
        self.data=json.loads((Path(__file__).parent/'sample.synthetic.json').read_text())
    def test_valid_fixture_does_not_claim_hardware_truth(self):
        result=inspect(self.data)
        self.assertEqual(result['shape'],[12])
        self.assertFalse(result['physical_authenticity_verified'])
        self.assertFalse(result['exposure_timing_known'])
    def test_equal_dimensions_with_wrong_order_rejected(self):
        self.data['field_order'].reverse()
        with self.assertRaises(ValueError): inspect(self.data)
    def test_missing_layer_and_nan_rejected(self):
        for change in ('missing','nan'):
            data=copy.deepcopy(self.data)
            if change=='missing': del data['observed_state']['left_gripper.pos']
            else: data['observed_state']['left_gripper.pos']=float('nan')
            with self.assertRaises(ValueError): inspect(data)
    def test_driver_return_not_silently_substituted_as_native_label(self):
        self.data['native_action'][0]=22
        with self.assertRaises(ValueError): inspect(self.data)
    def test_timestamp_units_and_attempt_contracts(self):
        for field,value in [('native_timestamp_s',100.1),('attempt_id',''),('units',['degree']*12)]:
            data=copy.deepcopy(self.data);data[field]=value
            with self.assertRaises(ValueError): inspect(data)
    def test_bad_container_types_get_clear_validation_error(self):
        with self.assertRaises(ValueError):inspect([])
        for field,value in [('provenance',None),('native_action',{}),('observed_state',[]),('attempt_id',True)]:
            data=copy.deepcopy(self.data);data[field]=value
            with self.assertRaises(ValueError):inspect(data)
if __name__=='__main__': unittest.main()
