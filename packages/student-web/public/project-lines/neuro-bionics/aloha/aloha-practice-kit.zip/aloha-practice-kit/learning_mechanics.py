"""Small, inspectable mathematics for the course; never connects to a robot.

All built-in examples are synthetic. These mechanisms are not a replacement for
the pinned LeRobot ACT implementation or for training on one's own demonstrations.
"""
import argparse
import json
import math
from pathlib import Path


def finite(values):
    if not all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in values):
        raise ValueError('Expected finite numeric values')


def normalize_fit(rows):
    if not rows or not rows[0]:
        raise ValueError('Empty training rows')
    width = len(rows[0])
    if any(len(r) != width for r in rows):
        raise ValueError('Inconsistent feature width')
    finite([x for row in rows for x in row])
    mean = [sum(row[j] for row in rows) / len(rows) for j in range(width)]
    std = [math.sqrt(sum((r[j]-mean[j])**2 for r in rows)/len(rows)) for j in range(width)]
    # Preserve the raw zero variance and document the constant-channel convention.
    scale = [s if s > 1e-8 else 1.0 for s in std]
    return {'mean': mean, 'std': std, 'scale': scale, 'fit_row_count': len(rows)}


def normalize_apply(rows, stats):
    if any(len(row) != len(stats['mean']) for row in rows):
        raise ValueError('Inconsistent feature width')
    finite([x for row in rows for x in row])
    return [[(x-m)/s for x,m,s in zip(row,stats['mean'],stats['scale'])] for row in rows]


def mlp_forward(params, row):
    """Two inputs, two tanh hidden units, one scalar output; nine parameters."""
    if len(params) != 9 or len(row) != 2:
        raise ValueError('Expected 9 parameters and 2 input features')
    finite(params+row)
    hidden = [math.tanh(params[0]*row[0]+params[1]*row[1]+params[4]),
              math.tanh(params[2]*row[0]+params[3]*row[1]+params[5])]
    return params[6]*hidden[0]+params[7]*hidden[1]+params[8], hidden


def mlp_loss_gradient(params, rows, labels):
    if not rows or len(rows) != len(labels):
        raise ValueError('Rows and labels must be nonempty and aligned')
    finite(labels)
    gradient = [0.0]*9
    loss = 0.0
    traces = []
    for row,label in zip(rows,labels):
        predicted,hidden = mlp_forward(params,row)
        error = predicted-label
        loss += error*error/len(rows)
        derivative = 2*error/len(rows)
        dh = [derivative*params[6+j]*(1-hidden[j]**2) for j in range(2)]
        gradient[0] += dh[0]*row[0]
        gradient[1] += dh[0]*row[1]
        gradient[2] += dh[1]*row[0]
        gradient[3] += dh[1]*row[1]
        gradient[4] += dh[0]
        gradient[5] += dh[1]
        gradient[6] += derivative*hidden[0]
        gradient[7] += derivative*hidden[1]
        gradient[8] += derivative
        traces.append({'input':row,'hidden':hidden,'predicted':predicted,'label':label,'error':error})
    return {'loss':loss,'gradient':gradient,'traces':traces}


def numerical_gradient(fn, params, epsilon=1e-5):
    result = []
    for i in range(len(params)):
        plus,minus = params.copy(),params.copy()
        plus[i] += epsilon
        minus[i] -= epsilon
        result.append((fn(plus)-fn(minus))/(2*epsilon))
    return result


def adamw_step(params, gradient, state=None, lr=.01, beta1=.9, beta2=.999, decay=.01, epsilon=1e-8):
    if len(params) != len(gradient) or not 0 <= beta1 < 1 or not 0 <= beta2 < 1 or lr <= 0:
        raise ValueError('Invalid AdamW shapes or settings')
    finite(params+gradient+[lr,beta1,beta2,decay,epsilon])
    state = state or {'step':0,'m':[0.0]*len(params),'v':[0.0]*len(params)}
    if len(state['m']) != len(params) or len(state['v']) != len(params):
        raise ValueError('Optimizer state has different parameter shape')
    step = state['step']+1
    moments = [beta1*m+(1-beta1)*g for m,g in zip(state['m'],gradient)]
    squares = [beta2*v+(1-beta2)*g*g for v,g in zip(state['v'],gradient)]
    updated = [p*(1-lr*decay)-lr*(m/(1-beta1**step))/(math.sqrt(v/(1-beta2**step))+epsilon)
               for p,m,v in zip(params,moments,squares)]
    return updated, {'step':step,'m':moments,'v':squares}


def attention(query, keys, values):
    """One query / one head, no learned projections; explicit softmax and Q derivative."""
    if not query or not keys or len(keys) != len(values) or any(len(k)!=len(query) for k in keys):
        raise ValueError('Attention dimensions disagree')
    if not values[0] or any(len(v)!=len(values[0]) for v in values):
        raise ValueError('Value dimensions disagree')
    finite(query+[x for k in keys for x in k]+[x for v in values for x in v])
    scale = math.sqrt(len(query))
    scores = [sum(q*k for q,k in zip(query,key))/scale for key in keys]
    exponentials = [math.exp(s-max(scores)) for s in scores]
    weights = [x/sum(exponentials) for x in exponentials]
    output = [sum(w*v[j] for w,v in zip(weights,values)) for j in range(len(values[0]))]
    # d output[j] / d query[d] = sum_i w_i(v_ij-output_j)k_id / sqrt(dim).
    jacobian = [[sum(w*(v[j]-output[j])*k[d]/scale for w,v,k in zip(weights,values,keys))
                 for d in range(len(query))] for j in range(len(output))]
    return {'scores':scores,'weights':weights,'output':output,'query_jacobian':jacobian}


def gaussian_kl(mean, log_variance):
    if not mean or len(mean)!=len(log_variance):
        raise ValueError('Mean and log variance dimensions disagree')
    finite(mean+log_variance)
    variance = [math.exp(v) for v in log_variance]
    per_dimension = [.5*(m*m+v-1-lv) for m,v,lv in zip(mean,variance,log_variance)]
    return {'per_dimension':per_dimension,'sum':sum(per_dimension),
            'd_mean':mean.copy(),'d_log_variance':[.5*(v-1) for v in variance]}


def reparameterize(mean, log_variance, noise):
    if len(mean)!=len(log_variance) or len(mean)!=len(noise):
        raise ValueError('Latent arrays disagree')
    finite(mean+log_variance+noise)
    scale = [math.exp(.5*lv) for lv in log_variance]
    return {'sample':[m+s*e for m,s,e in zip(mean,scale,noise)],
            'd_mean':[1.0]*len(mean),'d_log_variance':[.5*s*e for s,e in zip(scale,noise)]}


def masked_l1(predicted, target, is_pad):
    """One episode chunk. Same valid-action-element denominator as the pinned ACT source."""
    if not target or len(predicted)!=len(target) or len(target)!=len(is_pad):
        raise ValueError('Chunk lengths disagree')
    width = len(target[0])
    if not width or any(len(row)!=width for row in predicted+target) or any(type(x) is not bool for x in is_pad):
        raise ValueError('Invalid action width or pad mask')
    finite([x for row in predicted+target for x in row])
    numerator = sum(abs(p-t) for pp,tt,pad in zip(predicted,target,is_pad) if not pad for p,t in zip(pp,tt))
    denominator = sum(not pad for pad in is_pad)*width
    return {'numerator':numerator,'valid_action_elements':denominator,'loss':numerator/max(1,denominator)}


def make_chunk(episode, start, length):
    if not episode or type(start) is not int or not 0 <= start < len(episode) or type(length) is not int or length < 1:
        raise ValueError('Invalid within-episode chunk request')
    rows = [row.copy() for row in episode[start:start+length]]
    indices = list(range(start,start+len(rows)))
    padding = [False]*len(rows)
    while len(rows)<length:
        rows.append(episode[-1].copy())
        indices.append(None)
        padding.append(True)
    return {'actions':rows,'source_indices':indices,'is_pad':padding}


def demo():
    params = [.2,-.1,.3,.4,.05,-.02,.6,-.5,.1]
    rows,labels = [[1.,2.],[-1.,.5]], [.4,-.2]
    first = mlp_loss_gradient(params,rows,labels)
    numerical = numerical_gradient(lambda p:mlp_loss_gradient(p,rows,labels)['loss'],params)
    updated,state = adamw_step(params,first['gradient'])
    return {'provenance':'synthetic teaching example; not student demonstrations',
      'hardware_executed':False,'mlp':first,'numerical_gradient':numerical,
      'max_gradient_error':max(abs(a-b) for a,b in zip(first['gradient'],numerical)),
      'adamw':{'params':updated,'state':state,'new_loss':mlp_loss_gradient(updated,rows,labels)['loss']},
      'attention':attention([1.,0.],[[1.,0.],[0.,1.]],[[2.,4.],[6.,8.]]),
      'kl':gaussian_kl([0.,1.],[0.,math.log(4.)]),
      'sample':reparameterize([0.,1.],[0.,math.log(4.)],[.5,-1.]),
      'chunk':make_chunk([[1.,2.],[3.,4.]],1,3),
      'masked_l1':masked_l1([[2.,4.],[99.,99.]],[[1.,2.],[3.,4.]],[False,True])}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--demo',action='store_true')
    parser.add_argument('--mlp-data',type=Path,help='JSON with params, rows, labels and provenance')
    args=parser.parse_args()
    if args.demo:
        result=demo()
    elif args.mlp_data:
        data=json.loads(args.mlp_data.read_text())
        if not data.get('provenance'):
            parser.error('Input must state provenance')
        result=mlp_loss_gradient(data['params'],data['rows'],data['labels'])
        result['provenance']=data['provenance']
    else:
        parser.error('Use --demo or --mlp-data PATH')
    print(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
