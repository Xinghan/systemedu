"""Export explicit native LeRobot state/action columns into a teaching-only JSONL view.
Run within the fully installed pinned LeRobot environment. No device or upload call.
"""
import argparse,hashlib,json,os
from pathlib import Path
from data_package import validate_rows,SEMANTICS,FIELDS,UNITS
PIN='b64fe1ed9f11eeac53ee821356d2797601701054'
def as_list(value):return value.detach().cpu().tolist() if hasattr(value,'detach') else list(value)
def scalar(value):return int(value.item()) if hasattr(value,'item') else int(value)
def extract(dataset,contract):
 order=contract['joint_names']
 if order!=FIELDS:raise ValueError('joint_names must follow the fixed course left-then-right joint order')
 for key in ('observation.state','action'):
  names=dataset.features[key].get('names')
  if not isinstance(names,list) or len(names)!=12 or set(names)!=set(order):raise ValueError('feature names differ: '+key)
 if contract.get('action_semantics')!=SEMANTICS:raise ValueError('inspect pinned recording contract before export')
 mapping=contract['episodes'];rows=[]
 for i in range(len(dataset)):
  native=dataset[i];index=str(scalar(native['episode_index']))
  if index not in mapping:raise ValueError('unmapped native episode '+index)
  info=mapping[index];role=info['split']
  if role not in ('train','validation'):raise ValueError('sealed test must not be loaded by this teaching export')
  entry=dict(episode_id=info['episode_id'],attempt_id=info['attempt_id'],split=role,frame_index=scalar(native['frame_index']),action_semantics=SEMANTICS)
  for native_key,key in [('observation.state','observation_state'),('action','action')]:
   values=as_list(native[native_key]);names=dataset.features[native_key]['names'];entry[key]=[float(values[names.index(name)]) for name in order]
  rows.append(entry)
 errors=validate_rows(rows)
 if errors:raise ValueError('; '.join(errors))
 return rows

def write_new(out,rows,contract):
 out=Path(out)
 if out.exists():raise ValueError('output must be a new directory; never overwrite the original dataset')
 errors=validate_rows(rows)
 if errors:raise ValueError('; '.join(errors))
 if contract.get('joint_names')!=FIELDS:raise ValueError('fixed joint order required')
 for key in ('hardware_revision','dataset_source','split_policy','joint_names'):
  if not contract.get(key):raise ValueError('missing '+key)
 raw=('\n'.join(json.dumps(r,ensure_ascii=False,allow_nan=False) for r in rows)+'\n').encode()
 manifest={'schema':'aloha.teaching-frames.v1','provenance':contract['provenance'],'hardware_revision':contract['hardware_revision'],'dataset_source':contract['dataset_source'],'split_policy':contract['split_policy'],'frame_count':len(rows),'sha256':hashlib.sha256(raw).hexdigest(),'joint_names':contract['joint_names'],'joint_units':UNITS,'lerobot_revision':PIN,'purpose':'low-dimensional MLP mechanism practice; ACT still uses the original image-bearing LeRobot dataset','image_pixels_exported':False}
 (out/'data').mkdir(parents=True);(out/'data/frames.jsonl').write_bytes(raw);(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 return manifest
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--repo-id',required=True);p.add_argument('--contract',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.root).resolve();contract=json.loads(Path(a.contract).read_text())
 if not (root/'meta/info.json').is_file():raise SystemExit('local native dataset missing; no download attempted')
 if contract.get('provenance')!='learner_recorded':raise SystemExit('native export requires your reviewed learner_recorded provenance')
 if any(e.get('split') not in ('train','validation') for e in contract['episodes'].values()):raise SystemExit('do not request sealed test episodes')
 os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1'
 from lerobot.datasets.lerobot_dataset import LeRobotDataset
 dataset=LeRobotDataset(a.repo_id,root=root,episodes=[int(x) for x in contract['episodes']],download_videos=False)
 rows=extract(dataset,contract);print(json.dumps(write_new(a.out,rows,contract),ensure_ascii=False,indent=2))
