# 保留真实执行网关事件：aloha.gateway-log.v1

唯一生产者是 M72 现场集成，M75 只记录书挡，不发送命令。唯一验证实现为 lessons/M74/code/gateway_log.py 的 validate_gateway_log(path, run)。M74 主验收与 M80/M81 独立用途都复用它。日志为一个 JSON 对象；不用无法绑定元数据的裸 JSONL 冒充本合同。

必填字段：

- schema: `aloha.gateway-log.v1`
- run_id: M75 start_run 返回 start.json 内的 run_id；attempt_id: 同文件的 trial_id。
- policy_artifact_sha256: 同文件 observed_versions.model_manifest_sha256，即覆盖本次权重、processor 等文件的模型清单 SHA，不是另手填一个权重 SHA。
- hardware_manifest_sha256: 同文件 observed_versions.hardware_manifest_sha256。
- hardware_revision: 人可读的本工位版本名称，非空；身份绑定以 SHA 为准。
- source_kind: learner_policy_execution（真实学生模型执行）或 synthetic_fixture（软件夹具），与 start.json 的 learner_recording / synthetic 一一对应。
- events: `ExecutionGateway.events` 的完整原始顺序数组，不重命名 requested、observed_state、gateway_target、driver_returned_sent_action 或 monotonic_send_end。
- termination: {reason: 非空说明, gateway_event_index: 最后一个原生 latched 的从零起索引, supervisor_observed_stop: 人实际观察填写的布尔值, note: 具体现场说明}。
- 可选 clock: {monotonic_scope: one_process, wall_time_source: host_clock, wall_started_at: ISO 时间}。单调时间不能跨进程比较；主机元数据不是相机曝光或硬件实测时间。

最小完整序列为 manual_arm → 一条以上 source=policy 的 command → 最后 latched。每次只一次 manual_arm；下一次人工重新使能形成另一个记录，不能掩盖介入。本版只接受网关原生三种事件。command 的 sequence 严格递增，monotonic_send_end 递增，四组关节字段同名、非空且全部有限。manual_arm 保存 stop_test_reference 和 configuration_reference。实际消费同一进程网关，不从视频猜造 command。

正常结束同样需结束动力命令入口：现场集成在 finally 中显式调用 gateway.trip('end of run')，捕获它必然抛出的 RejectedCommand，保留原生 latched 及 stop_callback_returned。现场教师独立填写 supervisor_observed_stop，代码不能自动置 true。callback 返回不是机器人已停住的证据。失败的 stop 可保留 false 与 stop_error；status=completed 必须有人工观察的停止和成功返回的回调，失败记录不强迫伪填 true。

M75 close_run 总会尽可能保留已发生的尝试。若没有实际 policy command（例如启用前被拒绝），仍保存失败原因与原日志，但该行不算证据完整的实机尝试，审核明确 incomplete；不得编造命令填齐。遇到未完成行，应保留并说明整轮未完成，不能把编号复用为新成功。

SHA 只关联字节。本工具不能鉴别视频内容、观察者诚实、实际模型是否对应称述，也不能证明硬件停止。synthetic 永不性能 accepted；软件单元测试可以显式以夹具测试“声明为真实”的条件分支，但不能把该分支的返回值写作真实验收。
