#!/usr/bin/env python3
"""Run offline examples in a new folder. Only runs this package's Python tools."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True);p.add_argument('--check-expected',action='store_true');a=p.parse_args()
    root=Path(__file__).parent;out=Path(a.output).resolve()
    if out.exists():p.error('Output directory already exists; choose a new name')
    out.mkdir(parents=True)
    cases=[('fields','state.json'),('sampling','sampling.json'),('limits','limits.json'),('sync','sync.json'),
           ('toy-train','toy_train.json'),('ensemble','chunks.json'),('evaluate','evaluation.json')]
    commands=[(name,[str(root/'course_cli.py'),name,str(root/'examples'/file)]) for name,file in cases]
    commands.append(('split',[str(root/'course_cli.py'),'split',str(root/'examples'/'episode_index.json'),
                             '--source-dir',str(root/'examples'/'episodes'),'--output-dir',str(out/'split')]))
    for stage in ('record','split-lerobot','train','rollout'):
        cmd=[str(root/'act_commands.py'),stage,str(root/'examples'/'act_config.synthetic.json')]
        if stage in ('train','split-lerobot'):cmd+=['--split',str(out/'split'/'manifest.json')]
        commands.append(('act-'+stage,cmd))
    commands.append(('upstream-check',[str(root/'verify_upstream.py')]))
    rows=[]
    for name,cmd in commands:
        result=subprocess.run([sys.executable]+cmd,capture_output=True,text=True,check=True)
        obj=json.loads(result.stdout);(out/(name+'.json')).write_text(result.stdout)
        if a.check_expected:
            expected=json.loads((root/'expected'/(name+'.json')).read_text())
            if expected!=obj:raise AssertionError(f'{name} differs from expected result')
        rows.append({'example':name,'exit_code':result.returncode,'expected_match':True if a.check_expected else None})
    (out/'run-report.json').write_text(json.dumps({'scope':'Offline synthetic examples only','python':sys.version,'results':rows},indent=2)+'\n')
    print(json.dumps({'output':str(out),'examples_passed':len(rows),'hardware_executed':False},indent=2))
if __name__=='__main__':main()
