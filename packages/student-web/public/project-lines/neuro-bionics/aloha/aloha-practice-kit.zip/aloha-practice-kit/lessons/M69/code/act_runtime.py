"""One pinned ACT + saved-processors loader for M69/M70 and later offline control.

This module has no hardware or network call. It refuses action labels at the
inference boundary. Loader integration requires the actual fixed LeRobot install.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M67'/'code'))
from course_contract import *

class Runtime:
 def __init__(self,policy,preprocessor,postprocessor,manifest_sha256):
  self.policy=policy;self.pre=preprocessor;self.post=postprocessor;self.model_manifest_sha256=manifest_sha256;self.calls=0
 def reset(self):
  self.policy.reset()
  for processor in (self.pre,self.post):
   if hasattr(processor,'reset'):processor.reset()
 def _prepare(self,observation):
  import torch
  required={'observation.state',*CAMERAS}
  if not isinstance(observation,dict)or set(observation)!=required:raise ValueError('only current state and two images allowed; no action, pad or future labels')
  batch={}
  for key,v in observation.items():
   if not isinstance(v,torch.Tensor) or not v.is_floating_point()or not torch.isfinite(v).all():raise ValueError('finite floating tensor required: '+key)
   expected=tuple(self.policy.config.input_features[key].shape)
   if tuple(v.shape)==expected:v=v.unsqueeze(0)
   if tuple(v.shape)!=(1,*expected):raise ValueError('single current observation shape mismatch: '+key)
   if key in CAMERAS and (v.min()<0 or v.max()>1):raise ValueError('raw RGB [0,1] required; do not normalize twice')
   batch[key]=v.clone()
  return self.pre(batch)
 def predict_chunk(self,observation):
  import torch
  batch=self._prepare(observation);self.policy.eval()
  with torch.inference_mode():out=self.post(self.policy.predict_action_chunk(batch))
  self.calls+=1
  if tuple(out.shape)!=(1,self.policy.config.chunk_size,12)or not torch.isfinite(out).all():raise ValueError('invalid denormalized ACT chunk')
  return out[0].detach().cpu()
 def profile_action(self,observation,clock=None):
  """Time the same selection path; inference_s can be queue-only on cached steps."""
  import torch,time
  clock=clock or time.perf_counter
  device=next(self.policy.parameters()).device
  def sync():
   if device.type=='cuda':torch.cuda.synchronize(device)
  forwards=[];hook=self.policy.model.register_forward_hook(lambda *args:forwards.append(1))
  try:
   sync();t0=clock();batch=self._prepare(observation);sync();t1=clock();self.policy.eval()
   with torch.inference_mode():
    normalized=self.policy.select_action(batch);sync();t2=clock();out=self.post(normalized);sync();t3=clock()
  finally:hook.remove()
  self.calls+=1
  if tuple(out.shape)!=(1,12)or not torch.isfinite(out).all():raise ValueError('invalid denormalized ACT action')
  times={'preprocess_s':t1-t0,'inference_s':t2-t1,'postprocess_s':t3-t2,'total_s':t3-t0,'policy_model_calls':len(forwards),'cuda_synchronized':device.type=='cuda'}
  if any(not finite(times[k])or times[k]<0 for k in ('preprocess_s','inference_s','postprocess_s','total_s')):raise ValueError('profile clock must be finite monotonic')
  return out[0].detach().cpu(),times
 def select_action(self,observation):
  return self.profile_action(observation)[0]

def load_runtime(pretrained_dir,checkout,device='cpu',*,model_manifest=None,artifact_root=None):
 if device not in ('cpu','cuda'):raise ValueError('explicit tested device family required')
 pretrained=local(pretrained_dir);manifest_path=local(model_manifest or pretrained.parent/'model_manifest.json')
 root=local(artifact_root or manifest_path.parent.parent);manifest=read(manifest_path)
 if manifest.get('schema')!='aloha.act-model-manifest.v1' or manifest.get('lerobot_revision')!=REVISION:raise ValueError('frozen ACT manifest required')
 if manifest.get('action_fields')!=FIELDS or manifest.get('action_units')!=UNITS:raise ValueError('joint fields/units mismatch')
 if manifest.get('action_semantics')!='teleop_action_processor target':raise ValueError('wrong predicted-action meaning')
 if (root/manifest['pretrained_dir']).resolve()!=pretrained:raise ValueError('manifest points to another pretrained directory')
 verify_inventory(root,manifest['files']);check_checkout(checkout)
 import torch
 from lerobot.policies.act.configuration_act import ACTConfig
 from lerobot.policies.act.modeling_act import ACTPolicy
 from lerobot.policies.factory import make_pre_post_processors
 if device=='cuda'and not torch.cuda.is_available():raise ValueError('CUDA unavailable')
 cfg=ACTConfig.from_pretrained(pretrained,local_files_only=True)
 if set(cfg.input_features)!={'observation.state',*CAMERAS}or set(cfg.output_features)!={'action'}:raise ValueError('unexpected model inputs/outputs')
 if tuple(cfg.input_features['observation.state'].shape)!=(12,)or tuple(cfg.output_features['action'].shape)!=(12,):raise ValueError('model not twelve-channel course ACT')
 cfg.device=device
 # The local trained state supplies ALL weights. Avoid a torchvision network fetch
 # during constructor initialization; strict=True catches missing trained weights.
 cfg.pretrained_backbone_weights=None
 policy=ACTPolicy.from_pretrained(pretrained,config=cfg,local_files_only=True,strict=True)
 policy.to(device).eval()
 pre,post=make_pre_post_processors(cfg,pretrained_path=str(pretrained),preprocessor_overrides={'device_processor':{'device':device},'normalizer_processor':{'device':device}})
 runtime=Runtime(policy,pre,post,sha(manifest_path));runtime.reset();return runtime
