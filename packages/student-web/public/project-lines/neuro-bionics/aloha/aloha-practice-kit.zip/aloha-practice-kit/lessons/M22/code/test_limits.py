"""Offline gateway tests. No robot import or physical stop claim."""
import argparse,sys,unittest
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--kit',type=Path,required=True);args,rest=p.parse_known_args()
sys.path.insert(0,str(args.kit))
from execution_gateway import Bound,ExecutionGateway,RejectedCommand

class Limits(unittest.TestCase):
    def make(self):
        sent,stops=[],[]
        now=[1.0]
        def send(v): sent.append(dict(v));return dict(v)
        def stop(): stops.append('fake stop requested')
        g=ExecutionGateway({'joint':Bound(10,40,2,10)},.5,send,stop,clock=lambda:now[0],required_cameras=('cam',))
        g.arm_after_manual_checks(stop_test_reference='synthetic fake callback test',configuration_reference='synthetic fixture',clear_workspace=True)
        return g,sent,stops,now
    def submit(self,g,target=30,measured=20,sequence=0):
        return g.submit({'joint':target},{'joint':measured},sequence=sequence,observation_arrival_s=.9,camera_arrival_s={'cam':.9},source='teleop',communication_ok=True)
    def test_clip_keeps_intent(self):
        g,s,st,n=self.make();r=self.submit(g)
        self.assertEqual(r['requested']['joint'],30);self.assertEqual(r['gateway_target']['joint'],22)
    def test_invalid_latches_and_does_not_send(self):
        g,s,st,n=self.make()
        with self.assertRaises(RejectedCommand):self.submit(g,float('nan'))
        with self.assertRaises(RejectedCommand):self.submit(g,21)
        self.assertEqual(len(s),0);self.assertEqual(len(st),1)
    def test_bounds(self):
        for request,present,expected in [(10,11,10),(40,39,40),(9,11,10),(41,39,40)]:
            g,s,st,n=self.make();self.assertEqual(self.submit(g,request,present)['gateway_target']['joint'],expected)

if __name__=='__main__':unittest.main(argv=[sys.argv[0],*rest])
