#!/usr/bin/env python3
"""Fit only training episodes; preserve raw population standard deviation and reversible scales."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M35/code'))
from data_package import load

JOINTS=('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')
FIELDS=[f'{side}_{joint}.pos' for side in ('left','right') for joint in JOINTS]
UNITS=['degree']*5+['normalized_0_100']+['degree']*5+['normalized_0_100']

def read_package(folder,split='train',allow_synthetic=False):
    manifest,rows=load(folder,split,allow_synthetic)
    if manifest.get('joint_names')!=FIELDS or manifest.get('joint_units')!=UNITS:
        raise ValueError('Explicit left-five-rotations/gripper then right field and unit contract required')
    return manifest,rows

def statistics(values,threshold=1e-8):
    if not values:raise ValueError('Empty channel')
    mean=math.fsum(values)/len(values)
    variance=math.fsum((x-mean)**2 for x in values)/len(values)
    std=math.sqrt(variance)
    if not all(math.isfinite(v) for v in (mean,variance,std)):raise ValueError('Statistics overflow')
    return {'count':len(values),'mean':mean,'population_variance':variance,'raw_std':std,
            'scale':std if std>threshold else 1.0,'near_constant':std<=threshold,
            'scale_rule':'std if std>1e-8, otherwise 1; no clipping','threshold':threshold}

def forward(value,stats):return (value-stats['mean'])/stats['scale']
def inverse(value,stats):return value*stats['scale']+stats['mean']

def fit(folder,allow_synthetic=False):
    manifest,rows=read_package(folder,'train',allow_synthetic)
    stats={key:[statistics([r[key][j] for r in rows]) for j in range(12)] for key in ('observation_state','action')}
    error=max(abs(inverse(forward(r[key][j],stats[key][j]),stats[key][j])-r[key][j])
              for r in rows for key in stats for j in range(12))
    return {'schema':'aloha.normalization.v1','provenance':manifest['provenance'],'source_sha256':manifest['sha256'],
            'hardware_revision':manifest['hardware_revision'],'dataset_source':manifest['dataset_source'],
            'split_policy':manifest['split_policy'],'fitted_split':'train',
            'fitted_episode_ids':sorted({r['episode_id'] for r in rows}),
            'fitted_attempt_ids':sorted({r['attempt_id'] for r in rows}),
            'row_weighting':'equal frame weight; longer episodes contribute more frames',
            'frame_count':len(rows),'joint_names':FIELDS,'joint_units':UNITS,'statistics':stats,
            'roundtrip_max_abs_error':error,'clip':None,'test_loaded_for_learning':False}

def verify_config(config,manifest,train_rows):
    if config.get('schema')!='aloha.normalization.v1' or config.get('fitted_split')!='train':
        raise ValueError('Expected train-only normalization v1')
    if config['source_sha256']!=manifest['sha256'] or config['provenance']!=manifest['provenance']:
        raise ValueError('Normalization and data provenance/hash differ')
    for key in ('hardware_revision','dataset_source','split_policy'):
        if config.get(key)!=manifest.get(key):raise ValueError('Normalization and manifest metadata differ: '+key)
    if config['joint_names']!=FIELDS or config['joint_units']!=UNITS or config.get('clip') is not None:
        raise ValueError('Wrong field/unit/clip contract')
    if config['fitted_episode_ids']!=sorted({r['episode_id'] for r in train_rows}):
        raise ValueError('Fitted episodes differ from the frozen training set')
    if config.get('fitted_attempt_ids')!=sorted({r['attempt_id'] for r in train_rows}):
        raise ValueError('Fitted attempts differ from the frozen training set')
    if type(config.get('frame_count')) is not int or config['frame_count']!=len(train_rows):
        raise ValueError('Fitted frame count differs from the frozen training set')
    for key in ('observation_state','action'):
        if len(config['statistics'][key])!=12:raise ValueError('Twelve statistics required')
        for j,s in enumerate(config['statistics'][key]):
            expected=statistics([r[key][j] for r in train_rows])
            if s!=expected:raise ValueError('Saved statistics differ from a direct train-only recomputation')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('--out',required=True)
    p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
    try:
        result=fit(a.package,a.allow_synthetic)
        with Path(a.out).open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
        print(json.dumps({'source':result['provenance'],'training_frames':result['frame_count'],
                          'fitted_episode_ids':result['fitted_episode_ids'],'roundtrip_error':result['roundtrip_max_abs_error']},ensure_ascii=False))
    except (OSError,ValueError,KeyError,TypeError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
