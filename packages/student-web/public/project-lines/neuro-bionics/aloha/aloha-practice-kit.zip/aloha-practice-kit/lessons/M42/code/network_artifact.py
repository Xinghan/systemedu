"""Save/load explicit ReLU parameters with source and shape contracts."""
import hashlib,json
from pathlib import Path
from relu_network import validate_network
from linear_baseline import identity

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(folder,model,view,status='initialized_untrained'):
    import torch
    from safetensors.torch import save_file
    ni,nh,no=validate_network(model)
    if ni!=12 or no!=12:raise ValueError('Course artifact must have 12 inputs and 12 outputs')
    p=Path(folder);p.mkdir(parents=True,exist_ok=False)
    tensors={k:torch.tensor(model[k],dtype=torch.float64) for k in ('w1','b1','w2','b2')}
    save_file(tensors,str(p/'model.safetensors'),metadata={'schema':'aloha.relu.v1','activation':'relu','provenance':view['provenance']})
    metadata={'schema':'aloha.relu.v1','activation':'relu','input_count':ni,'hidden_count':nh,'output_count':no,
              'shapes':{k:list(t.shape) for k,t in tensors.items()},'weight_axes':['output','input'],'dtype':'F64',
              'input_semantics':'observation_state','output_semantics':'teleop_processor_action',
              'source':identity(view),'checkpoint_sha256':sha(p/'model.safetensors'),'initialization':model.get('initialization'),
              'training_status':status,'hardware_command':False,'is_act_policy':False}
    (p/'model.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2,allow_nan=False)+'\n');return metadata

def load(folder,view):
    import torch
    from safetensors.torch import load_file
    p=Path(folder);meta=json.loads((p/'model.json').read_text())
    if not isinstance(meta,dict) or meta.get('schema')!='aloha.relu.v1' or meta.get('activation')!='relu':raise ValueError('Wrong network schema/activation')
    if meta.get('input_count')!=12 or meta.get('output_count')!=12 or type(meta.get('hidden_count')) is not int or not 1<=meta['hidden_count']<=128:raise ValueError('Wrong architecture sizes')
    if meta.get('weight_axes')!=['output','input'] or meta.get('input_semantics')!='observation_state' or meta.get('output_semantics')!='teleop_processor_action':raise ValueError('Axes or semantics differ')
    if meta.get('source')!=identity(view):raise ValueError('Model source/normalization differs')
    if meta.get('checkpoint_sha256')!=sha(p/'model.safetensors'):raise ValueError('Parameter digest differs')
    h=meta['hidden_count'];expected={'w1':[h,12],'b1':[h],'w2':[12,h],'b2':[12]}
    if meta.get('shapes')!=expected or meta.get('dtype')!='F64':raise ValueError('Shape/dtype metadata differs')
    tensors=load_file(str(p/'model.safetensors'),device='cpu')
    if set(tensors)!=set(expected) or any(list(tensors[k].shape)!=shape or tensors[k].dtype!=torch.float64 for k,shape in expected.items()):raise ValueError('Tensor names/shapes/dtypes differ')
    model={k:t.tolist() for k,t in tensors.items()};model.update({'activation':'relu','initialization':meta.get('initialization')});validate_network(model)
    return model,meta
