# 环境固定与真实版本记录

离线教学工具只用 Python 标准库，要求 Python ≥3.12。制作环境实际 Python 版本在 `verification/environment.json`。ACT、视频和机械臂驱动使用单独环境；不能把离线测试成功解释为 GPU 环境已验证。

固定源码：LeRobot `b64fe1ed9f11eeac53ee821356d2797601701054`。本包的 `research/lerobot/uv.lock` 是该 revision 的完整官方锁文件，包含包版本、索引与分发包摘要；不要只固定顶层 lerobot 包而让依赖浮动。锁内读取到 LeRobot 0.6.2、draccus 0.11.6、torch 2.11.0（Linux CUDA 条目为 2.11.0+cu128）、torchvision 0.26.0、torchcodec 0.11.1；这是锁文件信息，不是本机已装结果。

在学生选择的空目录中由导师安装 uv 及平台所需 FFmpeg，再执行：

```sh
git clone https://github.com/huggingface/lerobot.git
cd lerobot
git checkout --detach b64fe1ed9f11eeac53ee821356d2797601701054
git rev-parse HEAD
uv sync --frozen --python 3.12 --extra core_scripts --extra training --extra feetech
```

`--frozen` 使用该仓库的上游 uv.lock，不自动更新解算。各平台能否安装轮子、GPU 驱动是否匹配、USB/相机权限与 FFmpeg 动态库需在实际机器检查。本次已安装固定源码的完整训练环境，实际通过 CPU、小型合成原生图像数据的训练、恢复、验证选版和新进程重载，实际依赖记录见 `verification/root-full-lerobot.json` 及其证据索引。此次没有连接 USB 相机/电机，也没有验证 GPU、原生视频解码或所有硬件 extras；学生仍需验证自己的完整安装。如果该平台锁定依赖不可安装，保存原错误，选择受支持机器或记录新版本迁移与重新验证，不能悄悄改为 main。

激活此环境后核验：

```sh
source .venv/bin/activate
python -c "import torch; print(torch.__version__); print(torch.cuda.is_available())"
lerobot-record --help
lerobot-edit-dataset --help
lerobot-train --help
lerobot-rollout --help
```

这些 help/导入检查不等于实际读视频或驱动电机通过。在真实相机录制后，先确认一段本地视频能读、真实数据能取一批、checkpoint 能保存/加载，再正式训练。

用本包记录已安装版本（在 LeRobot 环境内调用本包的绝对路径）：

```sh
python /absolute/practice-kit/capture_environment.py /absolute/student-work/environment-v1.json
python -m pip freeze > /absolute/student-work/pip-freeze-v1.txt
ffmpeg -version > /absolute/student-work/ffmpeg-v1.txt
```

`capture_environment.py` 不收集环境变量或密钥；生成 Python、OS、架构、包版本及待填写的 GPU/校准字段。`pip freeze` 是已装依赖清单补充，不替代带摘要的 uv.lock。保存实际 `uv --version`、GPU/驱动、代码 HEAD、数据与 checkpoint 哈希。若环境不提供 pip，用 `uv pip freeze` 保存清单。

默认不登录 Hub，不开 WandB，不上传原始影像或权重。安装会下载公开软件依赖；选择 ImageNet 骨干也会下载公开权重，需在模型卡记录来源。此处不包含任何真实账号或凭据。
