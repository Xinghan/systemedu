#!/usr/bin/env python3
"""Train only on train frames; evaluate fixed full train/validation views and stop by a frozen rule."""
import argparse,csv,hashlib,importlib.metadata,json,platform,shutil,sys
from html import escape
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M44/code'))
from train_minibatch import training_run,dump,load_model,load_checkpoint,sha
from dataset_view import load_view,assert_compatible,physical_report
from linear_baseline import identity
from relu_network import forward
import optimizers
from selection import plan,decide,dropout_values

def evaluate(folder,train,validation):
 model,meta=load_model(folder,train);assert_compatible(train,validation);reports={}
 for view in (train,validation):
  predictions=[forward(r['x'],model)['prediction'] for r in view['rows']]
  reports[view['split']]=physical_report(view,predictions)
 return {'model_sha256':meta['checkpoint_sha256'],'reports':reports,'evaluation_mode':'deterministic explicit ReLU; this model has no dropout or batchnorm','gradient_updates':0,'test_used_for_metrics':False}

def curve_svg(records,selected_step):
 width,height=1000,570;left,right,top,bottom=90,930,95,465
 ymax=max(max(r['train_mse'],r['validation_mse']) for r in records)*1.1 or 1.;xmax=max(r['step'] for r in records) or 1
 xy=lambda step,y:(left+(right-left)*step/xmax,bottom-(bottom-top)*y/ymax)
 s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="Fixed full train and validation mean squared errors by update step">','<rect width="1000" height="570" fill="#FAF9F5"/>','<g font-family="system-ui,sans-serif" fill="#191814">','<text x="50" y="40" font-size="25">Fixed views · standardized MSE per frame-channel cell</text>','<text x="50" y="68" font-size="15">No hardware commands · not task success rate · observed checkpoints only</text>']
 for k in range(5):
  yval=ymax*k/4;yp=xy(0,yval)[1];s.append(f'<path d="M{left} {yp}H{right}" stroke="#DED7C6"/><text x="78" y="{yp+5}" text-anchor="end" font-size="14">{yval:.4g}</text>')
 s.append(f'<path d="M{left} {top}V{bottom}H{right}" fill="none" stroke="#191814"/>')
 for key,color,label in [('train_mse','#306CA0','Train'),('validation_mse','#C26943','Validation')]:
  points=' '.join(f'{x:.3f},{y:.3f}' for x,y in [xy(r['step'],r[key]) for r in records]);s.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="3"/>')
  for r in records:
   x,y=xy(r['step'],r[key]);s.append(f'<circle cx="{x}" cy="{y}" r="4" fill="{color}"><title>{label} step {r["step"]}: {r[key]:.8g}</title></circle>')
 x=xy(selected_step,0)[0];s.append(f'<path d="M{x} {top}V{bottom}" stroke="#7161A8" stroke-dasharray="6 5"/><text x="{min(max(x,180),800)}" y="87" text-anchor="middle" font-size="15">selected step {selected_step}</text>')
 ticks=sorted(set([0,max(r['step'] for r in records),selected_step]))
 for tick in ticks:s.append(f'<text x="{xy(tick,0)[0]}" y="490" text-anchor="middle" font-size="14">{tick}</text>')
 s.extend(['<text x="880" y="520" text-anchor="end" font-size="16">Completed update steps</text>','<text x="90" y="545" font-size="16" fill="#306CA0">Train: same complete train view at every point</text>','<text x="545" y="545" font-size="16" fill="#C26943">Validation: same complete held-out view</text>','</g></svg>']);return ''.join(s)

def select_run(package,normalization,source,output,attempt_id,attempt_number=1,max_steps=20,every=5,patience=0,min_delta=0.,kind='adamw',lr=.01,batch_size=8,seed=17,weight_decay=.01,allow_synthetic=False,lock_file=None):
 if not isinstance(attempt_id,str) or not attempt_id.strip() or len(attempt_id)>80:raise ValueError('Record a nonempty attempt id of at most 80 characters')
 if type(attempt_number) is not int or attempt_number<1:raise ValueError('Record the self-reported cumulative attempt number')
 rule=plan(max_steps,every,patience,min_delta);cfg=optimizers.configuration(kind,lr,weight_decay=weight_decay)
 train=load_view(package,normalization,'train',allow_synthetic);validation=load_view(package,normalization,'validation',allow_synthetic);assert_compatible(train,validation)
 if not train['rows'] or not validation['rows']:raise ValueError('Both fixed views must contain frames')
 if type(batch_size) is not int or not 1<=batch_size<=len(train['rows']):raise ValueError('Batch size must fit the train view')
 model,meta=load_model(source,train)
 if meta.get('training_status')!='initialized_untrained':raise ValueError('Start this selection attempt from the M42 untrained initial model; inherited training needs its own declared protocol')
 out=Path(output)
 if out.exists():raise FileExistsError('Output exists; never overwrite selection history')
 lock=Path(lock_file or Path(__file__).resolve().parents[3]/'research/lerobot/uv.lock')
 if not lock.is_file():raise ValueError('Provide the fixed upstream lock file')
 out.mkdir(parents=True);(out/'evaluations').mkdir();(out/'segments').mkdir()
 protocol={'schema':'aloha.selection-plan.v1','attempt_id':attempt_id,'self_reported_attempt_number':attempt_number,'rule':rule,'optimizer':cfg,'batch_size':batch_size,'seed':seed,'source':identity(train),'initial_model_sha256':meta['checkpoint_sha256'],'train_frames':len(train['rows']),'validation_frames':len(validation['rows']),'rule_written_before_first_metric':True,'test_used_for_selection':False,'fixed_frame_weighting':'all frame-channel cells equal; episodes with more frames contribute more'}
 dump(out/'plan.json',protocol);records=[];paths=[]
 def observe(folder,step):
  result=evaluate(folder,train,validation);dump(out/'evaluations'/f'step-{step:06d}.json',result)
  row={'step':step,'train_mse':result['reports']['train']['standardized_mse_all_cells'],'validation_mse':result['reports']['validation']['standardized_mse_all_cells'],'model_sha256':result['model_sha256']};records.append(row);paths.append(Path(folder));return decide(records,rule)
 decision=observe(source,0);step=0;current=Path(source);status='budget_complete';failure=None
 while step<max_steps and not decision['stop']:
  count=min(every,max_steps-step);segment=out/'segments'/f'from-{step:06d}'
  kwargs={'steps':count,'checkpoint_every':count,'resume':step>0,'allow_synthetic':allow_synthetic,'lock_file':lock}
  if step==0:kwargs.update(kind=kind,lr=lr,batch_size=batch_size,seed=seed,weight_decay=weight_decay)
  result=training_run(package,normalization,current,segment,**kwargs);latest=json.loads((segment/'latest.json').read_text());current=segment/latest['directory'];new_step=result['end_step']
  if new_step>step:decision=observe(current,new_step)
  step=new_step
  if result['status']!='completed_requested_steps':status='training_update_rejected';failure=result['failure'];break
 if status=='budget_complete' and decision['stop']:status='early_stopped_at_declared_patience'
 chosen=paths[decision['selected_index']];selected=out/'selected';selected.mkdir()
 for name in ('model.safetensors','model.json','training-state.json'):
  if (chosen/name).is_file():shutil.copy2(chosen/name,selected/name)
 copy_model,copy_meta=load_model(selected,train)
 if copy_meta['checkpoint_sha256']!=records[decision['selected_index']]['model_sha256']:raise ValueError('Selected copy digest differs')
 with (out/'curves.csv').open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
 (out/'curves.svg').write_text(curve_svg(records,decision['selected_step']))
 result={'schema':'aloha.validation-selection.v1','source':identity(train),'attempt_id':attempt_id,'self_reported_attempt_number':attempt_number,'status':status,'failure':failure,'completed_updates':step,'plan_sha256':sha(out/'plan.json'),'initial_model_sha256':meta['checkpoint_sha256'],'selection':decision,'selected_directory':'selected','selected_model_sha256':copy_meta['checkpoint_sha256'],'selected_has_optimizer_state':(selected/'training-state.json').is_file(),'curve_point_count':len(records),'model':{'kind':'12-state → ReLU → 12-target','dropout':False,'batchnorm':False,'evaluation':'deterministic explicit forward; no gradients or updates'},'test_used_for_metrics_or_selection':False,'hardware_executed':False,'is_act_policy':False,'caveat':'Repeated attempts adapt choices to validation; report all attempts. This file cannot discover omitted external attempts.'};dump(out/'selection.json',result)
 dump(out/'dropout-demo.json',{'provenance':'synthetic fixed masks, independent demonstration; not enabled in trained M42 model','drop_probability':.5,'input':[2.,4.],'mask_a':[True,False],'train_a':dropout_values([2,4],[True,False]),'mask_b':[False,True],'train_b':dropout_values([2,4],[False,True]),'eval_both_masks':dropout_values([2,4],[True,False],training=False),'warning':'The two displayed masks are chosen for teaching; not the exhaustive set or a guarantee of a given random draw.'})
 dump(out/'environment.json',{'python':sys.version,'platform':platform.platform(),'packages':{name:importlib.metadata.version(name) for name in ('torch','safetensors')},'code_sha256':{p.name:sha(p) for p in Path(__file__).parent.glob('*.py') if not p.name.startswith('test_')},'upstream_lock_sha256':sha(lock),'scope':'offline scalar ReLU training and validation selection; no ACT/hardware'});(out/'upstream-uv.lock').write_bytes(lock.read_bytes())
 return result

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('source');p.add_argument('--out',required=True);p.add_argument('--attempt-id',required=True);p.add_argument('--attempt-number',type=int,default=1);p.add_argument('--max-steps',type=int,default=20);p.add_argument('--every',type=int,default=5);p.add_argument('--patience',type=int,default=0);p.add_argument('--min-delta',type=float,default=0.);p.add_argument('--optimizer',dest='kind',choices=['sgd','adam','adamw'],default='adamw');p.add_argument('--lr',type=float,default=.01);p.add_argument('--batch-size',type=int,default=8);p.add_argument('--seed',type=int,default=17);p.add_argument('--weight-decay',type=float,default=.01);p.add_argument('--allow-synthetic',action='store_true');p.add_argument('--lock-file');a=p.parse_args()
 try:
  r=select_run(a.package,a.normalization,a.source,a.out,a.attempt_id,a.attempt_number,a.max_steps,a.every,a.patience,a.min_delta,a.kind,a.lr,a.batch_size,a.seed,a.weight_decay,a.allow_synthetic,a.lock_file);print(json.dumps(r,ensure_ascii=False,indent=2));return 1 if r['status']=='training_update_rejected' else 0
 except (OSError,ValueError,KeyError,TypeError,ImportError,OverflowError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':raise SystemExit(main())
