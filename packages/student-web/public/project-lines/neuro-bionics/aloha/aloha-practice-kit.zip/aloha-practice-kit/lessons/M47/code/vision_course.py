"""Inspectable M47–M55 teaching components, not the full ACT policy.

No robot SDK or hardware output. Upstream comparison: LeRobot ACT revision
b64fe1ed9f11eeac53ee821356d2797601701054 (Apache-2.0).
The 2D positional convention and Q/K-only positional additions follow that source.
This small model omits its latent token, CVAE, chunk training and deployment system.
"""
from pathlib import Path
import hashlib
import json
import math
import torch
from torch import nn
from torch.nn import functional as F
from PIL import Image
from torchvision.transforms import functional as TVF

JOINTS=['shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper']
FIELDS=[side+'.'+name for side in ['left','right'] for name in JOINTS]
MEAN=[.485,.456,.406]
STD=[.229,.224,.225]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


def numbers(row, length):
    if not isinstance(row,list) or len(row)!=length:
        raise ValueError('Expected explicit list with '+str(length)+' values')
    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in row):
        raise ValueError('Values must be finite numbers, not bool')


def load_manifest(path, split='train', allow_synthetic=False):
    """Load one split only; check episode leakage before reading any image.

    Every row must carry episode_id, frame_index, cameras, state and action.
    Images are relative to the manifest. Original dimensions are checked before resize.
    No test split is exposed by the lesson CLI; it is reserved for later evaluation.
    """
    path=Path(path).resolve();data=json.loads(path.read_text())
    if data.get('source_kind') not in ['learner_recording','synthetic']:
        raise ValueError('Explicit source_kind required')
    if not data.get('dataset_source'):
        raise ValueError('Explicit dataset_source required; numeric M35 teaching views contain no images')
    if data.get('action_semantics')!='teleop_action_processor target':
        raise ValueError('action_semantics must match the fixed native teleop_action_processor target')
    if data['source_kind']=='synthetic' and not allow_synthetic:
        raise ValueError('Synthetic QA fixtures need --allow-synthetic; cannot count as learner evidence')
    if data.get('state_fields')!=FIELDS or data.get('action_fields')!=FIELDS:
        raise ValueError('12 named state/action fields must match the course order')
    contract=data['image_contract']
    if contract.get('camera_names')!=['front','overhead'] or contract.get('color_order')!='RGB':
        raise ValueError('Expected front/overhead and RGB contract')
    size=contract.get('resize_wh');raw=contract.get('original_wh')
    if not isinstance(size,list) or len(size)!=2 or any(type(v)!=int or v<8 for v in size):
        raise ValueError('resize_wh must be two integer dimensions >=8')
    if contract.get('normalization')!='imagenet_mean_std':
        raise ValueError('Explicit imagenet_mean_std preprocessing required')
    episode_splits={};attempt_splits={};keys=set()
    for row in data['rows']:
        for identity in ['episode_id','attempt_id']:
            if not isinstance(row.get(identity),str) or not row[identity].strip():raise ValueError('Nonempty string '+identity+' required')
        episode=row['episode_id'];attempt=row['attempt_id'];partition=row['split']
        if partition not in ['train','validation','test']:raise ValueError('Unknown split')
        if episode in episode_splits and episode_splits[episode]!=partition:
            raise ValueError('Episode leakage: '+episode)
        episode_splits[episode]=partition
        if attempt in attempt_splits and attempt_splits[attempt]!=partition:
            raise ValueError('Attempt leakage despite different episode IDs: '+attempt)
        attempt_splits[attempt]=partition
        if type(row['frame_index'])!=int or row['frame_index']<0:raise ValueError('Invalid frame index')
        key=(episode,row['frame_index'])
        if key in keys:raise ValueError('Duplicate episode/frame')
        keys.add(key);numbers(row['state'],12);numbers(row['action'],12)
        if set(row['cameras'])!=set(contract['camera_names']):raise ValueError('Wrong camera keys')
        if not isinstance(row.get('image_sha256'),dict) or set(row['image_sha256'])!=set(contract['camera_names']):raise ValueError('Saved SHA256 for every camera required')
    rows=[row for row in data['rows'] if row['split']==split]
    if not rows:raise ValueError('No rows in requested split: '+split)
    images=[];evidence=[]
    for row in rows:
        cams=[];origins=[]
        for camera in contract['camera_names']:
            image_path=(path.parent/row['cameras'][camera]).resolve()
            actual_hash=sha256(image_path)
            if row['image_sha256'][camera]!=actual_hash:raise ValueError('Image SHA256 changed since manifest review: '+camera)
            with Image.open(image_path) as image:
                if image.mode!='RGB':raise ValueError('Image must already be RGB: '+str(image_path))
                if list(image.size)!=raw[camera]:raise ValueError('Original image size changed: '+camera)
                image=image.resize(tuple(size),Image.Resampling.BILINEAR)
                tensor=TVF.pil_to_tensor(image).float()/255.0
            cams.append(tensor)
            origins.append(dict(camera=camera,path=str(image_path),sha256=actual_hash))
        images.append(torch.stack(cams));evidence.append(dict(episode_id=row['episode_id'],attempt_id=row['attempt_id'],frame_index=row['frame_index'],split=split,images=origins))
    pixels=torch.stack(images)
    mean=torch.tensor(MEAN)[None,None,:,None,None];std=torch.tensor(STD)[None,None,:,None,None]
    return dict(pixels=pixels,images=(pixels-mean)/std,state=torch.tensor([r['state'] for r in rows],dtype=torch.float32),action=torch.tensor([r['action'] for r in rows],dtype=torch.float32),evidence=evidence,source_kind=data['source_kind'],dataset_source=data['dataset_source'],manifest_sha256=sha256(path),contract=contract)


def training_stats(train):
    """Statistics are fit from the provided training rows only, never validation."""
    result={}
    for key in ['state','action']:
        x=train[key];mean=x.mean(0);std=x.std(0,unbiased=False);scale=torch.where(std>1e-6,std,torch.ones_like(std))
        result[key]=dict(mean=mean,scale=scale,raw_std=std)
    return result


def normalize(x, stats):
    return (x-stats['mean'])/stats['scale']


def denormalize(x, stats):
    return x*stats['scale']+stats['mean']


def conv_window(pixels, row=2, col=2):
    """PyTorch Conv2d uses cross-correlation: the kernel is NOT flipped."""
    kernel=torch.tensor([[1.,0.,-1.],[2.,0.,-2.],[1.,0.,-1.]],dtype=pixels.dtype)
    image=pixels[0,0,0]  # first record, front, red channel
    if row<1 or col<1 or row>=image.shape[0]-1 or col>=image.shape[1]-1:
        raise ValueError('Choose an interior centre for the 3x3 hand window')
    window=image[row-1:row+2,col-1:col+2]
    products=window*kernel;output=F.conv2d(image[None,None],kernel[None,None],padding=1)[0,0]
    return dict(channel='red',row=row,col=col,kernel=kernel.tolist(),window=window.tolist(),products=products.tolist(),manual_sum=products.sum().item(),library_value=output[row,col].item(),output_shape=list(output.shape),kernel_is_flipped=False),output


def build_backbone(weights='none'):
    from torchvision.models import resnet18,ResNet18_Weights
    from torchvision.models._utils import IntermediateLayerGetter
    from torchvision.ops.misc import FrozenBatchNorm2d
    if weights not in ['none','IMAGENET1K_V1']:raise ValueError('Unknown weights')
    selected=None if weights=='none' else ResNet18_Weights.IMAGENET1K_V1
    model=resnet18(weights=selected,norm_layer=FrozenBatchNorm2d,replace_stride_with_dilation=[False,False,False])
    return IntermediateLayerGetter(model,return_layers={'conv1':'conv1','maxpool':'maxpool','layer1':'layer1','layer2':'layer2','layer3':'layer3','layer4':'feature_map'})


def pos2d(height, width, dim, device=None):
    """ACT-compatible shared spatial encoding; NO camera-ID embedding.

    Actual upstream starts positions at 1, normalizes by H/W+1e-6 and 2*pi,
    uses temperature 10000, then concatenates y before x.
    """
    if dim%4:raise ValueError('dim must be divisible by 4')
    half=dim//2
    y=torch.arange(1,height+1,device=device,dtype=torch.float32)/(height+1e-6)*2*math.pi
    x=torch.arange(1,width+1,device=device,dtype=torch.float32)/(width+1e-6)*2*math.pi
    yy,xx=torch.meshgrid(y,x,indexing='ij')
    frequency=10000**(2*(torch.arange(half,device=device)//2)/half)
    def encode(axis):
        angle=axis[...,None]/frequency
        return torch.stack([angle[...,0::2].sin(),angle[...,1::2].cos()],-1).flatten(-2)
    return torch.cat([encode(yy),encode(xx)],-1).reshape(height*width,dim)


def tokens_from_maps(maps,camera_names):
    """maps B,camera,hidden,H,W -> tokens B,sequence,hidden + human audit index."""
    b,c,d,h,w=maps.shape
    if c!=len(camera_names):raise ValueError('Camera count mismatch')
    tokens=maps.permute(0,1,3,4,2).reshape(b,c*h*w,d)
    position=pos2d(h,w,d,maps.device).repeat(c,1)
    index=[dict(token=i*h*w+y*w+x,camera=camera_names[i],feature_row=y,feature_col=x,model_camera_id_embedding=False) for i in range(c) for y in range(h) for x in range(w)]
    return tokens,position,index


def attention_trace(query,keys,values,mask=None):
    """One query, one head; all intermediate arrays retained for hand checking."""
    scores=(keys*query).sum(-1)/math.sqrt(query.numel())
    if mask is not None:
        if mask.all():raise ValueError('All keys masked: no defined read')
        scores=scores.masked_fill(mask,-torch.inf)
    shifted=scores-scores.max();positive=shifted.exp();weights=positive/positive.sum();output=(weights[:,None]*values).sum(0)
    return dict(scores=scores,shifted=shifted,positive=positive,weights=weights,output=output)


def attention_loss_and_grads(xq,xkv,wq,wk,wv,target,fault=False):
    """Expanded reverse path for a half-squared-error; no autograd used here."""
    q=xq@wq;k=xkv@wk;v=xkv@wv;trace=attention_trace(q,k,v);a=trace['weights'];o=trace['output'];go=o-target
    ga=(v*go).sum(-1)
    # The weighted sum term includes every key; omitting it is the deliberate fault.
    gs=a*(1-a)*ga if fault else a*(ga-(a*ga).sum())
    gq=(gs[:,None]*k).sum(0)/math.sqrt(q.numel())
    gk=gs[:,None]*q/math.sqrt(q.numel());gv=a[:,None]*go
    return dict(loss=(go.square().sum()/2),trace=trace,score_grad=gs,q_grad=gq,k_grad=gk,v_grad=gv,wq_grad=xq[:,None]*gq[None,:],wk_grad=xkv.T@gk,wv_grad=xkv.T@gv)


class ExplicitMultiHead(nn.Module):
    def __init__(self,dim=8,heads=2):
        super().__init__()
        if dim%heads:raise ValueError('dim not divisible by heads')
        self.dim=dim;self.heads=heads
        self.q=nn.Linear(dim,dim);self.k=nn.Linear(dim,dim);self.v=nn.Linear(dim,dim);self.out=nn.Linear(dim,dim)

    def forward(self,query,key,value,key_mask=None):
        b,n,d=query.shape;m=key.shape[1];h=self.heads;dh=d//h
        q=self.q(query).reshape(b,n,h,dh).transpose(1,2)
        k=self.k(key).reshape(b,m,h,dh).transpose(1,2)
        v=self.v(value).reshape(b,m,h,dh).transpose(1,2)
        scores=q@k.transpose(-1,-2)/math.sqrt(dh)
        if key_mask is not None:
            if key_mask.shape!=(b,m) or key_mask.all(-1).any():raise ValueError('Invalid/all-masked keys')
            scores=scores.masked_fill(key_mask[:,None,None,:],-torch.inf)
        weights=torch.softmax(scores,-1);per_head=weights@v
        concatenated=per_head.transpose(1,2).reshape(b,n,d)
        self.trace=dict(q=q,k=k,v=v,scores=scores,weights=weights,per_head=per_head,concatenated=concatenated)
        return self.out(concatenated)


class Fusion(nn.Module):
    """One post-norm block, ReLU FFN, dropout=0 for deterministic hand checks."""
    def __init__(self,dim=8,heads=2):
        super().__init__();self.attn=ExplicitMultiHead(dim,heads);self.norm1=nn.LayerNorm(dim);self.norm2=nn.LayerNorm(dim);self.ff1=nn.Linear(dim,2*dim);self.ff2=nn.Linear(2*dim,dim)

    def forward(self,x,position,mask=None):
        read=self.attn(x+position,x+position,x,mask)
        first=self.norm1(x+read);hidden=F.relu(self.ff1(first));out=self.norm2(first+self.ff2(hidden))
        self.trace=dict(input=x,read=read,first_residual=x+read,first_norm=first,ff_hidden=hidden,output=out)
        return out


class ActionDecoder(nn.Module):
    def __init__(self,dim=8,heads=2,queries=1):
        super().__init__();self.query_position=nn.Parameter(torch.randn(queries,dim)*.02);self.self_attn=ExplicitMultiHead(dim,heads);self.cross_attn=ExplicitMultiHead(dim,heads);self.n1=nn.LayerNorm(dim);self.n2=nn.LayerNorm(dim);self.n3=nn.LayerNorm(dim);self.ff=nn.Sequential(nn.Linear(dim,2*dim),nn.ReLU(),nn.Linear(2*dim,dim));self.head=nn.Linear(dim,12)

    def forward(self,memory,position,mask=None):
        x=torch.zeros(memory.shape[0],len(self.query_position),memory.shape[-1],dtype=memory.dtype,device=memory.device)
        qpos=self.query_position[None]
        x=self.n1(x+self.self_attn(x+qpos,x+qpos,x))
        x=self.n2(x+self.cross_attn(x+qpos,memory+position,memory,mask))
        x=self.n3(x+self.ff(x));actions=self.head(x)
        self.trace=dict(hidden=x,actions=actions,query_position=qpos)
        return actions


class TinyVisionPolicy(nn.Module):
    """CPU teaching policy: 2x RGB -> small CNN -> state/image tokens -> action.

    It is explicitly not the pretrained ResNet18 or the formal ACT network.
    No camera-ID embedding, no output sent to a robot, one action time only.
    """
    def __init__(self,dim=8,heads=2):
        super().__init__();self.dim=dim;self.heads=heads
        self.visual=nn.Sequential(nn.Conv2d(3,8,3,padding=1),nn.ReLU(),nn.AvgPool2d(2),nn.Conv2d(8,dim,3,padding=1),nn.ReLU(),nn.AdaptiveAvgPool2d((2,2)))
        self.state_projection=nn.Linear(12,dim);self.state_position=nn.Parameter(torch.randn(1,dim)*.02)
        self.fusion=Fusion(dim,heads);self.decoder=ActionDecoder(dim,heads,1)

    def forward(self,images,state):
        b,c,_,h,w=images.shape
        if c!=2:raise ValueError('Exactly two cameras required')
        maps=self.visual(images.reshape(b*c,3,h,w)).reshape(b,c,self.dim,2,2)
        visual_tokens,visual_position,index=tokens_from_maps(maps,['front','overhead'])
        state_token=self.state_projection(state).unsqueeze(1)
        tokens=torch.cat([state_token,visual_tokens],1)
        positions=torch.cat([self.state_position,visual_position.to(images.dtype)],0)[None]
        mask=torch.zeros(b,tokens.shape[1],dtype=torch.bool,device=images.device)
        fused=self.fusion(tokens,positions,mask);out=self.decoder(fused,positions,mask)[:,0]
        self.trace=dict(maps=maps,tokens=tokens,positions=positions,mask=mask,index=[dict(token=0,kind='state',fields=FIELDS)]+[dict(x,token=x['token']+1) for x in index],fused=fused,output=out)
        return out


def serialize(value):
    if isinstance(value,torch.Tensor):return value.detach().cpu().tolist()
    if isinstance(value,dict):return {k:serialize(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [serialize(v) for v in value]
    return value
