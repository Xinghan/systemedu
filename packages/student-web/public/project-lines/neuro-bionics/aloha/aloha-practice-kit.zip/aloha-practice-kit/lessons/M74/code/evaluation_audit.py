"""Frozen-plan and byte-evidence audit. No driver imports and no truth certification."""
from pathlib import Path
from datetime import datetime
import hashlib,json,re,math
from gateway_log import validate_gateway_log

VERSION_SLOTS={'model_manifest_sha256':'model_manifest','hardware_manifest_sha256':'hardware_manifest','config_sha256':'config','dataset_split_manifest_sha256':'dataset_split_manifest','software_manifest_sha256':'software_manifest'}
CONDITIONS={'all_planned_trials_executed','all_evidence_verified','frozen_versions_match'}
REQUIRED_EVIDENCE={'video','gateway_log','outcome_note'}
STATUSES={'completed','failed','intervention','estop'}
PURPOSES={'evaluation','release_smoke','independent_handoff','domain_challenge','development'}

def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def text(x,label):
 if not isinstance(x,str) or not x.strip():raise ValueError(label+': nonempty string required')
 return x
def number(x,label):
 if type(x) not in (int,float) or not math.isfinite(x):raise ValueError(label+': finite number required')
 return float(x)
def timestamp(x,label):
 t=datetime.fromisoformat(text(x,label).replace('Z','+00:00'))
 if t.tzinfo is None:raise ValueError(label+': timezone required')
 return t
def contained(root,relative):
 p=Path(text(relative,'path'));root=Path(root).resolve()
 if p.is_absolute() or '..' in p.parts:raise ValueError('Use an artifact-root-relative path')
 p=(root/p).resolve()
 if not p.is_relative_to(root) or not p.is_file():raise ValueError('Missing/outside artifact: '+relative)
 return p
def verify_file(root,row):
 digest=row.get('sha256')
 if not isinstance(digest,str) or not re.fullmatch('[a-f0-9]{64}',digest):raise ValueError('Invalid SHA256')
 p=contained(root,row.get('path'))
 if sha(p)!=digest:raise ValueError('Changed bytes: '+row['path'])
 return p
def actual_versions(root,artifacts):
 """Read actual current manifests and their leaves; never accept hand-typed hashes."""
 if set(artifacts)!=set(VERSION_SLOTS.values()):raise ValueError('Five version artifact paths required')
 values={};files=[]
 for key,slot in VERSION_SLOTS.items():
  p=contained(root,artifacts[slot]);values[key]=sha(p);files.append({'kind':slot,'path':artifacts[slot],'sha256':values[key]})
  if slot.endswith('_manifest'):
   entries=read(p).get('files')
   if not isinstance(entries,list) or not entries:raise ValueError(slot+': nonempty files inventory required')
   seen=set()
   for row in entries:
    if row.get('path') in seen:raise ValueError('Duplicate manifest path')
    seen.add(row.get('path'));verify_file(root,row)
 return values,files
def validate_plan(plan,root):
 if plan.get('schema')!='aloha.independent-plan.v1':raise ValueError('Wrong frozen-plan schema')
 text(plan['evaluation_id'],'evaluation_id');timestamp(plan['registered_at'],'registered_at')
 if plan['source_kind'] not in ('synthetic','learner_recording'):raise ValueError('Explicit provenance required')
 limit=number(plan['time_limit_s'],'time_limit_s')
 if limit<=0:raise ValueError('Positive time limit required')
 threshold=plan['acceptance_threshold']
 for key in ('minimum_successes','maximum_interventions','maximum_estops'):
  if type(threshold.get(key)) is not int or not 0<=threshold[key]<=20:raise ValueError('Threshold integer outside 0–20: '+key)
 conditions=threshold['required_conditions']
 if not isinstance(conditions,list) or len(conditions)!=3 or set(conditions)!=CONDITIONS:raise ValueError('Unknown, duplicate or missing required condition')
 rows=plan['plan']
 if not isinstance(rows,list) or len(rows)!=20:raise ValueError('Exactly 20 preregistered trials required')
 seen=set()
 for i,row in enumerate(rows,1):
  tid=text(row['trial_id'],'trial_id')
  if not re.fullmatch('[A-Za-z0-9_-]+',tid) or tid in seen:raise ValueError('Unsafe or duplicate trial ID')
  seen.add(tid)
  if type(row['order']) is not int or row['order']!=i or row['planned_status']!='planned':raise ValueError('Plan order/status invalid')
  for k in ('condition','initial_setup','sealed_test_ref'):text(row[k],k)
  if not REQUIRED_EVIDENCE.issubset(set(row['evidence_requirements'])):raise ValueError('Each trial needs video/gateway_log/outcome_note')
 versions,_=actual_versions(root,plan['version_artifacts'])
 if versions!=plan['frozen_versions']:raise ValueError('Current artifact bytes differ from frozen versions')
 return plan
def validate_outcome(row,limit):
 if row.get('status') not in STATUSES:raise ValueError('An actually executed outcome status is required')
 for k in ('tray_held','block_in_tray','human_intervention'):
  if type(row.get(k)) is not bool:raise ValueError(k+': boolean required')
 duration=number(row['duration_s'],'duration_s')
 if duration<0:raise ValueError('Negative duration')
 start=timestamp(row['started_at'],'started_at');end=timestamp(row['ended_at'],'ended_at')
 if end<start:raise ValueError('End precedes start')
 if not isinstance(row.get('interventions'),list):raise ValueError('Intervention list required')
 for event in row['interventions']:
  offset=number(event['offset_s'],'intervention offset')
  if offset<0 or offset>duration:raise ValueError('Intervention outside execution interval')
  for k in ('actor_role','action','reason'):text(event[k],k)
 if bool(row['interventions'])!=row['human_intervention']:raise ValueError('Intervention flag and event list disagree')
 if row['status']=='intervention' and not row['human_intervention']:raise ValueError('Intervention status requires retained human event')
 success=row['status']=='completed' and row['tray_held'] and row['block_in_tray'] and not row['human_intervention'] and duration<=limit
 if not success:text(row.get('failure_reason'),'failure_reason')
 return success
def verify_evidence(root,rows,required=REQUIRED_EVIDENCE):
 if not isinstance(rows,list):raise ValueError('Evidence array required')
 if not required.issubset({r.get('kind') for r in rows}):raise ValueError('Missing required evidence kind')
 for row in rows:verify_file(root,row);text(row.get('description'),'evidence description')

def verify_outcome_binding(root,run):
 notes=[e for e in run['evidence'] if e.get('kind')=='outcome_note']
 if len(notes)!=1:raise ValueError('Exactly one observation outcome_note required')
 note=read(verify_file(root,notes[0]))
 if not isinstance(note,dict):raise ValueError('Outcome note must be an object')
 for key in ('status','started_at','ended_at','duration_s','tray_held','block_in_tray','human_intervention','failure_reason','interventions'):
  if note.get(key)!=run.get(key):raise ValueError('Observation outcome differs from closed run: '+key)
 return note

def audit_evaluation(evaluation_path,artifact_root):
 """Return an explicit incomplete result for invalid/missing evidence; never command hardware."""
 out={'complete':False,'accepted':False,'successes':0,'planned_trials':20,'recorded_trials':0,'errors':[],'trials':[],'truth_certified':False}
 try:
  d=read(evaluation_path)
  if d.get('schema')!='aloha.independent-evaluation.v1':raise ValueError('Wrong evaluation schema')
  p=verify_file(artifact_root,{'path':d['plan_path'],'sha256':d['plan_sha256']});plan=validate_plan(read(p),artifact_root)
  for key in ('evaluation_id','source_kind','time_limit_s','frozen_versions','acceptance_threshold','plan'):
   if d[key]!=plan[key]:raise ValueError('Evaluation differs from frozen plan: '+key)
  rows=d['results']
  if not isinstance(rows,list):raise ValueError('Results must be an array')
  out['recorded_trials']=len(rows);by_id={};all_ids={r['trial_id'] for r in plan['plan']}
  for row in rows:
   tid=text(row['trial_id'],'trial_id')
   if tid in by_id or tid not in all_ids:raise ValueError('Duplicate or unplanned result')
   by_id[tid]=row
  previous_end=None;interventions=estops=0
  for item in plan['plan']:
   tid=item['trial_id'];row=by_id.get(tid)
   if row is None:out['trials'].append({'trial_id':tid,'outcome':'not_executed','evidence_complete':False});continue
   issues=[];success=False
   try:
    if row.get('purpose')!='evaluation':raise ValueError('Separate-purpose run cannot enter main denominator')
    if row.get('source_kind')!=plan['source_kind']:raise ValueError('Run provenance differs from plan')
    text(row['run_id'],'run_id')
    if row['observed_versions']!=plan['frozen_versions']:raise ValueError('Run versions differ from frozen versions')
    success=validate_outcome(row,plan['time_limit_s']);verify_evidence(artifact_root,row['evidence'],set(item['evidence_requirements']));verify_outcome_binding(artifact_root,row)
    for evidence in row['evidence']:
     if evidence['kind']=='gateway_log':validate_gateway_log(contained(artifact_root,evidence['path']),row)
    original=read(verify_file(artifact_root,row['run_record_ref']))
    if original.get('version_validation_errors'):raise ValueError('Run retained an observed version verification failure')
    if original.get('evidence_validation_errors'):raise ValueError('Run retained missing or invalid execution evidence')
    opened=read(verify_file(artifact_root,original['start_record_ref']))
    if opened.get('status')!='open' or opened.get('plan_sha256')!=d['plan_sha256']:raise ValueError('Start record differs from frozen plan')
    for key in ('run_id','trial_id','purpose','source_kind','observed_versions'):
     if opened[key]!=original[key]:raise ValueError('Start/close identity mismatch: '+key)
    # Compare against the immutable close record; added audit annotations are allowed.
    for key in ('run_id','trial_id','purpose','source_kind','status','started_at','ended_at','duration_s','tray_held','block_in_tray','human_intervention','failure_reason','interventions','observed_versions','evidence'):
     if row[key]!=original[key]:raise ValueError('Result differs from closed run: '+key)
    start=timestamp(row['started_at'],'started_at');end=timestamp(row['ended_at'],'ended_at')
    if start<timestamp(plan['registered_at'],'registered_at'):raise ValueError('Execution precedes preregistration')
    if previous_end is not None and start<previous_end:raise ValueError('Execution order differs from frozen order')
    previous_end=end
   except (ValueError,KeyError,TypeError,FileNotFoundError,json.JSONDecodeError) as exc:issues.append(str(exc));success=False
   if row.get('human_intervention') is True:interventions+=1
   if row.get('status')=='estop':estops+=1
   out['successes']+=int(success);out['trials'].append({'trial_id':tid,'condition':item['condition'],'reported_status':row.get('status'),'outcome':'unverified' if issues else 'success' if success else 'failure','evidence_complete':not issues,'errors':issues})
   out['errors'].extend(tid+': '+x for x in issues)
  out['complete']=len(rows)==20 and not out['errors'] and all(x['evidence_complete'] for x in out['trials'])
  t=plan['acceptance_threshold'];out['accepted']=out['complete'] and plan['source_kind']=='learner_recording' and out['successes']>=t['minimum_successes'] and interventions<=t['maximum_interventions'] and estops<=t['maximum_estops']
  out.update(source_kind=plan['source_kind'],successes_over_planned=out['successes']/20,provisional=not out['complete'],intervention_trials=interventions,estop_trials=estops,acceptance_threshold=t)
  if not out['complete'] and len(rows)<20:out['errors'].append('Missing planned executions; reasons do not count as completion')
 except (ValueError,KeyError,TypeError,FileNotFoundError,json.JSONDecodeError) as exc:out['errors'].append(str(exc))
 return out

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('evaluation');p.add_argument('--root',required=True);p.add_argument('--output');a=p.parse_args();r=audit_evaluation(a.evaluation,a.root);s=json.dumps(r,ensure_ascii=False,indent=2)+'\n'
 if a.output:
  with open(a.output,'x') as f:f.write(s)
 print(s,end='');raise SystemExit(0 if r['complete'] else 2)
