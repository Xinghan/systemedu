#!/usr/bin/env python3
"""Generate reviewable argv only. Never import LeRobot or open a device."""
import argparse
import json
import math
from pathlib import Path
import re
import shlex
from course_cli import JOINTS, number, read_json

REVISION='b64fe1ed9f11eeac53ee821356d2797601701054'

def required_string(value, name):
    if not isinstance(value,str) or not value.strip() or any(x in value.upper() for x in ('REPLACE','TODO','<','>')):
        raise ValueError(f'{name}: replace placeholder with your measured/local value')
    if '\n' in value or '\x00' in value:raise ValueError(f'{name}: invalid control character')
    return value

def absolute(value,name):
    required_string(value,name)
    if not Path(value).is_absolute():raise ValueError(f'{name}: use an absolute local path')
    return value

def integer(value,name):
    if type(value)is not int or value<1:raise ValueError(f'{name}: positive integer required')
    return value

def generate(config,stage,split=None):
    if config['lerobot_revision']!=REVISION:raise ValueError('Revision differs from verified schema')
    if config['use_degrees'] is not True:raise ValueError('This course requires explicit use_degrees=true on all four arms')
    required_string(config['provenance'],'provenance')
    if config['device'] not in ('cpu','cuda','mps'):raise ValueError('Choose cpu, cuda or mps and validate availability locally')
    fps=integer(config['fps'],'fps');camera_names=set(config['cameras'])
    if camera_names!={'front','overhead'}:raise ValueError('Course camera contract requires front and overhead')
    cameras={}
    for name,camera in config['cameras'].items():
        idx=camera['index_or_path']
        if type(idx)is int:
            if idx<0:raise ValueError('Camera index must be nonnegative')
        else:required_string(idx,f'{name} camera')
        cameras[name]={'type':'opencv','index_or_path':idx,'width':integer(camera['width'],'width'),
                       'height':integer(camera['height'],'height'),'fps':fps}
    if cameras['front']['index_or_path']==cameras['overhead']['index_or_path']:raise ValueError('Camera sources must differ')
    ports=config['ports']
    if set(ports)!={'left_follower','right_follower','left_leader','right_leader'}:raise ValueError('Four arm ports required')
    for k,v in ports.items():required_string(v,k)
    if len(set(ports.values()))!=4:raise ValueError('Four independently identified serial ports required')
    for side in ('left','right'):
        caps=config['max_relative_target'][side]
        if set(caps)!=set(JOINTS):raise ValueError('Per-arm cap keys must match unprefixed motor names without .pos')
        if any(number(v)<=0 for v in caps.values()):raise ValueError('All caps must be measured positive numbers')
    for key in ('robot_id','teleop_id'):required_string(config[key],key)
    root=absolute(config['dataset_root'],'dataset_root');repo=required_string(config['dataset_repo_id'],'dataset_repo_id')
    if not re.fullmatch(r'[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+',repo):raise ValueError('repo_id must have namespace/name form; local-only use still needs an identifier')
    task=required_string(config['task'],'task')
    def arg(key,value):
        if isinstance(value,(dict,list,bool)):value=json.dumps(value,separators=(',',':'),ensure_ascii=False)
        return f'--{key}={value}'
    robot=[arg('robot.type','bi_so_follower'),arg('robot.id',config['robot_id']),arg('robot.cameras',cameras)]
    teleop=[arg('teleop.type','bi_so_leader'),arg('teleop.id',config['teleop_id'])]
    for side in ('left','right'):
        robot.extend([arg(f'robot.{side}_arm_config.port',ports[f'{side}_follower']),
                      arg(f'robot.{side}_arm_config.use_degrees',True),
                      arg(f'robot.{side}_arm_config.max_relative_target',{k:float(v) for k,v in config['max_relative_target'][side].items()}),
                      arg(f'robot.{side}_arm_config.disable_torque_on_disconnect',True)])
        teleop.extend([arg(f'teleop.{side}_arm_config.port',ports[f'{side}_leader']),arg(f'teleop.{side}_arm_config.use_degrees',True)])
    dataset=[arg('dataset.repo_id',repo),arg('dataset.root',root),arg('dataset.single_task',task),
             arg('dataset.fps',fps),arg('dataset.push_to_hub',False),arg('dataset.private',True),arg('dataset.no_stamp',True)]
    if stage=='record':
        argv=['lerobot-record']+robot+teleop+dataset+[
            arg('dataset.num_episodes',integer(config['record']['num_episodes'],'num_episodes')),
            arg('dataset.episode_time_s',integer(config['record']['episode_time_s'],'episode_time_s')),
            arg('dataset.reset_time_s',integer(config['record']['reset_time_s'],'reset_time_s')),
            arg('display_data',False),arg('play_sounds',False)]
    elif stage in ('split-lerobot','train'):
        if split is None:raise ValueError('Training requires the fixed split manifest')
        ids=split['lerobot_episode_indices'];all_ids=[x for k in ('train','validation','test') for x in ids[k]]
        if not ids['train'] or not ids['validation'] or not ids['test'] or len(set(all_ids))!=len(all_ids):raise ValueError('Empty/overlapping episode split')
        if any(type(x)is not int or x<0 for x in all_ids):raise ValueError('Invalid LeRobot episode index')
        split_root=absolute(config['split_root'],'split_root')
        if Path(split_root)==Path(root) or Path(split_root).is_relative_to(Path(root)):
            raise ValueError('Split output must be separate from the original dataset')
        if stage=='split-lerobot':
            argv=['lerobot-edit-dataset',arg('repo_id',repo),arg('root',root),arg('new_root',split_root),
                  arg('operation.type','split'),arg('operation.splits',{k:sorted(ids[k]) for k in ('train','validation','test')}),arg('push_to_hub',False)]
            return {'stage':stage,'revision':REVISION,'generated_only':True,'provenance':config['provenance'],
                    'argv':argv,'shell_preview':shlex.join(argv),
                    'reindex_map':{k:{str(old):new for new,old in enumerate(sorted(ids[k]))} for k in ids},
                    'note':'Official split tool copies/reindexes complete episodes and aggregates subset episode statistics. Inspect actual generated info/stats before training; original files remain evidence.'}
        tr=config['train'];chunk=integer(tr['chunk_size'],'chunk_size');actions=integer(tr['n_action_steps'],'n_action_steps')
        coeff=tr['temporal_ensemble_coeff']
        if actions>chunk or (coeff is not None and actions!=1):raise ValueError('n_action_steps <= chunk_size; temporal ensemble requires n_action_steps=1')
        if coeff is not None:number(coeff)
        if type(tr['seed'])is not int or tr['seed']<0:raise ValueError('seed must be a nonnegative integer')
        argv=['lerobot-train',arg('dataset.repo_id',repo+'_train'),arg('dataset.root',str(Path(split_root)/'train')),
              arg('dataset.episodes',list(range(len(ids['train'])))),
              arg('dataset.eval_split',0.0),arg('policy.type','act'),arg('policy.device',config['device']),
              arg('policy.push_to_hub',False),arg('policy.chunk_size',chunk),arg('policy.n_action_steps',actions),
              arg('policy.pretrained_backbone_weights','null'),arg('wandb.enable',False),
              arg('output_dir',absolute(tr['output_dir'],'output_dir')),arg('steps',integer(tr['steps'],'steps')),
              arg('batch_size',integer(tr['batch_size'],'batch_size')),arg('num_workers',0),arg('seed',tr['seed'])]
        if coeff is not None:argv.append(arg('policy.temporal_ensemble_coeff',coeff))
    elif stage=='rollout':
        roll=config['rollout'];trial=required_string(roll['trial_id'],'trial_id')
        if not re.fullmatch(r'[A-Za-z0-9_-]+',trial):raise ValueError('trial_id: use letters, digits, underscore or dash')
        eval_root=absolute(roll['root'],'rollout.root')
        if Path(eval_root)==Path(root):raise ValueError('Evaluation must not overwrite training data')
        eval_repo=repo.split('/')[0]+'/rollout_'+trial
        eval_dataset=[arg('dataset.repo_id',eval_repo),arg('dataset.root',str(Path(eval_root)/trial)),arg('dataset.single_task',task),
                      arg('dataset.fps',fps),arg('dataset.push_to_hub',False),arg('dataset.private',True),arg('dataset.no_stamp',True)]
        argv=['lerobot-rollout']+robot+eval_dataset+[
            arg('policy.path',absolute(roll['checkpoint'],'checkpoint')),arg('strategy.type','episodic'),
            arg('strategy.reset_to_initial_position',False),arg('inference.type','sync'),arg('device',config['device']),
            arg('fps',fps),arg('interpolation_multiplier',1),arg('dataset.num_episodes',1),
            arg('dataset.episode_time_s',integer(roll['time_limit_s'],'time_limit_s')),
            arg('dataset.reset_time_s',0),arg('display_data',False)]
    else:raise ValueError('Unknown stage')
    return {'stage':stage,'revision':REVISION,'generated_only':True,'provenance':config['provenance'],
            'argv':argv,'shell_preview':shlex.join(argv),
            'verification_scope':'Flags checked against pinned official dataclass source. No full LeRobot environment, GPU training, command execution, motor or camera validation performed by generator.',
            'before_execution':'Mentor validates hardware, ports, calibration, dataset/checkpoint compatibility, limits, power-stop and local --help. Rollout moves hardware when manually executed.'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['record','split-lerobot','train','rollout']);p.add_argument('config');p.add_argument('--split')
    a=p.parse_args()
    try:print(json.dumps(generate(read_json(a.config),a.stage,read_json(a.split) if a.split else None),indent=2,ensure_ascii=False,allow_nan=False))
    except (ValueError,KeyError,TypeError,OSError)as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
