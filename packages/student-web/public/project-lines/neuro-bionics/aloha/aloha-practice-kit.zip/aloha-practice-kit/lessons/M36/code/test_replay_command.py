import copy,json,tempfile,unittest,sys
from pathlib import Path
from replay_command import generate,FIELDS,HERE
P=HERE.parents[3]/'practice-kit'
if not P.exists():P=HERE.parents[3]
class ReplayCommandTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);(self.root/'meta').mkdir()
        self.info={'fps':15,'total_episodes':3,'features':{'action':{'names':list(FIELDS)}}};self.write_info()
        self.c=json.loads((P/'templates/act_config.json').read_text());self.c['provenance']='synthetic fixture only'
        self.c['ports']={k:'/dev/synthetic-'+k for k in self.c['ports']};self.c['dataset_root']=str(self.root)
        for side in self.c['max_relative_target']:self.c['max_relative_target'][side]={k:1 for k in self.c['max_relative_target'][side]}
        self.d={'source_dataset':'synthetic fixture identity','seed':0,'held_out_conditions':'fixture','near_duplicate_review_ref':'fixture','episodes':[dict(episode_id=f'e{i}',native_episode_index=i,attempt_id=f'a{i}',batch_id=f'b{i}',lineage_id=f'l{i}',content_sha256=str(i+1)*64,split=role,evidence_ref='fixture') for i,role in enumerate(('train','validation','test'))]}
        self.r=json.loads((Path(__file__).parent/'replay-review.template.json').read_text())
        for k,v in list(self.r.items()):
            if isinstance(v,str) and v.startswith('REPLACE'):self.r[k]='synthetic fixture declaration, not real evidence'
        self.r.update(source_episode_id='e0',source_dataset=self.d['source_dataset'],native_dataset_root=str(self.root),development_only=True,recorded_slow_motion_reviewed=True)
    def write_info(self):(self.root/'meta/info.json').write_text(json.dumps(self.info))
    def tearDown(self):self.tmp.cleanup()
    def test_generate_only_exact_native_fields(self):
        d=generate(self.c,self.d,self.r);self.assertTrue(d['generated_only']);self.assertFalse(d['hardware_executed'])
        self.assertEqual(d['argv'][0],'lerobot-replay');self.assertIn('--dataset.episode=0',d['argv'])
        self.assertTrue(any(s.startswith('--robot.left_arm_config.max_relative_target=') for s in d['argv']))
        self.assertFalse(any(s.startswith('--robot.cameras=') or s.startswith('--dataset.fps=') for s in d['argv']))
        self.assertEqual(d['dataset_fps_used_by_pinned_source'],15);self.assertIn('HF_HUB_OFFLINE=1',d['shell_preview'])
    def test_no_validation_or_test_replay(self):
        for eid in ['e1','e2']:
            self.r['source_episode_id']=eid
            with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
    def test_missing_review_and_development_refused(self):
        self.r['development_only']=False
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
        self.r['development_only']=True;self.r['start_state_check_ref']='REPLACE'
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
    def test_original_root_mismatch_refused(self):
        self.r['native_dataset_root']=str(self.root/'train')
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
    def test_action_names_refused(self):
        self.info['features']['action']['names'][0]='other';self.write_info()
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
    def test_bad_fps_refused(self):
        self.info['fps']=True;self.write_info()
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
    def test_synthetic_marker_cannot_authorize(self):
        self.r['provenance']='synthetic'
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
    def test_no_local_metadata_no_download(self):
        (self.root/'meta/info.json').unlink()
        with self.assertRaises(ValueError):generate(self.c,self.d,self.r)
if __name__=='__main__':unittest.main()
