"""Executable synthetic call-site demonstration, not a LeRobot patch or a driver.

Usage: python3 offline_tap.py --kit /path/to/practice-kit --output NEW.jsonl
The real pinned recording loop still needs learner-added instrumentation.
"""
import argparse,copy,json,sys,time
from pathlib import Path

def demonstrate(kit, output):
    sys.path.insert(0,str(kit))
    from recording_sidecar import RecordingSidecar,audit
    fields=('left_shoulder_pan.pos','right_shoulder_pan.pos')
    writer=RecordingSidecar(output,{'kind':'synthetic','source':'M27 fake two-field call-site fixture'},required_joint_fields=fields)
    native_frames=[]
    episode_index=0
    for frame in range(2):
        # Analog of robot.get_observation() returning. Capture BEFORE observation processor.
        obs={k:20.0 for k in fields}
        observation_arrival=time.perf_counter()
        obs_copy=copy.deepcopy(obs)
        # Analog of teleop.get_action() and teleop_action_processor output.
        act={k:30.0+frame for k in fields}
        raw_copy=copy.deepcopy(act)
        act_processed_teleop=copy.deepcopy(act)
        teleop_copy=copy.deepcopy(act_processed_teleop)
        action_values=act_processed_teleop
        # A non-Identity synthetic robot_action_processor.
        robot_action_to_send={k:v-2 for k,v in act_processed_teleop.items()}
        robot_copy=copy.deepcopy(robot_action_to_send)
        send_start=time.perf_counter()
        # Fake driver: relative-to-measured clipping, with no device connection.
        sent_action={k:max(obs[k]-2,min(obs[k]+2,v)) for k,v in robot_action_to_send.items()}
        send_end=time.perf_counter()
        sent_copy=copy.deepcopy(sent_action)
        assert action_values==teleop_copy, 'A processor mutated the native label; stop and audit semantics'
        # Analog of dataset.add_frame returning successfully.
        native_frames.append({'action':copy.deepcopy(action_values),'observation':obs_copy})
        native_frame_index=len(native_frames)-1
        writer.append_frame(episode_index=episode_index,frame_index=native_frame_index,nominal_fps=30,
            monotonic_observation_arrival=observation_arrival,monotonic_send_start=send_start,monotonic_send_end=send_end,
            raw_teleop_action=raw_copy,teleop_processor_action=teleop_copy,
            robot_processor_action_to_send=robot_copy,driver_returned_sent_action=sent_copy,observed_state=obs_copy)
    # This fixture has no native dataset. Do not falsely mark it saved into LeRobot.
    writer.close_attempt(disposition='discarded',reason='Synthetic call-site demonstration, not a native dataset')
    return {'provenance':'synthetic','hardware_executed':False,'native_frame_analogue':native_frames,'audit':audit(output)}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kit',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();print(json.dumps(demonstrate(a.kit,a.output),ensure_ascii=False,indent=2))
