import unittest
from episode_boundary import validate
def example():return dict(begin=0,end_exclusive=90,total_frames=120,declared_count=90,attempt_id='synthetic-A',provenance='synthetic',source_ref='synthetic-storyboard',end_reason='timeout',reset_begin=90,index_space='exported_source_sequence')
class TestBoundary(unittest.TestCase):
    def test_half_open(self):
        r=validate(example());self.assertTrue(r['valid']);self.assertEqual(r['last_included'],89);self.assertFalse(r['video_decoded'])
    def test_off_by_one(self):
        d=example();d['declared_count']=91;self.assertFalse(validate(d)['valid'])
    def test_reset_inside(self):
        d=example();d['reset_begin']=89;self.assertFalse(validate(d)['valid'])
    def test_out_of_range(self):
        d=example();d['end_exclusive']=121;d['declared_count']=121;self.assertFalse(validate(d)['valid'])
    def test_empty_range(self):
        d=example();d['end_exclusive']=0;d['declared_count']=0;self.assertFalse(validate(d)['valid'])
    def test_bool_not_index(self):
        d=example();d['begin']=False;self.assertFalse(validate(d)['valid'])
    def test_source_required(self):
        d=example();d['attempt_id']='';self.assertFalse(validate(d)['valid'])
if __name__=='__main__':unittest.main()
