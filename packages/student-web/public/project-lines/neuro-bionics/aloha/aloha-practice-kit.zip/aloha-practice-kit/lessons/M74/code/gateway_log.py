"""Inspect a retained ExecutionGateway event wrapper; never certify physical truth."""
import json,math,re

def validate_gateway_log(path,run):
 with open(path) as f:d=json.load(f)
 def need(ok,message):
  if not ok:raise ValueError('Gateway log: '+message)
 def nonempty(x):return isinstance(x,str) and bool(x.strip())
 def numeric(x):return type(x) in (int,float) and math.isfinite(x)
 need(isinstance(d,dict),'wrapper must be an object')
 need(d.get('schema')=='aloha.gateway-log.v1','wrong schema')
 for key,expected in [('run_id',run['run_id']),('attempt_id',run['trial_id']),('policy_artifact_sha256',run['observed_versions']['model_manifest_sha256']),('hardware_manifest_sha256',run['observed_versions']['hardware_manifest_sha256'])]:need(d.get(key)==expected,key+' differs from run')
 expected='learner_policy_execution' if run['source_kind']=='learner_recording' else 'synthetic_fixture'
 need(d.get('source_kind')==expected,'source provenance differs from run')
 need(nonempty(d.get('hardware_revision')),'hardware_revision required')
 events=d.get('events');need(isinstance(events,list) and len(events)>=3,'retain complete arm/command/latch sequence')
 need(all(isinstance(e,dict) for e in events),'every event must be an object')
 need(events[0].get('event')=='manual_arm' and events[-1].get('event')=='latched','first arm and final latch required')
 need(sum(e.get('event')=='manual_arm' for e in events)==1,'one arm per attempt; retain rearm as another attempt')
 for key in ('stop_test_reference','configuration_reference'):need(nonempty(events[0].get(key)),key+' required')
 last_seq=-1;last_time=None;commands=0;joint_keys=None;latched=False
 for event in events[1:]:
  kind=event.get('event')
  if kind=='latched':
   need(not latched,'duplicate latch');latched=True
   need(nonempty(event.get('reason')) and type(event.get('stop_callback_returned')) is bool,'invalid native latch fields')
   continue
  need(kind=='command' and not latched,'unknown event or command after latch')
  need(event.get('source')=='policy','autonomous run contains non-policy command')
  seq=event.get('sequence');need(type(seq) is int and seq>last_seq,'sequence must increase');last_seq=seq
  moment=event.get('monotonic_send_end');need(numeric(moment) and (last_time is None or moment>last_time),'command time must increase');last_time=moment
  for key in ('requested','observed_state','gateway_target','driver_returned_sent_action'):
   values=event.get(key);need(isinstance(values,dict) and bool(values),'missing joint values: '+key)
   if joint_keys is None:joint_keys=set(values)
   need(set(values)==joint_keys and all(nonempty(k) and numeric(v) for k,v in values.items()),'inconsistent/nonfinite joints: '+key)
  commands+=1
 need(commands>0,'no actual policy command retained')
 end=d.get('termination',{});need(isinstance(end,dict),'termination must be an object');need(end.get('gateway_event_index')==len(events)-1,'termination must reference native final latch')
 need(nonempty(end.get('reason')) and nonempty(end.get('note')) and type(end.get('supervisor_observed_stop')) is bool,'explicit human stop observation required')
 if run.get('status')=='completed':need(end['supervisor_observed_stop'] and events[-1]['stop_callback_returned'],'completed outcome needs recorded observed stop; callback alone is insufficient')
 if 'clock' in d:
  need(isinstance(d['clock'],dict),'clock must be an object')
  need(d['clock'].get('monotonic_scope')=='one_process' and d['clock'].get('wall_time_source')=='host_clock','clock metadata must retain its limited meaning')
 return {'commands':commands,'first_sequence':next(e['sequence'] for e in events if e['event']=='command'),'last_sequence':last_seq,'physical_truth_certified':False}
