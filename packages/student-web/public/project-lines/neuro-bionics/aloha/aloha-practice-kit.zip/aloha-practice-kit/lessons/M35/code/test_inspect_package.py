import unittest,tempfile,json,hashlib
from pathlib import Path
from test_package import Fake,C
from export_native import extract,write_new
from inspect_package import inspect

def fixture(root):
 write_new(root/'teaching',extract(Fake(),C),C)
 (root/'raw').mkdir();(root/'audit').mkdir();(root/'raw/source.synthetic.txt').write_text('synthetic placeholder, not a video');(root/'audit/labels.json').write_text('{}')
 split={'valid':True,'splits':{'train':['e0'],'validation':['e1'],'test':['sealed']}}
 (root/'audit/split.json').write_text(json.dumps(split));lookup={}
 for i,role in enumerate(('train','validation')):
  source={'root':'synthetic:no-native-root','repo_id':'synthetic/source','version_reference':'synthetic:v1'}
  read={'valid':True,'cross_source_verified':True,'episode_frame_counts':{str(i):2},'source_dataset':source,'sidecar':{'valid':True,'episode_index':i,'frame_count':2,'attempt_id':f'a{i}','native_dataset_reference':'synthetic:v1'}}
  rel=f'audit/read{i}.json';(root/rel).write_text(json.dumps(read));lookup[f'e{i}']={'split':role,'native_episode_index':i,'read_report':rel,'source_refs':['raw/source.synthetic.txt'],'labels_ref':'audit/labels.json','source_dataset':source}
 files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
 index={'schema':'aloha.local-package.v1','provenance':'synthetic','files':files,'split_audit':'audit/split.json','teaching_export':'teaching','episode_lookup':lookup}
 (root/'index.json').write_text(json.dumps(index));return root/'index.json'
class InspectTests(unittest.TestCase):
 def test_good_synthetic_only_with_opt_in(self):
  with tempfile.TemporaryDirectory() as d:
   p=fixture(Path(d));self.assertTrue(inspect(p,True)['valid']);self.assertFalse(inspect(p)['valid'])
 def test_missing_file(self):
  with tempfile.TemporaryDirectory() as d:
   p=fixture(Path(d));(Path(d)/'raw/source.synthetic.txt').unlink();self.assertFalse(inspect(p,True)['valid'])
 def test_changed_file(self):
  with tempfile.TemporaryDirectory() as d:
   p=fixture(Path(d));(Path(d)/'audit/labels.json').write_text('{"changed":true}');self.assertFalse(inspect(p,True)['valid'])
 def test_unknown_timing_rejected_even_with_refreshed_hash(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);p=fixture(root);r=root/'audit/read0.json';obj=json.loads(r.read_text());obj['sidecar']['valid']=None;r.write_text(json.dumps(obj));idx=json.loads(p.read_text());idx['files']['audit/read0.json']=hashlib.sha256(r.read_bytes()).hexdigest();p.write_text(json.dumps(idx));self.assertFalse(inspect(p,True)['valid'])
 def test_swapped_roles_rejected_after_hash_refresh(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);p=fixture(root);f=root/'teaching/data/frames.jsonl';rows=[json.loads(x) for x in f.read_text().splitlines()]
   for r in rows:r['split']='validation' if r['split']=='train' else 'train'
   f.write_text('\n'.join(json.dumps(r) for r in rows)+'\n');m=root/'teaching/manifest.json';manifest=json.loads(m.read_text());manifest['sha256']=hashlib.sha256(f.read_bytes()).hexdigest();m.write_text(json.dumps(manifest));idx=json.loads(p.read_text())
   for rel in ('teaching/manifest.json','teaching/data/frames.jsonl'):idx['files'][rel]=hashlib.sha256((root/rel).read_bytes()).hexdigest()
   p.write_text(json.dumps(idx));self.assertFalse(inspect(p,True)['valid'])
 def test_mismatched_version_rejected_after_hash_refresh(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);p=fixture(root);r=root/'audit/read0.json';obj=json.loads(r.read_text());obj['sidecar']['native_dataset_reference']='other:v2';r.write_text(json.dumps(obj));idx=json.loads(p.read_text());idx['files']['audit/read0.json']=hashlib.sha256(r.read_bytes()).hexdigest();p.write_text(json.dumps(idx));self.assertFalse(inspect(p,True)['valid'])
 def test_escape_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=fixture(Path(d));obj=json.loads(p.read_text());obj['files']['../outside']='0'*64;p.write_text(json.dumps(obj));self.assertFalse(inspect(p,True)['valid'])
if __name__=='__main__':unittest.main()
