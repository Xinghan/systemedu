# M76 实际输入、操作与恢复

从解压后的实践包根目录运行；保留 lessons/M73–M78 的相邻目录，入口通过同包相对路径复用 M74 的唯一审核。Python 3.12 标准库足够运行本批证据/统计工具；真实 ACT 的加载、处理器与设备环境仍沿用 M69–M72 固定实现，不能用本批轻量环境替代。

所有输出新建、不覆盖。空白模板只说明输入字段，不能直接充当真实成绩。synthetic 仅软件夹具，永不性能达标；learner_recording 是来源声明，摘要一致不认证现场真实性。保存整个证据根目录，相对路径随包移动。单独拷贝一个Python文件会丢失跨节点审核依赖。

## 从冻结计划逐项汇总

每次仍通过M75入口，不手造results。休息前关闭当前回合，恢复时核对工位/版本/停止条件。只有evaluation目的进入主表。

```sh
python lessons/M76/code/assemble_evaluation.py work/evidence/plan.json --root work/evidence --output work/evidence/evaluation.json
python lessons/M74/code/evaluation_audit.py work/evidence/evaluation.json --root work/evidence --output work/evidence/audit.json
```

complete表示二十项结构、文件与证据全部核验，accepted还检查来源声明与事前阈值；truth_certified始终false，视频和现场真实性需人复核。成功/失败是完整证据结果，unverified和not_executed都不是完成的替代。

separate_runs保留release_smoke、independent_handoff和domain_challenge等额外用途，不混主分母。程序exit 0表示完整，不必然表示性能达标；同时阅读accepted及阈值。失败报告也新建保存，不删除原执行。若版本必须变更，保留旧轮与未完成原因，另立计划。
