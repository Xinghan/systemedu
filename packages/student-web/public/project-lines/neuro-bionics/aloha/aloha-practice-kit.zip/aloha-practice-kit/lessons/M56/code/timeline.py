"""Offline action-chunk timing; no driver or policy import."""
import argparse,json,math
from pathlib import Path
def timeline(data):
    if data.get('provenance') not in ('synthetic','learner_recording'):
        raise ValueError('Declare provenance')
    fps=data['nominal_fps'];k=data['chunk_size'];n=data['n_action_steps']
    if type(k) is not int or type(n) is not int or not 1<=n<=k or not isinstance(fps,(int,float)) or isinstance(fps,bool) or not math.isfinite(fps) or fps<=0:
        raise ValueError('Require positive FPS and 1 <= action steps <= chunk size')
    times=data['decision_monotonic_s']
    if len(times)<2 or not all(isinstance(t,(int,float)) and not isinstance(t,bool) and math.isfinite(t) for t in times) or any(b<=a for a,b in zip(times,times[1:])):
        raise ValueError('At least two strictly increasing actual host decision times required')
    if data.get('temporal_ensemble_coeff') is not None and n!=1:raise ValueError('Pinned ACT temporal ensembling requires n_action_steps=1')
    rows=[]
    for t,x in enumerate(times):
        generate=(t%n==0);origin=t-t%n
        rows.append({'decision_index':t,'actual_host_time_s':x,'generate_new_chunk':generate,'prediction_origin_index':origin,'consume_chunk_offset':t-origin,'prediction_target_indices':list(range(t,t+k)) if generate else None,'elapsed_since_prediction_s':x-times[origin]})
    return {'provenance':data['provenance'],'hardware_executed':False,'nominal_period_s':1/fps,'first_to_last_target_span_s':(k-1)/fps,'nominal_requery_interval_s':n/fps,'rows':rows,'boundary':'Actual observation may be acquired each loop; queued actions do not consume newer observations until prediction. Nominal schedule is not measured inference or motor servo frequency.'}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);a=p.parse_args();print(json.dumps(timeline(json.loads(a.input.read_text())),ensure_ascii=False,indent=2,allow_nan=False))
