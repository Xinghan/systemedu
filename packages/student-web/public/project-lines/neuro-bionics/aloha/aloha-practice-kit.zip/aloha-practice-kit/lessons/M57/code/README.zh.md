# M57：同回合切片

在实践包根目录运行以下命令；需要 Python 3.10 或更新版本，仅用标准库。输出文件需使用新名字，保留旧运行与失败记录。

```sh
python3 lessons/M57/code/chunks.py lessons/M57/code/synthetic.json --request E0:1 --length 3
```

输入 episodes 为完整、从帧0连续编号的回合，complete_episode=true 是来源契约声明，需由原生完整记录支持。每帧有 frame_index、action 与 image_refs。--request 可重复构成batch，每项为回合ID:起始索引。E0:1 长度3 输出 action 三项均[3,4]，mask为false,true,true，只有第一项是真标签；不跨E1。用于本人完整开发回合的低维切片审计，image_refs仅来源引用，本工具不解码图片。M66另用真实M47图像视图准备神经网络批次。

所有预置输入为 synthetic，既非本人演示，也非实机结果。本工具只离线读取文件和计算，不驱动设备、不上传影像。本人数据的真实性与采集授权需按课程来源表核查；更改 provenance 文字不会把示例变成真实数据。
