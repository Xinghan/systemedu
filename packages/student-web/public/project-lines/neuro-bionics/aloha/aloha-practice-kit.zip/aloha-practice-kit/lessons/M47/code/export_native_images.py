"""Export a SMALL reviewed train/validation view from original local LeRobot data.

This is not the full ACT dataset and never exports the sealed test split.
Native decoding requires the pinned full LeRobot installation. Offline QA tests the
mapping/writing functions with fake tensor rows, not a real LeRobot decoder.
"""
import argparse,json,os,hashlib
from pathlib import Path
import torch
from PIL import Image
from vision_course import FIELDS,write_json
PIN='b64fe1ed9f11eeac53ee821356d2797601701054'
SEMANTICS='teleop_action_processor target'

def scalar(x):
    return int(x.item()) if hasattr(x,'item') else int(x)

def validate_contract(c):
    if c.get('source_kind')!='learner_recording' or not c.get('dataset_source'):
        raise ValueError('Reviewed learner_recording and original dataset_source required')
    if c.get('action_semantics')!=SEMANTICS:
        raise ValueError('Inspect native recording action semantics first')
    if set(c['camera_keys'])!={'front','overhead'} or len(set(c['camera_keys'].values()))!=2:
        raise ValueError('Two distinct native image keys required')
    for group in ['state_name_map','action_name_map']:
        if set(c[group])!=set(FIELDS) or len(set(c[group].values()))!=12:
            raise ValueError('Explicit unique 12-field mapping required: '+group)
    identities={}
    for native,info in c['episodes'].items():
        if str(int(native))!=native or int(native)<0:raise ValueError('Native episode index must be nonnegative integer string')
        if info['split'] not in ['train','validation']:raise ValueError('Never request sealed test episodes')
        if not info.get('episode_id') or not info.get('attempt_id'):raise ValueError('Preserve original episode/attempt identities')
        if type(info.get('episode_length'))!=int or info['episode_length']<1 or not info.get('episode_length_source'):
            raise ValueError('Original native episode length and metadata evidence required; selected frames do not establish the true tail')
        identity=info['episode_id']
        if identity in identities:raise ValueError('Repeated original episode identity')
        identities[identity]=info['split']
        frames=info['frame_indices']
        if not frames or any(type(i)!=int or i<0 for i in frames) or len(set(frames))!=len(frames):raise ValueError('Explicit distinct selected frame indices required')
        if max(frames)>=info['episode_length']:raise ValueError('Selected frame lies beyond declared native length')
    if set(identities.values())!={'train','validation'}:raise ValueError('Provide separate training and validation episodes')

def export_view(dataset,c,out):
    validate_contract(c);out=Path(out)
    if out.exists():raise ValueError('Use a new output directory; original data is read-only')
    names={}
    for key,group in [('observation.state','state_name_map'),('action','action_name_map')]:
        names[key]=dataset.features[key].get('names')
        if not isinstance(names[key],list) or set(names[key])!=set(c[group].values()):raise ValueError('Native feature names disagree: '+key)
    selected={(int(e),i) for e,v in c['episodes'].items() for i in v['frame_indices']};found=set();rows=[];sizes={};native_frames={int(e):set() for e in c['episodes']}
    out.mkdir(parents=True)
    for n in range(len(dataset)):
        r=dataset[n];episode=scalar(r['episode_index']);frame=scalar(r['frame_index'])
        if episode not in native_frames:raise ValueError('Loaded an unrequested episode')
        if frame in native_frames[episode]:raise ValueError('Repeated native frame index')
        native_frames[episode].add(frame)
        if (episode,frame) not in selected:continue
        if (episode,frame) in found:raise ValueError('Duplicate native episode/frame')
        found.add((episode,frame));info=c['episodes'][str(episode)];cameras={};digests={}
        for camera,key in c['camera_keys'].items():
            x=r[key].detach().cpu()
            if x.ndim!=3 or x.shape[0]!=3 or not torch.isfinite(x).all() or x.min()<0 or x.max()>1:raise ValueError('Expected untransformed RGB CHW float pixels in [0,1]')
            wh=[int(x.shape[2]),int(x.shape[1])]
            if camera in sizes and sizes[camera]!=wh:raise ValueError('Camera dimensions changed')
            sizes[camera]=wh
            # The saved PNG is an explicit 8-bit derived view, not an original video file.
            array=(x.permute(1,2,0)*255).round().to(torch.uint8).numpy()
            relative=f'images/e{episode}-f{frame}-{camera}.png';path=out/relative;path.parent.mkdir(exist_ok=True)
            Image.fromarray(array).save(path);cameras[camera]=relative;digests[camera]=hashlib.sha256(path.read_bytes()).hexdigest()
        row=dict(episode_id=info['episode_id'],attempt_id=info['attempt_id'],native_episode_index=episode,frame_index=frame,split=info['split'],cameras=cameras,image_sha256=digests)
        for key,group,output in [('observation.state','state_name_map','state'),('action','action_name_map','action')]:
            x=r[key].detach().cpu().tolist();row[output]=[float(x[names[key].index(c[group][name])]) for name in FIELDS]
        rows.append(row)
    if found!=selected:raise ValueError('Some selected frames absent; incomplete export preserved for diagnosis')
    for episode,frames in native_frames.items():
        if frames!=set(range(c['episodes'][str(episode)]['episode_length'])):raise ValueError('Loaded native episode frames disagree with reviewed metadata length; do not infer tail from selected frames')
    manifest=dict(schema='aloha.vision-teaching-view.v1',source_kind='learner_recording',dataset_source=c['dataset_source'],lerobot_revision=PIN,action_semantics=SEMANTICS,state_fields=FIELDS,action_fields=FIELDS,image_contract=dict(camera_names=['front','overhead'],color_order='RGB',original_wh=sizes,resize_wh=[64,64],normalization='imagenet_mean_std'),rows=rows,derivation='native untransformed decoded float RGB -> rounded 8-bit PNG; original videos remain the ACT source',sealed_test_loaded=False)
    manifest['episode_lengths']={v['episode_id']:v['episode_length'] for v in c['episodes'].values()}
    manifest['episode_length_sources']={v['episode_id']:v['episode_length_source'] for v in c['episodes'].values()}
    write_json(out/'manifest.json',manifest);write_json(out/'export-contract.json',c);return manifest

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--repo-id',required=True);p.add_argument('--contract',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    c=json.loads(Path(a.contract).read_text());validate_contract(c);root=Path(a.root).resolve()
    if not (root/'meta/info.json').is_file():raise SystemExit('Original local LeRobot dataset missing; M35 numeric export is not an image dataset')
    os.environ['HF_HUB_OFFLINE']='1';os.environ['HF_DATASETS_OFFLINE']='1'
    from lerobot.datasets.lerobot_dataset import LeRobotDataset
    dataset=LeRobotDataset(a.repo_id,root=root,episodes=[int(x) for x in c['episodes']],image_transforms=None,download_videos=False)
    result=export_view(dataset,c,a.output);print(json.dumps({'frames':len(result['rows']),'source':result['dataset_source'],'hardware_output':False},ensure_ascii=False,indent=2))
