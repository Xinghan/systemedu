#!/usr/bin/env python3
"""Transparent full-batch scalar MSE updates. Offline; does not load test or drive robots."""
import argparse,csv,hashlib,json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M38/code'))
from scalar_predictor import predict,finite
from make_slice import make,FIELDS

def statistics(data,weight,bias):
    result=predict(data,weight,bias);rows=result['rows'];n=len(rows)
    squared=[finite(r['signed_error']**2) for r in rows]
    gw=[finite(2*r['signed_error']*r['x']) for r in rows]
    gb=[finite(2*r['signed_error']) for r in rows]
    return {'loss':finite(math.fsum(squared)/n),'gradient_weight':finite(math.fsum(gw)/n),
            'gradient_bias':finite(math.fsum(gb)/n),'rows':rows,'count':n}

def difference_check(data,weight,bias,epsilon):
    epsilon=finite(epsilon)
    if epsilon<=0:raise ValueError('epsilon must be positive')
    base=statistics(data,weight,bias);answer={'epsilon':epsilon,'analytic':{k:base[k] for k in ('gradient_weight','gradient_bias')},'coordinates':{}}
    for name,at in [('weight',0),('bias',1)]:
        plus=[finite(weight),finite(bias)];minus=list(plus);plus[at]+=epsilon;minus[at]-=epsilon
        if plus[at]==minus[at]:raise ValueError('epsilon is too small to change the parameter in floating point')
        a=statistics(data,*plus)['loss'];b=statistics(data,*minus)['loss'];slope=finite((a-b)/(2*epsilon));exact=base['gradient_'+name]
        answer['coordinates'][name]={'plus_loss':a,'minus_loss':b,'central_difference':slope,
            'analytic_gradient':exact,'absolute_error':abs(slope-exact),
            'scaled_error':abs(slope-exact)/max(1,abs(slope),abs(exact))}
    return answer

def train(data,weight,bias,learning_rate,steps,max_loss=1e12):
    weight,bias,learning_rate,max_loss=map(finite,(weight,bias,learning_rate,max_loss))
    if learning_rate<=0 or max_loss<=0:raise ValueError('learning rate and max_loss must be positive')
    if type(steps) is not int or not 0<=steps<=2000:raise ValueError('steps must be an integer from 0 to 2000')
    trace=[];status='completed_requested_steps';rejected=None
    for step in range(steps+1):
        try:stat=statistics(data,weight,bias)
        except (ValueError,OverflowError) as e:
            if not trace:raise
            status='nonfinite_update_rejected';rejected={'step':step,'reason':str(e)};break
        trace.append({'step':step,'weight':weight,'bias':bias,'loss':stat['loss'],
                      'gradient_weight':stat['gradient_weight'],'gradient_bias':stat['gradient_bias']})
        if stat['loss']>max_loss:status='loss_budget_stop';break
        if step==steps:break
        # Both gradients were computed above at the same old (weight, bias).
        try:
            next_weight=finite(weight-learning_rate*stat['gradient_weight'])
            next_bias=finite(bias-learning_rate*stat['gradient_bias'])
        except (ValueError,OverflowError) as e:
            status='nonfinite_update_rejected';rejected={'step':step+1,'reason':str(e)};break
        weight,bias=next_weight,next_bias
    final=trace[-1]
    return {'learning_rate':learning_rate,'requested_steps':steps,'completed_updates':final['step'],
            'max_loss':max_loss,'status':status,'rejected_update':rejected,'trace':trace,
            'final_prediction':predict(data,final['weight'],final['bias']),
            'hardware_command':False,'meaning':'training MSE only; no held-out or physical task claim'}

def loss_svg(runs):
    max_step=max(max(r['step'] for r in run['trace']) for run in runs) or 1
    ymax=max(max(r['loss'] for r in run['trace']) for run in runs) or 1
    colors=['#276f9e','#bf673d','#4d8557','#875ca6']
    elements=['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="560" viewBox="0 0 1000 560">',
              '<rect width="1000" height="560" fill="#FAF9F5"/>',
              '<g font-family="sans-serif" fill="#191814"><text x="70" y="30" font-size="21">Full-batch training MSE / shared linear axes / offline</text>']
    for j in range(5):
        y=435-j*85;value=ymax*j/4
        elements.append(f'<path d="M110 {y} H920" stroke="#ddd6c7"/><text x="100" y="{y+5}" text-anchor="end" font-size="13">{value:.5g}</text>')
    elements.append('<path d="M110 70 V435 H920" stroke="#191814" fill="none"/>')
    for i,run in enumerate(runs):
        points=' '.join(f'{110+810*r["step"]/max_step:.3f},{435-340*r["loss"]/ymax:.3f}' for r in run['trace'])
        elements.append(f'<polyline points="{points}" fill="none" stroke="{colors[i]}" stroke-width="2.5"/>')
        for r in run['trace']:
            elements.append(f'<circle cx="{110+810*r["step"]/max_step:.3f}" cy="{435-340*r["loss"]/ymax:.3f}" r="2.5" fill="{colors[i]}"/>')
        elements.append(f'<text x="{110+(i%2)*420}" y="{492+(i//2)*25}" font-size="14" fill="{colors[i]}">rate {run["learning_rate"]:g}: {run["status"]}</text>')
    elements.extend([f'<text x="110" y="456" font-size="13">0</text><text x="920" y="456" text-anchor="end" font-size="13">{max_step}</text>',
                    '<text x="515" y="474" text-anchor="middle" font-size="14">Completed parameter updates</text></g></svg>'])
    return ''.join(elements)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization')
    p.add_argument('--field',choices=FIELDS,required=True);p.add_argument('--episode');p.add_argument('--weight',type=float,default=0);p.add_argument('--bias',type=float,default=0)
    p.add_argument('--rates',type=float,nargs='+',required=True);p.add_argument('--steps',type=int,default=20);p.add_argument('--epsilon',type=float,default=1e-4)
    p.add_argument('--max-loss',type=float,default=1e12);p.add_argument('--out',required=True);p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
    try:
        if not 1<=len(a.rates)<=4 or len(set(a.rates))!=len(a.rates):raise ValueError('Choose 1–4 distinct learning rates')
        data=make(a.package,a.normalization,a.field,a.episode,a.allow_synthetic)
        runs=[train(data,a.weight,a.bias,r,a.steps,a.max_loss) for r in a.rates]
        one={**data,'rows':[data['rows'][0]]}
        check=difference_check(data,a.weight,a.bias,a.epsilon)
        first=difference_check(one,a.weight,a.bias,a.epsilon)
        report={'source':data['provenance'],'normalization_sha256':data['normalization_sha256'],
                'feature':data['feature'],'target':data['target'],'frame_count':len(data['rows']),
                'slice_sha256':hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest(),
                'initial':{'weight':a.weight,'bias':a.bias},'full_batch_difference_check':check,
                'first_sample_handcheck':{'identity':{k:data['rows'][0][k] for k in ('episode_id','attempt_id','frame_index')},
                                         'x':data['rows'][0]['x'],'target':data['rows'][0]['target'],'calculation':first},
                'runs':[{k:v for k,v in r.items() if k!='final_prediction'} for r in runs],
                'hardware_command':False,'test_opened':False}
        output=Path(a.out);output.mkdir(parents=True,exist_ok=False)
        def dump(name,value):
            with (output/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
        dump('training.json',report)
        for i,run in enumerate(runs):
            dump(f'prediction-run-{i+1}.json',run['final_prediction'])
            with (output/f'trace-run-{i+1}.csv').open('x',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(run['trace'][0]));w.writeheader();w.writerows(run['trace'])
        (output/'loss-curves.svg').write_text(loss_svg(runs));print('Saved offline training traces:',output)
    except (OSError,ValueError,TypeError,KeyError,OverflowError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
