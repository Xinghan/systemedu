import csv,unittest
from pathlib import Path
from check_index import check
def rows():
    with (Path(__file__).parent/'episode-index.synthetic.csv').open(newline='') as f:return list(csv.DictReader(f))
class TestIndex(unittest.TestCase):
    def test_empty_index_is_incomplete(self):self.assertFalse(check([])['valid'])
    def test_keep_archive(self):
        r=check(rows());self.assertTrue(r['valid']);self.assertEqual(r['archive_rows'],3);self.assertEqual(r['candidate_attempt_ids'],['demo-A']);self.assertIsNone(r['model_success_rate'])
    def test_missing_reason(self):
        d=rows();d[1]['decision_reason']='';self.assertFalse(check(d)['valid'])
    def test_unknown_cannot_pass(self):
        d=rows();d[2]['training_candidate']='yes';self.assertFalse(check(d)['valid'])
    def test_duplicate_attempt(self):
        d=rows();d[1]['attempt_id']=d[0]['attempt_id'];self.assertFalse(check(d)['valid'])
    def test_unsaved_candidate_rejected(self):
        d=rows();d[0]['episode_index']='not_saved';r=check(d);self.assertFalse(r['valid']);self.assertEqual(r['candidate_attempt_ids'],[])
    def test_invalid_episode_identity(self):
        for value in ('banana','-1','1.2'):
            d=rows();d[0]['episode_index']=value;self.assertFalse(check(d)['valid'])
    def test_unsaved_archive_retained(self):
        d=rows();d[1]['episode_index']='not_saved';self.assertTrue(check(d)['valid'])
    def test_no_invented_semantic_pass(self):
        self.assertFalse(check(rows())['labels_semantically_verified'])
if __name__=='__main__':unittest.main()
