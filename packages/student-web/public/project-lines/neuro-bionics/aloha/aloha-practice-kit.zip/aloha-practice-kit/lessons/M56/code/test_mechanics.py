import copy
import importlib.util
import json
import math
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
def module(mid,name):
    spec=importlib.util.spec_from_file_location(name,ROOT/mid/'code'/f'{name}.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
T=module('M56','timeline');C=module('M57','chunks');E=module('M58','ensemble')
S=module('M59','scheduler');D=module('M60','diversity');R=module('M62','reparameterize')
K=module('M63','kl_audit');O=module('M64','objective')
def fixture(mid):return json.loads((ROOT/mid/'code/synthetic.json').read_text())
class Mechanics(unittest.TestCase):
    def test_queue_timing(self):
        r=T.timeline(fixture('M56'));self.assertEqual([x['prediction_origin_index'] for x in r['rows']],[0,0,2,2,4]);self.assertAlmostEqual(r['first_to_last_target_span_s'],.3);self.assertAlmostEqual(r['rows'][3]['elapsed_since_prediction_s'],.1)
    def test_ensemble_configuration(self):
        d=fixture('M56');d['temporal_ensemble_coeff']=.01
        with self.assertRaises(ValueError):T.timeline(d)
    def test_rewinding_time(self):
        d=fixture('M56');d['decision_monotonic_s']=[3,2]
        with self.assertRaises(ValueError):T.timeline(d)
    def test_no_cross_episode(self):
        r=C.make_batch(fixture('M57'),[{'episode_id':'E0','start':1}],3)
        self.assertEqual(r['batch'][0]['actions'],[[3,4]]*3);self.assertEqual(r['batch'][0]['action_is_pad'],[False,True,True])
    def test_incomplete_export_is_not_tail(self):
        d=fixture('M57');d['episodes'][0]['complete_episode']=False
        with self.assertRaises(ValueError):C.make_batch(d,[{'episode_id':'E0','start':1}],3)
    def test_single_frame_episode(self):
        r=C.make_batch(fixture('M57'),[{'episode_id':'E1','start':0}],3)
        self.assertEqual(r['shape'],[1,3,2]);self.assertEqual(r['batch'][0]['actions'],[[90,91]]*3)
    def test_oldest_weighted(self):
        r=E.ensemble(fixture('M58'));self.assertAlmostEqual(r['weights'][0],4/7);self.assertAlmostEqual(r['action'][0],86/7)
    def test_same_target_required(self):
        d=fixture('M58');d['predictions'][0]['target_index']=99
        with self.assertRaises(ValueError):E.ensemble(d)
    def test_coefficient_zero(self):
        d=fixture('M58');d['coefficient']=0;r=E.ensemble(d);self.assertAlmostEqual(r['action'][0],14)
    def test_negative_prefers_newer(self):
        d=fixture('M58');d['coefficient']=-math.log(2);r=E.ensemble(d);self.assertGreater(r['weights'][-1],r['weights'][0])
    def test_scheduler_reset_clears(self):
        r=S.run(fixture('M59'));self.assertEqual(r['log'][-1]['status'],'rejected');self.assertEqual(r['log'][-2]['history_size'],0)
    def test_scheduler_reject_stale(self):
        s=S.Scheduler(2,2,max_observation_age_s=.5);s.event({'op':'observe','at_s':0});s.event({'op':'predict','at_s':.1,'actions':[[1],[2]]})
        with self.assertRaises(S.ProtocolError):s.event({'op':'consume','at_s':1})
        with self.assertRaises(S.ProtocolError):s.event({'op':'observe','at_s':1.1})
        self.assertEqual(s.event({'op':'reset','at_s':1.2})['queue_size'],0)
    def test_density_unequal_bins(self):
        rows=[{'episode_id':str(i),'group':'g','channel':'x','unit':'mm','source_ref':'synthetic','value':str(v)} for i,v in enumerate([.5,.5,2,2])]
        r=D.summarize(rows,[0,1,3],'synthetic')['groups'][0]
        self.assertEqual([x['density_height'] for x in r['bins']],[.5,.25]);self.assertEqual(sum(x['density_height']*(x['right']-x['left']) for x in r['bins']),1)
    def test_no_duplicate_episode_samples(self):
        row={'episode_id':'E','group':'g','channel':'x','unit':'mm','source_ref':'s','value':'1'}
        with self.assertRaises(ValueError):D.summarize([row,row],[0,2],'synthetic')
    def test_fixed_noise_gradient(self):
        r=R.experiment(fixture('M62'));self.assertAlmostEqual(r['sample'],0);self.assertAlmostEqual(r['finite_difference']['d_sample_d_mean'],1,places=7);self.assertAlmostEqual(r['finite_difference']['d_sample_d_log_variance'],-.5,places=7)
    def test_KL_batch_reduction(self):
        r=K.audit(fixture('M63'));self.assertAlmostEqual(r['sum_latent_per_sample'][0],1.3068528194400546);self.assertAlmostEqual(r['sum_latent_per_sample'][1],2);self.assertAlmostEqual(r['mean_batch'],1.6534264097200273)
    def test_KL_zero(self):
        r=K.audit({'provenance':'synthetic','source_ref':'same','mu':[[0,0]],'log_variance':[[0,0]]});self.assertEqual(r['mean_batch'],0)
    def test_L1_valid_coordinate_denominator(self):
        r=O.objective(fixture('M64'));self.assertEqual(r['l1_denominator'],6);self.assertEqual(r['l1_numerator'],9);self.assertEqual(r['l1'],1.5)
    def test_padding_invariant(self):
        d=fixture('M64');a=O.objective(d);d['prediction'][0][1]=[123456,789123];self.assertEqual(O.objective(d)['total'],a['total'])
    def test_ELBO_identity_and_Bayes(self):
        r=O.table_example();self.assertEqual(r['p_z_given_A'],[.8,.2]);self.assertAlmostEqual(r['identity_residual'],0,places=12);self.assertLess(r['ELBO'],r['log_evidence'])
    def test_ensemble_k1_still_requires_new_observation(self):
        s=S.Scheduler(1,1,mode='ensemble');s.event({'op':'observe','at_s':0})
        s.event({'op':'predict','at_s':.01,'actions':[[1]]});s.event({'op':'consume','at_s':.02})
        self.assertEqual(s.history,[])
        with self.assertRaisesRegex(S.ProtocolError,'new observation'):
            s.event({'op':'predict','at_s':.03,'actions':[[2]]})
    def test_ensemble_k1_new_observation_and_reset(self):
        s=S.Scheduler(1,1,mode='ensemble')
        for t in [0,.1]:
            s.event({'op':'observe','at_s':t});s.event({'op':'predict','at_s':t+.01,'actions':[[1]]})
            self.assertEqual(s.event({'op':'consume','at_s':t+.02})['action'],[1])
        s.event({'op':'reset','at_s':.2});self.assertIsNone(s.last_prediction_observation)
    def test_sampling_underflow_refused(self):
        d=fixture('M62');d['log_variance']=-2000
        with self.assertRaises(ValueError):R.experiment(d)
    def test_KL_underflow_refused(self):
        d=fixture('M63');d['log_variance'][0][0]=-2000
        with self.assertRaises(ValueError):K.audit(d)
    def test_KL_finite_input_overflow_refused(self):
        d=fixture('M63');d['mu'][0][0]=1e308
        with self.assertRaises(ValueError):K.audit(d)
    def test_objective_total_overflow_refused(self):
        d=fixture('M64');d['beta']=1e308;d['kl_mean_batch']=1e308
        with self.assertRaises(ValueError):O.objective(d)

if __name__=='__main__':unittest.main(verbosity=2)
