"""Synthetic unit tests only; M74 evaluator is stubbed at this boundary."""
import copy,json,sys,tempfile,unittest
from datetime import datetime,timezone
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
for node in ('M74','M75','M79','M80','M81','M82'):sys.path.insert(0,str(BASE/node/'code'))
from freeze_plan import freeze_plan
from run_record import start_run,close_run
from synthetic_gateway_fixture import synthetic_gateway
from evidence_files import sha,verify_file
from revision_audit import audit_revision,IMPACTS
from release_audit import audit_release,VERSION_KEYS
from handoff_audit import audit_handoff,STAGES,OUTCOMES
from claims_audit import audit_claims

class Artifacts(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='aloha-final-unit-');self.root=Path(self.tmp.name).resolve();self.files=[]
  self.leaf=self.put('leaf','synthetic fixture only',kind='other')
  self.video=self.put('video','synthetic text placeholder, NOT video',kind='video')
  stamp=datetime.now(timezone.utc).isoformat()
  self.outcome=self.put('outcome',{'status':'failed','started_at':stamp,'ended_at':stamp,'duration_s':0,'tray_held':False,'block_in_tray':False,'human_intervention':False,'failure_reason':'SYNTHETIC failed observation','interventions':[]},kind='outcome_note')
  versions={};bindings={}
  for key,slot in VERSION_KEYS.items():
   item=self.put(slot,{'files':[self.leaf]} if slot.endswith('_manifest') else {'synthetic':True})
   bindings[slot]=item['id'];versions[key]=item['sha256']
  evaluation=self.put('evaluation',{'frozen_versions':versions,'source_kind':'synthetic'})
  draft={'evaluation_id':'synthetic-test','source_kind':'synthetic','time_limit_s':30,'version_artifacts':{slot:next(x['path'] for x in self.files if x['id']==slot) for slot in VERSION_KEYS.values()},'acceptance_threshold':{'minimum_successes':16,'maximum_interventions':0,'maximum_estops':0,'required_conditions':['all_planned_trials_executed','all_evidence_verified','frozen_versions_match']},'plan':[{'trial_id':f'trial-{i}','condition':'SYNTHETIC','initial_setup':'SYNTHETIC','sealed_test_ref':f'SYNTHETIC-{i}','evidence_requirements':['video','gateway_log','outcome_note']} for i in range(20)]}
  self.put('draft',draft);freeze_plan(self.root/'draft.json',self.root,self.root/'plan.json',1)
  def closed(tid,purpose):
   opening=start_run(self.root/'plan.json',self.root,tid,purpose=purpose,operator='peer')
   g=self.put('gateway' if purpose=='release_smoke' else 'handoff-gateway',synthetic_gateway(json.loads(Path(opening).read_text())),kind='gateway_log')
   closing=close_run(opening,self.root,self.root/self.outcome['path'],[dict(x,description='SYNTHETIC placeholder') for x in (self.video,g,self.outcome)])
   return json.loads(Path(closing).read_text())
  smoke=closed('smoke-1','release_smoke');run=self.put('smoke',smoke)
  self.release={'schema':'aloha.release.v1','release_id':'v1','source_kind':'synthetic','files':self.files.copy(),'bindings':bindings,'frozen_versions':versions,'evaluation_evidence':evaluation['id'],'smoke_run':{'run_id':smoke['run_id'],'metadata_evidence':run['id'],'evidence':['video','gateway','outcome']},'gateway_physical_checks':['leaf']}
  self.release_ref=self.put('release',self.release)
  self.newrun=self.put('newrun',closed('handoff-1','independent_handoff'))
  self.handoff={'schema':'aloha.handoff.v1','files':self.files.copy(),'stages':[{'id':i,'source_evidence':['leaf'],'checked_evidence':['leaf'],'limits':'synthetic only'} for i in STAGES],'outcomes':[{'id':i,'source_evidence':['leaf'],'checked_evidence':['leaf'],'limits':'synthetic only'} for i in OUTCOMES],'roles':{'author':'author','operator':'peer','mentor':'mentor','operator_wrote_instructions':False},'release_evidence':'release','checks':{k:{'status':'completed','observation':'synthetic observed failure','evidence':['video','handoff-gateway','outcome'] if k=='new_run' else ['leaf']} for k in ['fabrication','environment','native_data_read','training_to_weights','new_run']},'new_run_evidence':'newrun','help_log_evidence':['leaf'],'operator_feedback':['leaf']}
  self.revision={'schema':'aloha.revision.v1','source_kind':'synthetic','files':[self.leaf],'old_version':{'id':'v1','archive_evidence':['leaf'],'evaluation_id':'e1'},'new_version':{'id':'v2'},'failure_observation':{'observed':'slip after contact','hypothesis':'contact patch','evidence':['leaf']},'main_change':{'before':'narrow','after':'wide','reason':'test contact hypothesis','evidence':['leaf']},'impacts':[{'area':i,'decision':'pending','reason':'needs learner check','evidence':[]} for i in IMPACTS],'seen_test_refs':['seen-condition-1'],'new_evaluation':{'state':'not_started','resume_next':'collect fresh conditions'},'resume':{'last_completed':'synthetic design review','next_step':'real learner work required'}}
  self.claims={'schema':'aloha.claims.v1','files':[self.leaf],'sources':[{'id':s,'kind':k,'url':'https://example.invalid/synthetic','revision':'synthetic','use':'unit test only','license_evidence':['leaf']} for s,k in [('ALOHA','method'),('SO-101','design'),('LeRobot','software')]],'claims':[{'id':'c1','statement':'synthetic structure test','scope':'unit test','own_work':'authored test only','limits':'not learner evidence','evidence':['leaf'],'source_ids':['ALOHA']}],'counterexample':{'observed':'synthetic failure','unknown':'physical behavior','evidence':['leaf']},'next_question':{'change':'one factor','prediction':'synthetic effect','refuting_result':'no effect','fresh_test_plan':'new unseen conditions'},'questions_record':['leaf']}
 def tearDown(self):self.tmp.cleanup()
 def put(self,id,value,kind='other'):
  p=self.root/(id+'.json' if not isinstance(value,str) else id+'.txt');p.write_text(json.dumps(value) if not isinstance(value,str) else value)
  r={'id':id,'path':p.name,'sha256':sha(p),'kind':kind};self.files.append(r);return r
 def doc(self,d):p=self.root/'input.json';p.write_text(json.dumps(d));return p
 def evaluator(self,*args):return {'complete':True,'accepted':True,'successes':16,'planned_trials':20,'recorded_trials':20,'errors':[],'trials':[]}
 def rel(self,d=None,e=None):return audit_release(self.doc(d or self.release),self.root,evaluator=e or self.evaluator)
 def hand(self,d=None):return audit_handoff(self.doc(d or self.handoff),self.root,release_checker=lambda p,r:audit_release(p,r,evaluator=self.evaluator))
 def test_revision_pending_is_honest(self):
  r=audit_revision(self.doc(self.revision),self.root);self.assertTrue(r['structural_complete']);self.assertIsNone(r['performance_accepted']);self.assertEqual(len(r['pending_impacts']),8)
 def test_seen_test_renamed_evaluation_rejected(self):
  d=copy.deepcopy(self.revision);d['new_evaluation']={'state':'partial','evaluation_id':'e2','sealed_test_refs':['seen-condition-1'],'independence_evidence':['leaf'],'evaluation_evidence':['leaf']}
  with self.assertRaisesRegex(ValueError,'Seen test'):audit_revision(self.doc(d),self.root)
 def test_reusing_evaluation_identity_rejected(self):
  d=copy.deepcopy(self.revision);d['new_evaluation']={'state':'partial','evaluation_id':'e1'}
  with self.assertRaisesRegex(ValueError,'V1 evaluation'):audit_revision(self.doc(d),self.root)
 def test_missing_impact_rejected(self):
  d=copy.deepcopy(self.revision);d['impacts'].pop()
  with self.assertRaisesRegex(ValueError,'eight'):audit_revision(self.doc(d),self.root)
 def test_modified_archive_rejected(self):
  (self.root/self.leaf['path']).write_text('changed')
  with self.assertRaisesRegex(ValueError,'Content changed'):audit_revision(self.doc(self.revision),self.root)
 def test_synthetic_never_certifies_student(self):
  r=self.rel();self.assertEqual(r['performance_status'],'synthetic_only');self.assertEqual(r['evaluation_decision'],'passed');self.assertFalse(r['performance_accepted']);self.assertFalse(r['truth_certified'])
 def test_sixteen_complete_stays_incomplete(self):
  r=self.rel(e=lambda *a:{'complete':False,'accepted':False,'successes':16,'planned_trials':20,'recorded_trials':16,'errors':['four missing'],'trials':[]})
  self.assertEqual(r['evaluation_decision'],'incomplete');self.assertEqual(r['performance_status'],'synthetic_only');self.assertFalse(r['performance_accepted'])
 def test_version_binding_mismatch_rejected(self):
  d=copy.deepcopy(self.release);d['frozen_versions']['config_sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'actual files'):self.rel(d)
 def test_missing_video_rejected(self):
  (self.root/self.video['path']).unlink()
  with self.assertRaisesRegex(ValueError,'Missing'):self.rel()
 def test_nested_checkpoint_change_rejected(self):
  (self.root/self.leaf['path']).write_text('mutated checkpoint')
  # Remove leaf from top inventory; nested manifest must still detect it.
  d=copy.deepcopy(self.release);d['files']=[x for x in d['files'] if x['id']!='leaf']
  with self.assertRaisesRegex(ValueError,'Content changed'):self.rel(d)
 def test_outside_path_rejected(self):
  with self.assertRaisesRegex(ValueError,'inside artifact root'):verify_file(self.root,{'path':'../outside','sha256':'0'*64})
 def test_symlink_escape_rejected(self):
  p=self.root/'escape';p.symlink_to(Path(__file__).resolve())
  with self.assertRaisesRegex(ValueError,'outside evidence'):verify_file(self.root,{'path':'escape','sha256':sha(Path(__file__))})
 def test_failed_run_can_complete_handoff_not_performance(self):
  r=self.hand();self.assertTrue(r['structural_complete']);self.assertEqual(r['handoff_run_status'],'failed');self.assertFalse(r['truth_certified'])
 def test_author_cannot_be_independent_operator(self):
  d=copy.deepcopy(self.handoff);d['roles']['operator']='author'
  with self.assertRaisesRegex(ValueError,'distinct'):self.hand(d)
 def test_missing_core_outcome_rejected(self):
  d=copy.deepcopy(self.handoff);d['outcomes'].pop()
  with self.assertRaisesRegex(ValueError,'outcomes'):self.hand(d)
 def test_handoff_run_needs_video_kind(self):
  d=copy.deepcopy(self.handoff);d['checks']['new_run']['evidence']=['gateway','outcome']
  with self.assertRaisesRegex(ValueError,'video'):self.hand(d)
 def test_pending_handoff_not_complete(self):
  d=copy.deepcopy(self.handoff);d['checks']['environment']['status']='not_completed'
  self.assertFalse(self.hand(d)['structural_complete'])
 def test_claim_links_without_originality_score(self):
  r=audit_claims(self.doc(self.claims),self.root);self.assertTrue(r['structural_complete']);self.assertFalse(r['originality_scored']);self.assertFalse(r['legal_approval'])
 def test_claim_cannot_drop_source(self):
  d=copy.deepcopy(self.claims);d['claims'][0]['source_ids']=['imaginary']
  with self.assertRaisesRegex(ValueError,'Unknown claim source'):audit_claims(self.doc(d),self.root)
 def test_claim_cannot_omit_counterexample(self):
  d=copy.deepcopy(self.claims);d['counterexample']['evidence']=[]
  with self.assertRaisesRegex(ValueError,'evidence IDs'):audit_claims(self.doc(d),self.root)

if __name__=='__main__':unittest.main()
