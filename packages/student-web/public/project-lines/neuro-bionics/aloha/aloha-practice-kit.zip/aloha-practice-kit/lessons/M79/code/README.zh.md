# M79：版本谱系检查

从整套实践包根目录运行，保留 `lessons/M79/code` 与后续 `M80–M82` 相邻结构。

```sh
python lessons/M79/code/revision_audit.py my-project/revision.json --root my-project --output my-project/revision-check-01.json
```

`--output` 使用独占创建，已存在会拒绝，避免覆盖旧审核。程序只读输入，不操作机器人，不修改旧档案。成功退出表示显式结构可查；不代表新版性能通过。

先复制 `revision.template.json` 到本人目录并填写。示例中的 `REPLACE_...` 都是待填位置，空数组不能当成已经完成。导师可协助编辑JSON；主要学习任务是解释改动与证据关系，不是记字段拼写。

1. `files` 每项为 `{id, path, sha256, kind}`。路径相对 `--root`，不能越出根目录；用 `python lessons/M79/code/hash_files.py my-project relative/path` 计算实际摘要。
2. `old_version.archive_evidence` 连接不可覆盖旧材料；`failure_observation` 分开观察、假设和证据；`main_change` 写前后差异。
3. 八项 `impacts` 均需判断。`updated / checked_reuse / not_affected` 必须有证据与理由；`pending` 保留未完成，不补假文件。
4. `seen_test_refs` 记录已经影响开发的条件来源。新评价不得重复旧评价身份，也不得直接使用这些来源声称独立。
5. `new_evaluation.state` 可为 `not_started / partial / complete`。未开始写恢复步骤；开始后填写新 `evaluation_id`、`sealed_test_refs`、协作者独立性记录 `independence_evidence` 和评价文件 `evaluation_evidence`。完整状态不能仍有未处理的依赖项。

程序只核对显式ID与字节。人改名重填旧场景可能逃过ID比较，所以仍需真实协作者记录、条件描述和人工审查。`performance_accepted: null` 是有意设计：本节不根据一份改版声明批准性能。

自测：`python lessons/M79/code/test_final_artifacts.py -v`。二十项测试全部使用临时合成文件，视频字段只存明确标记的文本占位，**没有解码实际视频、安装完整LeRobot、操作机械臂或完成学生验收**。M74审核器在这些边界单测里被替身隔离；正式M80入口必须调用真正M74审核器，不准用计数旧入口替换。

真实接口合成回归另运行 `python lessons/M79/code/test_real_chain.py`：实际调用 M74 冻结与审计、M75 开始/关闭、M76 汇总、M80 发布与 M81 交接，不使用审核器替身。检查16项缺4项未完成、20项完整仍不批准合成性能、跨回合挪用和缺失证据拒绝，以及标准 manifest 叶接口兼容。它仍不是实机测试；临时文本占位不能充当本人影像。
