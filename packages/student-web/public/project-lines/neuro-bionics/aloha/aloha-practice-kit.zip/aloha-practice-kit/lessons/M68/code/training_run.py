"""Generate or run the pinned official offline training CLI, preserving a receipt.

No motor, camera, Hub upload or account is involved. --execute is deliberately
separate from reviewable command generation; output and receipt must be new.
"""
import argparse,json,os,shlex,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M67'/'code'))
from course_contract import *

def generate(request_path):
 r=validate_request(read(request_path));ds=r['dataset'];t=r['training'];p=r['policy']
 if Path(t['output_dir']).exists():raise ValueError('new training output directory required; resume uses separate command')
 flags={'dataset.repo_id':ds['repo_id'],'dataset.root':ds['root'],'dataset.episodes':list(range(len(ds['original_train_indices']))),'dataset.eval_split':0.0,'policy.type':'act','policy.push_to_hub':False,'policy.pretrained_backbone_weights':None,'wandb.enable':False,'output_dir':t['output_dir'],'steps':t['steps'],'batch_size':t['batch_size'],'seed':t['seed'],'num_workers':0,'save_freq':t['save_freq'],'log_freq':t['log_freq'],'save_checkpoint':True,'checkpoint_format':'safetensors','env_eval_freq':0,'eval_steps':0}
 flags.update({'policy.'+k:v for k,v in p.items()})
 def val(x):return json.dumps(x,separators=(',',':')) if x is None or isinstance(x,(bool,list,dict)) else str(x)
 argv=[sys.executable,'-m','lerobot.scripts.lerobot_train']+[f'--{k}={val(v)}'for k,v in flags.items()]
 return {'schema':'aloha.training-command.v1','request_sha256':sha(request_path),'request':r,'dataset_files_sha256':{name:sha(Path(ds['root'])/'meta'/name)for name in ('info.json','stats.json')},'argv':argv,'shell_preview':shlex.join(argv),'generated_only':True,'source_checked_revision':REVISION,'training_measurement_scope':'same architecture, batch, fp32 and workers=0 as M67; CLI overhead/save time can differ'}

def resume_command(pretrained,checkout,new_steps):
 pretrained=local(pretrained);check_checkout(checkout)
 for name in ('train_config.json','config.json','model.safetensors','policy_preprocessor.json','policy_postprocessor.json'):
  if not(pretrained/name).is_file():raise ValueError('missing resume policy file: '+name)
 state=pretrained.parent/'training_state'
 for name in ('training_step.json','rng_state.safetensors','optimizer_state.safetensors','optimizer_param_groups.json'):
  if not(state/name).is_file():raise ValueError('missing single-process fp32 resume state: '+name)
 cfg=read(pretrained/'train_config.json');meta=read(state/'training_step.json')
 if not positive(new_steps)or new_steps<=meta['step']:raise ValueError('new total steps must exceed saved microbatch step')
 if cfg.get('policy',{}).get('type')!='act' or cfg.get('wandb',{}).get('enable')or cfg.get('policy',{}).get('push_to_hub'):raise ValueError('resume only reviewed local ACT configuration')
 argv=[sys.executable,'-m','lerobot.scripts.lerobot_train',f'--config_path={pretrained/"train_config.json"}','--resume=true',f'--steps={new_steps}','--wandb.enable=false','--policy.push_to_hub=false']
 return {'argv':argv,'shell_preview':shlex.join(argv),'saved_step':meta['step'],'resume_inventory':inventory(pretrained.parent),'note':'Do not change batch, architecture, processors, precision or topology and call it exact continuation. Preserve original checkpoint/logs. Validate scheduler state when one exists.'}

def execute_command(command,receipt):
 req=command['request'];check_checkout(req['checkout']);receipt=Path(receipt)
 start=time.monotonic();env=dict(os.environ);env.update(HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',WANDB_MODE='disabled')
 with(receipt/'stdout-stderr.log').open('x')as log:result=subprocess.run(command['argv'],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=req['checkout'])
 outcome={'schema':'aloha.training-run.v1','request_sha256':command['request_sha256'],'source_kind':req['source_kind'],'command_sha256':sha(receipt/'command.json'),'log_sha256':sha(receipt/'stdout-stderr.log'),'returncode':result.returncode,'elapsed_s':time.monotonic()-start,'output_dir':req['training']['output_dir'],'hardware_opened':False,'task_success_claimed':False}
 write_new(receipt/'result.json',outcome)
 if result.returncode:raise RuntimeError('official trainer failed; receipt and log retained')
 return outcome

def run(request_path,receipt,execute=False):
 command=generate(request_path)
 if not execute:write_new(receipt,command);return command
 receipt=Path(receipt)
 if receipt.exists():raise ValueError('new receipt directory required')
 receipt.mkdir();command['generated_only']=False;write_new(receipt/'command.json',command)
 return execute_command(command,receipt)

def resume_run(pretrained,request_path,new_steps,receipt,execute=False):
 import copy
 req=validate_request(read(request_path));pretrained=local(pretrained)
 cfg=read(pretrained/'train_config.json');meta=read(pretrained.parent/'training_state'/'training_step.json')
 if not pretrained.is_relative_to(local(req['training']['output_dir'])/'checkpoints'):raise ValueError('resume checkpoint from another run')
 if cfg['batch_size']!=req['training']['batch_size']or cfg['dataset']['root']!=req['dataset']['root']:raise ValueError('resume batch or dataset changed')
 if any(cfg['policy'].get(k)!=v for k,v in req['policy'].items()):raise ValueError('resume policy changed')
 if meta.get('dp_world_size')!=1 or meta.get('grad_accum_steps')!=1 or meta.get('mixed_precision')!='no':raise ValueError('this course resume path is single-process fp32, one update per batch')
 cmd=resume_command(pretrained,req['checkout'],new_steps);updated=copy.deepcopy(req);updated['training']['steps']=new_steps
 receipt=Path(receipt)
 if receipt.exists():raise ValueError('new resume receipt directory required')
 receipt.mkdir();write_new(receipt/'training-request.json',updated)
 command={**cmd,'schema':'aloha.training-command.v1','request':updated,'request_sha256':sha(receipt/'training-request.json'),'previous_request_sha256':sha(request_path),'dataset_files_sha256':{name:sha(Path(req['dataset']['root'])/'meta'/name)for name in ('info.json','stats.json')},'source_checkpoint':str(pretrained.parent),'generated_only':not execute,'resume':True}
 write_new(receipt/'command.json',command)
 return execute_command(command,receipt)if execute else command

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='mode',required=True)
 q=sub.add_parser('train');q.add_argument('request');q.add_argument('receipt');q.add_argument('--execute',action='store_true')
 q=sub.add_parser('resume');q.add_argument('pretrained');q.add_argument('request');q.add_argument('new_total_steps',type=int);q.add_argument('receipt');q.add_argument('--execute',action='store_true')
 a=p.parse_args()
 if a.mode=='train':r=run(a.request,a.receipt,a.execute)
 else:r=resume_run(a.pretrained,a.request,a.new_total_steps,a.receipt,a.execute)
 print(json.dumps(r,ensure_ascii=False,indent=2))
