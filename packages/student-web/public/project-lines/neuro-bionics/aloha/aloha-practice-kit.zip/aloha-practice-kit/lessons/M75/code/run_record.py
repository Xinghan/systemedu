"""Evidence bookends only. Never imports a device driver or sends motor commands."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,uuid,re
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M74/code'))
from evaluation_audit import read,sha,text,contained,actual_versions,validate_plan,validate_outcome,verify_evidence,verify_outcome_binding,PURPOSES
from gateway_log import validate_gateway_log

def now():return datetime.now(timezone.utc).isoformat()
def write_new(path,data):
 with open(path,'x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
def start_run(plan_path,artifact_root,trial_id,*,purpose='evaluation',operator='local_operator',context_plan_path=None):
 root=Path(artifact_root).resolve();p=Path(plan_path).resolve()
 if not p.is_relative_to(root):raise ValueError('Frozen plan must be inside artifact root')
 plan=validate_plan(read(p),root);text(operator,'operator');text(trial_id,'trial_id')
 if purpose not in PURPOSES or not re.fullmatch('[A-Za-z0-9_-]+',trial_id):raise ValueError('Invalid purpose or trial ID')
 if purpose=='evaluation' and trial_id not in {x['trial_id'] for x in plan['plan']}:raise ValueError('Unplanned evaluation trial')
 run_id=uuid.uuid4().hex;folder=root/'runs'/run_id
 # Check earlier main executions, including open attempts; never silently overwrite/retry.
 if purpose=='evaluation':
  existing=[]
  for prior in (root/'runs').glob('*/start.json'):
   row=read(prior)
   if row.get('evaluation_id')==plan['evaluation_id'] and row.get('purpose')=='evaluation':existing.append((prior,row))
  planned=[x['trial_id'] for x in plan['plan']]
  if len(existing)>=20 or trial_id!=planned[len(existing)]:raise ValueError('Start the next frozen-plan trial exactly once')
  if any(not x.with_name('closed.json').is_file() for x,_ in existing):raise ValueError('Close and retain the prior run before another evaluation')
 versions,files=actual_versions(root,plan['version_artifacts'])
 record={'schema':'aloha.execution-record.v1','run_id':run_id,'evaluation_id':plan['evaluation_id'],'trial_id':trial_id,'purpose':purpose,'operator':operator,'source_kind':plan['source_kind'],'status':'open','record_opened_at':now(),'plan_path':str(p.relative_to(root)),'plan_sha256':sha(p),'observed_versions':versions,'version_artifacts':plan['version_artifacts'],'version_files':files,'hardware_commands_sent_by_recorder':False,'truth_certified':False}
 if purpose=='domain_challenge':
  if context_plan_path is None:raise ValueError('Domain challenge requires its frozen context plan')
  cp=Path(context_plan_path).resolve()
  if not cp.is_relative_to(root) or not cp.is_file():raise ValueError('Challenge plan must be inside artifact root')
  cd=read(cp)
  if cd.get('schema')!='aloha.challenge-plan.v1' or cd.get('evaluation_id')!=plan['evaluation_id'] or trial_id not in {r['trial_id'] for r in cd['trials']}:raise ValueError('Challenge plan/ID mismatch')
  record['context_plan_ref']={'path':str(cp.relative_to(root)),'sha256':sha(cp)}
 folder.mkdir(parents=True,exist_ok=False);out=folder/'start.json';write_new(out,record);return str(out)

def close_run(run_path,artifact_root,outcome_path,evidence_paths):
 """evidence_paths is [{kind,path,description}]; all hashes are computed from bytes."""
 root=Path(artifact_root).resolve();start_path=Path(run_path).resolve()
 if not start_path.is_relative_to(root):raise ValueError('Run record outside artifact root')
 start=read(start_path)
 if start.get('status')!='open':raise ValueError('Pass the original open start.json')
 closed_path=start_path.with_name('closed.json')
 if closed_path.exists():raise ValueError('Closed record is immutable; keep the earlier outcome')
 plan_path=contained(root,start['plan_path'])
 if sha(plan_path)!=start['plan_sha256']:raise ValueError('Frozen plan changed during run')
 plan=read(plan_path);version_errors=[]
 try:versions,_=actual_versions(root,start['version_artifacts'])
 except (ValueError,KeyError,TypeError,FileNotFoundError) as exc:
  version_errors.append(str(exc));versions={}
  from evaluation_audit import VERSION_SLOTS
  for key,slot in VERSION_SLOTS.items():
   try:versions[key]=sha(contained(root,start['version_artifacts'][slot]))
   except (ValueError,KeyError,FileNotFoundError):versions[key]=None
 if versions!=start['observed_versions']:version_errors.append('Versions changed during execution; retain this run and fail frozen-version audit')
 op=Path(outcome_path).resolve()
 if not op.is_relative_to(root) or not op.is_file():raise ValueError('Outcome note must exist inside artifact root')
 outcome=read(op);validate_outcome(outcome,plan['time_limit_s']);evidence=[];evidence_errors=[]
 for row in evidence_paths:
  entry={'kind':row['kind'],'path':row['path'],'sha256':None,'description':text(row['description'],'description')}
  try:entry['sha256']=sha(contained(root,row['path']))
  except (ValueError,FileNotFoundError) as exc:evidence_errors.append(str(exc))
  evidence.append(entry)
 if not any(r['kind']=='outcome_note' and r['path']==str(op.relative_to(root)) for r in evidence):raise ValueError('Include the exact observer outcome JSON as outcome_note evidence')
 try:verify_evidence(root,evidence)
 except (ValueError,KeyError,TypeError,FileNotFoundError) as exc:evidence_errors.append(str(exc))
 record=dict(start,status=outcome['status'],record_closed_at=now(),evidence=evidence,notes=outcome.get('notes',''),observed_versions=versions,version_validation_errors=version_errors,evidence_validation_errors=evidence_errors)
 for key in ('started_at','ended_at','duration_s','tray_held','block_in_tray','human_intervention','failure_reason','interventions'):record[key]=outcome[key]
 record['start_record_ref']={'path':str(start_path.relative_to(root)),'sha256':sha(start_path)}
 try:verify_outcome_binding(root,record)
 except (ValueError,KeyError,TypeError,FileNotFoundError,json.JSONDecodeError) as exc:record['evidence_validation_errors'].append(str(exc))
 for row in evidence:
  if row['kind']=='gateway_log':
   try:validate_gateway_log(contained(root,row['path']),record)
   except (ValueError,KeyError,TypeError,FileNotFoundError,json.JSONDecodeError) as exc:record['evidence_validation_errors'].append(str(exc))
 write_new(closed_path,record);return str(closed_path)

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='command',required=True);a=s.add_parser('start');a.add_argument('plan');a.add_argument('--root',required=True);a.add_argument('--trial',required=True);a.add_argument('--purpose',default='evaluation',choices=sorted(PURPOSES));a.add_argument('--operator',required=True);a.add_argument('--context-plan');c=s.add_parser('close');c.add_argument('run');c.add_argument('--root',required=True);c.add_argument('--outcome',required=True);c.add_argument('--evidence-list',required=True);args=p.parse_args()
 if args.command=='start':print(start_run(args.plan,args.root,args.trial,purpose=args.purpose,operator=args.operator,context_plan_path=args.context_plan))
 else:print(close_run(args.run,args.root,args.outcome,read(args.evidence_list)))
