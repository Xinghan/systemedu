import unittest,copy
from coverage import coverage
C={'cells':{'A':{'role':'development','status':'known','boundary':'synthetic rectangle A'},'B':{'role':'development','status':'known','boundary':'synthetic rectangle B'},'U':{'role':'development','status':'unknown','boundary':'synthetic rectangle U'},'T':{'role':'sealed_test','status':'known','boundary':'synthetic sealed T'}}}
R=[dict(attempt_id='s1',cell='A',batch_id='b1',date='synthetic-day',operator='synthetic-person',hardware_revision='synthetic-v1',training_candidate='yes',evidence_ref='synthetic:no-real-file',provenance='synthetic')]
class CoverageTests(unittest.TestCase):
    def test_zero_is_not_unknown(self):
        x=coverage(C,R);self.assertTrue(x['valid']);self.assertEqual(x['coverage']['B']['attempts'],0);self.assertIsNone(x['coverage']['U']['attempts']);self.assertEqual(x['coverage']['A']['attempt_ids'],['s1'])
    def test_repeats_do_not_add_cells(self):
        r=copy.deepcopy(R);r.append({**r[0],'attempt_id':'s2','training_candidate':'no'});x=coverage(C,r);self.assertEqual(x['coverage']['A']['attempts'],2);self.assertEqual(x['coverage']['A']['candidates'],1)
    def test_sealed_rejected(self):self.assertFalse(coverage(C,[{**R[0],'cell':'T'}])['valid'])
    def test_unknown_with_row_rejected(self):self.assertFalse(coverage(C,[{**R[0],'cell':'U'}])['valid'])
    def test_duplicate_rejected(self):self.assertFalse(coverage(C,R+R)['valid'])
    def test_mixed_provenance_rejected(self):self.assertFalse(coverage(C,R+[{**R[0],'attempt_id':'real','provenance':'learner_recording'}])['valid'])
    def test_missing_evidence_rejected(self):
        x=coverage(C,[{**R[0],'evidence_ref':''}]);self.assertFalse(x['valid']);self.assertIsNone(x['coverage'])
    def test_no_prediction(self):self.assertIsNone(coverage(C,R)['model_success_rate'])
if __name__=='__main__':unittest.main()
