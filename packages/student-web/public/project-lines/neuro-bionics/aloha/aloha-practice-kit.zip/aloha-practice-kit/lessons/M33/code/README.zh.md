# M33 · 整回合分组审计

Python 3.12 标准库。运行 `python audit_split.py splits.synthetic.json > split-audit.synthetic.json` 和 `python -m unittest -v`。示例均 synthetic，不能用于本人课程验收。

本人新建 splits.json，声明原始 source_dataset（所有 native_episode_index 都指这个未重排的原始库）、种子/固定顺序、held_out_conditions、near_duplicate_review_ref。每条保存稳定 episode_id、原生非负整数 native_episode_index、attempt_id、batch_id、lineage_id、约定完整回合内容的 content_sha256、split（train/validation/test）和 evidence_ref。摘要对象必须写明，不把共享大视频容器摘要误当每回合身份。真实文件摘要在M34计算；裁剪/转码仍同lineage。

运行 `python audit_split.py splits.json > split-audit.json`。只有exit0且valid=true才能消费输出的lerobot_episode_indices。它与根目录act_commands.py的--split接口一致：先在实践包根目录将 templates/act_config.json 复制为 student-act-config.json 并填完整，再运行 `python act_commands.py split-lerobot student-act-config.json --split lessons/M33/code/split-audit.json`（配置须按ENVIRONMENT和本人工位填写）。工具只生成待审阅命令，不自动执行；核对原始根目录与source_dataset确实一致后，才复制官方分片命令运行。原件保留，目标是新目录，push_to_hub为false。

本节检查共享尝试、批次、派生身份与精确摘要跨用途；不会自动发现所有近重复，也不会读取视频确认标签。字段可以被人填错，因此必须抽查来源。没有足够独立组时应补采或标未完成，不能造三条假身份。

规范化清单摘要用于版本比对，并非防篡改签名。新的划分需要新版本、审计、训练统计和后续结果关联。官方分片包含按所选回合聚合的统计，仍须核对它们确实只来自训练组；需要时按固定工具重算，不能沿用全量stats。
