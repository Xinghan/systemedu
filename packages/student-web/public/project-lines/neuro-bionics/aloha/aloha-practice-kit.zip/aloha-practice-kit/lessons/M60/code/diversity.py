"""Describe exported within-condition learner samples; do not infer causal latent styles."""
import argparse,csv,json,math
from collections import defaultdict
from pathlib import Path
def summarize(rows,edges,provenance):
    if provenance not in ('synthetic','learner_recording') or not rows:raise ValueError('Nonempty data with declared provenance required')
    if len(edges)<2 or not all(math.isfinite(e) for e in edges) or any(b<=a for a,b in zip(edges,edges[1:])):raise ValueError('Increasing finite bin edges required')
    groups=defaultdict(list);seen=set()
    for r in rows:
        if any(not r.get(k,'').strip() for k in ['episode_id','group','channel','unit','source_ref']):raise ValueError('Missing identity, condition group, units, or source')
        key=(r['episode_id'],r['group'],r['channel'])
        if key in seen:raise ValueError('One comparable sample per episode/group/channel; repeated frames are not independent demonstrations')
        seen.add(key);v=float(r['value'])
        if not math.isfinite(v) or not edges[0]<=v<=edges[-1]:raise ValueError('Nonfinite or out-of-range value; do not silently drop it')
        groups[(r['group'],r['channel'],r['unit'])].append((v,r))
    out=[]
    for (group,channel,unit),values in groups.items():
        xs=[v for v,r in values];n=len(xs);mean=sum(xs)/n;counts=[0]*(len(edges)-1)
        for v in xs:
            i=next(i for i,(a,b) in enumerate(zip(edges,edges[1:])) if a<=v<b or (i==len(edges)-2 and v==b));counts[i]+=1
        cumulative=0;bins=[]
        for i,count in enumerate(counts):
            cumulative+=count;bins.append({'left':edges[i],'right':edges[i+1],'count':count,'relative_frequency':count/n,'density_height':count/n/(edges[i+1]-edges[i]),'cumulative_fraction':cumulative/n})
        out.append({'group':group,'channel':channel,'unit':unit,'n_episodes':n,'mean':mean,'second_moment':sum(x*x for x in xs)/n,'population_variance':sum((x-mean)**2 for x in xs)/n,'bins':bins,'sources':[r['source_ref'] for v,r in values]})
    return {'provenance':provenance,'groups':out,'hardware_executed':False,'boundary':'Empirical descriptions under declared grouping, not a proof of identical hidden conditions, multimodal latent structure, Gaussianity, or generalization.'}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('csv',type=Path);p.add_argument('--edges',nargs='+',type=float,required=True);p.add_argument('--provenance',choices=['synthetic','learner_recording'],required=True);a=p.parse_args()
    with a.csv.open(newline='') as f:rows=list(csv.DictReader(f))
    print(json.dumps(summarize(rows,a.edges,a.provenance),ensure_ascii=False,indent=2,allow_nan=False))
