"""Measure a real local LeRobot ACT training configuration; never open robot hardware.

Single-process fp32, workers=0, no accumulation; timings are deliberately serial
and CUDA-synchronized. They do not predict a different parallel/mixed-precision run.
"""
import argparse,importlib.metadata,json,math,platform,random,statistics,time
from pathlib import Path
from course_contract import *

def summarize(samples):
 if not samples or any(not finite(x)or x<=0 for x in samples):raise ValueError('positive finite measured durations required')
 s=sorted(samples);return {'mean_s':statistics.mean(s),'median_s':statistics.median(s),'p90_s':s[math.ceil(.9*len(s))-1],'count':len(s)}
def tensor_bytes(obj):
 if hasattr(obj,'numel')and hasattr(obj,'element_size'):return obj.numel()*obj.element_size()
 if isinstance(obj,dict):return sum(tensor_bytes(v)for v in obj.values())
 if isinstance(obj,(list,tuple)):return sum(tensor_bytes(v)for v in obj)
 return 0

def benchmark(request_path):
 req=validate_request(read(request_path));check_checkout(req['checkout'])
 import torch,numpy as np
 from torch.utils.data import DataLoader
 from lerobot.datasets.factory import make_dataset
 from lerobot.policies.factory import make_policy,make_pre_post_processors
 from lerobot.optim.factory import make_optimizer_and_scheduler
 from lerobot.scripts.lerobot_train import _preprocess_dataset_batch
 seed=req['training']['seed'];random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
 cfg=official_config(req);device=cfg.policy.device
 if device=='cuda' and not torch.cuda.is_available():raise ValueError('requested CUDA is not available')
 def sync():
  if device=='cuda':torch.cuda.synchronize()
 start=time.perf_counter();dataset=make_dataset(cfg);policy=make_policy(cfg.policy,ds_meta=dataset.meta);pre,_=make_pre_post_processors(cfg.policy,dataset_stats=dataset.meta.stats)
 optimizer,scheduler=make_optimizer_and_scheduler(cfg,policy)
 if len(dataset)<cfg.batch_size:raise ValueError('train dataset smaller than batch; no silent drop-to-empty')
 loader=DataLoader(dataset,batch_size=cfg.batch_size,shuffle=True,num_workers=0,drop_last=True);iterator=iter(loader);sync();setup_s=time.perf_counter()-start
 rows=[];warm=req['training']['warmup_steps'];count=req['training']['measure_steps']
 if device=='cuda':torch.cuda.reset_peak_memory_stats()
 for step in range(warm+count):
  sync();t0=time.perf_counter()
  try:batch=next(iterator)
  except StopIteration:iterator=iter(loader);batch=next(iterator)
  t1=time.perf_counter();batch=_preprocess_dataset_batch(batch,dataset.meta.camera_keys,{},pre);sync();t2=time.perf_counter()
  optimizer.zero_grad(set_to_none=True);policy.train();loss,parts=policy(batch)
  if not torch.isfinite(loss):raise ValueError('non-finite loss: retain failure and inspect data/normalization')
  loss.backward();norm=torch.nn.utils.clip_grad_norm_(policy.parameters(),cfg.optimizer.grad_clip_norm,error_if_nonfinite=True);optimizer.step()
  if scheduler is not None:scheduler.step()
  sync();t3=time.perf_counter()
  if step>=warm:rows.append({'step':step,'load_including_decode_s':t1-t0,'preprocess_including_transfer_s':t2-t1,'forward_backward_update_s':t3-t2,'total_s':t3-t0,'loss':float(loss.detach()),'gradient_norm':float(norm),'loss_parts':parts})
  if step==warm-1 and device=='cuda':torch.cuda.reset_peak_memory_stats()
 mem={'parameter_bytes':sum(p.numel()*p.element_size()for p in policy.parameters()),'gradient_bytes':sum(p.grad.numel()*p.grad.element_size()for p in policy.parameters()if p.grad is not None),'optimizer_tensor_bytes':tensor_bytes(optimizer.state),'cuda_peak_allocated_bytes':None,'cuda_peak_reserved_bytes':None,'cuda_free_after_bytes':None,'cuda_total_bytes':None}
 if device=='cuda':
  free,total=torch.cuda.mem_get_info();mem.update(cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(),cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved(),cuda_free_after_bytes=free,cuda_total_bytes=total)
 summary={key:summarize([r[key]for r in rows])for key in ('load_including_decode_s','preprocess_including_transfer_s','forward_backward_update_s','total_s')}
 return {'schema':'aloha.resource-measurement.v1','status':'measured','candidate_id':req['candidate_id'],'source_kind':req['source_kind'],'request_sha256':sha(request_path),'request':req,'lerobot_revision':REVISION,'scope':'real installed ACT; local train-only dataset; single-process fp32 workers=0; short weights discarded; not full formal training or hardware evaluation','device':{'type':device,'name':torch.cuda.get_device_name()if device=='cuda'else platform.processor()or platform.machine(),'platform':platform.platform(),'torch':torch.__version__,'cuda_runtime':torch.version.cuda},'setup_s':setup_s,'warmup_steps':warm,'measured_steps':count,'timing':summary,'memory':mem,'samples':rows,'observed_samples_per_s':cfg.batch_size/summary['total_s']['mean_s'],'remaining_time_method':'Multiply remaining steps by measured p90; add separately measured startup, saves, validation, queue and contingency. Estimate only for this unchanged candidate.','not_measured':['separate disk-vs-codec breakdown','concurrent GPU allocations during future runs','formal checkpoint write cost','future task success']}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('request');p.add_argument('output');a=p.parse_args()
 if Path(a.output).exists():p.error('output must be new')
 try:r=benchmark(a.request)
 except Exception as e:
  write_new(a.output,{'schema':'aloha.resource-measurement.v1','status':'failed','source_kind':read(a.request).get('source_kind'),'request_sha256':sha(a.request),'error_type':type(e).__name__,'error':str(e),'hardware_opened':False});raise
 write_new(a.output,r)
