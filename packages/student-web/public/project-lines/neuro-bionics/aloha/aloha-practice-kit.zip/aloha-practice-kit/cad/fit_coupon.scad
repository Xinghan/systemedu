// Original course design. Units: mm. No SO-101 mounting dimensions are assumed.
// Measure your actual screw shank before entering this value.
measured_shank_d = undef;
clearance_candidates = [0, 0.15, 0.30, 0.45];
plate_thickness = 3;
hole_pitch = 12;
edge = 7;
$fn = 64;
assert(!is_undef(measured_shank_d) && measured_shank_d > 0,
       "Measure screw shank and set measured_shank_d. No default hardware size.");
assert(len(clearance_candidates) >= 2);
assert(hole_pitch > measured_shank_d + max(clearance_candidates) + 3);
assert(edge > (measured_shank_d + max(clearance_candidates))/2 + 2);
difference() {
    cube([2*edge + (len(clearance_candidates)-1)*hole_pitch,2*edge,plate_thickness]);
    for (i=[0:len(clearance_candidates)-1]) {
        translate([edge+i*hole_pitch,edge,-1])
            cylinder(h=plate_thickness+2,d=measured_shank_d+clearance_candidates[i]);
    }
}
// Mark holes on paper left-to-right; do not force screws through tight holes.
