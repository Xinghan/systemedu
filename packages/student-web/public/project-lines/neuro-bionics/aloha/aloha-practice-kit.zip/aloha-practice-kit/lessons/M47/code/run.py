from vision_lab import main
if __name__=='__main__':main(47)
