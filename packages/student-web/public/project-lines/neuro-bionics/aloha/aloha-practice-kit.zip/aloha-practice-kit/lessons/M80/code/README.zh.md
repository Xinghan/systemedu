# M80：发布绑定与验收状态

本工具直接调用整包 `lessons/M74/code/evaluation_audit.py` 的 `audit_evaluation(evaluation_path, artifact_root)`，不另建一个宽松的成功率判断。必须保留整包节点相邻目录。

```sh
python lessons/M80/code/release_audit.py my-project/release.json --root my-project --output my-project/release-check-01.json
```

输出文件独占创建，避免覆盖。输入采用 `release.template.json`，所有路径相对 `--root`。

- `files`: 非空实际文件表，每项含唯一 `id`、`path`、真实 `sha256`、`kind`。
- `bindings`: 分别引用 `model_manifest / hardware_manifest / config / dataset_split_manifest / software_manifest` 五项文件ID。
- 除 `config` 是叶文件，其余四种 manifest 均有非空 `files`，清单内路径也相对同一根目录。已有前作配置若格式不同，保留原件，另建包装清单引用它，不改写其原格式。模型清单包括权重和处理器，硬件包括打印版本、标定和装配记录，数据清单包括原划分，软件包括固定提交/依赖与网关源码。
- `frozen_versions` 是这五个实际文件的SHA，必须与M74冻结计划及评价一致，不能在验收之后只改一份清单。
- `evaluation_evidence` 引用 M74–M76 的 `aloha.independent-evaluation.v1` 文件。`plan_sha256` 检查原始单独计划字节，事前阈值和其他条件由M74审核器处理。
- `smoke_run` 包含 `run_id / metadata_evidence / evidence`。复用 M75 的 `start_run(..., purpose='release_smoke')` 与 `close_run(...)` 自动绑定版本；元数据需有 `run_id / purpose / source_kind / observed_versions / status`。视频、网关日志和结果说明作为三类实际证据登记，`kind` 分别为 `video / gateway_log / outcome_note`。这次联调不并入主验收。
- `metadata_evidence` 必须引用 M75 完整 `closed.json`，保留其 `start_record_ref`、计划引用和全部错误数组。检查器重读开始记录、冻结计划及每份关闭证据；`smoke_run.evidence` 中的路径、摘要、类型须与 `closed.json` 的证据集合完全相同。开始/结束身份不一致、记录保留缺失证据或版本错误、挪用另一回合文件均拒绝。`outcome_note` 的观察字段也须与关闭记录一致。四种嵌套 manifest 的叶只需实际 `path / sha256`，不要求额外文件 ID；发布顶层 `files` 仍需唯一 ID。
- `gateway_physical_checks` 引用 M72 已完成现场停止与网关记录。结构检查不会自动证明真机停止行为，导师仍需核验原证据。

判读：`structural_complete` 表示发布引用连接完整；`performance_status` 才表示实际验收状态。本人数据可为 `passed / failed / incomplete`。合成夹具始终为 `synthetic_only`，即使计算示例得到通过也不批准学生表现。`truth_certified` 永远为false，工具不做视频内容鉴真或自动行为判定。

把副本的一段视频移走，应报Missing；改错实际文件摘要，应报Content changed；版本混搭应报disagree。恢复后再运行。二十次中只有十六次结果应由M74报告incomplete，不能只看成功数。命令不启动电机，真实运行继续走M72已验证网关与现场导师流程。

可运行 `python lessons/M79/code/test_real_chain.py`，从冻结20项计划，经真实 M75/M76 API 到本节和 M81 走完合成接口链。视频只是明确标记的文本夹具，没有解码真实视频、驱动电机或批准学生性能；与使用 M74 替身的边界单测分开保存。
