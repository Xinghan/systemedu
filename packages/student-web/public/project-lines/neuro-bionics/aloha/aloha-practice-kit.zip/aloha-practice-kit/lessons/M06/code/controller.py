"""Pure offline target mapping. Teaching ranges are not hardware limits."""
import argparse
import copy
import json
import math
from pathlib import Path
import sys

JOINTS = ('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')
NAMES = tuple(f'{side}.{joint}' for side in ('left','right') for joint in JOINTS)
DEFAULT_FIELD = 'left.shoulder_pan'
DEFAULT_STEP = 5.0  # Student change: set to 3, then inspect the changed-fields report.

def validate(data):
    if not isinstance(data, dict) or data.get('schema') != 'aloha.course.channels.v1':
        raise ValueError('schema不匹配')
    if data.get('provenance') != 'synthetic' or data.get('use_degrees') is not True:
        raise ValueError('本练习只收synthetic且use_degrees为true的输入')
    rows = data.get('fields')
    if not isinstance(rows, list) or len(rows) != 12:
        raise ValueError('fields必须恰好12项')
    values = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('每项必须为字段记录')
        name = row.get('name')
        if not isinstance(name,str) or name not in NAMES or name in values:
            raise ValueError(f'未知或重复字段：{name}')
        unit = 'calibrated_0_100' if name.endswith('.gripper') else 'deg'
        if row.get('unit') != unit or row.get('quantity') != 'target':
            raise ValueError(f'单位或quantity错误：{name}')
        value = row.get('value')
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            raise ValueError(f'必须为有限数值：{name}')
        low,high = (0,100) if name.endswith('.gripper') else (-30,30)
        if not low <= value <= high:
            raise ValueError(f'超出离线练习范围[{low},{high}]：{name}')
        values[name] = value
    if set(values) != set(NAMES):
        raise ValueError('字段集合不完整')
    return values

def map_targets(data, field=DEFAULT_FIELD, step=DEFAULT_STEP):
    before = validate(data)
    if field not in NAMES or isinstance(step,bool) or not isinstance(step,(int,float)) or not math.isfinite(step):
        raise ValueError('修改参数无效')
    output = copy.deepcopy(data)
    for row in output['fields']:
        if row['name'] == field:
            row['value'] = row['value'] + step
    after = validate(output)  # Reject the entire output if the change violates the teaching contract.
    changed = [name for name in NAMES if before[name] != after[name]]
    return {'mode':'dry_run','provenance':'synthetic','hardware_output':False,
            'field':field,'step':step,'changed_fields':changed,'input':data,'output':output}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input',type=Path)
    parser.add_argument('--output',type=Path,default=Path('target-log.json'))
    parser.add_argument('--field',default=DEFAULT_FIELD)
    parser.add_argument('--step',type=float,default=DEFAULT_STEP)
    args = parser.parse_args()
    try:
        result=map_targets(json.loads(args.input.read_text(encoding='utf-8')),args.field,args.step)
        args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print('ACCEPT dry_run；改变字段：'+', '.join(result['changed_fields']))
    except (ValueError,TypeError,OSError) as exc:
        # A rejected run writes no target file; never interpret an older output as this run's result.
        print('REJECT: '+str(exc),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
