"""Small synthetic file/shape regressions. No learner evidence is fabricated."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from PIL import Image
from act_step import validate_batch, STATE,ACTION,CAMERAS
from make_synthetic import generate
from prepare_batch import prepare,VIEW_FIELDS,digest

class Contract(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        generate(self.root/'fixture');self.arrays=dict(np.load(self.root/'fixture/batch.npz',allow_pickle=False))
        self.manifest=json.loads((self.root/'fixture/manifest.json').read_text())
    def tearDown(self):self.tmp.cleanup()
    def test_shape_and_valid_count(self):
        self.assertEqual(validate_batch(self.arrays,self.manifest),(2,3));self.assertEqual((~self.arrays['action_is_pad']).sum()*12,48)
    def test_no_valid_after_pad(self):
        self.arrays['action_is_pad'][1]=[False,True,False]
        with self.assertRaises(ValueError):validate_batch(self.arrays,self.manifest)
    def test_no_frame_after_pad(self):
        self.manifest['trace'][1]['target_frame_indices'][1]=10
        with self.assertRaises(ValueError):validate_batch(self.arrays,self.manifest)
    def test_nonfinite_rejected(self):
        self.arrays[ACTION][0,0,0]=np.nan
        with self.assertRaises(ValueError):validate_batch(self.arrays,self.manifest)
    def test_wrong_current_frame(self):
        self.manifest['trace'][0]['observation_frame_index']=1
        with self.assertRaises(ValueError):validate_batch(self.arrays,self.manifest)
    def view(self):
        path=self.root/'image.png';Image.new('RGB',(40,40),(120,30,210)).save(path)
        rows=[]
        for eid,split,length in [('E0','train',3),('E1','train',1),('V','validation',2)]:
            for i in range(length):
                rows.append(dict(episode_id=eid,attempt_id='attempt-'+eid,frame_index=i,split=split,
                    state=[float(i)]*12,action=[float(i+1)]*12,
                    cameras={c:'image.png' for c in ['front','overhead']},
                    image_sha256={c:digest(path) for c in ['front','overhead']}))
        view=dict(schema='aloha.vision-teaching-view.v1',source_kind='synthetic',dataset_source='unit-test artificial RGB/rows',
            action_semantics='teleop_action_processor target',state_fields=VIEW_FIELDS,action_fields=VIEW_FIELDS,
            image_contract={'camera_names':['front','overhead'],'color_order':'RGB','original_wh':{'front':[40,40],'overhead':[40,40]}},
            rows=rows,episode_lengths={'E0':3,'E1':1,'V':2},episode_length_sources={e:'synthetic known length' for e in ['E0','E1','V']})
        request={'chunk_size':3,'split_ref':'synthetic declared splits','samples':[{'episode_id':'E0','start_frame_index':1},{'episode_id':'E1','start_frame_index':0}]}
        return view,request
    def write_view(self,view,request):
        v=self.root/'view.json';q=self.root/'request.json';v.write_text(json.dumps(view));q.write_text(json.dumps(request));return v,q
    def test_actual_file_adapter(self):
        view,request=self.view();v,q=self.write_view(view,request)
        result=prepare(v,q,self.root/'prepared',allow_synthetic=True)
        self.assertEqual(result['provenance'],'synthetic');self.assertEqual(result['trace'][0]['target_frame_indices'],[1,2,None])
        a=dict(np.load(self.root/'prepared/batch.npz',allow_pickle=False));self.assertEqual(validate_batch(a,result),(2,3))
        stats=json.loads((self.root/'prepared/preprocessing.json').read_text());self.assertEqual(stats['training_rows'],4)
        self.assertEqual(stats['training_episodes'],['E0','E1'])
    def test_missing_frame_not_tail(self):
        view,request=self.view();view['rows']=[r for r in view['rows'] if not (r['episode_id']=='E0' and r['frame_index']==2)]
        v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'missing consecutive'):prepare(v,q,self.root/'bad',True)
    def test_no_validation_update(self):
        view,request=self.view();request['samples'][0]['episode_id']='V';v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'train episodes'):prepare(v,q,self.root/'bad',True)
    def test_digest_enforced(self):
        view,request=self.view();view['rows'][1]['image_sha256']['front']='wrong';v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'digest'):prepare(v,q,self.root/'bad',True)
    def test_synthetic_opt_in(self):
        view,request=self.view();v,q=self.write_view(view,request)
        with self.assertRaises(ValueError):prepare(v,q,self.root/'bad')
    def test_attempt_alias_cannot_cross_splits(self):
        view,request=self.view()
        for row in view['rows']:
            if row['episode_id']=='V':row['attempt_id']='attempt-E0'
        v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'attempt crosses'):prepare(v,q,self.root/'bad',True)
    def test_no_test_rows_in_development_view(self):
        view,request=self.view();view['rows'][-1]['split']='test';v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'invalid frame or split'):prepare(v,q,self.root/'bad',True)
    def test_attempt_id_must_be_string(self):
        view,request=self.view();view['rows'][0]['attempt_id']=123;v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'nonempty string'):prepare(v,q,self.root/'bad',True)

    def test_same_shape_swapped_joint_names_refused(self):
        for key in ('action_field_names','state_field_names'):
            self.manifest[key] = list(reversed(self.manifest[key]))
        with self.assertRaisesRegex(ValueError,'fixed course field'):validate_batch(self.arrays,self.manifest)
    def test_boolean_measurement_not_coerced_to_float(self):
        view,request=self.view();view['rows'][0]['state'][0]=True
        v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'booleans'):prepare(v,q,self.root/'bad',True)
    def test_numeric_string_not_coerced_to_float(self):
        view,request=self.view();view['rows'][0]['action'][0]='1.0'
        v,q=self.write_view(view,request)
        with self.assertRaisesRegex(ValueError,'numeric'):prepare(v,q,self.root/'bad',True)

if __name__=='__main__':unittest.main(verbosity=2)
