"""Audit explicit whole-episode and linked-group splits; never split frames."""
import argparse,json,hashlib,re
ROLES=('train','validation','test')
def audit(document):
    if not isinstance(document,dict):return {'valid':False,'errors':['manifest must be an object'],'splits':None,'lerobot_episode_indices':None}
    if not isinstance(document.get('episodes'),list):return {'valid':False,'errors':['episodes must be a list'],'splits':None,'lerobot_episode_indices':None}
    errors=[];episodes=document.get('episodes',[]);ids={};groups={};roles={s:[] for s in ROLES};native_roles={s:[] for s in ROLES};native_seen=set()
    if not episodes:errors.append('no episodes')
    for i,e in enumerate(episodes):
        if not isinstance(e,dict):errors.append(f'episode {i}: entry must be an object');continue
        row_invalid=False
        for k in ('episode_id','attempt_id','batch_id','lineage_id','content_sha256','split','evidence_ref'):
            if not isinstance(e.get(k),str) or not e[k].strip():errors.append(f'episode {i}: invalid or missing {k}');row_invalid=True
        if row_invalid:continue
        eid=e.get('episode_id');role=e.get('split')
        native=e.get('native_episode_index')
        if type(native) is not int or native<0:errors.append(f'{eid}: invalid native_episode_index')
        elif native in native_seen:errors.append(f'{eid}: duplicate native episode index')
        else:native_seen.add(native)
        if eid in ids:errors.append(f'duplicate episode_id: {eid}')
        ids[eid]=e
        if role not in ROLES:errors.append(f'{eid}: invalid split')
        else:roles[role].append(eid);native_roles[role].append(native)
        if not re.fullmatch('[0-9a-f]{64}',str(e.get('content_sha256',''))):errors.append(f'{eid}: invalid SHA256')
        for key in ('attempt_id','batch_id','lineage_id','content_sha256'):
            value=e.get(key)
            if value:groups.setdefault((key,value),[]).append((eid,role))
    for (key,value),members in groups.items():
        if len({role for _,role in members})>1:errors.append(f'{key} group crosses splits: {value}')
    for role,values in roles.items():
        if not values:errors.append(f'no {role} episodes; do not fabricate independence')
    if not document.get('source_dataset'):errors.append('missing original source dataset identity')
    if not document.get('held_out_conditions'):errors.append('missing held-out test conditions')
    if not document.get('near_duplicate_review_ref'):errors.append('missing near-duplicate human review reference')
    if not isinstance(document.get('seed'),int) or isinstance(document.get('seed'),bool):errors.append('declare seed (or fixed manual-order seed 0)')
    digest=hashlib.sha256(json.dumps(document,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    return {'valid':not errors,'errors':errors,'splits':roles if not errors else None,'lerobot_episode_indices':native_roles if not errors else None,'source_dataset':document.get('source_dataset'),'canonical_manifest_sha256':digest,'statistics_source':'train_only','source_files_modified':False,'near_duplicates_automatically_ruled_out':False}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('manifest');a=p.parse_args();r=audit(json.load(open(a.manifest)));print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['valid'] else 1)
