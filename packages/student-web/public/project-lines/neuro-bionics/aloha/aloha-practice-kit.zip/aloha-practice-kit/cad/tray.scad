// Original course tray; mm. This is a grip tab, not a claimed SO-101 mount.
inside_x = 65;
inside_y = 45;
wall = 2.4;
floor = 2.4;
wall_height = 8;
corner_radius = 5;
// Measure jaw contact opening/area in the planned pose, then choose and test these.
grip_tab_width = undef;
grip_tab_length = undef;
grip_tab_thickness = undef;
$fn=48;
assert(!is_undef(grip_tab_width) && grip_tab_width>0,"Input measured/tested grip_tab_width");
assert(!is_undef(grip_tab_length) && grip_tab_length>0,"Input grip_tab_length");
assert(!is_undef(grip_tab_thickness) && grip_tab_thickness>0,"Input tested grip_tab_thickness");
assert(grip_tab_width < inside_y && grip_tab_thickness <= floor+wall_height);
assert(inside_x>2*corner_radius && inside_y>2*corner_radius);
module rounded_rect(x,y,r) {
    hull() for (a=[r,x-r]) for(b=[r,y-r])translate([a,b])circle(r=r);
}
union() {
    difference() {
        linear_extrude(height=floor+wall_height)
            rounded_rect(inside_x+2*wall,inside_y+2*wall,corner_radius+wall);
        translate([wall,wall,floor])linear_extrude(height=wall_height+1)
            rounded_rect(inside_x,inside_y,corner_radius);
    }
    translate([-grip_tab_length+wall,(inside_y+2*wall-grip_tab_width)/2,0])
        cube([grip_tab_length,grip_tab_width,grip_tab_thickness]);
}
