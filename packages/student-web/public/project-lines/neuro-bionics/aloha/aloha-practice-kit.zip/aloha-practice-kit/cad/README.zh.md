# 参数化打印件

这些是本课程新写的 OpenSCAD 源，单位为 mm。它们不是 SO-101 官方臂结构；四只臂使用固定 commit 的官方 SO101 文件。学生改造件的孔距、螺钉直径、夹爪接触尺寸都必须实测，`undef` 会主动阻止导出。不要把下面的演示尺寸当成 SO-101 接口。

1. 用卡尺测实际螺杆，填写 `fit_coupon.scad` 的 `measured_shank_d`。候选间隙只是试验变量。先打印试片，用手轻放配合，记录哪个孔能装入、有无晃动；不能靠强行拧入判合格。
2. 打开 `tray.scad`。用纸板试握确定接触片宽、长、厚，再输入三个 grip 参数。先检查左臂姿态下的相机可见性、桌面支撑及右夹爪路径。底板、壁和接触片为一个打印件。
3. 打开 `finger_pad.scad`，测量实际打印夹爪的安装面和孔心，逐个填 `hole_centres`；孔径取试片结果。画草图注明坐标原点，校核螺钉长度不顶到电机、不穿出接触面。先做平面 v1，再设计接触几何 v2，每版保留源文件。
4. `camera_plate.scad` 接受实测相机/支架孔位。它只是接口平板，桌面夹具和承重固定要另行核实。相机架应位于工作区外；固定后记录画面和标尺，训练与部署不移动。
5. `light_block.scad` 的长度是任务物体尺寸，不是安装尺寸。打印后称重，检查钝边，并把质量、最长力臂和受力姿态记录到载荷表；不根据堵转力矩宣称可长期负载。

在 OpenSCAD 修改参数后按 F5 预览，再 F6 渲染并导出 STL。切片先按你的材料、喷嘴和官方打印建议，保存切片工程。比较平放与立放的连接试片，记录层纹、挠度和裂纹后再选主件方向。成人负责打印热端与取件。

无硬件时可用下面**纯虚构测量**检查模型语法，只做形状预览，不打印安装到机械臂：

```sh
openscad -o /tmp/coupon-demo.stl -D 'measured_shank_d=3' cad/fit_coupon.scad
openscad -o /tmp/tray-demo.stl -D 'grip_tab_width=16' -D 'grip_tab_length=18' -D 'grip_tab_thickness=3' cad/tray.scad
openscad -o /tmp/pad-demo.stl -D 'pad_width=20' -D 'pad_length=30' -D 'tested_hole_d=3.3' -D 'hole_centres=[[10,8],[10,22]]' cad/finger_pad.scad
```

本包已检查源文件与参数保护；当前交付没有进行 OpenSCAD 渲染、切片、打印、承重或实机试配。学生应提交源文件、STL、切片工程、实测尺寸、实际打印照片以及每次改版依据。
