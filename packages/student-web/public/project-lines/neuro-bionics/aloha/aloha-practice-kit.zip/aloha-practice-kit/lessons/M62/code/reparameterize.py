#!/usr/bin/env python3
"""Numeric reparameterization and fixed-noise finite differences; no network/hardware."""
import argparse
import json
import math
import random
from pathlib import Path


def sample(mean,log_variance,noise):
    if not all(type(x) in (int,float) and math.isfinite(x) for x in (mean,log_variance,noise)):
        raise ValueError("finite real inputs required")
    std=math.exp(log_variance/2)
    value=mean+std*noise
    if std<=0 or not math.isfinite(std) or not math.isfinite(value):
        raise ValueError("sampling scale or output is not finite positive; retain failed input")
    return value


def experiment(data):
    if data.get("provenance") not in ("synthetic","learner_recording") or not data.get("source_ref"):
        raise ValueError("provenance/source_ref required")
    mean,lv,noise = data["mean"],data["log_variance"],data["fixed_noise"]
    count = data["sample_count"]
    if type(count) is not int or not 2<=count<=1000000 or type(data["seed"]) is not int:
        raise ValueError("integer sample count 2..1000000 and seed required")
    std = math.exp(lv/2)
    z = sample(mean,lv,noise)
    eps = 1e-5
    dmean = (sample(mean+eps,lv,noise)-sample(mean-eps,lv,noise))/(2*eps)
    dlv = (sample(mean,lv+eps,noise)-sample(mean,lv-eps,noise))/(2*eps)
    rng = random.Random(data["seed"])
    values = [sample(mean,lv,rng.gauss(0,1)) for _ in range(count)]
    empirical_mean = sum(values)/count
    empirical_var = sum((v-empirical_mean)**2 for v in values)/count
    target=data.get('teaching_target',1.0)
    if type(target) not in (int,float) or not math.isfinite(target):raise ValueError('finite teaching target required')
    loss=lambda m,l:.5*(sample(m,l,noise)-target)**2
    loss_slopes={'mean':(loss(mean+eps,lv)-loss(mean-eps,lv))/(2*eps),
        'log_variance':(loss(mean,lv+eps)-loss(mean,lv-eps))/(2*eps)}
    if not all(math.isfinite(v) for v in (std*std,empirical_mean,empirical_var,dmean,dlv,*loss_slopes.values())) or std*std<=0:
        raise ValueError("variance/statistics exceed finite numerical range; retain failed input")
    return {"provenance":data["provenance"],"source_ref":data["source_ref"],
        "mean":mean,"log_variance":lv,"variance":std*std,"standard_deviation":std,
        "fixed_noise":noise,"sample":z,"finite_difference":{"step":eps,"d_sample_d_mean":dmean,
            "d_sample_d_log_variance":dlv},"analytic_local_slope":{"mean":1,"log_variance":std*noise/2},
        "draws":{"count":count,"seed":data["seed"],"mean":empirical_mean,"population_variance":empirical_var},
        'teaching_half_squared_loss':{'target':target,'value':loss(mean,lv),'finite_difference_slopes':loss_slopes,
            'chain_rule_slopes':{'mean':z-target,'log_variance':(z-target)*std*noise/2},'not_ACT_reconstruction_loss':True},
        "scope":"scalar mechanism; finite sample moments differ from distribution parameters; fixed noise for perturbation test"}


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("input");p.add_argument("output")
    a=p.parse_args();result=experiment(json.loads(Path(a.input).read_text()))
    with Path(a.output).open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write("\n")
