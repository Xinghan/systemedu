# 回合边界检查

这是纯离线索引练习，不解码视频、不读取 LeRobot 数据库、不向机器人发送动作。

```sh
python episode_boundary.py episode-boundary.synthetic.json
python -m unittest test_episode_boundary.py -v
```

示例是120帧的虚构现场片段：任务为 `[0,90)`，随后复位。`index_space` 明确指本地导出的来源序列，不是直接冒充 LeRobot 回合索引。本人作业要从真实元数据与原始画面填写来源映射；如果原生任务回合不包含复位，`reset_begin` 填 null，并在独立复位日志说明位置。

复制示例，试把 `declared_count` 改成91、`reset_begin` 改成89，分别观察错误。再换本人数据。检查通过只能说明这份声明内部一致，不能证明影像真实或任务成功。大视频保留本地，来源路径或摘要作为索引。
