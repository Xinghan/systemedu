#!/usr/bin/env python3
"""Train an explicit 12→12 affine baseline, save safe weights, report untouched validation."""
import argparse,csv,hashlib,importlib.metadata,json,platform,sys
from pathlib import Path
from dataset_view import load_view,assert_compatible,physical_report,FIELDS,UNITS
from linear_layer import forward,fit,validate

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(view):return {k:view[k] for k in ('provenance','dataset_source','hardware_revision','frames_sha256','normalization_sha256','fields','units','action_semantics')}
def dump(path,value):
    with Path(path).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')

def save_checkpoint(folder,result,view,lock_file):
    import torch
    from safetensors.torch import save_file
    p=Path(folder);lock=Path(lock_file)
    if not lock.is_file():raise ValueError('Provide the fixed official uv.lock; do not invent an environment lock')
    if p.exists():raise FileExistsError('Output directory already exists; choose a new version')
    if validate(result['weight'],result['bias'])!=(12,12):raise ValueError('Production checkpoint requires 12 inputs and 12 outputs')
    p.mkdir(parents=True)
    tensors={'weight':torch.tensor(result['weight'],dtype=torch.float64),'bias':torch.tensor(result['bias'],dtype=torch.float64)}
    save_file(tensors,str(p/'model.safetensors'),metadata={'schema':'aloha.affine.v1','axis_order':'weight[out,in]','provenance':view['provenance']})
    metadata={'schema':'aloha.affine.v1','input_semantics':'observation_state','output_semantics':'teleop_processor_action',
              'weight_axes':['output','input'],'tensor_shapes':{'weight':[12,12],'bias':[12]},'dtype':'F64',
              'source':identity(view),'checkpoint_sha256':sha(p/'model.safetensors'),'normalization_fit_split':'train',
              'training_status':result['status'],'hardware_command':False,'is_act_policy':False}
    dump(p/'model.json',metadata)
    environment={'python':sys.version,'platform':platform.platform(),'packages':{name:importlib.metadata.version(name) for name in ('torch','safetensors')},
                 'upstream_lock_sha256':sha(lock),'upstream_lerobot_commit':'b64fe1ed9f11eeac53ee821356d2797601701054',
                 'verification_scope':'Offline scalar numerical training and checkpoint I/O only; full LeRobot/hardware/GPU not verified here',
                 'code_sha256':{name:sha(Path(__file__).with_name(name)) for name in ('linear_baseline.py','linear_layer.py','dataset_view.py')}}
    dump(p/'environment.json',environment);(p/'upstream-uv.lock').write_bytes(lock.read_bytes())
    with (p/'weight-table.csv').open('x',newline='') as f:
        w=csv.writer(f);w.writerow(['output_field','input_field','weight'])
        for j,name in enumerate(FIELDS):
            for i,input_name in enumerate(FIELDS):w.writerow([name,input_name,result['weight'][j][i]])
    with (p/'bias-table.csv').open('x',newline='') as f:
        w=csv.writer(f);w.writerow(['output_field','bias']);w.writerows(zip(FIELDS,result['bias']))
    return metadata

def load_checkpoint(folder,view):
    from safetensors.torch import load_file
    p=Path(folder);meta=json.loads((p/'model.json').read_text())
    if not isinstance(meta,dict):raise ValueError('Checkpoint metadata must be an object')
    if meta.get('schema')!='aloha.affine.v1' or meta.get('weight_axes')!=['output','input'] or meta.get('tensor_shapes')!={'weight':[12,12],'bias':[12]}:raise ValueError('Checkpoint architecture/axis contract differs')
    if meta.get('input_semantics')!='observation_state' or meta.get('output_semantics')!='teleop_processor_action':raise ValueError('Checkpoint semantics differ')
    if meta.get('source')!=identity(view):raise ValueError('Checkpoint source/normalization contract differs')
    if sha(p/'model.safetensors')!=meta.get('checkpoint_sha256'):raise ValueError('Checkpoint digest differs')
    tensors=load_file(str(p/'model.safetensors'),device='cpu')
    if set(tensors)!={'weight','bias'}:raise ValueError('Unexpected checkpoint keys')
    import torch
    if list(tensors['weight'].shape)!=[12,12] or list(tensors['bias'].shape)!=[12] or any(t.dtype!=torch.float64 for t in tensors.values()):raise ValueError('Tensor shapes/dtype differ')
    weights=tensors['weight'].tolist();bias=tensors['bias'].tolist();validate(weights,bias)
    return weights,bias,meta

def train_baseline(package,normalization,rate,steps,output,lock_file,allow_synthetic=False,max_loss=1e8):
    train=load_view(package,normalization,'train',allow_synthetic)
    validation=load_view(package,normalization,'validation',allow_synthetic);assert_compatible(train,validation)
    if Path(output).exists():raise FileExistsError('Output directory already exists')
    result=fit(train['rows'],12,12,rate,steps,max_loss)
    # Validation is evaluated once after training; it never enters gradient calculations.
    reports={}
    for view in (train,validation):
        predictions=[forward(r['x'],result['weight'],result['bias']) for r in view['rows']]
        reports[view['split']]=physical_report(view,predictions)
    p=Path(output);save_checkpoint(p,result,train,lock_file)
    restored_w,restored_b,_=load_checkpoint(p,train)
    if restored_w!=result['weight'] or restored_b!=result['bias']:raise ValueError('Saved weights did not round-trip exactly')
    hand=train['rows'][0];prediction,detail=forward(hand['x'],restored_w,restored_b,True)
    for j,row in enumerate(detail):
        row['output_field']=FIELDS[j]
        for term in row['terms']:term['input_field']=FIELDS[term['input_index']]
    dump(p/'forward-trace.json',{'provenance':train['provenance'],'source':identity(train),
        'frame':{k:hand[k] for k in ('episode_id','attempt_id','frame_index')},'input_standardized':hand['x'],'target_standardized':hand['y'],
        'outputs':detail,'prediction_standardized':prediction,'layout':{'batch':1,'input_fields':12,'output_fields':12,'weight':'12 output rows × 12 input columns'},
        'warning':'shape alone cannot detect transpose of a square 12×12 table; check asymmetric named terms'})
    dump(p/'training.json',{k:v for k,v in result.items() if k not in ('weight','bias')})
    dump(p/'metrics.json',{'source':identity(train),'reports':reports,'validation_use':'once after fixed training; not a selection sweep',
        'test_opened':False,'saved_loaded_exactly':True,'hardware_command':False})
    with (p/'train-loss.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(result['trace'][0]));w.writeheader();w.writerows(result['trace'])
    return {'status':result['status'],'completed_updates':result['completed_updates'],'train_frames':len(train['rows']),
            'validation_frames':len(validation['rows']),'train_mse':reports['train']['standardized_mse_all_cells'],
            'validation_mse':reports['validation']['standardized_mse_all_cells'],'saved_loaded_exactly':True,'provenance':train['provenance']}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('--rate',type=float,default=.2);p.add_argument('--steps',type=int,default=100)
    p.add_argument('--out',required=True);p.add_argument('--lock-file',default=str(Path(__file__).resolve().parents[3]/'research/lerobot/uv.lock'))
    p.add_argument('--max-loss',type=float,default=1e8);p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
    try:print(json.dumps(train_baseline(a.package,a.normalization,a.rate,a.steps,a.out,a.lock_file,a.allow_synthetic,a.max_loss),ensure_ascii=False,indent=2))
    except (OSError,ValueError,KeyError,TypeError,OverflowError,ImportError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
