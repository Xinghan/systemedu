#!/usr/bin/env python3
"""One real pinned ACT computation step, never a motor controller.

Default backend imports a full, separately installed LeRobot checkout.
--isolated-source verifies an unmodified file and extracts its original class/function
definitions for a limited CPU mechanism test. It is NOT a LeRobot installation.
"""
from __future__ import annotations
import argparse
import ast
from collections import deque
from collections.abc import Callable
import hashlib
from itertools import chain
import json
import math
from pathlib import Path
import subprocess
from types import SimpleNamespace

REVISION = "b64fe1ed9f11eeac53ee821356d2797601701054"
SOURCE_SHA256 = "8d622935319af7d03f1efd95d51e726af2921010f7e4f5ec3742f62280493111"
STATE = "observation.state"
ACTION = "action"
CAMERAS = ["observation.images.front", "observation.images.overhead"]


def dependencies():
    import numpy as np
    import torch
    return np, torch


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_batch(arrays, manifest):
    np, _ = dependencies()
    if manifest.get("provenance") not in ("synthetic", "learner_recording"):
        raise ValueError("provenance must be synthetic or learner_recording")
    for key in ("source_ref", "preprocessing_ref", "split_ref"):
        if not isinstance(manifest.get(key), str) or not manifest[key].strip():
            raise ValueError(f"missing {key}")
    if manifest.get("split") != "train":
        raise ValueError("this update tool accepts a train batch only")
    names = manifest.get("action_field_names")
    expected_names = [f"{side}_{joint}.pos" for side in ("left", "right")
        for joint in ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper")]
    if names != expected_names:
        raise ValueError("exact fixed course field names and left/right joint order required")
    if not isinstance(names, list) or len(names) != 12 or len(set(names)) != 12 or not all(isinstance(x,str) and x for x in names):
        raise ValueError("exact ordered 12 unique action field names required")
    if manifest.get("state_field_names") != names:
        raise ValueError("state and action field order must explicitly agree for this course batch")
    for key in [STATE, ACTION, *CAMERAS]:
        if key not in arrays or arrays[key].dtype.kind != "f" or not np.isfinite(arrays[key]).all():
            raise ValueError(f"{key}: finite floating point data required")
    actions = arrays[ACTION]
    if actions.ndim != 3 or actions.shape[0] < 1 or actions.shape[1] < 1 or actions.shape[2] != 12:
        raise ValueError("action must be B x K x 12")
    b, k, _ = actions.shape
    if arrays[STATE].shape != (b,12):
        raise ValueError("state must be B x 12")
    mask = arrays.get("action_is_pad")
    if mask is None or mask.dtype != np.bool_ or mask.shape != (b,k) or mask[:,0].any():
        raise ValueError("action_is_pad must be bool B x K with valid first steps")
    if ((mask[:,:-1]) & (~mask[:,1:])).any():
        raise ValueError("padding must be a tail, never valid again after pad")
    for key in CAMERAS:
        if arrays[key].shape != (b,3,32,32):
            raise ValueError("this CPU mechanism configuration requires B x 3 x 32 x 32 for both cameras")
    trace = manifest.get("trace")
    if not isinstance(trace,list) or len(trace) != b:
        raise ValueError("one trace row per batch item required")
    for i,row in enumerate(trace):
        if not isinstance(row.get("episode_id"),str) or not row["episode_id"]:
            raise ValueError("trace episode_id required")
        indices = row.get("target_frame_indices")
        if not isinstance(indices,list) or len(indices) != k:
            raise ValueError("one frame index per target required")
        count = int((~mask[i]).sum())
        valid = indices[:count]
        if any(type(v) is not int or v < 0 for v in valid) or valid != list(range(valid[0],valid[0]+count)):
            raise ValueError("valid target frame indices must be contiguous within declared episode")
        if any(v is not None for v in indices[count:]):
            raise ValueError("padded target indices must be null")
        if row.get("observation_frame_index") != valid[0]:
            raise ValueError("current observation must match first target index")
        if set(row.get("current_image_refs",{})) != set(CAMERAS) or not all(isinstance(v,str) and v for v in row["current_image_refs"].values()):
            raise ValueError("both current image provenance refs required")
    return b,k


def isolated_policy(source, chunk_size):
    """Use original ACT definitions, with only package/config integration replaced."""
    import einops
    import numpy as np
    import torch
    import torch.nn.functional as F
    import torchvision
    from torch import nn, Tensor
    from torchvision.models._utils import IntermediateLayerGetter
    from torchvision.ops.misc import FrozenBatchNorm2d
    if sha(source) != SOURCE_SHA256:
        raise ValueError("isolated source hash differs from reviewed pinned modeling_act.py")
    class Base(nn.Module):
        def __init__(self, config):
            super().__init__()
            self.config = config
    class Configuration(SimpleNamespace):
        def validate_features(self):
            if not self.image_features:
                raise ValueError("two cameras required")
    cfg = Configuration(**tiny_options(chunk_size),
        image_features={key:SimpleNamespace(shape=(3,32,32)) for key in CAMERAS},
        robot_state_feature=SimpleNamespace(shape=(12,)),
        action_feature=SimpleNamespace(shape=(12,)), env_state_feature=None)
    scope = dict(math=math,deque=deque,Callable=Callable,chain=chain,einops=einops,
        np=np,torch=torch,F=F,torchvision=torchvision,Tensor=Tensor,nn=nn,
        IntermediateLayerGetter=IntermediateLayerGetter,FrozenBatchNorm2d=FrozenBatchNorm2d,
        ACTION=ACTION,OBS_ENV_STATE="observation.environment_state",OBS_IMAGES="observation.images",
        OBS_STATE=STATE,PreTrainedPolicy=Base,ACTConfig=Configuration)
    tree = ast.parse(Path(source).read_text())
    nodes = [n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),"exec"),scope)
    return scope["ACTPolicy"](cfg), {"backend":"isolated_unmodified_ACT_definitions",
        "source_sha256":SOURCE_SHA256,"scope":"original neural network and policy loss; config/base-class integration substituted; no full LeRobot install or dataset pipeline"}


def tiny_options(chunk_size):
    return dict(chunk_size=chunk_size,n_action_steps=1,n_obs_steps=1,
        dim_model=32,n_heads=4,dim_feedforward=64,n_encoder_layers=1,n_decoder_layers=1,
        n_vae_encoder_layers=1,latent_dim=2,dropout=0.0,kl_weight=0.1,
        vision_backbone="resnet18",pretrained_backbone_weights=None,
        replace_final_stride_with_dilation=False,pre_norm=False,
        feedforward_activation="relu",use_vae=True,temporal_ensemble_coeff=None,
        optimizer_lr_backbone=1e-5)


def installed_policy(chunk_size, checkout):
    from lerobot.policies.act.configuration_act import ACTConfig
    from lerobot.policies.act.modeling_act import ACTPolicy
    import lerobot.policies.act.modeling_act as module
    from lerobot.configs.types import FeatureType,PolicyFeature
    revision = subprocess.check_output(["git","-C",str(checkout),"rev-parse","HEAD"],text=True).strip()
    if revision != REVISION or sha(module.__file__) != SOURCE_SHA256:
        raise ValueError("installed LeRobot does not match fixed revision and ACT source hash")
    if not Path(module.__file__).resolve().is_relative_to(Path(checkout).resolve()):
        raise ValueError("imported LeRobot is not from supplied checkout")
    cfg = ACTConfig(**tiny_options(chunk_size),
        input_features={STATE:PolicyFeature(type=FeatureType.STATE,shape=(12,)),
            **{key:PolicyFeature(type=FeatureType.VISUAL,shape=(3,32,32)) for key in CAMERAS}},
        output_features={ACTION:PolicyFeature(type=FeatureType.ACTION,shape=(12,))})
    return ACTPolicy(cfg), {"backend":"installed_LeRobot_ACTPolicy","revision":revision,
        "source_sha256":SOURCE_SHA256,"scope":"local one-batch mechanism experiment; not lerobot-train CLI or hardware verification"}


def run(batch_path, manifest_path, output_dir, *, isolated_source=None, checkout=None):
    np, torch = dependencies()
    torch.set_num_threads(1)
    arrays = dict(np.load(batch_path,allow_pickle=False))
    manifest = json.loads(Path(manifest_path).read_text())
    b,k = validate_batch(arrays,manifest)
    out = Path(output_dir)
    if out.exists():
        raise ValueError("output directory must not exist; keep previous evidence")
    torch.manual_seed(31)
    policy,backend = isolated_policy(isolated_source,k) if isolated_source else installed_policy(k,checkout)
    batch = {key:torch.from_numpy(value.copy()).to(dtype=torch.bool if key=="action_is_pad" else torch.float32) for key,value in arrays.items() if key in [STATE,ACTION,"action_is_pad",*CAMERAS]}
    captured = {}
    def capture_model(module,args,result):
        captured["prediction"] = result[0]
        captured["mu"],captured["logvar"] = result[1]
    hook = policy.model.register_forward_hook(capture_model)
    policy.train()
    torch.manual_seed(71)
    loss, native = policy(batch)
    prediction,mu,logvar = captured["prediction"],captured["mu"],captured["logvar"]
    mask = (~batch["action_is_pad"]).unsqueeze(-1)
    numerator = ((prediction-batch[ACTION]).abs()*mask).sum()
    denominator = mask.sum()*12
    l1 = numerator/denominator
    per_dim = -0.5*(1+logvar-mu.square()-logvar.exp())
    kl = per_dim.sum(-1).mean()
    assert torch.allclose(loss,l1+policy.config.kl_weight*kl)
    # Change only padded target values. Same random draw makes the comparison meaningful.
    padded = {key:value.clone() for key,value in batch.items()}
    padded[ACTION][batch["action_is_pad"]] = 1234.0
    torch.manual_seed(71)
    padded_loss,_ = policy(padded)
    pad_prediction_equal = torch.allclose(prediction,captured["prediction"],atol=2e-6,rtol=2e-6)
    pad_loss_equal = torch.allclose(loss,padded_loss,atol=2e-6,rtol=2e-6)
    if not (pad_prediction_equal and pad_loss_equal):
        raise RuntimeError("padding invariance failed")
    optimizer = torch.optim.AdamW(policy.parameters(),lr=1e-5,weight_decay=0.0)
    optimizer.zero_grad(set_to_none=True)
    before = policy.model.action_head.weight.detach().clone()
    loss.backward()
    gradient_norm = math.sqrt(sum(float(p.grad.detach().square().sum()) for p in policy.parameters() if p.grad is not None))
    if not math.isfinite(gradient_norm) or gradient_norm <= 0:
        raise RuntimeError("expected finite nonzero gradients")
    gradient_groups = {}
    for group,prefix in [('vision','model.backbone.'),('posterior','model.vae_encoder.'),
                         ('main_encoder','model.encoder.'),('decoder','model.decoder.'),
                         ('action_head','model.action_head.')]:
        squares = [float(p.grad.detach().square().sum()) for name,p in policy.named_parameters()
                   if name.startswith(prefix) and p.grad is not None]
        gradient_groups[group] = math.sqrt(sum(squares))
        if not squares or not math.isfinite(gradient_groups[group]) or gradient_groups[group] <= 0:
            raise RuntimeError(f"missing finite nonzero gradient in {group}")
    optimizer.step()
    delta = float((before-policy.model.action_head.weight.detach()).abs().max())
    if delta <= 0:
        raise RuntimeError("action head did not update")
    torch.manual_seed(71)
    with torch.no_grad():
        after_loss, after_native = policy(batch)
    # Evaluation branch: future labels are not supplied and posterior must not run.
    posterior_calls = []
    latent_samples = []
    hp = policy.model.vae_encoder.register_forward_hook(lambda *args:posterior_calls.append(1))
    hz = policy.model.encoder_latent_input_proj.register_forward_pre_hook(lambda mod,args:latent_samples.append(args[0].detach().clone()))
    observed = {key:value for key,value in batch.items() if key not in [ACTION,"action_is_pad"]}
    clean = policy.predict_action_chunk(observed)
    poisoned = dict(observed)
    poisoned[ACTION] = torch.full_like(batch[ACTION],9999)
    poisoned["action_is_pad"] = ~batch["action_is_pad"]
    dirty = policy.predict_action_chunk(poisoned)
    info_pass = len(latent_samples)==2 and not posterior_calls and torch.equal(clean,dirty) and all(torch.count_nonzero(x)==0 for x in latent_samples)
    hp.remove();hz.remove();hook.remove()
    if not info_pass:
        raise RuntimeError("evaluation information contract failed")
    out.mkdir(parents=True)
    posterior = {"provenance":manifest["provenance"],"source_ref":manifest["source_ref"],
        "mu":mu.detach().tolist(),"log_variance":logvar.detach().tolist(),
        "kl_per_dimension":per_dim.detach().tolist(),"trace":manifest["trace"],"backend":backend}
    (out/"posterior.json").write_text(json.dumps(posterior,ensure_ascii=False,indent=2)+"\n")
    np.savez(out/"step-arrays.npz",prediction=prediction.detach().numpy(),target=batch[ACTION].numpy(),
        action_is_pad=batch["action_is_pad"].numpy(),mu=mu.detach().numpy(),log_variance=logvar.detach().numpy(),
        eval_prediction=clean.numpy())
    report = {"provenance":manifest["provenance"],"source_ref":manifest["source_ref"],
        "input_sha256":sha(batch_path),"manifest_sha256":sha(manifest_path),"backend":backend,
        "configuration":tiny_options(k),"shape":{"batch":b,"chunk":k,"action":12,"latent":2,"cameras":2},
        "before":{"loss":float(loss.detach()),**native,"l1_numerator":float(numerator.detach()),"l1_denominator":int(denominator),"kl_sum_dimensions_mean_batch":float(kl.detach())},
        "after":{"loss":float(after_loss),**after_native},"gradient_norm":gradient_norm,
        "gradient_groups":gradient_groups,
        "action_head_max_abs_update":delta,"padded_target_prediction_invariant":bool(pad_prediction_equal),
        "padded_target_loss_invariant":bool(pad_loss_equal),"evaluation":{"posterior_calls":len(posterior_calls),
            "future_labels_ignored":torch.equal(clean,dirty),"latent_is_zero":True},
        "runtime":{"torch":str(torch.__version__),"numpy":str(np.__version__)},
        "result_scope":"one genuine ACT update with tiny CPU config; no accuracy/safety claim, no motor control, not a deployment checkpoint"}
    torch.save({"state_dict":policy.state_dict(),"configuration":tiny_options(k),"report":report,
        "mechanism_only_not_for_deployment":True},out/"mechanism-only.pt")
    # A new instance must obtain the same inference from saved weights alone.
    # weights_only=True is deliberate: this tool never loads arbitrary Python objects.
    saved = torch.load(out/"mechanism-only.pt",map_location="cpu",weights_only=True)
    if saved['configuration'] != tiny_options(k) or saved['mechanism_only_not_for_deployment'] is not True:
        raise RuntimeError("checkpoint configuration contract failed")
    reloaded,_ = isolated_policy(isolated_source,k) if isolated_source else installed_policy(k,checkout)
    reloaded.load_state_dict(saved['state_dict'],strict=True)
    reload_posterior_calls=[]
    reload_hook=reloaded.model.vae_encoder.register_forward_hook(lambda *args:reload_posterior_calls.append(1))
    reloaded_output=reloaded.predict_action_chunk(observed)
    reload_hook.remove()
    if not torch.equal(clean,reloaded_output) or reload_posterior_calls:
        raise RuntimeError("saved-weight inference did not reproduce without posterior")
    report['checkpoint_reload']={'new_instance':True,'strict_state_dict':True,
        'future_labels_supplied':False,'posterior_calls':len(reload_posterior_calls),
        'prediction_bitwise_equal':True,'checkpoint_sha256':sha(out/'mechanism-only.pt')}
    (out/"report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("batch");parser.add_argument("manifest");parser.add_argument("output")
    backend = parser.add_mutually_exclusive_group(required=True)
    backend.add_argument("--isolated-source",type=Path)
    backend.add_argument("--checkout",type=Path)
    args = parser.parse_args()
    report = run(args.batch,args.manifest,args.output,isolated_source=args.isolated_source,checkout=args.checkout)
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
