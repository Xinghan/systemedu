# 哪些能处理真实数据

| 工具 | 能用于学生真实数据的范围 | 不能据此声称什么 |
|---|---|---|
| fields | 同字段、同单位契约的实测状态表 | 没有读真实电机；不验证校准有效性 |
| sampling | 导出的真实秒级时间戳 | 不推断相机真实曝光时刻 |
| limits | 本人实测位置、请求目标、边界的离线数学审查 | 不下发；不会自动把绝对限位装到 LeRobot |
| sync | 明确时钟偏移的真实状态/图像/动作时间表 | 不凭软件接收时间证明传感器硬同步 |
| split | 真实或 synthetic 的课程 JSONL 导出，整回合/批次复制 | 不是 LeRobot 视频/Parquet 拆分器 |
| toy-train | 标量 x/y 表的真实线性模型梯度训练 | 它始终不是 ACT 或机械臂策略 |
| ensemble | 真实或 synthetic 动作块的离线加权核算 | 不验证模型能完成任务或控制平滑 |
| evaluate | 真实事前计划和全部试次结果表 | 表格不证明真实性、安全或普遍可靠性 |
| act_commands | 从学生标准 JSON 配置生成真实 LeRobot CLI argv/可复制命令 | 生成器不执行命令；字段匹配不等于安装/实机测试通过 |
| validate_act | 装好固定 LeRobot 后，用真实本地权重和验证数据计算离线推理 MAE | 本次未有真实权重做端到端运行；MAE 不等于自主成功率 |
| capture_environment | 当前 Python 环境的实际版本清单 | 空白 GPU/校准字段必须本人补；包版本不证明设备工作 |

来源中的 AST 核验和 isolated-function 检查只是源代码级证据。学生提交文件必须保留 provenance 与原始数据，不能把包内 synthetic 标记改成本人实验。
