"""Analyze exported real host-time rows; never connects to a robot."""
import argparse,csv,json,math
from pathlib import Path
from xml.sax.saxutils import escape

def analyze(rows):
    if len(rows)<2:
        raise ValueError('At least two rows required')
    units={r['unit'] for r in rows}
    if len(units)!=1 or not next(iter(units)):
        raise ValueError('Do not mix units in one response trace')
    result=[]
    for i,r in enumerate(rows):
        t,u,q=[float(r[k]) for k in ['monotonic_s','target','observed']]
        if not all(math.isfinite(v) for v in [t,u,q]):
            raise ValueError('Nonfinite value')
        if i and t<=result[-1]['monotonic_s']:
            raise ValueError('Host times must strictly increase')
        dt=t-result[-1]['monotonic_s'] if i else None
        result.append({'monotonic_s':t,'relative_s':t-float(rows[0]['monotonic_s']),
                       'target':u,'observed':q,'error_target_minus_observed':u-q,
                       'delta_time_s':dt,'finite_difference_velocity':(q-result[-1]['observed'])/dt if i else None,
                       'unit':r['unit']})
    return result

def svg(rows,provenance,max_gap_s):
    if not isinstance(max_gap_s,(int,float)) or isinstance(max_gap_s,bool) or not math.isfinite(max_gap_s) or max_gap_s<=0:
        raise ValueError('Explicit positive maximum connecting interval required')
    times=[r['relative_s'] for r in rows]
    values=[r[k] for r in rows for k in ('target','observed')]
    lo,hi=min(values)-.2,max(values)+.2
    x=lambda t:100+t/max(times)*1000
    y=lambda v:620-(v-lo)/(hi-lo)*470
    parts=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 760">',
           '<rect width="1200" height="760" fill="#faf9f5"/>',
           f'<text x="60" y="60" font-size="26">{escape(provenance)} — host arrival trace; not exposure</text>',
           '<path d="M100 130V620H1120" stroke="#191814" fill="none"/>']
    for key,color in [('target','#b85a33'),('observed','#527b95')]:
        groups=[[]]
        for r in rows:
            if groups[-1] and r['delta_time_s']>max_gap_s:groups.append([])
            groups[-1].append(r)
        for group in groups:
            pts=' '.join(f'{x(r["relative_s"]):.2f},{y(r[key]):.2f}' for r in group)
            parts.append(f'<polyline points="{pts}" stroke="{color}" stroke-width="3" fill="none"/>')
        for r in rows:
            parts.append(f'<circle cx="{x(r["relative_s"])}" cy="{y(r[key])}" r="5" fill="{color}"/>')
        parts.append(f'<text x="{120 if key=="target" else 600}" y="105" fill="{color}" font-size="24">{key}</text>')
    parts.extend([f'<text x="60" y="690" font-size="22">time: 0 to {max(times):.3f} seconds; values {lo:.2f} to {hi:.2f} {escape(rows[0]["unit"])}</text>',
                  f'<text x="60" y="730" font-size="20">No line across intervals greater than {max_gap_s:g} s; connecting samples is not observed motion.</text></svg>'])
    return ''.join(parts)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('input',type=Path);p.add_argument('--provenance',choices=['synthetic','learner_recording'],required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--max-gap-s',type=float,required=True,help='Visualization break threshold, not a device safety threshold')
    a=p.parse_args()
    if a.output.exists() or a.output.with_suffix('.svg').exists():
        p.error('Choose a new output basename; existing evidence is not overwritten')
    rows=analyze(list(csv.DictReader(a.input.open())))
    drawing=svg(rows,a.provenance,a.max_gap_s)
    a.output.write_text(json.dumps({'provenance':a.provenance,'hardware_executed':False,'max_connect_gap_s':a.max_gap_s,'rows':rows},indent=2,allow_nan=False))
    a.output.with_suffix('.svg').write_text(drawing)
