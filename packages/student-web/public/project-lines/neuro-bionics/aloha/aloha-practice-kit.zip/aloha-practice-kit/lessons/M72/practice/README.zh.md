# M72：唯一受监督策略入口

所有命令从实践包根运行，实际代码在 `lessons/M72/code/`。本课提供真实固定ACT→课程ExecutionGateway→固定BiSOFollower桥；作者只进行了软件及真实CPU ACT的合成边界测试，没有接硬件，也没有替学生完成现场停机。

## 1. 离线故障注入

```sh
python lessons/M72/code/fault_tests.py --output NEW_FAULT_REPORT.json
python lessons/M72/code/deploy_gateway.py --help
```

9个实际网关软件路径：正常、一路陈旧、通信失败、非有限数、缺字段、重复序号、未知来源、部分发送失败、停止回调失败。故障后再交合法目标，验证仍锁存。输出全部标synthetic_fixture。不要把模拟stop函数返回改成“已实测停止”。

## 2. 保持原模型与当前硬件证据

激活M67–70固定环境。原M69模型清单和候选/pretrained_model/处理器/来源相对结构保持不变；`--root`对应其artifact_root。不能另建generic model manifest改变模型身份。

将当前真实标定文件保存在此根下的标定目录，文件名与robot.id派生的`ID_left.json`、`ID_right.json`一致。硬件清单必须逐项列真实字节SHA，包括这两个文件。不得拿另一只臂的标定顶替。`file_refs.py`只从实际文件计算引用，不自动写任何人已检查或停止成功结论：

```sh
python lessons/M72/code/file_refs.py --root ARTIFACT_ROOT_ABSOLUTE \
  --file calibration/YOUR_ID_left.json --file calibration/YOUR_ID_right.json \
  --output NEW_HARDWARE_INVENTORY.json
```

把其他实际硬件修订、接线、范围测量证据一并用重复`--file`收进清单。配置模板的所有null必须由实际M22/M71与导师批准记录填写。`calibration_dir`是证据根内真实绝对路径。旋转五通道为degree，夹爪为percent_0_100。桥按原生目标工作；不要额外整体乘“低速系数”。低速联调依赖逐关节批准的相对幅度和目标速率，不保证实测运动速度。

## 3. 先完成当前工位的停止与恢复测试

监督者准备支承、清空运动/下落区域、验证独立物理断电、禁用leader任务写入。关闭力矩可能引起重力运动，不能把停止写成绝对静止保证。按M15/M22已制定的现场方法验证停止与人工恢复，保留视频或原始日志；硬件与配置变化后要重新核对测试。

填写`on-site-stop-test.template.json`：当前hardware_manifest_sha256和config_sha256由实际文件计算，test_method与recovery_check写真实步骤，evidence为真实文件path/sha256数组。没有完成就保留false/null，不进入动力阶段。ordinary Python被卡住时不是独立硬件看门狗，串口坏了停止命令也可能失败。

## 4. 准备本次身份，仍不开设备

第一次M72用development路径，不需要预先完成M74：

```sh
python lessons/M72/code/deploy_gateway.py prepare \
  --root ARTIFACT_ROOT_ABSOLUTE --config CONFIG_ABSOLUTE \
  --manifest ORIGINAL_MODEL_MANIFEST_ABSOLUTE --hardware HARDWARE_MANIFEST_ABSOLUTE \
  --attempt UNIQUE_DEVELOPMENT_ID --operator LOCAL_OPERATOR_CODE \
  --output NEW_CONTEXT_ABSOLUTE
```

`prepare`读取真实文件，检查模型为learner_recording、硬件/标定清单和单位，生成唯一run_id。后续M75/M80/M81已有start.json时，以`--start START_ABSOLUTE`替代`--attempt/--operator`；同一条入口从start绑定run_id、trial_id和五SHA。正式run也必须再传同一`--start`。

监督者填写`supervised-run-approval.template.json`，核对本次context的run_id、停止测试摘要、实际环境及连接可能启用力矩。不能复制旧run的批准文件。SHA用`file_refs.py`或系统sha256工具按实际字节计算；模板不是授权。

## 5. 获当前现场批准后，才运行动力路径

以下命令会打开两个串口和相机并可能使能力矩。作者不会替你执行。监督者在场，独立物理停止可及，支承和清空范围到位：

```sh
python lessons/M72/code/deploy_gateway.py run \
  --root ARTIFACT_ROOT_ABSOLUTE --config CONFIG_ABSOLUTE \
  --manifest ORIGINAL_MODEL_MANIFEST_ABSOLUTE --hardware HARDWARE_MANIFEST_ABSOLUTE \
  --context CONTEXT_ABSOLUTE --pretrained PRETRAINED_ABSOLUTE \
  --checkout FIXED_CHECKOUT_ABSOLUTE --stop-test ACTUAL_STOP_TEST_ABSOLUTE \
  --approval THIS_RUN_APPROVAL_ABSOLUTE --output NEW_RUN_DIRECTORY --device cpu
```

已有正式start时再加 `--start START_ABSOLUTE`。桥在任何设备连接前重核文件/批准与Runtime身份；连接时读取两臂已有标定并核电机值，不自动重标定；之后连接相机并按固定驱动配置电机。任务目标只能经gateway再调driver，leader没有任务入口。两臂顺序发送，不是原子同步。

每轮读取真实状态和成对的像素/原到达时间，调用M69唯一Runtime，网关在发送前检年龄/通信/字段/范围/序号。异常及正常有限步数结束都锁存并对两臂尝试关闭力矩。一臂失败仍尝试另一臂；退出清理也保留异常。阻塞/强杀无法承诺及时软件停止，监督者须使用独立现场手段，不能等待脚本自救。

## 6. 原始日志与人观察分开

输出context.json、gateway.raw.json、timing.json、events-prefix.jsonl。原生events保留manual_arm→command→latched；如果没成功启动或发送失败，序列可能不完整，保留并判未完成，绝不补造command。wrapper中run_id/attempt_id/原模型SHA/硬件SHA供M74–M81共用。初始人观察为false/PENDING，并非默认认定已停止。

监督者填写stop-observation.template.json，绑定准确raw_gateway_sha256并如实给supervisor_observed_stop、原因、姓名代号。再运行：

```sh
python lessons/M72/code/deploy_gateway.py attest \
  --raw GATEWAY_RAW_ABSOLUTE --observation ACTUAL_STOP_OBSERVATION_ABSOLUTE \
  --output NEW_GATEWAY_JSON_ABSOLUTE
```

此步不动硬件，保留原始记录并生成新的带观察日志。交M75 close_run时，gateway_log证据引用这个最终gateway.json；连续视频与唯一outcome_note另列。只有同一次run证据可组合，启动未成功/停止未知不能通过完整主验收。失败后人工恢复要另建尝试，不能覆盖本次。
