# M70：交付包离开训练进程

本节不新增理论和练习。只有M67资源记录、M68本人正式权重、M69完整验证选择已实际完成，才能交付本人部署包。以下命令在[实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)根目录和固定环境中执行，所有ABS路径须替换。

## 收齐支持材料

执行 `python capture_environment.py environment.json` 保存当前解释器的真实环境；`manual_fields.lerobot_git_rev_parse_HEAD`必须填实际核对的固定revision，不能仅复制模板。复制 `interface_context.example.json`，填本人硬件/相机版本，登记相对共同artifact_root的硬件清单、相机清单、校准、已测限制与环境锁文件及实际SHA。五类引用必须都在files清单中。只能声明 `power_authorization=not_granted_by_this_package`。

模板不能通过：REPLACE、缺文件、错SHA、通道或单位变化均须先修。相同字段名不能自动证明图像视角相同，需人工结合真实安装与采集记录核对。所有source_kind与候选一致，合成材料始终保持synthetic_fixture。

```sh
python lessons/M70/code/reload_bundle.py package selection.json /ABS/artifacts/candidate-step400/model_manifest.json /ABS/artifacts /ABS/new-delivery --environment /ABS/environment.json --interface /ABS/interface-context.json
```

输出新目录包含权重、保存处理器与旁文件、原始来源、选择记录、环境与接口支持文件，以及完整文件摘要清单。不会覆盖旧目录；共享相对路径不能逃出根。目录复制成功还不是推理成功。

## 准备当前输入与新进程

复制 `current_observation.example.json`，填实际12维状态、固定顺序/单位、当前前视和俯视图片路径与SHA，以及源回合/帧等capture信息。图片保留原RGB尺寸，脚本转换到0–1浮点后由保存处理器归一化；不要提前再标准化。只提供当前观察，不加入未来action或标签。

```sh
python lessons/M70/code/reload_bundle.py smoke /ABS/new-delivery /ABS/lerobot /ABS/current-observation.json /ABS/new-smoke --device cpu
```

实际启动新Python进程。父进程receipt、子进程result、stdout-stderr日志保留不同进程ID和返回码；子进程校验包、实际加载权重/处理器，reset后同输入两次逐值一致，另一次reset后的select_action与块首项对照。输出块长×12、通道/单位和名义时间偏移。它没有连接摄像头或电机，输出是policy请求，不是批准动作、driver返回或实测状态。

## 三个失败探针与恢复

对**副本**依次移走一个processor旁状态、向输入加入未来action、修改图片但保留旧SHA，各用新smoke目录保存错误。原冻结包不改。恢复后重新运行并保留前后证据；随机模型或手填输出不能修复原包。新进程不等于跨机器；若后来换机器，另留实际环境与测试。

交付启动卡需含环境激活方式、共同根位置、可执行命令、输入来源、输出形状/单位、失败回查位置以及未完成条件。根作者实际做过固定完整LeRobot合成CPU/image-backed新进程链，学生真实数据和硬件任务仍须完成。接下来只经M71无动力时序→M72真实网关及现场停止验证进入受控动力，不可把直接rollout命令当正式捷径。
