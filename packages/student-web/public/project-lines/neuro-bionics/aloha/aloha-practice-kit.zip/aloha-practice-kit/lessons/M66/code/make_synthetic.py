#!/usr/bin/env python3
"""Explicit synthetic tensor fixture; never a learner recording."""
import argparse
import json
from pathlib import Path
import numpy as np


def generate(output):
    out = Path(output)
    out.mkdir(parents=True,exist_ok=False)
    rng = np.random.default_rng(11)
    state = rng.normal(0,.2,(2,12)).astype(np.float32)
    actions = rng.normal(0,.2,(2,3,12)).astype(np.float32)
    mask = np.array([[False,False,False],[False,True,True]])
    actions[1,1:] = actions[1,0]
    cameras = ["observation.images.front","observation.images.overhead"]
    arrays = {"observation.state":state,"action":actions,"action_is_pad":mask}
    arrays.update({key:rng.normal(0,.2,(2,3,32,32)).astype(np.float32) for key in cameras})
    np.savez(out/"batch.npz",**arrays)
    fields = [f"{side}_{joint}.pos" for side in ("left","right") for joint in
        ("shoulder_pan","shoulder_lift","elbow_flex","wrist_flex","wrist_roll","gripper")]
    manifest = {"provenance":"synthetic","source_ref":"make_synthetic.py seeded noise; no real images",
        "preprocessing_ref":"synthetic_normalized_fixture_v1; not real dataset statistics",
        "split":"train","split_ref":"synthetic E0/E1 train fixture only",
        "state_field_names":fields,"action_field_names":fields,"trace":[
            {"episode_id":"synthetic-E0","observation_frame_index":0,"target_frame_indices":[0,1,2],
             "current_image_refs":{key:"synthetic/noise/E0/frame0/"+key for key in cameras}},
            {"episode_id":"synthetic-E1","observation_frame_index":9,"target_frame_indices":[9,None,None],
             "current_image_refs":{key:"synthetic/noise/E1/frame9/"+key for key in cameras}}]}
    (out/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("output")
    generate(p.parse_args().output)
