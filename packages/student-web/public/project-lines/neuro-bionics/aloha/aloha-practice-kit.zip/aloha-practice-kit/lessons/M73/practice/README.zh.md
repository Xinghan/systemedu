# M73 实际输入、操作与恢复

从解压后的实践包根目录运行；保留 lessons/M73–M78 的相邻目录，入口通过同包相对路径复用 M74 的唯一审核。Python 3.12 标准库足够运行本批证据/统计工具；真实 ACT 的加载、处理器与设备环境仍沿用 M69–M72 固定实现，不能用本批轻量环境替代。

所有输出新建、不覆盖。空白模板只说明输入字段，不能直接充当真实成绩。synthetic 仅软件夹具，永不性能达标；learner_recording 是来源声明，摘要一致不认证现场真实性。保存整个证据根目录，相对路径随包移动。单独拷贝一个Python文件会丢失跨节点审核依赖。

## 真实开发预测与网关对照

M69 的唯一 `export_predictions.py` 使用冻结ACT和同目录保存的processors，从本人validation原生图像视图导出当前帧第一项chunk预测；输出 `aloha.offline-action-pairs.v1`。不读取封存test，不在本课另装第二套模型。目标和预测均须回到同一原生动作单位，作用量为teleop_action_processor目标。

```sh
python lessons/M73/code/compare_runs.py work/development/offline-pairs.json work/development/gateway.json --output work/development/comparison.json
```

网关日志来自同一模型清单SHA的M72开发执行。输出逐关节MAE/MSE、请求到网关目标的约束差、驱动返回差及命令序号/主机时间。没有自动视频对齐，没有自动因果判决，tracking_error始终为空：命令前测量不等于命令后跟踪。

在worksheet填写真实视频定位、时间原点、两候选原因与能否定解释的下一次开发检查。模式错误、单位不一致、重复帧字段或模型摘要不同将报错，先查来源再扩大实验。浏览器一维轨迹另存synthetic，不代替真实ACT预测。
