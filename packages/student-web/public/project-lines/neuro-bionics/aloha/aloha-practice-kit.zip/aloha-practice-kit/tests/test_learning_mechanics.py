import math
import unittest
import learning_mechanics as m


class MechanicsTests(unittest.TestCase):
    def test_hidden_layer_gradient_matches_finite_difference(self):
        result=m.demo()
        self.assertLess(result['max_gradient_error'],1e-8)
        self.assertLess(result['adamw']['new_loss'],result['mlp']['loss'])

    def test_attention_derivative(self):
        q=[.3,-.2]; k=[[1.,2.],[.5,-1.],[0.,.6]]; v=[[2.,3.],[5.,-1.],[3.,0.]]
        result=m.attention(q,k,v)
        self.assertAlmostEqual(sum(result['weights']),1)
        for j in range(2):
            numeric=m.numerical_gradient(lambda x:m.attention(x,k,v)['output'][j],q)
            for a,b in zip(numeric,result['query_jacobian'][j]): self.assertAlmostEqual(a,b,places=7)

    def test_optimizer_resume(self):
        p=[.3,-.7]; g=[.1,-.2]
        p1,s1=m.adamw_step(p,g)
        import json
        restored=json.loads(json.dumps({'params':p1,'state':s1}))
        self.assertEqual(m.adamw_step(p1,g,s1),m.adamw_step(restored['params'],g,restored['state']))

    def test_latent_gradients(self):
        mu=[.2,-.4]; lv=[.3,-.2]
        result=m.gaussian_kl(mu,lv)
        for a,b in zip(m.numerical_gradient(lambda x:m.gaussian_kl(mu,x)['sum'],lv),result['d_log_variance']):
            self.assertAlmostEqual(a,b,places=7)
        self.assertEqual(m.gaussian_kl([0.,0.],[0.,0.])['sum'],0)
        noise=[.2,-.6]; result=m.reparameterize(mu,lv,noise)
        for j in range(2):
            numeric=m.numerical_gradient(lambda x:m.reparameterize(mu,x,noise)['sample'][j],lv)
            self.assertAlmostEqual(numeric[j],result['d_log_variance'][j],places=7)

    def test_padding_denominator_and_episode_boundary(self):
        self.assertEqual(m.masked_l1([[2.,4.],[99.,99.]],[[1.,2.],[3.,4.]],[False,True])['loss'],1.5)
        c=m.make_chunk([[1.,2.],[3.,4.]],1,3)
        self.assertEqual(c['is_pad'],[False,True,True])
        self.assertEqual(c['source_indices'],[1,None,None])
        self.assertEqual(m.masked_l1([[9.]],[[1.]],[True])['loss'],0)

    def test_training_statistics_do_not_refit_on_test(self):
        stats=m.normalize_fit([[1.,5.],[3.,5.]])
        self.assertEqual(m.normalize_apply([[5.,5.]],stats),[[3.,0.]])
        self.assertEqual(stats['mean'],[2.,5.])

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError): m.mlp_forward([0.]*9,[math.nan,0.])
        with self.assertRaises(ValueError): m.make_chunk([[0]],1,2)
        with self.assertRaises(ValueError): m.masked_l1([[0]],[[1]],['false'])


if __name__=='__main__': unittest.main()
