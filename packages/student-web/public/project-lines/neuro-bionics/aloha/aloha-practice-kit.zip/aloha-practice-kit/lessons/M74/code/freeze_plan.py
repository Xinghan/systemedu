"""Freeze the real preregistration draft; numeric targets are chosen before outcomes."""
from pathlib import Path
from datetime import datetime,timezone
import json,random,argparse
from evaluation_audit import read,actual_versions,validate_plan,sha

def freeze_plan(draft_path,artifact_root,output_path,seed):
 if type(seed) is not int:raise ValueError('Integer shuffle seed required')
 draft=read(draft_path);plan=dict(draft);plan['schema']='aloha.independent-plan.v1';plan['registered_at']=datetime.now(timezone.utc).isoformat();plan['random_seed']=seed
 versions,_=actual_versions(artifact_root,plan['version_artifacts']);plan['frozen_versions']=versions
 rows=[dict(x) for x in plan['plan']];random.Random(seed).shuffle(rows)
 for i,row in enumerate(rows,1):row.update(order=i,planned_status='planned')
 plan['plan']=rows;validate_plan(plan,artifact_root)
 path=Path(output_path).resolve();root=Path(artifact_root).resolve()
 if not path.is_relative_to(root):raise ValueError('Freeze plan within the artifact root')
 with open(path,'x') as f:json.dump(plan,f,ensure_ascii=False,indent=2);f.write('\n')
 return {'path':str(path),'sha256':sha(path),'registered_at':plan['registered_at'],'trial_order':[r['trial_id'] for r in rows],'truth_certified':False}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('draft');p.add_argument('--root',required=True);p.add_argument('--output',required=True);p.add_argument('--seed',required=True,type=int);a=p.parse_args();print(json.dumps(freeze_plan(a.draft,a.root,a.output,a.seed),ensure_ascii=False,indent=2))
