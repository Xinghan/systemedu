# 本节实践文件

这些 CSV 只有字段表头，故意没有伪造样本。用本人记录填写，未执行写 `not_executed`，未知写 `unknown`。示意计算和浏览器实验数据必须与本人记录分开。

- [parameters.csv](parameters.csv)：填写实际记录；原始照片、日志路径保留可追溯关系。
- [export-check.csv](export-check.csv)：填写实际记录；原始照片、日志路径保留可追溯关系。
- [tray.scad](tray.scad)：可编辑源；接口参数需本人测量，先预览、渲染并检查单位。
- [finger_pad.scad](finger_pad.scad)：可编辑源；接口参数需本人测量，先预览、渲染并检查单位。
- [camera_plate.scad](camera_plate.scad)：可编辑源；接口参数需本人测量，先预览、渲染并检查单位。
- [light_block.scad](light_block.scad)：可编辑源；接口参数需本人测量，先预览、渲染并检查单位。

具体操作顺序、成人分工和验收边界见本节 assignment.md。保存版本，不覆盖失败记录。本目录不声称已有任何真实打印、通电或实机测试结果。
