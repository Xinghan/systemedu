"""Inspectable execution guard for a mentor-integrated teaching robot.

This module contains no driver, network or device connection. A caller supplies
send and physical-stop callbacks. Offline tests cannot certify a real stop.
"""
from dataclasses import dataclass
import math
import time
from typing import Callable


class RejectedCommand(RuntimeError):
    pass


def finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise RejectedCommand(f'{name}: expected a finite numeric value')
    return float(value)


@dataclass(frozen=True)
class Bound:
    minimum: float
    maximum: float
    relative_to_measured: float
    command_rate_per_second: float | None = None

    def validate(self):
        lo, hi, delta = [finite(v, 'bound') for v in
                         (self.minimum, self.maximum, self.relative_to_measured)]
        if lo >= hi or delta <= 0:
            raise ValueError('Each bound needs minimum < maximum and a positive measured-position delta')
        if self.command_rate_per_second is not None and finite(self.command_rate_per_second, 'rate') <= 0:
            raise ValueError('Command rate must be positive when enabled')


class ExecutionGateway:
    """One explicit writer. Every failure latches, requiring a new manual check.

    Frame timestamps must be from the same monotonic clock as this gateway.
    Values are arrived observations, not assertions about exposure time.
    This is not collision checking or a hardware emergency-stop circuit.
    """
    def __init__(self, bounds: dict[str, Bound], max_age_s: float,
                 send: Callable[[dict], dict], stop: Callable[[], None],
                 clock: Callable[[], float] = time.monotonic,
                 required_cameras: tuple[str, ...] = ('camera',)):
        if not bounds:
            raise ValueError('Explicit measured joint bounds required')
        for bound in bounds.values():
            bound.validate()
        self.bounds = dict(bounds)
        self.max_age = finite(max_age_s, 'max_age_s')
        if self.max_age <= 0:
            raise ValueError('max_age_s must be positive')
        self.send, self.stop, self.clock = send, stop, clock
        if not required_cameras or len(set(required_cameras)) != len(required_cameras):
            raise ValueError('List each required camera stream exactly once')
        self.required_cameras = set(required_cameras)
        self.state = 'latched'
        self.last_sequence = -1
        self.last_time = None
        self.last_target = None
        self.events = []

    def arm_after_manual_checks(self, *, stop_test_reference: str,
                                configuration_reference: str, clear_workspace: bool):
        self.state = 'latched'
        if not stop_test_reference.strip() or not configuration_reference.strip() or clear_workspace is not True:
            raise RejectedCommand('Record the current on-site stop test, configuration and clear workspace first')
        self.state = 'armed'
        self.last_sequence = -1
        self.last_time = self.last_target = None
        self.events.append({'event': 'manual_arm', 'stop_test_reference': stop_test_reference,
                            'configuration_reference': configuration_reference})

    def trip(self, reason):
        self.state = 'latched'
        event = {'event': 'latched', 'reason': str(reason), 'stop_callback_returned': False}
        try:
            self.stop()
            event['stop_callback_returned'] = True
        except Exception as error:
            event['stop_error'] = f'{type(error).__name__}: {error}'
        self.events.append(event)
        # A returning callback is not evidence that the robot physically stopped.
        raise RejectedCommand(str(reason))

    def submit(self, requested, measured, *, sequence: int, observation_arrival_s: float,
               camera_arrival_s: dict[str, float], source: str, communication_ok: bool):
        if self.state != 'armed':
            raise RejectedCommand('Gateway latched; physical stop and manual reset are required')
        try:
            now = finite(self.clock(), 'clock')
            if source not in ('teleop', 'policy'):
                raise RejectedCommand('Unknown command source')
            if communication_ok is not True:
                raise RejectedCommand('Communication is not known healthy')
            if type(sequence) is not int or sequence <= self.last_sequence:
                raise RejectedCommand('Command sequence must increase')
            if set(requested) != set(self.bounds) or set(measured) != set(self.bounds):
                raise RejectedCommand('Missing or extra joint fields')
            if set(camera_arrival_s) != self.required_cameras:
                raise RejectedCommand('Required camera arrivals missing or unexpected')
            stamps = {'observation': observation_arrival_s, **camera_arrival_s}
            for name, stamp in stamps.items():
                age = now - finite(stamp, name)
                if age < 0 or age > self.max_age:
                    raise RejectedCommand(f'{name}: future or stale arrival in the gateway clock domain')
            if self.last_time is not None and now <= self.last_time:
                raise RejectedCommand('Gateway time did not increase')
            constrained, intervals = {}, {}
            for key, bound in self.bounds.items():
                present = finite(measured[key], key + ' measured')
                target = finite(requested[key], key + ' requested')
                if not bound.minimum <= present <= bound.maximum:
                    raise RejectedCommand(key + ': measured position outside approved interval')
                lo = max(bound.minimum, present - bound.relative_to_measured)
                hi = min(bound.maximum, present + bound.relative_to_measured)
                if self.last_target is not None and bound.command_rate_per_second is not None:
                    step = bound.command_rate_per_second * (now - self.last_time)
                    lo = max(lo, self.last_target[key] - step)
                    hi = min(hi, self.last_target[key] + step)
                if lo > hi:
                    raise RejectedCommand(key + ': incompatible constraints')
                constrained[key] = max(lo, min(hi, target))
                intervals[key] = (lo, hi)
            sent = self.send(dict(constrained))
            if not isinstance(sent, dict) or set(sent) != set(self.bounds):
                raise RejectedCommand('Driver return has missing or extra fields')
            for key, value in sent.items():
                value = finite(value, key + ' driver return')
                lo, hi = intervals[key]
                if not lo <= value <= hi:
                    raise RejectedCommand(key + ': driver returned a target outside approved constraints')
            send_end = finite(self.clock(), 'send end')
            if send_end < now or send_end - now > self.max_age:
                raise RejectedCommand('Send callback exceeded declared timing budget')
            self.last_sequence, self.last_time, self.last_target = sequence, now, constrained
            result = {'event': 'command', 'source': source, 'sequence': sequence,
                      'requested': dict(requested), 'observed_state': dict(measured),
                      'gateway_target': constrained, 'driver_returned_sent_action': dict(sent),
                      'monotonic_send_end': send_end}
            self.events.append(result)
            return result
        except Exception as error:
            self.trip(error)
