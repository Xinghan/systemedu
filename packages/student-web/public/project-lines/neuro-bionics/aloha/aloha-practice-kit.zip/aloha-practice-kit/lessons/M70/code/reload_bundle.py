"""Package a selected ACT candidate and check it in a fresh unpowered process."""
import argparse,json,os,shutil,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[2];sys.path.insert(0,str(BASE/'M69'/'code'));sys.path.insert(0,str(BASE/'M67'/'code'))
from course_contract import *
from act_runtime import load_runtime

def package(selection_path,manifest_path,artifact_root,destination,*,environment_manifest,interface_manifest):
 selection=read(selection_path);manifest=read(manifest_path);root=local(artifact_root);out=Path(destination)
 if out.exists():raise ValueError('new package destination required')
 if selection.get('schema')!='aloha.selection-result.v1'or selection.get('final_test_used')is not False:raise ValueError('development selection required')
 if selection['selected']['model_manifest_sha256']!=sha(manifest_path)or selection['selected']['candidate_id']!=manifest['candidate_id']:raise ValueError('selected candidate differs from model manifest')
 verify_inventory(root,manifest['files'])
 environment=read(environment_manifest);context=read(interface_manifest)
 if not text(environment.get('python'))or not isinstance(environment.get('packages'),list)or not environment['packages'] or environment.get('manual_fields',{}).get('lerobot_git_rev_parse_HEAD')!=REVISION:raise ValueError('actual captured interpreter/packages and checked fixed revision required')
 if context.get('schema')!='aloha.deployment-context.v1'or context.get('source_kind')!=manifest['source_kind']or context.get('action_fields')!=FIELDS or context.get('action_units')!=UNITS or context.get('camera_keys')!=CAMERAS:raise ValueError('explicit matching interface context required')
 if context.get('power_authorization')!='not_granted_by_this_package':raise ValueError('offline package cannot grant motor authority')
 verify_inventory(root,context['files']);known={row['path']for row in context['files']}
 for key in ('hardware_manifest_ref','camera_manifest_ref','calibration_ref','measured_limits_ref','environment_lock_ref'):
  if context.get(key)not in known:raise ValueError('interface evidence file missing: '+key)
 rel=Path(manifest_path).resolve().relative_to(root)
 out.mkdir(parents=True)
 for row in manifest['files']:
  src=child(root,row['path']);dst=out/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 for row in context['files']:
  src=child(root,row['path']);dst=out/row['path']
  if dst.exists()and sha(dst)!=row['sha256']:raise ValueError('model/support path collision')
  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 support=out/'support'
 if support.exists():raise ValueError('reserved support directory collision')
 support.mkdir();shutil.copy2(environment_manifest,support/'environment.json');shutil.copy2(interface_manifest,support/'interface-context.json')
 (out/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(manifest_path,out/rel);shutil.copy2(selection_path,out/'selection.json')
 receipt={'schema':'aloha.deployment-package.v1','candidate_id':manifest['candidate_id'],'model_manifest_path':str(rel),'model_manifest_sha256':sha(out/rel),'selection_sha256':sha(out/'selection.json'),'environment_sha256':sha(support/'environment.json'),'interface_sha256':sha(support/'interface-context.json'),'files':inventory(out),'source_kind':manifest['source_kind'],'execution_permission':'unpowered offline reload only; M71 timing and M72 gateway/physical stop still required'}
 write_new(out/'package.json',receipt);return receipt

def read_observation(path,rt):
 import torch,numpy as np
 from PIL import Image
 path=Path(path);d=read(path)
 required={'schema','source_kind','state_fields','state_units','state','images','capture'}
 if set(d)!=required or d['schema']!='aloha.current-observation.v1' or d['source_kind']not in ('learner_recording','synthetic_fixture'):raise ValueError('current-only observation schema; no action labels or extra fields')
 if d['state_fields']!=FIELDS or d['state_units']!=UNITS or not isinstance(d['state'],list)or len(d['state'])!=12 or any(not finite(v)for v in d['state']):raise ValueError('native finite twelve-channel state contract required')
 if not isinstance(d['capture'],dict)or not text(d['capture'].get('episode_id'))or type(d['capture'].get('frame_index'))is not int or d['capture']['frame_index']<0 or not d['capture'].get('dataset_source'):raise ValueError('current observation source trace required')
 if set(d['images'])!={'front','overhead'}:raise ValueError('two current image files required')
 obs={'observation.state':torch.tensor(d['state'],dtype=torch.float32)}
 for name,key in zip(['front','overhead'],CAMERAS):
  row=d['images'][name];p=child(path.parent,row['path'])
  if sha(p)!=row['sha256']:raise ValueError('image digest mismatch')
  with Image.open(p)as im:
   if im.mode!='RGB':raise ValueError('RGB required; no silent conversion')
   obs[key]=torch.from_numpy(np.array(im,dtype=np.float32).transpose(2,0,1).copy()/255)
 return d,obs

def worker(package_dir,checkout,observation_path,output,device):
 import torch
 root=local(package_dir);p=read(root/'package.json');verify_inventory(root,p['files'])
 manifest=root/p['model_manifest_path']
 if sha(manifest)!=p['model_manifest_sha256']or sha(root/'selection.json')!=p['selection_sha256']:raise ValueError('package manifest or selection changed')
 m=read(manifest);rt=load_runtime(root/m['pretrained_dir'],checkout,device,model_manifest=manifest,artifact_root=root);d,obs=read_observation(observation_path,rt)
 rt.reset();first=rt.predict_chunk(obs);rt.reset();second=rt.predict_chunk(obs)
 if not torch.equal(first,second):raise ValueError('same-process reset inference changed; inspect deterministic settings')
 rt.reset();selected=rt.select_action(obs)
 if not torch.allclose(first[0],selected,rtol=1e-5,atol=1e-5):raise ValueError('first selected action differs from chunk first element after reset')
 result={'schema':'aloha.offline-reload-result.v1','status':'passed','process_id':os.getpid(),'model_manifest_sha256':sha(manifest),'package_sha256':sha(root/'package.json'),'observation_sha256':sha(observation_path),'source_kind':d['source_kind'],'capture':d['capture'],'action_fields':FIELDS,'action_units':UNITS,'action_semantics':'teleop_action_processor target','chunk_shape':list(first.shape),'actions':first.tolist(),'target_offsets':list(range(m['chunk_size'])),'time_basis':'nominal decision offsets only; not measured command timing or camera exposure','reset_bitwise_equal':True,'first_selected_action_matches':True,'future_action_labels_supplied':False,'motor_or_camera_opened':False,'task_success_claimed':False}
 write_new(output,result);return result

def smoke(package_dir,checkout,observation_path,output,device='cpu'):
 output=Path(output)
 if output.exists():raise ValueError('new output directory required')
 output.mkdir(parents=True);argv=[sys.executable,str(Path(__file__).resolve()),'_worker',str(local(package_dir)),str(local(checkout)),str(Path(observation_path).resolve()),str((output/'result.json').resolve()),'--device',device]
 env=dict(os.environ);env.update(HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',WANDB_MODE='disabled')
 with(output/'process.log').open('x')as f:p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env)
 receipt={'returncode':p.returncode,'parent_process_id':os.getpid(),'argv':argv,'log_sha256':sha(output/'process.log'),'hardware_opened':False}
 if p.returncode==0:
  result=read(output/'result.json')
  if result['process_id']==os.getpid():raise ValueError('independent process check failed')
  receipt['result_sha256']=sha(output/'result.json')
 write_new(output/'receipt.json',receipt)
 if p.returncode:raise RuntimeError('reload failed; process log preserved')
 return receipt
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='mode',required=True)
 q=s.add_parser('package')
 for k in ('selection','manifest','artifact_root','destination'):q.add_argument(k)
 q.add_argument('--environment',required=True);q.add_argument('--interface',required=True)
 for name in ('smoke','_worker'):
  q=s.add_parser(name)
  for k in ('package_dir','checkout','observation','output'):q.add_argument(k)
  q.add_argument('--device',choices=['cpu','cuda'],default='cpu')
 a=p.parse_args()
 if a.mode=='package':r=package(a.selection,a.manifest,a.artifact_root,a.destination,environment_manifest=a.environment,interface_manifest=a.interface)
 elif a.mode=='smoke':r=smoke(a.package_dir,a.checkout,a.observation,a.output,a.device)
 else:r=worker(a.package_dir,a.checkout,a.observation,a.output,a.device)
 print(json.dumps(r,ensure_ascii=False,indent=2))
