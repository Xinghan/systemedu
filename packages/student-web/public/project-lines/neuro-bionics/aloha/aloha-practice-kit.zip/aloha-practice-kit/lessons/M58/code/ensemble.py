"""Scalar/list temporal ensembling at ONE target index, oldest prediction first."""
import argparse,json,math
from pathlib import Path
def ensemble(data):
    if data.get('provenance') not in ('synthetic','learner_model_output'):raise ValueError('Declare prediction provenance')
    rows=sorted(data['predictions'],key=lambda x:x['origin_index']);target=data['target_index'];coefficient=data['coefficient']
    if type(target) is not int or target<0 or not rows or isinstance(coefficient,bool) or not isinstance(coefficient,(int,float)) or not math.isfinite(coefficient):raise ValueError('Invalid target or coefficient')
    width=len(rows[0]['action']);seen=set()
    for r in rows:
        origin=r['origin_index']
        if type(origin) is not int or origin<0 or origin>target or r['target_index']!=target or origin in seen:raise ValueError('Distinct causal prediction origins, same target required')
        seen.add(origin)
        if not width or len(r['action'])!=width or any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in r['action']):raise ValueError('Finite same-width actions required')
    scores=[-coefficient*i for i in range(len(rows))];top=max(scores);raw=[math.exp(s-top) for s in scores];total=sum(raw);weights=[w/total for w in raw]
    return {'provenance':data['provenance'],'target_index':target,'coefficient':coefficient,'origin_indices_oldest_first':[r['origin_index'] for r in rows],'weights':weights,'action':[sum(w*r['action'][j] for w,r in zip(weights,rows)) for j in range(width)],'hardware_executed':False,'boundary':'Matches pinned oldest-first weighting for aligned overlapping chunks; missing-step recovery is a separate scheduler contract.'}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);a=p.parse_args();print(json.dumps(ensemble(json.loads(a.input.read_text())),ensure_ascii=False,indent=2,allow_nan=False))
