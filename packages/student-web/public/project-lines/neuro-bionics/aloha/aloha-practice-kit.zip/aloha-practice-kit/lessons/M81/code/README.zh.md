# M81：独立交接的五条追溯线

```sh
python lessons/M81/code/handoff_audit.py my-project/handoff.json --root my-project --output my-project/handoff-check-01.json
```

从 `handoff.template.json` 填写实际引用，文件表和摘要规则与M79相同。所有软件只读取本地档案，不导入驱动或启动机械臂。

`stages` 必须恰好覆盖 M08、M18、M28、M35、M46、M55、M66、M70、M80；`outcomes` 恰好覆盖 FO1–FO5。每项有 `source_evidence`、`checked_evidence` 与 `limits`。它们表示实体/标定、本人示范/数据、学习机制、本人训练/部署、验收边界的源材料与实际检查。仅把同一空文件重复填入所有位置，虽然字段可能齐全，也无法通过人工成果审查。

`roles` 记录 author/operator/mentor 的本地代号，operator 必须不同于作者且没有编写启动说明。导师仍可监督现场，帮助全部进入 `help_log_evidence`。不要求公开身份。

`checks` 包含 fabrication/environment/native_data_read/training_to_weights/new_run，每项是 `completed` 或 `not_completed`，有实际观察，完成项有证据。不完整项使交接状态保持未完成。

`release_evidence` 引用M80发布清单，程序真实调用M80与M74检查。`new_run_evidence` 引用 M75 `start_run(..., purpose='independent_handoff')` / `close_run(...)` 的新记录，含 run_id、operator、purpose、source_kind、observed_versions、status；对应的 `checks.new_run.evidence` 至少有 video、gateway_log、outcome_note 三类文件。它不进入旧的主20次。未执行不能标completed；实际失败可形成完整交接记录，但不改变M80性能状态。

已执行的新回合必须保留完整 M75 `closed.json` 及其引用的 `start.json` 和冻结计划。复用 M80 的共同校验，核对开始/结束身份、版本与来源、关闭时的错误数组，以及 `checks.new_run.evidence` 和关闭记录中的证据集合完全相同；仅凑齐三种类型的旧文件不算本次证据。观察说明须与关闭结果字段对应，缺失证据或版本错误仍保留并阻止结构完整。

`operator_feedback` 引用三句反馈：独立完成了什么，需要帮助什么，哪些主张未确认。记录真实环境范围，同机测试不宣称跨平台。

只在副本移走标定或改错模型来源，验证报告能发现。软件核对字节和显式关系，不能认证操作者身份、制造事实或日志真假；原始记录与现场评审仍必需。原始目录不覆盖，输出文件同样拒绝覆盖。
