"""Make a byte inventory of actual local evidence; does not certify the content."""
from pathlib import Path
import argparse,json
from evaluation_audit import contained,sha
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--file',action='append',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 if len(set(a.file))!=len(a.file):raise ValueError('Duplicate file path')
 rows=[{'path':v,'sha256':sha(contained(a.root,v))} for v in a.file]
 with open(a.output,'x') as f:json.dump({'schema':'aloha.byte-inventory.v1','truth_certified':False,'files':rows},f,ensure_ascii=False,indent=2);f.write('\n')
