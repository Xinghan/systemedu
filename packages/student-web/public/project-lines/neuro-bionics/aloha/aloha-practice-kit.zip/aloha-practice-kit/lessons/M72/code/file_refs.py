"""Compute actual byte references only. Never grants physical authority."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M67/code'))
from course_contract import child,sha,write_new
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--file',action='append',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 write_new(a.output,{'schema':'aloha.file-inventory.v1','files':[{'path':r,'sha256':sha(child(a.root,r))}for r in a.file],'physical_truth_certified':False})
