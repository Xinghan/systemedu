import math
import unittest
from execution_gateway import Bound, ExecutionGateway, RejectedCommand


class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.now = 10.0
        self.sent, self.stops = [], []
        def send(action):
            self.sent.append(action)
            return action
        self.gateway = ExecutionGateway({'joint': Bound(-90, 90, 2, 5)}, .2,
                                         send, lambda: self.stops.append('stop'), lambda: self.now)
        self.arm()

    def arm(self):
        self.gateway.arm_after_manual_checks(stop_test_reference='synthetic-test-only',
                                             configuration_reference='synthetic-config', clear_workspace=True)

    def submit(self, target=30, **changes):
        args = dict(sequence=1, observation_arrival_s=self.now-.01,
                    camera_arrival_s={'camera': self.now-.02}, source='policy', communication_ok=True)
        args.update(changes)
        return self.gateway.submit({'joint': target}, {'joint': 20}, **args)

    def test_measured_delta_and_command_rate_are_different(self):
        self.assertEqual(self.submit()['gateway_target']['joint'], 22)
        self.now += .1
        value = self.submit(target=18, sequence=2)['gateway_target']['joint']
        self.assertAlmostEqual(value, 21.5)

    def test_stale_latches_before_any_send_and_needs_reset(self):
        with self.assertRaises(RejectedCommand): self.submit(observation_arrival_s=9)
        self.assertEqual(self.sent, [])
        self.assertEqual(self.stops, ['stop'])
        with self.assertRaises(RejectedCommand): self.submit()
        self.arm()
        self.submit()
        self.assertEqual(len(self.sent), 1)

    def test_unknown_future_nan_missing_and_duplicate_rejected(self):
        cases = [dict(source='unknown'), dict(observation_arrival_s=11),
                 dict(target=math.nan), dict(camera_arrival_s={}), dict(communication_ok=False)]
        for case in cases:
            self.arm()
            with self.assertRaises(RejectedCommand): self.submit(**case)
        self.assertEqual(self.sent, [])
        self.arm(); self.submit()
        with self.assertRaises(RejectedCommand): self.submit()
        self.assertEqual(len(self.sent), 1)

    def test_driver_failure_is_latched_even_if_stop_callback_fails(self):
        def broken_send(action): raise OSError('serial disconnected')
        def broken_stop(): raise OSError('stop channel disconnected')
        self.gateway.send, self.gateway.stop = broken_send, broken_stop
        with self.assertRaisesRegex(RejectedCommand, 'serial'): self.submit()
        self.assertEqual(self.gateway.state, 'latched')
        self.assertIn('stop_error', self.gateway.events[-1])

    def test_incomplete_joint_map_never_reaches_driver(self):
        with self.assertRaises(RejectedCommand):
            self.gateway.submit({}, {'joint':20}, sequence=1, observation_arrival_s=10,
                                camera_arrival_s={'camera':10}, source='teleop', communication_ok=True)
        self.assertEqual(self.sent, [])

    def test_reset_without_evidence_is_not_armed(self):
        with self.assertRaises(RejectedCommand):
            self.gateway.arm_after_manual_checks(stop_test_reference='',
                                                 configuration_reference='test', clear_workspace=True)
        self.assertEqual(self.gateway.state, 'latched')

    def test_all_configured_cameras_must_arrive(self):
        self.gateway.required_cameras = {'top', 'wrist'}
        with self.assertRaises(RejectedCommand): self.submit(camera_arrival_s={'top': 10})
        self.assertEqual(self.sent, [])

    def test_late_send_or_invalid_driver_return_latches(self):
        def late_send(action):
            self.now += .3
            return action
        self.gateway.send = late_send
        with self.assertRaisesRegex(RejectedCommand, 'timing'): self.submit()
        self.arm()
        self.gateway.send = lambda action: {'joint': 25}
        with self.assertRaisesRegex(RejectedCommand, 'constraints'): self.submit()


if __name__ == '__main__': unittest.main()
