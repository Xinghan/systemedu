"""Run the bridge against pinned isolated ACT core; NOT full LeRobot loader testing."""
import sys,unittest
from types import SimpleNamespace
from pathlib import Path
BASE=Path(__file__).resolve().parents[2];sys.path.insert(0,str(BASE/'M66/code'))
from act_step import dependencies,isolated_policy
from act_runtime import Runtime
SOURCE=Path(sys.argv[1])if len(sys.argv)>1 else None
if SOURCE is not None:sys.argv=sys.argv[:1]
np,torch=dependencies();torch.set_num_threads(1)
class RuntimeTensor(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if SOURCE is None:raise ValueError('supply pinned modeling_act.py path')
  torch.manual_seed(9);cls.policy,cls.backend=isolated_policy(SOURCE,4)
  # The isolated backend substitutes Configuration: expose only the native feature
  # descriptor interface needed by this wrapper test, without changing ACT code.
  cls.policy.config.input_features={"observation.state":SimpleNamespace(shape=(12,)),**{k:SimpleNamespace(shape=(3,32,32))for k in ("observation.images.front","observation.images.overhead")}}
 def setUp(self):
  self.rt=Runtime(self.policy,lambda x:x,lambda x:x*2+10,'a'*64);self.rt.reset()
  self.obs={k:torch.rand(tuple(v.shape))for k,v in self.policy.config.input_features.items()}
 def test_actual_chunk_shape_and_postprocess(self):
  raw=self.policy.predict_action_chunk({k:v.unsqueeze(0)for k,v in self.obs.items()})[0]
  out=self.rt.predict_chunk(self.obs);self.assertEqual(tuple(out.shape),(4,12));self.assertTrue(torch.allclose(out,raw*2+10))
 def test_current_only_boundary(self):
  with self.assertRaises(ValueError):self.rt.predict_chunk({**self.obs,'action':torch.zeros(4,12)})
 def test_boolean_tensor_rejected(self):
  o=dict(self.obs);o['observation.state']=torch.zeros(12,dtype=torch.bool)
  with self.assertRaises(ValueError):self.rt.predict_chunk(o)
 def test_image_scale_rejected(self):
  o=dict(self.obs);o['observation.images.front']=torch.full((3,32,32),255.)
  with self.assertRaises(ValueError):self.rt.predict_chunk(o)
 def test_shape_not_silently_resized(self):
  o=dict(self.obs);o['observation.images.front']=torch.zeros(3,16,16)
  with self.assertRaises(ValueError):self.rt.predict_chunk(o)
 def test_actual_profile_stages(self):
  out,times=self.rt.profile_action(self.obs)
  self.assertEqual(tuple(out.shape),(12,));self.assertEqual(times['policy_model_calls'],1)
  self.assertAlmostEqual(times['total_s'],times['preprocess_s']+times['inference_s']+times['postprocess_s'])
  self.assertTrue(all(times[k]>=0 for k in ('preprocess_s','inference_s','postprocess_s')))
 def test_actual_zero_latent_and_no_posterior(self):
  posterior=[];latents=[]
  hs=[self.policy.model.vae_encoder.register_forward_hook(lambda *x:posterior.append(1)),self.policy.model.encoder_latent_input_proj.register_forward_pre_hook(lambda m,a:latents.append(a[0].clone()))]
  try:
   a=self.rt.predict_chunk(self.obs);self.rt.reset();b=self.rt.predict_chunk(self.obs);self.rt.reset();c=self.rt.select_action(self.obs)
  finally:
   for h in hs:h.remove()
  self.assertTrue(torch.equal(a,b));self.assertTrue(torch.allclose(a[0],c));self.assertEqual(posterior,[]);self.assertEqual(len(latents),3);self.assertTrue(all(torch.count_nonzero(x)==0 for x in latents))
if __name__=='__main__':unittest.main(verbosity=2)
