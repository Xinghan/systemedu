"""Record the interpreter actually running this script."""
import json
import platform
import sys
print(json.dumps({'python':platform.python_version(),'executable':sys.executable,
                  'platform':platform.platform(),'external_dependencies':[],
                  'mode':'dry_run','future_lerobot_commit':'b64fe1ed9f11eeac53ee821356d2797601701054'},
                 ensure_ascii=False,indent=2))
