import copy,unittest
from linear_layer import forward,loss_and_gradient,update,fit
class LinearTests(unittest.TestCase):
    def setUp(self):self.w=[[.5,-1],[1,.25]];self.b=[.2,-.1]
    def test_two_inputs_two_outputs(self):
        p,t=forward([2,-1],self.w,self.b,True);self.assertAlmostEqual(p[0],2.2);self.assertAlmostEqual(p[1],1.65)
        self.assertEqual(t[0]['terms'][1]['product'],1);self.assertEqual(t[1]['terms'][1]['product'],-.25)
    def test_asymmetric_transpose_changes_answer(self):
        transposed=[list(x) for x in zip(*self.w)]
        self.assertNotEqual(forward([2,-1],self.w,self.b),forward([2,-1],transposed,self.b))
        with self.assertRaises(ValueError):forward([1,2,3],self.w,self.b)
    def test_nonsquare_shape_catches_transpose(self):
        weights=[[1,2],[3,4],[5,6]]
        self.assertEqual(forward([1,1],weights,[0,0,0]),[3,7,11])
        wrong=[list(row) for row in zip(*weights)]
        with self.assertRaises(ValueError):forward([1,1],wrong,[0,0])
    def test_cell_mean_and_multibranch_gradient(self):
        rows=[{'x':[2,-1],'y':[1.2,2.65]}];g=loss_and_gradient(rows,self.w,self.b)
        self.assertAlmostEqual(g['loss'],1);self.assertEqual(g['denominator'],2)
        self.assertAlmostEqual(g['weight_gradient'][0][0],2);self.assertAlmostEqual(g['weight_gradient'][0][1],-1)
        self.assertAlmostEqual(g['weight_gradient'][1][0],-2);self.assertAlmostEqual(g['weight_gradient'][1][1],1)
        self.assertAlmostEqual(g['bias_gradient'][0],1);self.assertAlmostEqual(g['bias_gradient'][1],-1)
    def test_all_weights_and_bias_central_difference(self):
        rows=[{'x':[2,-1],'y':[1.2,2.65]},{'x':[-.5,1.2],'y':[.3,-1]}];g=loss_and_gradient(rows,self.w,self.b);h=1e-5
        for j in range(2):
            for i in range(2):
                plus=copy.deepcopy(self.w);minus=copy.deepcopy(self.w);plus[j][i]+=h;minus[j][i]-=h
                fd=(loss_and_gradient(rows,plus,self.b)['loss']-loss_and_gradient(rows,minus,self.b)['loss'])/(2*h)
                self.assertAlmostEqual(fd,g['weight_gradient'][j][i],places=8)
            plus=list(self.b);minus=list(self.b);plus[j]+=h;minus[j]-=h
            fd=(loss_and_gradient(rows,self.w,plus)['loss']-loss_and_gradient(rows,self.w,minus)['loss'])/(2*h)
            self.assertAlmostEqual(fd,g['bias_gradient'][j],places=8)
    def test_same_old_state_updates_and_no_input_mutation(self):
        rows=[{'x':[2,-1],'y':[1.2,2.65]}];before=copy.deepcopy((self.w,self.b));g=loss_and_gradient(rows,self.w,self.b);w,b=update(self.w,self.b,g,.1)
        self.assertEqual((self.w,self.b),before);self.assertAlmostEqual(w[0][0],.3);self.assertAlmostEqual(w[0][1],-.9);self.assertAlmostEqual(b[0],.1)
        self.assertAlmostEqual(w[1][0],1.2);self.assertAlmostEqual(w[1][1],.15);self.assertAlmostEqual(b[1],0)
    def test_repeated_batch_does_not_change_mean_gradient(self):
        rows=[{'x':[2,-1],'y':[1.2,2.65]}];a=loss_and_gradient(rows,self.w,self.b);b=loss_and_gradient(rows*3,self.w,self.b)
        self.assertAlmostEqual(a['loss'],b['loss']);self.assertAlmostEqual(a['weight_gradient'][0][0],b['weight_gradient'][0][0])
    def test_training_improves_and_guard_is_explicit(self):
        rows=[{'x':[-1,1],'y':[-1,1]},{'x':[1,-1],'y':[1,-1]}]
        r=fit(rows,2,2,.1,8);self.assertLess(r['trace'][-1]['loss'],r['trace'][0]['loss']);self.assertEqual(r['completed_updates'],8)
        bad=fit(rows,2,2,10,50,max_loss=100);self.assertEqual(bad['status'],'loss_budget_stop');self.assertGreater(bad['trace'][-1]['loss'],100)
    def test_bad_shapes_and_values_refused(self):
        for x,w,b in [([1],self.w,self.b),([True,1],self.w,self.b),([1,2],[[1],[1,2]],[0,0]),([1,2],self.w,[0]),([1,2],self.w,[float('nan'),0])]:
            with self.assertRaises(ValueError):forward(x,w,b)
if __name__=='__main__':unittest.main()
