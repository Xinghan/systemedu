# M40 · 从平方展开走到一次可复算更新

标准库、离线、无硬件调用。只读M35教学包中的train；它不含图像，不能替代完整ACT训练。先完成M37 normalization.json，并保留实践包中 lessons/M35、M37、M38、M40相对目录。

在实践包根目录运行，字段名改成自己的明确通道：

```sh
python3 lessons/M40/code/gradient_descent.py work/teaching-package work/normalization.json --field left_shoulder_pan.pos --weight 0 --bias 0 --rates 0.05 1.5 --steps 20 --out work/scalar-training-v1
```

命令沿M38 make_slice重新从已验证M35包与M37配置生成切片，复核来源/训练统计，不盲信手工改写的独立slice。可用 `--episode` 指定一个训练episode；不支持validation/test。归一化仍由整个训练集合拟合，不因选择一个episode而重拟合。合成测试包必须显式加 `--allow-synthetic`，输出保持synthetic，不能当本人作业。

两个学习率从完全相同初值出发，每一步使用选定训练切片的全部帧。0.05与1.5只是实验候选，并非对所有数据都合适/过大的保证。批次与尺度会改变曲率，应看自己曲线。默认最多20次更新，可显式修改到0–2000。程序没有自动“换小步长直到图好看”。

公式口径为每帧平方误差的平均，没有二分之一系数。权重方向为每帧 `2 * error * x` 再平均，偏置方向为每帧 `2 * error` 再平均；两个方向都在同一组旧参数计算，然后同时更新。没有动量、权重衰减或Adam。

输出 `training.json` 保留来源、归一化SHA256、切片内容摘要、初值、候选步长、完整轨迹与停止原因。`first_sample_handcheck`给第一帧身份和两侧微扰，用于一帧手算；`full_batch_difference_check`才与整批更新方向对照。不要把单帧斜率与全批平均混用。

`trace-run-1.csv` 等从step=0的初态开始，step=1代表完成一次同时更新。`loss-curves.svg`用共同线性纵轴，不删上升点、不平滑；大损失可令小曲线看起来扁平，应结合CSV数值阅读。最后 `prediction-run-1.json` 可继续交M39 joint_ledger.py，回到原单位看误差；其中包含同样的帧身份和归一化摘要。

默认 `max_loss=1e12` 是停止计算的教学护栏，不是达标阈值。有限但超阈值的点仍保存并标loss_budget_stop；非有限更新拒绝，保留此前有效参数与轨迹，标nonfinite_update_rejected。不要把这些状态改成收敛。参数、目标或输入非法在开始时就拒绝；输出目录必须全新，不覆盖旧实验。

示意一帧：输入2、目标3、旧权重0、旧偏置0，误差−3，损失9。权重方向−12，偏置方向−6。学习率0.05后权重0.6、偏置0.3，预测1.5、误差−1.5、损失2.25。学习率0.3从同一初态出发，预测9、误差6、损失36；第二步变144。这只是固定synthetic算例，个人数据可能不同。

默认两侧微扰 `epsilon=1e-4`。精确二次函数的中心差商在实数算术中等于局部一次项系数；计算机仍有舍入误差。误差变大时分别检查算式、样本范围、同一初态和epsilon，不将epsilon无限缩小。微扰检查只核算计算链，不能证明模型会泛化。

```sh
python3 -m unittest discover -s lessons/M40/code -p 'test_*.py' -v
```

所有测试是synthetic离线数值检查；本课没有自动控制真机、没有打开保留测试、没有报告个人任务成功。
