# 来源与贡献边界

`course_cli.py`、命令生成器、学生模板、中文实践说明和 `cad/*.scad` 是为本次 ALOHA 启发课程新写的教学材料，没有复用其他项目业务内容。

`research/lerobot/` 是 Hugging Face LeRobot 固定 commit 的官方源码/文档/依赖锁快照；`research/soarm100/` 是 TheRobotStudio SO-ARM100 固定 commit 的 README 与许可。原版权头和 LICENSE 均保留，具体路径与获取摘要见 `sources.json`。这些内容仍归原作者，不是课程或学生原创。

ALOHA/ACT 方法署名 Tony Z. Zhao 等原研究作者。学生 SO-101 工位不代表 Stanford ALOHA 原机，也不暗示研究机构合作、认证或复现原论文性能。

所有 `examples/`、`expected/` 和自动运行日志中的机器人/学习数值都是 synthetic 教学数据或这些数据上的真实软件计算。没有实际采集个人影像、训练学生 ACT、运行机械臂或生成实机通过证明。实际学生数据与记录应明确作者、采集日期和验证边界。
