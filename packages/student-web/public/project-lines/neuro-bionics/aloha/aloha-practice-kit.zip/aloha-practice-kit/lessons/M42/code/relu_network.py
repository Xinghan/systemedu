"""Two affine layers with an explicit ReLU; forward mechanics only, no hidden training."""
import math,random,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M41/code'))
from linear_layer import forward as affine,validate,finite

def validate_network(model):
    if not isinstance(model,dict):raise ValueError('Model must be an object')
    ni,nh=validate(model['w1'],model['b1']);hidden,no=validate(model['w2'],model['b2'])
    if hidden!=nh:raise ValueError('Second-layer input size differs from hidden count')
    if model.get('activation')!='relu':raise ValueError('Only explicitly declared ReLU is supported')
    return ni,nh,no

def initialize(inputs=12,hidden=4,outputs=12,seed=23):
    if any(type(v) is not int or v<1 for v in (inputs,hidden,outputs)) or type(seed) is not int:raise ValueError('Positive integer sizes and integer seed required')
    if max(inputs,hidden,outputs)>128:raise ValueError('This teaching network is bounded to 128 units per layer')
    rng=random.Random(seed);a=1/math.sqrt(inputs);b=1/math.sqrt(hidden)
    return {'activation':'relu','w1':[[rng.uniform(-a,a) for _ in range(inputs)] for _ in range(hidden)],'b1':[0.05]*hidden,
            'w2':[[rng.uniform(-b,b) for _ in range(hidden)] for _ in range(outputs)],'b2':[0.]*outputs,
            'initialization':{'seed':seed,'rule':'independent uniform weights ±1/sqrt(fan_in), hidden bias .05, output bias 0; course choice, not an optimality claim'}}

def forward(x,model,with_relu=True):
    ni,nh,no=validate_network(model)
    z,first=affine(x,model['w1'],model['b1'],True)
    hidden=[max(0.,v) if with_relu else v for v in z]
    output,second=affine(hidden,model['w2'],model['b2'],True)
    return {'input':list(x),'preactivation':z,'active_positive':[v>0 for v in z],
            'activation':hidden,'prediction':output,'hidden_rule':'max(0,z)' if with_relu else 'identity (controlled comparison only)',
            'first_layer_terms':first,'second_layer_terms':second,'shapes':{'input':[ni],'hidden':[nh],'output':[no]},
            'output_rule':'affine, no ReLU on final target predictions'}

def worked_example():
    return {'activation':'relu','w1':[[.5,-1],[-1,.5]],'b1':[.2,.5],
            'w2':[[1,-.5],[.25,1]],'b2':[.1,-.2],
            'initialization':{'rule':'fixed synthetic arithmetic example; not learned'}}

def absolute_value_example(x):
    x=finite(x);positive=max(0.,x);negative=max(0.,-x)
    return {'input':x,'hidden':[positive,negative],'prediction':positive+negative,'provenance':'constructed synthetic, not trained'}
