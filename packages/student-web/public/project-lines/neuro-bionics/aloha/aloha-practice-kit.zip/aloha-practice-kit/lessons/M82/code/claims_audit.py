"""M82: source/license/contribution/claim link completeness; no legal or originality score."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M79'/'code'))
from evidence_files import read,inventory,references,text,run_cli

def audit_claims(document,artifact_root):
    d=read(document)
    if d.get('schema')!='aloha.claims.v1':raise ValueError('Wrong claims schema')
    files=inventory(artifact_root,d['files']);source_ids=set()
    for src in d['sources']:
        sid=text(src['id'],'source id')
        if sid in source_ids:raise ValueError('Duplicate source identity')
        source_ids.add(sid);text(src['url'],'source URL');text(src['revision'],'source revision')
        if src['kind'] not in ('method','design','software'):raise ValueError('Unknown source kind')
        text(src['use'],'source use')
        if src['kind']!='method':references(src['license_evidence'],files,'license reference')
    if not {'ALOHA','SO-101','LeRobot'}.issubset(source_ids):raise ValueError('Separate ALOHA, SO-101 and LeRobot sources')
    ids=set()
    for claim in d['claims']:
        cid=text(claim['id'],'claim id')
        if cid in ids:raise ValueError('Duplicate claim id')
        ids.add(cid);text(claim['statement'],'claim');text(claim['scope'],'claim scope');text(claim['own_work'],'own work');text(claim['limits'],'claim limits')
        references(claim['evidence'],files,'claim evidence')
        if not claim['source_ids'] or any(s not in source_ids for s in claim['source_ids']):raise ValueError('Unknown claim source')
    if not ids:raise ValueError('At least one bounded claim required')
    fail=d['counterexample'];text(fail['observed'],'counterexample observation');text(fail['unknown'],'remaining uncertainty');references(fail['evidence'],files,'counterexample')
    nxt=d['next_question']
    for k in ('change','prediction','refuting_result','fresh_test_plan'):text(nxt[k],k)
    references(d['questions_record'],files,'questions record')
    return {'structural_complete':True,'claim_count':len(ids),'truth_certified':False,'legal_approval':False,'originality_scored':False,'errors':[],'limits':'Checks explicit links and fields. A human must review whether evidence supports wording and whether sharing complies with the actual source licenses.'}

if __name__=='__main__':run_cli(audit_claims)
