"""Independent synthetic integration, never sends hardware commands or fabricates learner results."""
from pathlib import Path
from datetime import datetime, timezone
import copy, json, sys, tempfile

BASE=Path(__file__).resolve().parents[2]
for node in ('M74','M75','M76','M79','M80','M81','M82'):
    sys.path.insert(0,str(BASE/node/'code'))
from freeze_plan import freeze_plan
from evaluation_audit import actual_versions, audit_evaluation
from run_record import start_run, close_run
from assemble_evaluation import assemble_evaluation
from evidence_files import sha
from release_audit import audit_release, VERSION_KEYS
from handoff_audit import audit_handoff, STAGES, OUTCOMES
from synthetic_gateway_fixture import synthetic_gateway

def trial_chain(root, leaf_ids=True):
    files=[]
    def put(name, data, kind='other'):
        path=root/(name+'.txt' if isinstance(data,str) else name+'.json')
        path.write_text(data if isinstance(data,str) else json.dumps(data,ensure_ascii=False,indent=2))
        ref={'id':name,'kind':kind,'path':str(path.relative_to(root)),'sha256':sha(path)}
        files.append(ref)
        return ref
    leaf=put('leaf','SYNTHETIC placeholder. No robot, real learner data, weights, or video.')
    artifacts={}; bindings={}
    for slot in VERSION_KEYS.values():
        nested=leaf if leaf_ids else {k:leaf[k] for k in ('path','sha256')}
        ref=put(slot,{'files':[nested]} if slot.endswith('_manifest') else {'synthetic':True})
        artifacts[slot]=ref['path'];bindings[slot]=ref['id']
    draft={'evaluation_id':'synthetic-independent-chain','source_kind':'synthetic','time_limit_s':30,
           'version_artifacts':artifacts,
           'acceptance_threshold':{'minimum_successes':16,'maximum_interventions':0,'maximum_estops':0,
            'required_conditions':['all_planned_trials_executed','all_evidence_verified','frozen_versions_match']},
           'plan':[{'trial_id':f'trial-{i:02}','condition':f'SYNTHETIC condition {i}',
                    'initial_setup':'SYNTHETIC no hardware','sealed_test_ref':f'synthetic-condition-{i}',
                    'evidence_requirements':['video','gateway_log','outcome_note']} for i in range(20)]}
    draftref=put('draft',draft)
    freeze_plan(root/draftref['path'],root,root/'plan.json',71)
    plan=json.loads((root/'plan.json').read_text())
    def run(tid,purpose='evaluation',success=True,operator='peer',missing_video=False,gateway_fault=None):
        opening=start_run(root/'plan.json',root,tid,purpose=purpose,operator=operator)
        stamp=datetime.now(timezone.utc).isoformat()
        outcome={'status':'completed' if success else 'failed','started_at':stamp,'ended_at':stamp,
                 'duration_s':0,'tray_held':success,'block_in_tray':success,'human_intervention':False,
                 'failure_reason':'' if success else 'SYNTHETIC failure case','interventions':[]}
        v=put(tid+'-video','SYNTHETIC TEXT PLACEHOLDER, NOT VIDEO','video')
        gw=synthetic_gateway(json.loads(Path(opening).read_text()))
        if gateway_fault=='wrong_run':gw['run_id']='another-synthetic-run'
        if gateway_fault=='teleop':gw['events'][1]['source']='teleop'
        if gateway_fault=='unobserved_stop':gw['termination']['supervisor_observed_stop']=False
        g=put(tid+'-gateway',gw,'gateway_log')
        o=put(tid+'-outcome',outcome,'outcome_note')
        evid=[dict(x,description='SYNTHETIC test fixture') for x in (v,g,o)]
        if missing_video:evid[0]['path']='nonexistent-synthetic-video'
        closed=close_run(opening,root,root/o['path'],evid)
        cr={'id':tid+'-closed','path':str(Path(closed).relative_to(root)),'sha256':sha(closed),'kind':'closed_record'}
        files.append(cr)
        return cr,[v,g,o]
    partial=None
    for i,item in enumerate(plan['plan']):
        run(item['trial_id'],success=i<16)
        if i==15:partial=assemble_evaluation(root/'plan.json',root,root/'partial.json')
    full=assemble_evaluation(root/'plan.json',root,root/'evaluation.json')
    evalref={'id':'evaluation','path':'evaluation.json','sha256':sha(root/'evaluation.json'),'kind':'evaluation'}
    files.append(evalref)
    smoke,se=run('release-smoke',purpose='release_smoke',success=False)
    release={'schema':'aloha.release.v1','release_id':'synthetic-v1','source_kind':'synthetic',
             'files':files.copy(),'bindings':bindings,'frozen_versions':plan['frozen_versions'],
             'evaluation_evidence':'evaluation','smoke_run':{'run_id':json.loads((root/smoke['path']).read_text())['run_id'],
             'metadata_evidence':smoke['id'],'evidence':[x['id'] for x in se]},'gateway_physical_checks':['leaf']}
    releasepath=root/'release.json';releasepath.write_text(json.dumps(release))
    return locals()

checks=[]
def result(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
def attempt(fn):
    try:return {'accepted':True,'value':fn()}
    except Exception as e:return {'accepted':False,'error':str(e),'type':type(e).__name__}

with tempfile.TemporaryDirectory(prefix='aloha-independent-final-chain-') as td:
    root=Path(td).resolve(); c=trial_chain(root)
    result('16_runs_remain_incomplete',not c['partial']['complete'] and c['partial']['successes']==16)
    result('20_runs_16_success_4_failure_complete_synthetic_unaccepted',c['full']['complete'] and c['full']['successes']==16 and not c['full']['accepted'])
    base=attempt(lambda:audit_release(c['releasepath'],root))
    result('real_M74_M75_M76_to_M80_chain',base['accepted'] and base['value']['structural_complete'] and base['value']['performance_status']=='synthetic_only',base)
    nr,ne=c['run']('handoff',purpose='independent_handoff',success=False)
    relref={'id':'release','path':'release.json','sha256':sha(c['releasepath']),'kind':'release'}
    c['files'].append(relref)
    hand={'schema':'aloha.handoff.v1','files':c['files'].copy(),
          'stages':[{'id':x,'source_evidence':['leaf'],'checked_evidence':['leaf'],'limits':'SYNTHETIC only'} for x in STAGES],
          'outcomes':[{'id':x,'source_evidence':['leaf'],'checked_evidence':['leaf'],'limits':'SYNTHETIC only'} for x in OUTCOMES],
          'roles':{'author':'author','operator':'peer','mentor':'mentor','operator_wrote_instructions':False},
          'release_evidence':'release','new_run_evidence':nr['id'],
          'checks':{k:{'status':'completed','observation':'SYNTHETIC test fixture','evidence':[x['id'] for x in ne] if k=='new_run' else ['leaf']} for k in ('fabrication','environment','native_data_read','training_to_weights','new_run')},
          'help_log_evidence':['leaf'],'operator_feedback':['leaf']}
    hp=root/'handoff.json';hp.write_text(json.dumps(hand));hr=attempt(lambda:audit_handoff(hp,root))
    result('real_chain_through_M81',hr['accepted'] and hr['value']['structural_complete'],hr)
    # A valid older file of the same kind must not replace the closed run's recorded bytes.
    switched=copy.deepcopy(c['release']);switched['smoke_run']['evidence']=[x['id'] for x in ne]
    sp=root/'switched.json';sp.write_text(json.dumps(switched))
    # add the new files to this alternate inventory so rejection cannot be mere unknown ID
    switched['files']=c['files'].copy();sp.write_text(json.dumps(switched))
    rr=attempt(lambda:audit_release(sp,root))
    result('reject_smoke_evidence_from_other_run',not rr['accepted'],rr)
    bad,bade=c['run']('broken-smoke',purpose='release_smoke',missing_video=True)
    bd=copy.deepcopy(c['release']);bd['files']=c['files'].copy();bd['smoke_run']['metadata_evidence']=bad['id'];bd['smoke_run']['run_id']=json.loads((root/bad['path']).read_text())['run_id']
    bp=root/'broken.json';bp.write_text(json.dumps(bd));br=attempt(lambda:audit_release(bp,root))
    result('reject_M75_retained_smoke_evidence_errors',not br['accepted'],br)
    badh,badhe=c['run']('broken-handoff',purpose='independent_handoff',missing_video=True)
    hh=copy.deepcopy(hand);hh['files']=c['files'].copy();hh['new_run_evidence']=badh['id']
    bhp=root/'broken-handoff.json';bhp.write_text(json.dumps(hh));hhr=attempt(lambda:audit_handoff(bhp,root))
    result('reject_M75_retained_handoff_evidence_errors',not hhr['accepted'],hhr)
    for fault in ('wrong_run','teleop','unobserved_stop'):
        bad,bade=c['run']('gateway-'+fault,purpose='release_smoke',gateway_fault=fault)
        bd=copy.deepcopy(c['release']);bd['files']=c['files'].copy();bd['smoke_run']={'run_id':json.loads((root/bad['path']).read_text())['run_id'],'metadata_evidence':bad['id'],'evidence':[x['id'] for x in bade]}
        bp=root/('gateway-'+fault+'.json');bp.write_text(json.dumps(bd))
        gr=attempt(lambda:audit_release(bp,root));result('reject_gateway_'+fault,not gr['accepted'],gr)
        # Adversarial synthetic copy: clearing the error list must not bypass content checks.
        bad_record=json.loads((root/bad['path']).read_text());bad_record['evidence_validation_errors']=[]
        override=c['put']('gateway-'+fault+'-cleared',bad_record)
        bd['files']=c['files'].copy();bd['smoke_run']['metadata_evidence']=override['id'];bp.write_text(json.dumps(bd))
        gr=attempt(lambda:audit_release(bp,root));result('reject_gateway_'+fault+'_even_if_error_list_cleared',not gr['accepted'],gr)
with tempfile.TemporaryDirectory(prefix='aloha-minimal-manifest-') as td:
    root=Path(td).resolve();c=trial_chain(root,leaf_ids=False)
    rr=attempt(lambda:audit_release(c['releasepath'],root))
    result('M74_valid_path_sha_manifest_accepted_in_M80',rr['accepted'],rr)

report={'scope':'Real authored API integration on synthetic temporary files; no video decode, student data, ACT deployment, motor calls or physical performance validation.',
        'checked_at':datetime.now(timezone.utc).isoformat(),'checks':checks}
print(json.dumps(report,ensure_ascii=False,indent=2))

raise SystemExit(0 if all(item['passed'] for item in checks) else 1)
