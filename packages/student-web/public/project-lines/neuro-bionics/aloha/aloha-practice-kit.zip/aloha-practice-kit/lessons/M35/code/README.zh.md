# M35 · 本地数据包与低维教学视图

完整原生 LeRobot 包仍是后续视觉 ACT 的数据来源。这里的 JSONL 只为 M36–46 手算、小模型和归一化提供12维状态/动作，不包含图像，不能替代原生训练数据。

Python 3.12 标准库可运行 data_package.py、inspect_package.py 和本目录测试；export_native.py 的原生入口必须在 M14/M16 的完整固定 LeRobot 环境运行（根目录 docs/ENVIRONMENT.zh.md）。本课程作者验证了纯接口和合成边界测试，未声称完整原生库、真实学生采集或机器人硬件已验证。

## 先预演，再接本人原件

`python -m unittest -v` 会运行 synthetic 夹具。随包 synthetic-package 也可以这样读取：

```sh
python data_package.py synthetic-package/teaching --allow-synthetic
python inspect_package.py synthetic-package/index.json --allow-synthetic
```

去掉 --allow-synthetic 必须拒绝。该包只有微型合成张量与假来源文本，没有真实视频，不能改标签后当作完成作品。

## 本人导出

1. 复制 export-contract.template.json 为本人配置。保留规定 joint_names 顺序，核对它与原生 feature names 集合一致；逐回合写稳定身份、attempt、train/validation与原始库整数编号。
2. dataset_source 指向本人完整原生版本，split_policy记录M33清单摘要和位置；填写工位版本及通过审核后的learner_recorded来源。不填test回合，不用新分片编号去索引旧根目录。
3. 在固定LeRobot环境运行，替换大写绝对路径与本人repo身份：

```sh
python export_native.py --root /ABS/PATH/NATIVE_DATASET --repo-id local/course_demo_v1 --contract export-contract.json --out /ABS/PATH/NEW_TEACHING_VIEW
python data_package.py /ABS/PATH/NEW_TEACHING_VIEW --split train
python data_package.py /ABS/PATH/NEW_TEACHING_VIEW --split validation
```

输出目录必须不存在，原件保持不动。网络访问关闭，源文件缺失就报错；默认__getitem__仍会访问原生帧，所需视频不能省略。导出按字段名重排，action语义固定teleop_processor_action，不可改成驱动返回或已到达状态。每侧前5列单位degree，第6列夹爪normalized_0_100。manifest保存SHA、frame_count、固定字段与单位；加载时逐项核对。

## 完整本地包索引

组织完整包，例如 raw/（原生与证据）、audit/（M33/M34报告）、teaching/（低维输出），另有README与数据卡。不要只复制JSONL。M34每个开发回合保留一份实际原生读取报告及匹配sidecar；当前检查器把缺时钟标未完成，不以名义时间补齐。

复制 package-index.template.json为draft，填入split_audit、teaching_export及每个开发episode的原始native索引、source_dataset、source_refs、labels_ref、read_report和用途。所有引用相对包根目录，source_dataset须与实际读取报告一致，原始版本与新位置映射写在README。模板只展示一个条目，必须填齐批准的train/validation回合。

```sh
python create_index.py --root /ABS/PATH/LOCAL_PACKAGE --draft /ABS/PATH/DRAFT.json --out /ABS/PATH/LOCAL_PACKAGE/index.json
python inspect_package.py /ABS/PATH/LOCAL_PACKAGE/index.json
```

create_index计算文件摘要，拒绝覆盖旧索引或跟随符号链接；它不进行课程验收。inspect_package再核对摘要、分组报告、低维样本、原生读取数量、sidecar身份与证据路径。实际视频解码要先运行M34命令，检查器不能认证报告真实性；人工原件复核和来源许可仍须保留。

新的审计报告应放在已签存包外，避免改变版本。故障注入只在副本进行，原始包不改。任何缺失、未知、错序或组交叉都先修复再新建版本；训练运行始终记录该版本。默认本地私有，不含上传步骤。
