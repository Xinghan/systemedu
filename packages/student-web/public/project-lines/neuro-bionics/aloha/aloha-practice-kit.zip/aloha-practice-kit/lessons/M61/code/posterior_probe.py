#!/usr/bin/env python3
"""Inspect actual pinned ACT posterior from a saved normalized batch, without updating."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"M66"/"code"))
from act_step import dependencies,validate_batch,isolated_policy,installed_policy,CAMERAS,STATE,ACTION,sha


def probe(batch_path,manifest_path,output,isolated_source=None,checkout=None):
    np,torch=dependencies();torch.set_num_threads(1)
    arrays=dict(np.load(batch_path,allow_pickle=False));manifest=json.loads(Path(manifest_path).read_text())
    _,k=validate_batch(arrays,manifest)
    torch.manual_seed(31)
    policy,backend=isolated_policy(isolated_source,k) if isolated_source else installed_policy(k,checkout)
    batch={key:torch.from_numpy(arrays[key].copy()).to(dtype=torch.bool if key=="action_is_pad" else torch.float32) for key in [STATE,ACTION,"action_is_pad",*CAMERAS]}
    captured={}
    def encoder_input(module,args,kwargs):
        captured["tokens_shape"]=list(args[0].shape)
        captured["padding_mask"]=kwargs["key_padding_mask"].tolist()
    def output_params(module,args,result):captured["packed_parameters"]=result.detach().tolist()
    def model_output(module,args,result):
        captured["mu"]=result[1][0].detach().tolist();captured["log_variance"]=result[1][1].detach().tolist()
        captured["action_shape"]=list(result[0].shape)
    hs=[policy.model.vae_encoder.register_forward_pre_hook(encoder_input,with_kwargs=True),
        policy.model.vae_encoder_latent_output_proj.register_forward_hook(output_params),
        policy.model.register_forward_hook(model_output)]
    policy.train()
    with torch.no_grad():
        torch.manual_seed(71);policy(batch)
        original=json.loads(json.dumps(captured))
        changed={key:value.clone() for key,value in batch.items()}
        for camera in CAMERAS:changed[camera].add_(10)
        torch.manual_seed(71);policy(changed)
        same_posterior=original["mu"]==captured["mu"] and original["log_variance"]==captured["log_variance"]
    for h in hs:h.remove()
    variance=np.exp(np.asarray(original['log_variance'],dtype=np.float64))
    if not np.isfinite(variance).all() or (variance<=0).any():raise ValueError('posterior variance is not finite positive')
    result={"provenance":manifest["provenance"],"source_ref":manifest["source_ref"],"input_sha256":sha(batch_path),
        "backend":backend,"trace":manifest["trace"],**original,"variance":variance.tolist(),"standard_deviation":np.sqrt(variance).tolist(),
        "posterior_inputs":["CLS","current robot state","valid future action targets"],
        "posterior_images_perturbation_unchanged":same_posterior,
        "scope":"untrained tiny real ACT posterior; output numbers do not yet encode demonstrated skill; images condition main network, not this posterior encoder"}
    if not same_posterior:raise RuntimeError("unexpected image dependence in fixed posterior")
    with Path(output).open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("batch");p.add_argument("manifest");p.add_argument("output")
    g=p.add_mutually_exclusive_group(required=True);g.add_argument("--isolated-source");g.add_argument("--checkout")
    a=p.parse_args();print(json.dumps(probe(a.batch,a.manifest,a.output,a.isolated_source,a.checkout),ensure_ascii=False,indent=2))
