import unittest,copy
from audit_split import audit
D={'source_dataset':'synthetic:no-native-dataset','seed':17,'held_out_conditions':'synthetic reserved arrangement','near_duplicate_review_ref':'synthetic review only','episodes':[dict(native_episode_index=i-1,episode_id=f'e{i}',attempt_id=f'a{i}',batch_id=f'b{i}',lineage_id=f'l{i}',content_sha256=str(i)*64,split=role,evidence_ref='synthetic') for i,role in enumerate(('train','validation','test'),1)]}
class SplitTests(unittest.TestCase):
 def test_bad_container_types(self):
  for value in (None,[],{'episodes':{}},{'episodes':[[]]}):self.assertFalse(audit(value)['valid'])
  for key in ('episode_id','batch_id','lineage_id','split'):
   d=copy.deepcopy(D);d['episodes'][0][key]=[];self.assertFalse(audit(d)['valid'])
 def test_valid(self):self.assertTrue(audit(D)['valid'])
 def test_each_group_boundary(self):
  for key in ('attempt_id','batch_id','lineage_id','content_sha256'):
   d=copy.deepcopy(D);d['episodes'][1][key]=d['episodes'][0][key];self.assertFalse(audit(d)['valid'],key)
 def test_missing_group_no_independence(self):
  d=copy.deepcopy(D);d['episodes'].pop();self.assertFalse(audit(d)['valid'])
 def test_duplicate_id(self):
  d=copy.deepcopy(D);d['episodes'][1]['episode_id']='e1';self.assertFalse(audit(d)['valid'])
 def test_native_identity_unique(self):
  d=copy.deepcopy(D);d['episodes'][1]['native_episode_index']=0;self.assertFalse(audit(d)['valid'])
 def test_digest_changes_with_assignment(self):
  d=copy.deepcopy(D);d['seed']=18;self.assertNotEqual(audit(D)['canonical_manifest_sha256'],audit(d)['canonical_manifest_sha256'])
 def test_near_duplicate_not_promised(self):self.assertFalse(audit(D)['near_duplicates_automatically_ruled_out'])
 def test_missing_review(self):
  d=copy.deepcopy(D);d.pop('near_duplicate_review_ref');self.assertFalse(audit(d)['valid'])
if __name__=='__main__':unittest.main()
