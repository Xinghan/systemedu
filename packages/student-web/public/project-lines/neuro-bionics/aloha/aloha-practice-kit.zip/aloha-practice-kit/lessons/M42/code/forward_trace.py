#!/usr/bin/env python3
"""Record a real sample through an untrained ReLU network, with a fixed-weight identity comparison."""
import argparse,csv,importlib.metadata,json,platform,sys
from pathlib import Path
from relu_network import initialize,forward,worked_example,absolute_value_example
from network_artifact import save,load,sha
from dataset_view import load_view,FIELDS
from linear_baseline import load_checkpoint,identity
from linear_layer import forward as affine
from trace_svg import render

def dump(path,value):
    with Path(path).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')

def generate(package,normalization,linear_folder,output,hidden=4,seed=23,episode=None,frame=None,allow_synthetic=False):
    view=load_view(package,normalization,'train',allow_synthetic)
    w,b,linear_meta=load_checkpoint(linear_folder,view)
    if (episode is None)!=(frame is None):raise ValueError('Choose both episode and frame, or omit both for first train frame')
    rows=view['rows'] if episode is None else [r for r in view['rows'] if r['episode_id']==episode and r['frame_index']==frame]
    if not rows:raise ValueError('Requested frame is not in train')
    row=rows[0];model=initialize(12,hidden,12,seed);trace=forward(row['x'],model);plain=forward(row['x'],model,False)
    linear_prediction=affine(row['x'],w,b)
    p=Path(output);save(p,model,view);restored,metadata=load(p,view)
    restored_trace=forward(row['x'],restored)
    if restored_trace!=trace:raise ValueError('Parameter save/load changed forward values')
    for j,term in enumerate(trace['first_layer_terms']):
        term['hidden_index']=j
        for v in term['terms']:v['input_field']=FIELDS[v['input_index']]
    for j,term in enumerate(trace['second_layer_terms']):term['output_field']=FIELDS[j]
    evidence={'source':identity(view),'frame':{k:row[k] for k in ('episode_id','attempt_id','frame_index')},
              'training_status':'initialized_untrained','network':trace,'same_parameters_identity_hidden':plain,
              'linear_reference':{'checkpoint_sha256':linear_meta['checkpoint_sha256'],'training_status':linear_meta['training_status'],
                                  'prediction':linear_prediction,'meaning':'M41 trained reference; not a fair trained performance comparison with this initialized network'},
              'target_standardized':row['y'],'validation_opened':False,'test_opened':False,'hardware_command':False,
              'saved_loaded_forward_identical':True}
    dump(p/'forward-trace.json',evidence)
    (p/'forward-trace.svg').write_text(render(evidence))
    with (p/'hidden-activations.csv').open('x',newline='') as f:
        writer=csv.writer(f);writer.writerow(['hidden_index','preactivation','positive_branch','relu_value'])
        for j,z in enumerate(trace['preactivation']):writer.writerow([j,z,z>0,trace['activation'][j]])
    with (p/'predictions.csv').open('x',newline='') as f:
        writer=csv.writer(f);writer.writerow(['field','target_standardized','untrained_relu','same_weights_no_relu','M41_trained_reference'])
        for j,name in enumerate(FIELDS):writer.writerow([name,row['y'][j],trace['prediction'][j],plain['prediction'][j],linear_prediction[j]])
    toy=worked_example();dump(p/'synthetic-expressivity.json',{'provenance':'constructed synthetic examples, never learner outcomes',
        'worked_relu':forward([2,-1],toy),'same_weights_identity':forward([2,-1],toy,False),
        'absolute_value_three_points':[absolute_value_example(x) for x in (-1,0,1)],
        'meaning':'Constructed expressivity example; no training success or model superiority claim'})
    dump(p/'environment.json',{'python':sys.version,'platform':platform.platform(),'packages':{name:importlib.metadata.version(name) for name in ('torch','safetensors')},
        'code_sha256':{name:sha(Path(__file__).with_name(name)) for name in ('relu_network.py','network_artifact.py','forward_trace.py','trace_svg.py')},
        'inherited_environment_file':str(Path(linear_folder)/'environment.json'),'inherited_environment_sha256':sha(Path(linear_folder)/'environment.json'),
        'scope':'offline forward computation only; no network training or hardware execution'})
    return {'provenance':view['provenance'],'frame':evidence['frame'],'shapes':trace['shapes'],
            'training_status':'initialized_untrained','active_hidden_count':sum(trace['active_positive']),
            'saved_loaded_forward_identical':True,'hardware_command':False}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('linear_model');p.add_argument('--out',required=True)
    p.add_argument('--hidden',type=int,default=4);p.add_argument('--seed',type=int,default=23);p.add_argument('--episode');p.add_argument('--frame',type=int);p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
    try:print(json.dumps(generate(a.package,a.normalization,a.linear_model,a.out,a.hidden,a.seed,a.episode,a.frame,a.allow_synthetic),ensure_ascii=False,indent=2))
    except (OSError,ValueError,KeyError,TypeError,OverflowError,ImportError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
