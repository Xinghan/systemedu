"""Compare local file bytes; matching hashes do not certify truth or quality."""
import argparse,hashlib,json
from pathlib import Path

def inventory(root):
 root=Path(root).resolve();files={};errors=[]
 if not root.is_dir():return {'valid':False,'errors':['root is not a directory'],'files':{}}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():errors.append('symbolic link not audited: '+str(p.relative_to(root)));continue
  if p.is_file():
   h=hashlib.sha256()
   with p.open('rb') as f:
    while chunk:=f.read(1024*1024):h.update(chunk)
   files[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
 if not files:errors.append('empty directory')
 return {'valid':not errors,'errors':errors,'files':files,'truth_of_content_verified':False}
def compare(current,expected):
 a=current['files'];b=expected['files'];changes={'missing':sorted(set(b)-set(a)),'extra':sorted(set(a)-set(b)),'changed':sorted(k for k in set(a)&set(b) if a[k]!=b[k])}
 return {'valid':current['valid'] and expected['valid'] and not any(changes.values()),**changes,'truth_of_content_verified':False}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root');p.add_argument('--expected');a=p.parse_args();r=inventory(a.root)
 if a.expected:r=compare(r,json.loads(Path(a.expected).read_text()))
 print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['valid'] else 1)
