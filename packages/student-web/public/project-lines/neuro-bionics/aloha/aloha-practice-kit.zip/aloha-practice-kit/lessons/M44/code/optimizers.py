"""Explicit scalar SGD, Adam and decoupled AdamW. Fresh gradients enter each update."""
import copy,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M43/code'))
from backprop import parameters,get,set_value,zeros
from linear_layer import finite
def configuration(kind='sgd',lr=.01,beta1=.9,beta2=.999,epsilon=1e-8,weight_decay=0.):
 if kind not in ('sgd','adam','adamw'):raise ValueError('Choose sgd, adam or adamw')
 for value in (lr,beta1,beta2,epsilon,weight_decay):finite(value)
 if lr<=0 or epsilon<=0 or not 0<=beta1<1 or not 0<=beta2<1 or weight_decay<0 or lr*weight_decay>=1:raise ValueError('Invalid optimizer hyperparameters')
 if kind!='adamw' and weight_decay!=0:raise ValueError('This teaching SGD/Adam use no decay; choose adamw for decoupled decay')
 return {'kind':kind,'lr':float(lr),'beta1':float(beta1),'beta2':float(beta2),'epsilon':float(epsilon),'weight_decay':float(weight_decay),'decay_scope':'all parameters including biases, explicit teaching choice'}
def initialize(model,config):return {'schema':'aloha.optimizer.v1','config':dict(config),'step':0,'first_moment':zeros(model),'second_moment':zeros(model)}
def validate(model,state):
 if not isinstance(state,dict) or state.get('schema')!='aloha.optimizer.v1' or type(state.get('step')) is not int or state['step']<0:raise ValueError('Invalid optimizer state')
 c=state['config'];expected=configuration(**{k:c[k] for k in ('kind','lr','beta1','beta2','epsilon','weight_decay')})
 if c!=expected:raise ValueError('Optimizer configuration differs')
 for key in ('first_moment','second_moment'):
  if set(state[key])!=set(zeros(model)):raise ValueError('Moment keys differ')
  for group in zeros(model):
   a=state[key][group];b=model[group]
   if not isinstance(a,list) or len(a)!=len(b) or group.startswith('w') and any(not isinstance(r,list) or len(r)!=len(q) for r,q in zip(a,b)):raise ValueError('Moment shape differs')
  for path in parameters(model):
   value=finite(get(state[key],path))
   if key=='second_moment' and value<0:raise ValueError('Second moment must be nonnegative')
 return c
def scalar_update(value,gradient,m,v,step,config):
 value,gradient,m,v=map(finite,(value,gradient,m,v));c=config
 if type(step) is not int or step<1:raise ValueError('Step index starts at one')
 if v<0:raise ValueError('Negative second moment')
 if c['kind']=='sgd':return {'old':value,'gradient':gradient,'first_moment':m,'second_moment':v,'bias_corrected_first':None,'bias_corrected_second':None,'denominator':None,'adaptive_change':c['lr']*gradient,'decay_change':0.,'new':finite(value-c['lr']*gradient)}
 m=finite(c['beta1']*m+(1-c['beta1'])*gradient);v=finite(c['beta2']*v+(1-c['beta2'])*gradient*gradient)
 mh=finite(m/(1-c['beta1']**step));vh=finite(v/(1-c['beta2']**step));den=finite(math.sqrt(vh)+c['epsilon']);change=finite(c['lr']*mh/den);decay=finite(c['lr']*c['weight_decay']*value) if c['kind']=='adamw' else 0.
 return {'old':value,'gradient':gradient,'first_moment':m,'second_moment':v,'bias_corrected_first':mh,'bias_corrected_second':vh,'denominator':den,'adaptive_change':change,'decay_change':decay,'new':finite(value-decay-change)}
def update(model,gradient,state):
 c=validate(model,state);new=copy.deepcopy(model);next_state=copy.deepcopy(state);next_state['step']+=1;trace=[]
 for path in parameters(model):
  r=scalar_update(get(model,path),get(gradient,path),get(state['first_moment'],path),get(state['second_moment'],path),next_state['step'],c)
  set_value(new,path,r['new']);set_value(next_state['first_moment'],path,r['first_moment']);set_value(next_state['second_moment'],path,r['second_moment']);trace.append({'parameter':list(path),**r})
 return new,next_state,trace
def worked_table():
 configs=[configuration(k,.1,.5,.5,.01,.1 if k=='adamw' else 0.) for k in ('sgd','adam','adamw')];runs=[]
 for c in configs:
  w=1.;m=v=0.;rows=[]
  for step,g in enumerate((2.,-1.,1.),1):
   r=scalar_update(w,g,m,v,step,c);rows.append({'step':step,**r});w,m,v=r['new'],r['first_moment'],r['second_moment']
  runs.append({'config':c,'steps':rows,'provenance':'synthetic prescribed gradients; not a learned trajectory'})
 return runs
