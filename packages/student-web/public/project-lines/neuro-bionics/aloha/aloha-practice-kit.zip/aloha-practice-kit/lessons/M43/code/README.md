# M43：三种途径核对同一隐藏权重

沿用 M35 教学包、M37 统计、M42 初始网络，以及 M41 核验过的固定 torch/safetensors 环境。程序全程离线，不训练、不发送命令；源数据只选 train。输出目标仍是 `teleop_processor_action`，不是实测状态或驱动返回。

在实践包根目录，把路径换成本人的前作：

```sh
python lessons/M43/code/gradient_check.py work/M35/package work/M37/normalization.json work/M42/forward-v1 --out work/M43/correct
python lessons/M43/code/gradient_check.py work/M35/package work/M37/normalization.json work/M42/forward-v1 --inject-fault --out work/M43/omit-branch
```

第一条复用 M42 选帧，显式逐支回传、中心差分、torch float64 autograd 核对全部112个参数。三档扰动0.001、0.0001、0.00001；损失分母为本次帧数乘12，不含二分之一。也可同时提供 `--episode 本人标识 --frame 整数` 改选另一训练帧，不能拿test挑容易通过的例子。

第二条只在显式反传中漏掉一个确实影响隐藏权重的输出分支，前向和另两种计算保持不变。它会保存失败报告并退出1，这是故意检测到错误，**不应改成绿色**。若该帧所有相关贡献恰为零，工具明确要求另选训练帧，不伪造非零差异。退出2表示输入/来源/环境错误；先修复这些问题。

- `backprop.py`：路径贡献先相加，再乘隐藏ReLU本地因子，再乘对应输入。完整梯度在同一旧参数上计算；返回值给 M44 优化器使用。
- `gradient-check.json`：全部显式/自动/数值比较、每个扰动的正负损失、开关跨界记录、容差和状态。
- `hand-trace.json`：正确路径账本，逐输出字段的误差、平均后的信号、出向权重、乘积与汇合，再列每个入向权重；选一条隐藏连接本人手推。
- `comparisons.csv`、`summary.json`：完整结果；`mismatch`是差异，`inconclusive_branch`是扰动均跨拐点，不能写成通过。
- `environment.json`：实际Python、torch、代码与模型元数据摘要。

判定采用绝对误差加相对误差，近零不直接相除。ReLU拐点附近先看正负扰动是否切换开关，跨界那一档保留为不适用，不用调大容差掩盖。若只有跨界档位，需换明确非拐点参数/样本再检查，原报告仍保存。小得无法改变浮点参数的扰动也不能认证。数学零点不可微与框架采用零作为反传约定是不同概念。

示意计算：M42固定两输入网络目标设1.3、0.75，误差1、−0.4，平均平方0.58。第一个隐藏单元收到1×1与−0.4×0.25两条贡献，和为0.9；正分支因子1，入向输入2，故指定权重方向1.8。漏第二支路误得2。参数加减0.001的损失分别0.581802125、0.578202125，差除0.002得1.8。所有示意标为synthetic，不代替本人手推。

数值差分本身也可能受舍入或跨分支影响；三方一致仅核验本次图、目标、样本与参数，不证明整套ACT或实机任务可靠。不要通过换数据、调容差、删除失败参数来让报告变绿。

浏览器图导出后的本地核验：

```sh
python lessons/M43/code/game_graph_check.py downloads/m43-reverse-graph.json --out work/M43/browser-torch-check.json
```

此程序重新计算数值来源、构造节点、完整前向及真实torch自动梯度，不信任导出文件声称的答案。它仍是synthetic机制练习，不替代上面的本人数据报告。只保留第一路径的图应为mismatch；改正后可再次导出到另一个文件，保留修复前后证据。
