"""Regenerate explicitly synthetic teaching fixtures, never student experiment results."""
import json
from pathlib import Path
from course_cli import FIELDS,JOINTS
from act_commands import REVISION
ROOT=Path(__file__).parent
P='synthetic teaching example; not student data or real robot results'
def write(name,obj):
 p=ROOT/'examples'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
state={k:50.0 if 'gripper' in k else 0.0 for k in FIELDS}
write('state.json',{'provenance':P,'state':state})
write('sampling.json',{'provenance':P,'timestamps_s':[0,0.1,0.2,0.4]})
write('limits.json',{'provenance':P,'present':state,'target':{k:120 for k in FIELDS},'limits':{k:{'min':0 if 'gripper' in k else -30,'max':100 if 'gripper' in k else 30,'max_delta':2.0} for k in FIELDS}})
write('sync.json',{'provenance':P,'image_clock_offset_s':0.0,'max_age_s':0.05,'rows':[{'state_time_s':0.0,'image_capture_time_s':0.0,'action_time_s':0.01},{'state_time_s':0.1,'image_capture_time_s':0.13,'action_time_s':0.11}]})
write('toy_train.json',{'provenance':P,'train':[{'x':0,'y':1},{'x':1,'y':3}],'validation':[{'x':0.5,'y':2}],'initial_w':0,'initial_b':0,'learning_rate':0.1,'steps':20})
write('chunks.json',{'provenance':P,'target_step':1,'coefficient':0.6931471805599453,'chunks':[{'start_step':0,'actions':[[0,0],[10,20],[20,30]]},{'start_step':1,'actions':[[40,50],[50,60]]},{'start_step':2,'actions':[[999,999]]}]})
write('evaluation.json',{'provenance':P,'time_limit_s':60,'plan':[{'trial_id':f'T{i}','condition':'centre' if i<3 else 'edge'} for i in range(1,5)],'results':[{'trial_id':'T1','status':'completed','tray_held':True,'block_in_tray':True,'human_intervention':False,'duration_s':25},{'trial_id':'T2','status':'failed','tray_held':False,'block_in_tray':False,'human_intervention':False,'duration_s':60,'failure_reason':'tray slipped'},{'trial_id':'T3','status':'intervention','tray_held':True,'block_in_tray':True,'human_intervention':True,'duration_s':30,'failure_reason':'mentor repositioned tray'},{'trial_id':'T4','status':'completed','tray_held':True,'block_in_tray':True,'human_intervention':False,'duration_s':61,'failure_reason':'time limit exceeded'}]})
manifest={'provenance':P,'reserved_test_batches':['C'],'validation_batch_count':1,'episodes':[]}
for i in range(6):
 path=ROOT/'examples'/'episodes'/f'{i}.jsonl';path.parent.mkdir(exist_ok=True)
 path.write_text(''.join(json.dumps({'provenance':P,'episode_index':i,'timestamp_s':t/10,'state':i+t})+'\n' for t in range(3)))
 manifest['episodes'].append({'episode_index':i,'batch':'ABC'[i//2],'file':f'{i}.jsonl','accepted_for_learning':i!=1,'exclusion_reason':'synthetic dropped-frame example' if i==1 else ''})
write('episode_index.json',manifest)
config={'provenance':P,'lerobot_revision':REVISION,'use_degrees':True,'device':'cpu','fps':30,'ports':{k:f'/SYNTHETIC_NOT_A_DEVICE/{k}' for k in ('left_follower','right_follower','left_leader','right_leader')},'robot_id':'course_pair_v1','teleop_id':'course_teachers_v1','max_relative_target':{s:{j:1.0 for j in JOINTS} for s in ('left','right')},'cameras':{'front':{'index_or_path':0,'width':640,'height':480},'overhead':{'index_or_path':1,'width':640,'height':480}},'dataset_root':'/SYNTHETIC_NOT_A_DATASET/demo_v1','dataset_repo_id':'local/course_demo_v1','task':'Left arm holds the tray while right arm places the light block in it.','record':{'num_episodes':2,'episode_time_s':60,'reset_time_s':30},'train':{'output_dir':'/SYNTHETIC_NOT_A_OUTPUT/act_v1','steps':1000,'batch_size':2,'seed':7,'chunk_size':20,'n_action_steps':1,'temporal_ensemble_coeff':0.01},'rollout':{'trial_id':'T01','root':'/SYNTHETIC_NOT_A_OUTPUT/evaluation_v1','checkpoint':'/SYNTHETIC_NOT_A_CHECKPOINT/pretrained_model','time_limit_s':60}}
config['split_root']='/SYNTHETIC_NOT_A_DATASET/splits_v1'
write('act_config.synthetic.json',config)
config['provenance']='student local configuration; fill with measured values'
config['ports']={k:'REPLACE_WITH_IDENTIFIED_PORT' for k in config['ports']}
config['max_relative_target']={s:{j:None for j in JOINTS} for s in ('left','right')}
config['dataset_root']='REPLACE_WITH_ABSOLUTE_LOCAL_PATH';config['train']['output_dir']='REPLACE_WITH_NEW_ABSOLUTE_PATH';config['rollout']['checkpoint']='REPLACE_WITH_CHECKPOINT_PATH';config['rollout']['root']='REPLACE_WITH_EVALUATION_ROOT'
config['split_root']='REPLACE_WITH_NEW_SPLITS_ROOT'
(ROOT/'templates'/'act_config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
