# M05：只读取自己的字段文件

这些是标准库离线程序，不需要LeRobot，也没有硬件接口。先把M03的个人表另存为 `channels-mine.json`，保留原始样例的 `synthetic` 标签。日志只支持本机读取成功的主张。

请导师先准备Python 3.12。在此目录打开终端。

macOS / Linux：
```text
python3.12 -m venv .venv
.venv/bin/python read_config.py channels-mine.json --output read-log.json
.venv/bin/python fingerprint.py > environment.json
```

Windows：
```text
py -3.12 -m venv .venv
.venv\Scripts\python.exe read_config.py channels-mine.json --output read-log.json
.venv\Scripts\python.exe fingerprint.py > environment.json
```

打开日志逐项检查，不只看字段数。故意使用不存在的输入文件时，程序打印REJECT并返回退出码2；恢复后应返回0。关闭终端后从同一目录重跑，保存自己的运行记录。本附件不附“替学生完成”的运行日志。
