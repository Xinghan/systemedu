"""Check a local package index and evidence references; not an authenticity certificate."""
import argparse,hashlib,json
from pathlib import Path
from data_package import load

def inside(root,relative):
 if not isinstance(relative,str) or Path(relative).is_absolute():raise ValueError('relative package path required')
 p=(root/relative).resolve()
 if not p.is_relative_to(root):raise ValueError('path escapes package')
 return p

def inspect(index_path,allow_synthetic=False):
 index_path=Path(index_path).resolve();root=index_path.parent;index=json.loads(index_path.read_text());errors=[]
 if index.get('schema')!='aloha.local-package.v1':errors.append('invalid package schema')
 if index.get('provenance')!='learner_recorded' and not (allow_synthetic and index.get('provenance')=='synthetic'):errors.append('learner_recorded provenance required')
 files=index.get('files',{})
 if not files:errors.append('no referenced files')
 for relative,expected in files.items():
  try:
   p=inside(root,relative)
   if not p.is_file():errors.append('missing file: '+relative);continue
   h=hashlib.sha256()
   with p.open('rb') as f:
    while chunk:=f.read(1024*1024):h.update(chunk)
   if h.hexdigest()!=expected:errors.append('changed file: '+relative)
  except (ValueError,OSError) as e:errors.append(str(e))
 def read_ref(relative):
  if relative not in files:raise ValueError('unhashed reference: '+str(relative))
  return json.loads(inside(root,relative).read_text())
 try:
  split=read_ref(index['split_audit'])
  if split.get('valid') is not True:errors.append('split audit not passed')
  role_sets={role:set((split.get('splits') or {}).get(role,[])) for role in ('train','validation','test')}
  if any(role_sets[a]&role_sets[b] for a,b in [('train','validation'),('train','test'),('validation','test')]):errors.append('split audit contains overlapping roles')
  lookup=index['episode_lookup'];needed=set((split.get('splits') or {}).get('train',[])+(split.get('splits') or {}).get('validation',[]))
  if not needed:errors.append('no approved development episodes')
  all_rows=[]
  for role in ('train','validation'):
   meta,rows=load(inside(root,index['teaching_export']),role,allow_synthetic);all_rows.extend(rows)
   for rel in (index['teaching_export']+'/manifest.json',index['teaching_export']+'/data/frames.jsonl'):
    if rel not in files:errors.append('teaching file not in hashed index: '+rel)
  if {r['episode_id'] for r in all_rows}!=needed:errors.append('teaching episodes differ from split audit')
  for eid in needed:
   e=lookup[eid];role=e['split'];native=str(e['native_episode_index']);read=read_ref(e['read_report'])
   if eid not in split['splits'].get(role,[]):errors.append(eid+': role mismatch')
   for relative in e['source_refs']+[e['labels_ref']]:
    if relative not in files:errors.append(eid+': unhashed evidence '+relative)
   if not e['source_refs']:errors.append(eid+': source references empty')
   if read.get('valid') is not True or read.get('cross_source_verified') is not True:errors.append(eid+': native read/source-binding report failed')
   n=read.get('episode_frame_counts',{}).get(native)
   mine=[r for r in all_rows if r['episode_id']==eid]
   if {r['split'] for r in mine}!={role}:errors.append(eid+': teaching row split differs from approved role')
   if type(n) is not int or n<=0 or n!=len(mine):errors.append(eid+': decoded/native teaching frame count mismatch')
   side=read.get('sidecar',{})
   if side.get('valid') is not True or str(side.get('episode_index'))!=native or side.get('frame_count')!=n:errors.append(eid+': timing evidence missing or mismatched')
   if {r['attempt_id'] for r in mine}!={side.get('attempt_id')}:errors.append(eid+': attempt ID mismatch')
   if not side.get('native_dataset_reference') or side.get('native_dataset_reference')!=(read.get('source_dataset') or {}).get('version_reference'):errors.append(eid+': saved version reference mismatch')
   if read.get('source_dataset')!=e.get('source_dataset'):errors.append(eid+': native source version/location mismatch')
 except (KeyError,ValueError,OSError,TypeError) as e:errors.append('package reference/contract error: '+str(e))
 return {'valid':not errors,'errors':errors,'provenance':index.get('provenance'),'files_checked':len(files),'report_role':'reference and structural audit; actual decoding is evidenced by linked native reports','authenticity_verified':False,'model_trained':False,'uploaded':False}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('index');p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args();r=inspect(a.index,a.allow_synthetic);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['valid'] else 1)
