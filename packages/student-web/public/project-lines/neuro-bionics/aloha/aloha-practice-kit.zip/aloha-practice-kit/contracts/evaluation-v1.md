# 独立试次交接契约：aloha.independent-evaluation.v1

M73–78 的验收与 M79–82 的改版/发布共同消费此格式。兼容 practice-kit/course_cli.py evaluate 的 plan/results/time_limit_s/provenance；旧 evaluate 只给计数，不能替代本契约的来源及证据完整性闸门。

顶层：schema、evaluation_id、source_kind（learner_recording 或 synthetic）、provenance（字符串）、created_at、time_limit_s、plan_path、plan_sha256、acceptance_threshold、frozen_versions、plan（恰好20项）、results（可少于20项；少则 incomplete）。计划必须在第一次执行前保存冻结，plan_sha256 是单独 plan.json 原始字节 SHA256。plan_path 为证据根目录内相对路径。

单独 plan.json 含 schema=aloha.independent-plan.v1、evaluation_id、registered_at、time_limit_s、acceptance_threshold、frozen_versions、plan。验收文件中的对应字段必须与该文件内容完全一致，不能仅复用摘要而偷换门槛。acceptance_threshold 固定结构：minimum_successes（0–20整数，由学生/导师运行前填写，不预填成达标数）、maximum_interventions（0–20整数）、maximum_estops（0–20整数）、required_conditions（必须含 all_planned_trials_executed、all_evidence_verified、frozen_versions_match）。未知条件拒绝；自由文字解释可另放 notes，不可当成自动判定规则。

frozen_versions：model_manifest_sha256、hardware_manifest_sha256、config_sha256、dataset_split_manifest_sha256、software_manifest_sha256。前三项不能只是随手输入的型号名称：对应实际文件清单/配置的 SHA256。model_manifest 包含 checkpoint/processor 各文件路径与 SHA256；hardware_manifest 包含四臂型号、打印件版本、标定文件哈希与装配记录；software_manifest 包含锁定提交、包版本、网关源码哈希。每个哈希必须64位小写十六进制。

plan 单项：trial_id（唯一稳定编号）、order（1–20）、condition（稳定条件名）、initial_setup（可检查的文字和量值）、planned_status（恒 planned）、sealed_test_ref（条件来源记录）、evidence_requirements（至少 video/gateway_log/outcome_note）。计划不写假结果，不临时替换失败编号。

results 单项：trial_id、status（completed/failed/intervention/estop）、started_at、ended_at、duration_s、tray_held、block_in_tray、human_intervention（后三项布尔）、failure_reason（失败时非空）、observed_versions（与 frozen_versions 相同五个键）、evidence（条目数组）、interventions（数组）、notes。不存在的试次不造一行 failed；保留缺行并派生 not_executed/incomplete。执行但记录缺失/损坏以实际 status 保留，evidence_complete=false，不能评达标。

evidence 单项：kind（video/gateway_log/outcome_note/other）、path（发布包内相对路径）、sha256、description；不可只有外部会失效 URL。可额外保留 original_url。interventions 单项：offset_s、actor_role、action、reason；含人工托扶、复位、策略期间触碰、急停等。已执行失败与介入永久保留。停止后的新尝试不得覆盖旧试次。

派生 outcome 只由上述原始字段计算：status==completed 且 tray_held 且 block_in_tray 且非 human_intervention 且 duration_s<=time_limit_s → success，否则 failure；planned但无结果 → not_executed。完整性独立于成功：20行、证据可读取且哈希匹配、五个版本匹配、时间顺序合理才 complete。成功分母固定20；不完整仅报告 provisional_successes_over_20，不宣布最终通过。新增改版另建 evaluation_id 和冻结计划，保留原20次。

此文档是接口承诺，实际学生数据尚未产生。JSON Schema 负责结构，后续 Python 审计负责交叉引用、字节哈希、版本一致性、20次顺序与证据存在性；不能声称仅通过 Schema 就是真实实机结果。

审核 API：`lessons/M74/code/evaluation_audit.py` 的 `audit_evaluation(evaluation_path, artifact_root)`，返回 complete、accepted、successes、planned_trials、recorded_trials、errors、trials。accepted 还要求 source_kind=learner_recording、complete、成功数达到预注册门槛、介入与急停不超过预注册上限。合成QA可验证计算但 accepted 永远为 false。此API实现与反例已交付M74作者包并经合成文件测试；没有声称真实学生或硬件已执行验收。


## 实际运行绑定补充

单独plan.json还必须含source_kind及version_artifacts五个路径入口。它们是证据根目录的相对路径，模型/硬件/划分/软件清单的files数组为非空[{path,sha256}]，全部叶文件重新核对；不要求额外id字段。M74 make_inventory.py可从实际文件建立字节清单，内容真实性仍需人审。

每个results含run_id、purpose=evaluation、source_kind、run_record_ref与start_record_ref。run_record_ref引用M75不可覆盖的closed，closed引用原start；身份、冻结计划摘要和实际五类版本绑定。M75 close遇到版本或证据缺失会尽可能保存错误数组；这些错误不能由汇总工具抹去。

观察证据恰好一份outcome_note，M74 verify_outcome_binding(root,run)核其状态、起止时间、duration、托盘/插块/人工flags、失败原因及介入数组与closed一致。原生gateway_log由gateway-log-v1.md规定；validate_gateway_log(path,run)检查run/trial/模型与硬件SHA、policy来源、单次arm、递增命令与最终latched。没有实际policy命令的启用前拒绝仍保存，但不冒充证据完整的物理任务。

M75 start_run(plan_path,artifact_root,trial_id,purpose='evaluation',operator='local_operator',context_plan_path=None)与close_run(run_path,artifact_root,outcome_path,evidence_paths)只读写证据，不发电机命令。release_smoke与independent_handoff另列，后者保存本地operator代号。domain_challenge必须额外context_plan_path，start保存其字节摘要；M78挑战报告核对该绑定，防看过结果后改因素、量值或次数。

truth_certified始终false。synthetic结果永不accepted；测试代码有显式以合成字节验证“声明为learner_recording”的条件分支，不能把分支返回值报告为真实验收。主验收完整性与性能达标分开，所有未执行和未核验位置保留。

模型清单特别约定：正式Runtime使用M69原始aloha.act-model-manifest.v1；冻结model_manifest_sha256与gateway policy_artifact_sha256均引用它的同一实际SHA。通用make_inventory适用于硬件/软件等清单，不能给模型原清单再包一层。保留M69 artifact_root内全部候选目录相对结构。
