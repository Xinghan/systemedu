"""Numerical invariants and provenance checks on explicitly synthetic data."""
import copy,hashlib,json,sys,tempfile,unittest
from pathlib import Path
from loss_ledger import ledger
from joint_ledger import audit
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M37/code'))
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M38/code'))
from normalize import FIELDS,UNITS,fit
from make_slice import make
from scalar_predictor import predict

class LossTests(unittest.TestCase):
    def scalar(self,pred,target):
        return {'rows':[{'prediction':p,'target':t} for p,t in zip(pred,target)],'provenance':{'kind':'synthetic'},'feature':{'field':'a'},'target':{'field':'a'},'normalization_sha256':'unit-fixture'}
    def test_signed_errors_cannot_certify_accuracy(self):
        d=ledger(self.scalar([2,4,5],[3,3,5]));self.assertEqual(d['mean_signed_error'],0)
        self.assertAlmostEqual(d['mae'],2/3);self.assertAlmostEqual(d['mse'],2/3)
    def test_large_error_and_denominator(self):
        d=ledger(self.scalar([2,4,8],[3,3,5]));self.assertEqual(d['denominator'],3)
        self.assertAlmostEqual(d['mae'],5/3);self.assertAlmostEqual(d['mse'],11/3)
    def test_invalid_numeric_input(self):
        for p in [True,float('nan'),float('inf'),1e200]:
            with self.subTest(p=p),self.assertRaises(ValueError):ledger(self.scalar([p],[0]))
        with self.assertRaises(ValueError):ledger(self.scalar([],[]))
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);(self.root/'data').mkdir()
        rows=[dict(episode_id='fixture',attempt_id='synthetic-a',frame_index=i,split='train',observation_state=[x]+[0]*11,action=[x+2]+[0]*11,action_semantics='teleop_processor_action') for i,x in enumerate([8,8,12,12])]
        raw=('\n'.join(json.dumps(r) for r in rows)+'\n').encode();(self.root/'data/frames.jsonl').write_bytes(raw)
        manifest=dict(schema='aloha.teaching-frames.v1',provenance='synthetic',hardware_revision='no hardware',dataset_source='unit fixture',split_policy='one artificial train episode',frame_count=4,sha256=hashlib.sha256(raw).hexdigest(),joint_names=FIELDS,joint_units=UNITS)
        (self.root/'manifest.json').write_text(json.dumps(manifest));self.norm=self.root/'norm.json';self.norm.write_text(json.dumps(fit(self.root,True)))
        self.pred=predict(make(self.root,self.norm,FIELDS[0],allow_synthetic=True),.5,.1);self.pp=self.root/'pred.json';self.save()
    def save(self):self.pp.write_text(json.dumps(self.pred))
    def tearDown(self):self.tmp.cleanup()
    def test_twelve_channels_have_explicit_baselines(self):
        d=audit(self.root,self.norm,self.pp,True);self.assertEqual(len(d['per_channel']),12)
        self.assertAlmostEqual(d['per_channel'][0]['standardized']['mse'],.26)
        self.assertAlmostEqual(d['per_channel'][0]['physical']['mse'],1.04)
        self.assertAlmostEqual(d['normalized_all_channels']['mse'],.26/12)
        self.assertEqual(d['normalized_all_channels']['n'],48)
        self.assertTrue(all('copy current' in c['predictor'] for c in d['per_channel'][1:]))
        self.assertFalse(d['hardware_executed']);self.assertFalse(d['task_success_assessed'])
    def test_source_mutation_refused(self):
        self.pred['provenance']['frames_sha256']='changed';self.save()
        with self.assertRaises(ValueError):audit(self.root,self.norm,self.pp,True)
    def test_normalization_mutation_refused(self):
        self.norm.write_text(self.norm.read_text()+' ')
        with self.assertRaises(ValueError):audit(self.root,self.norm,self.pp,True)
    def test_duplicate_and_boolean_refused(self):
        original=copy.deepcopy(self.pred);self.pred['rows'].append(self.pred['rows'][0]);self.save()
        with self.assertRaises(ValueError):audit(self.root,self.norm,self.pp,True)
        self.pred=original;self.pred['rows'][0]['prediction']=True;self.save()
        with self.assertRaises(ValueError):audit(self.root,self.norm,self.pp,True)

if __name__=='__main__':unittest.main()
