"""Offline paired occlusion of the saved teaching policy; never accesses hardware."""
import sys,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M47/code'))
from vision_course import *
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--checkpoint',required=True);p.add_argument('--manifest',required=True);p.add_argument('--output',required=True);p.add_argument('--split',choices=['train','validation'],default='validation');p.add_argument('--camera',choices=['front','overhead'],default='front');p.add_argument('--rectangle',nargs=4,type=int,required=True);p.add_argument('--hypothesis',required=True);p.add_argument('--allow-synthetic',action='store_true');a=p.parse_args()
if not a.hypothesis.strip():p.error('State the intervention hypothesis first')
out=Path(a.output)
if out.exists():p.error('Use a new output JSON filename')
data=load_manifest(a.manifest,a.split,a.allow_synthetic);cp=torch.load(a.checkpoint,weights_only=True,map_location='cpu')
if cp['source_kind']=='synthetic' and not a.allow_synthetic:p.error('Synthetic checkpoint requires explicit QA flag')
if cp['image_contract']!=data['contract'] or cp['action_fields']!=FIELDS or cp['state_fields']!=FIELDS:p.error('Checkpoint contract mismatch')
if cp['train_manifest_sha256']!=data['manifest_sha256']:p.error('Use the same reviewed development manifest for this paired probe')
x0,y0,x1,y1=a.rectangle;h,w=data['pixels'].shape[-2:]
if not(0<=x0<x1<=w and 0<=y0<y1<=h):p.error('Rectangle outside resized input')
model=TinyVisionPolicy(**cp['config']);model.load_state_dict(cp['model_state']);model.eval();torch.set_num_threads(1)
pixels=data['pixels'][:1].clone();pixels[0,['front','overhead'].index(a.camera),:,y0:y1,x0:x1]=0
mean=torch.tensor(MEAN)[None,None,:,None,None];std=torch.tensor(STD)[None,None,:,None,None];state=normalize(data['state'][:1],cp['stats']['state'])
with torch.no_grad():
    before=model(data['images'][:1],state);after=model((pixels-mean)/std,state)
    before_units=denormalize(before,cp['stats']['action']);after_units=denormalize(after,cp['stats']['action'])
write_json(out,serialize(dict(source_kind=data['source_kind'],dataset_source=data['dataset_source'],checkpoint_sha256=sha256(a.checkpoint),manifest_sha256=data['manifest_sha256'],split=a.split,evidence=data['evidence'][0],hypothesis=a.hypothesis,camera=a.camera,rectangle=a.rectangle,fill_rgb_0_1=0,fields=FIELDS,baseline=before_units,occluded=after_units,change=after_units-before_units,normalized_max_abs_change=(after-before).abs().max(),scope='Paired input sensitivity of a saved small teaching policy; no proof of task robustness or object understanding.',hardware_output=False,test_rows_loaded=False)))
print(str(out.resolve()))
