"""Read-only review of an episode-index CSV; not a video classifier."""
import argparse,csv,json,re
FIELDS=('attempt_id','episode_index','source_ref','provenance','result','integrity','intervention','tags','evidence_ref','training_candidate','decision_reason','rule_version','review_status')
def check(rows):
    errors=[];seen=set();selected=[]
    if not rows:errors.append('index must contain at least one attempt')
    for i,r in enumerate(rows,2):
        label=f'row {i}'
        for k in FIELDS:
            if not str(r.get(k,'')).strip():errors.append(f'{label}: missing {k}')
        attempt=r.get('attempt_id','')
        if attempt in seen:errors.append(f'{label}: duplicate attempt_id')
        seen.add(attempt)
        for key,values in [('provenance',('synthetic','learner_recording')),('result',('success','failure','unknown')),('integrity',('complete','incomplete','unknown')),('intervention',('none_observed','observed','unknown')),('training_candidate',('yes','no')),('review_status',('reviewed','pending'))]:
            if r.get(key) not in values:errors.append(f'{label}: invalid {key}')
        episode=r.get('episode_index','')
        if not (re.fullmatch(r'[0-9]+',episode) or episode=='not_saved'):
            errors.append(f'{label}: episode_index must be a nonnegative integer or not_saved')
        if episode=='not_saved' and r.get('training_candidate')!='no':
            errors.append(f'{label}: unsaved attempt cannot be a training candidate')
        if r.get('training_candidate')=='yes':
            if (r.get('result'),r.get('integrity'),r.get('intervention'),r.get('review_status'))!=('success','complete','none_observed','reviewed'):
                errors.append(f'{label}: candidate violates this lesson’s declared selection rule')
            selected.append(attempt)
    return dict(valid=not errors,errors=errors,archive_rows=len(rows),candidate_attempt_ids=selected if not errors else [],source_files_modified=False,labels_semantically_verified=False,model_success_rate=None)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('csv');a=p.parse_args()
    with open(a.csv,newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
    r=check(rows);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['valid'] else 1)
