"""Predeclared validation selection and patience over observed checkpoints only."""
import math
def number(value):
 if type(value) not in (int,float) or not math.isfinite(value) or value<0:raise ValueError('Expected a finite nonnegative metric')
 return float(value)
def plan(max_steps=20,every=5,patience=0,min_delta=0.):
 if type(max_steps) is not int or not 1<=max_steps<=2000 or type(every) is not int or not 1<=every<=max_steps:raise ValueError('Positive evaluation interval within 1–2000 step budget required')
 if type(patience) is not int or not 0<=patience<=100:raise ValueError('Patience counts evaluation events; use 0 to disable')
 return {'max_steps':max_steps,'evaluate_every_steps':every,'patience_events':patience,'min_delta':number(min_delta),'monitor':'validation standardized MSE over every frame-channel cell','selection':'lowest observed validation metric; exact ties choose earlier step','early_stop':'strict improvement beyond min_delta resets patience; 0 patience disables stopping','test_used_for_selection':False}
def decide(records,rule):
 if not isinstance(records,list) or not records:raise ValueError('At least the initial checkpoint must be evaluated')
 previous=-1;best=0;reference=None;stale=0;history=[]
 for i,r in enumerate(records):
  if type(r.get('step')) is not int or r['step']<=previous:raise ValueError('Evaluation steps must strictly increase')
  previous=r['step'];val=number(r['validation_mse']);number(r['train_mse'])
  if val<number(records[best]['validation_mse']):best=i
  significant=reference is None or val<reference-rule['min_delta']
  if significant:reference=val;stale=0
  else:stale+=1
  stop=rule['patience_events']>0 and stale>=rule['patience_events']
  history.append({'step':r['step'],'significant_improvement':significant,'stale_evaluations':stale,'patience_reference':reference,'stop':stop})
  if stop and i<len(records)-1:raise ValueError('Records continue beyond the declared stop; choose a new attempt, not a retroactive rule')
 return {'selected_index':best,'selected_step':records[best]['step'],'selected_validation_mse':records[best]['validation_mse'],'stop':history[-1]['stop'],'stale_evaluations':stale,'patience_history':history}
def dropout_values(values,keep_mask,drop_probability=.5,training=True):
 """Fixed-mask demonstration of inverted dropout, not part of the M42 network."""
 if type(training) is not bool or type(drop_probability) not in (int,float) or not math.isfinite(drop_probability) or not 0<=drop_probability<1:raise ValueError('Invalid mode/probability')
 if len(values)!=len(keep_mask) or any(type(k) is not bool for k in keep_mask):raise ValueError('Boolean keep mask of matching size required')
 if any(type(v) not in (int,float) or not math.isfinite(v) for v in values):raise ValueError('Finite activation values required')
 result=[float(v) if not training else (v/(1-drop_probability) if keep else 0.) for v,keep in zip(values,keep_mask)]
 if any(not math.isfinite(v) for v in result):raise ValueError('Dropout scaling produced a nonfinite value')
 return result
