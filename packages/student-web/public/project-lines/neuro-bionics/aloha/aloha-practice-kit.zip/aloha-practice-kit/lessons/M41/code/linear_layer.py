"""A transparent dense affine layer. W[out][in]; no hidden autograd or device calls."""
import math

def finite(v):
    if type(v) not in (int,float) or not math.isfinite(v):raise ValueError('Finite number required; boolean refused')
    return float(v)

def validate(weights,bias):
    if not isinstance(weights,list) or not weights or not all(isinstance(r,list) and r for r in weights):raise ValueError('Nonempty output rows required')
    width=len(weights[0])
    if any(len(r)!=width for r in weights):raise ValueError('Weight rows must have equal input width')
    if not isinstance(bias,list) or len(bias)!=len(weights):raise ValueError('One bias per output required')
    for row in weights:
        for v in row:finite(v)
    for v in bias:finite(v)
    return width,len(weights)

def forward(x,weights,bias,trace=False):
    ni,no=validate(weights,bias)
    if not isinstance(x,list) or len(x)!=ni:raise ValueError('Input length differs from columns of W[out][in]')
    x=[finite(v) for v in x];answer=[];details=[]
    for j in range(no):
        terms=[finite(weights[j][i]*x[i]) for i in range(ni)]
        p=finite(math.fsum(terms)+bias[j]);answer.append(p)
        if trace:details.append({'output_index':j,'terms':[{'input_index':i,'input':x[i],'weight':weights[j][i],'product':terms[i]} for i in range(ni)],'sum_products':math.fsum(terms),'bias':bias[j],'prediction':p})
    return (answer,details) if trace else answer

def loss_and_gradient(rows,weights,bias):
    ni,no=validate(weights,bias)
    if not isinstance(rows,list) or not rows:raise ValueError('Nonempty batch required')
    count=len(rows)*no;gw=[[0.]*ni for _ in range(no)];gb=[0.]*no;squares=[];predictions=[]
    for row in rows:
        y=row['y']
        if not isinstance(y,list) or len(y)!=no:raise ValueError('Target length differs from output rows')
        y=[finite(v) for v in y];p=forward(row['x'],weights,bias);predictions.append(p)
        for j in range(no):
            e=finite(p[j]-y[j]);squares.append(finite(e*e));output_slope=2*e/count
            gb[j]+=output_slope
            for i in range(ni):gw[j][i]+=finite(output_slope*row['x'][i])
    for row in gw:
        for v in row:finite(v)
    for v in gb:finite(v)
    return {'loss':finite(math.fsum(squares)/count),'weight_gradient':gw,'bias_gradient':gb,'predictions':predictions,'denominator':count}

def update(weights,bias,gradient,rate):
    ni,no=validate(weights,bias);rate=finite(rate)
    if rate<=0:raise ValueError('Positive learning rate required')
    if len(gradient['weight_gradient'])!=no or any(len(row)!=ni for row in gradient['weight_gradient']) or len(gradient['bias_gradient'])!=no:raise ValueError('Gradient shape differs')
    return ([[finite(weights[j][i]-rate*gradient['weight_gradient'][j][i]) for i in range(ni)] for j in range(no)],
            [finite(bias[j]-rate*gradient['bias_gradient'][j]) for j in range(no)])

def fit(rows,inputs,outputs,rate,steps,max_loss=1e8):
    if any(type(v) is not int or v<1 for v in (inputs,outputs)):raise ValueError('Positive integer input/output sizes required')
    if type(steps) is not int or not 0<=steps<=2000:raise ValueError('steps must be 0–2000')
    if finite(rate)<=0 or finite(max_loss)<=0:raise ValueError('Positive rate and max_loss required')
    weights=[[0.]*inputs for _ in range(outputs)];bias=[0.]*outputs;history=[];status='completed_requested_steps';last_valid=None
    for step in range(steps+1):
        try:result=loss_and_gradient(rows,weights,bias)
        except (ValueError,OverflowError) as e:
            if last_valid is None:raise
            weights,bias=last_valid;status='nonfinite_update_rejected';break
        history.append({'step':step,'loss':result['loss'],'denominator':result['denominator']})
        last_valid=([list(r) for r in weights],list(bias))
        if result['loss']>max_loss:status='loss_budget_stop';break
        if step==steps:break
        try:weights,bias=update(weights,bias,result,rate)
        except (ValueError,OverflowError):weights,bias=last_valid;status='nonfinite_update_rejected';break
    return {'weight':weights,'bias':bias,'trace':history,'status':status,'requested_steps':steps,'completed_updates':history[-1]['step'],
            'learning_rate':rate,'max_loss':max_loss,'initialization':'all zero; valid for this single affine layer only',
            'loss_reduction':'sum squared errors / (frames * outputs), no one-half coefficient'}
