# M19 本人记录空表

下载[课程实践包](/project-lines/neuro-bionics/aloha/aloha-practice-kit.zip)，解压后进入 `lessons/M19/practice/`。此处是空白学习模板，预填的名称是任务结构，所有实际结果均待本人填写，不是synthetic测试输出，更不是实测成绩。复制模板为新文件，保留原始照片/日志及文件摘要，完成者和导师分别记录自己的核验范围。

每个设备独立ID和校准路径，不重复覆盖。unit依据固定配置填写；夹爪0–100归一化，不能写毫米。reading为同一参考姿态的五次真实读数，reference_value只有独立参考支持才填。没有独立参考时可求平均与极差，不能声称相对真值偏差。
