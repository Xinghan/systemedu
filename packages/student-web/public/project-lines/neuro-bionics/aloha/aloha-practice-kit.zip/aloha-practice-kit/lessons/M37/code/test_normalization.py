"""Meaningful numerical/data-boundary tests; all fixtures synthetic."""
import hashlib,json,math,sys,tempfile,unittest
from pathlib import Path
from normalize import fit,forward,inverse,read_package,statistics,FIELDS,UNITS,verify_config
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M38/code'))
from make_slice import make
from scalar_predictor import predict
from report_normalization import report
from sample_four import calculate

class Normalization(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        (self.root/'data').mkdir()
        rows=[]
        for split,values in [('train',[8,8,12,12]),('validation',[1000,2000])]:
            for i,x in enumerate(values):
                rows.append({'episode_id':split+'-episode','attempt_id':split+'-attempt','frame_index':i,'split':split,
                             'action_semantics':'teleop_processor_action','observation_state':[x]+[0]*11,'action':[x+2]+[0]*11})
        raw=('\n'.join(json.dumps(r) for r in rows)+'\n').encode();(self.root/'data/frames.jsonl').write_bytes(raw)
        self.manifest={'schema':'aloha.teaching-frames.v1','provenance':'synthetic','hardware_revision':'synthetic-only',
                       'dataset_source':'unit fixture no robot','split_policy':'fixed synthetic episodes','sha256':hashlib.sha256(raw).hexdigest(),
                       'frame_count':len(rows),'joint_names':FIELDS,'joint_units':UNITS}
        (self.root/'manifest.json').write_text(json.dumps(self.manifest))
    def tearDown(self):self.tmp.cleanup()
    def test_training_only_population_statistics(self):
        c=fit(self.root,True);s=c['statistics']['observation_state'][0]
        self.assertEqual((s['mean'],s['population_variance'],s['raw_std']),(10,4,2))
        self.assertEqual(c['fitted_episode_ids'],['train-episode'])
        self.assertEqual(c['frame_count'],4)
    def test_constant_roundtrip_and_raw_std(self):
        s=statistics([7,7,7]);self.assertEqual(s['raw_std'],0);self.assertEqual(s['scale'],1)
        self.assertTrue(s['near_constant']);self.assertEqual(inverse(forward(9,s),s),9)
    def test_nonconstant_roundtrip(self):
        s=statistics([1,2,4])
        for x in [-3,0,2,100]:self.assertAlmostEqual(inverse(forward(x,s),s),x)
    def test_no_implicit_synthetic_permission(self):
        with self.assertRaises(ValueError):fit(self.root)
    def test_test_split_is_rejected(self):
        with self.assertRaises(ValueError):read_package(self.root,'test',True)
    def test_field_order_and_units_rejected(self):
        self.manifest['joint_names']=FIELDS[::-1];(self.root/'manifest.json').write_text(json.dumps(self.manifest))
        with self.assertRaises(ValueError):fit(self.root,True)
    def test_data_mutation_rejected(self):
        with (self.root/'data/frames.jsonl').open('a') as f:f.write('\n')
        with self.assertRaises(ValueError):fit(self.root,True)
    def test_modified_stats_rejected(self):
        c=fit(self.root,True);m,r=read_package(self.root,allow_synthetic=True)
        c['statistics']['action'][0]['mean']=0
        with self.assertRaises(ValueError):verify_config(c,m,r)
    def test_metadata_changed_without_frame_changes_refused(self):
        c=fit(self.root,True);before=(self.root/'data/frames.jsonl').read_bytes()
        for key in ('hardware_revision','dataset_source','split_policy'):
            original=self.manifest[key];self.manifest[key]='changed metadata';(self.root/'manifest.json').write_text(json.dumps(self.manifest))
            m,rows=read_package(self.root,allow_synthetic=True)
            with self.subTest(key=key),self.assertRaises(ValueError):verify_config(c,m,rows)
            self.assertEqual((self.root/'data/frames.jsonl').read_bytes(),before);self.manifest[key]=original
    def test_fitted_attempts_and_count_refused(self):
        m,rows=read_package(self.root,allow_synthetic=True)
        for key,value in [('fitted_attempt_ids',['other-attempt']),('frame_count',3),('frame_count',True)]:
            c=fit(self.root,True);c[key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):verify_config(c,m,rows)
    def test_slice_keeps_semantics_and_copy_baseline(self):
        c=fit(self.root,True);path=self.root/'norm.json';path.write_text(json.dumps(c))
        s=make(self.root,path,FIELDS[0],allow_synthetic=True)
        self.assertEqual(len(s['rows']),4);r=s['rows'][0]
        self.assertEqual((r['x'],r['target'],r['copy_current_state_prediction']),(-1,-1,-2))
        self.assertEqual(r['episode_id'],'train-episode')
        p=predict(s,.5,.1);self.assertAlmostEqual(p['rows'][0]['prediction'],-.4)
        self.assertFalse(p['hardware_command'])
    def test_validation_cannot_become_scalar_training(self):
        c=fit(self.root,True);path=self.root/'norm.json';path.write_text(json.dumps(c));s=make(self.root,path,FIELDS[0],allow_synthetic=True)
        s['rows'][0]['split']='validation'
        with self.assertRaises(ValueError):predict(s,.5,.1)
    def test_four_frame_trace(self):
        d=calculate(self.root,'train-episode',0,FIELDS[0],'observation_state',True)
        self.assertEqual(d['statistics_of_these_four_only']['mean'],10)
        self.assertEqual([r['squared_deviation'] for r in d['rows']],[4]*4)
        self.assertEqual([r['standardized_by_four_frame_stats'] for r in d['rows']],[-1,-1,1,1])
        with self.assertRaises(ValueError):calculate(self.root,'train-episode',1,FIELDS[0],'action',True)
    def test_report_counts_and_roundtrip(self):
        path=self.root/'norm.json';path.write_text(json.dumps(fit(self.root,True)))
        rows,svg,meta=report(self.root,path,FIELDS[0],'action',False,True)
        self.assertEqual(len(rows),4);self.assertEqual(sum(meta['bin_counts']['train']),4)
        self.assertEqual(sum(meta['bin_counts']['validation']),0);self.assertEqual(meta['roundtrip_max_abs_error'],0)
        self.assertIn('Frame counts, not a probability density',svg)
    def test_validation_plot_uses_frozen_training_scale(self):
        path=self.root/'norm.json';path.write_text(json.dumps(fit(self.root,True)))
        before=path.read_bytes();rows,_,meta=report(self.root,path,FIELDS[0],'observation_state',True,True)
        self.assertEqual(path.read_bytes(),before);self.assertEqual(rows[-1]['standardized'],995)
        self.assertEqual(sum(meta['bin_counts']['train']),4);self.assertEqual(sum(meta['bin_counts']['validation']),2)
if __name__=='__main__':unittest.main()
