#!/usr/bin/env python3
"""Transparent mini-batch ReLU training with exact optimizer/sampler resume state."""
import argparse,copy,csv,hashlib,importlib.metadata,json,math,platform,sys
from pathlib import Path
import minibatch,optimizers
from backprop import loss_gradient
from network_artifact import save as save_model,load as load_model,sha
from dataset_view import load_view
from linear_baseline import identity
def dump(path,value):
 with Path(path).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def code_identity():
 here=Path(__file__).resolve().parent;result={name:sha(here/name) for name in ('optimizers.py','minibatch.py','train_minibatch.py')}
 for module,name in [('M43','backprop.py'),('M42','relu_network.py'),('M41','linear_layer.py'),('M41','dataset_view.py')]:result[f'{module}/{name}']=sha(here.parents[1]/module/'code'/name)
 return result
def save_checkpoint(folder,model,optimizer,sampler,view,history):
 meta=save_model(folder,model,view,status='trained_checkpoint' if optimizer['step'] else 'initialized_untrained')
 state={'schema':'aloha.training-state.v1','source':identity(view),'model_sha256':meta['checkpoint_sha256'],'optimizer':optimizer,'sampler':sampler,'history':history,'code_sha256':code_identity(),'training_scope':'only standardized 12-state to 12-target ReLU network; no images or ACT','validation_opened':False,'test_opened':False,'hardware_command':False}
 dump(Path(folder)/'training-state.json',state);return meta
def load_checkpoint(folder,view):
 model,meta=load_model(folder,view);state=json.loads((Path(folder)/'training-state.json').read_text())
 if not isinstance(state,dict) or state.get('schema')!='aloha.training-state.v1' or state.get('source')!=identity(view) or state.get('model_sha256')!=meta['checkpoint_sha256']:raise ValueError('Training-state model/source binding differs')
 if state.get('code_sha256')!=code_identity():raise ValueError('Training code differs from checkpoint; do not call this an exact resume')
 optimizers.validate(model,state['optimizer']);minibatch.validate(state['sampler'],len(view['rows']));s=state['sampler'];step=state['optimizer']['step']
 expected=s['epoch']*math.ceil(s['count']/s['batch_size'])+math.ceil(s['cursor']/s['batch_size'])
 if step!=expected:raise ValueError('Optimizer step and sampler position disagree')
 history=state['history']
 if not isinstance(history,list) or len(history)!=step or any(not isinstance(v,dict) or v.get('step')!=i+1 for i,v in enumerate(history)):raise ValueError('Training history is incomplete or out of order')
 return model,state['optimizer'],state['sampler'],history
def training_run(package,normalization,source,output,steps,checkpoint_every=5,resume=False,kind=None,lr=None,batch_size=None,seed=None,beta1=None,beta2=None,epsilon=None,weight_decay=None,allow_synthetic=False,lock_file=None):
 if type(steps) is not int or not 1<=steps<=2000 or type(checkpoint_every) is not int or checkpoint_every<1:raise ValueError('Choose 1–2000 additional steps and positive checkpoint interval')
 view=load_view(package,normalization,'train',allow_synthetic);out=Path(output)
 if out.exists():raise FileExistsError('Output exists; choose a new run directory')
 lock=Path(lock_file or Path(__file__).resolve().parents[3]/'research/lerobot/uv.lock')
 if not lock.is_file():raise ValueError('Fixed upstream uv.lock is required')
 requested={'kind':kind,'lr':lr,'beta1':beta1,'beta2':beta2,'epsilon':epsilon,'weight_decay':weight_decay}
 if resume:
  model,opt,sampler,history=load_checkpoint(source,view)
  for key,value in requested.items():
   if value is not None and value!=opt['config'][key]:raise ValueError('Resume hyperparameter differs: '+key)
  if batch_size is not None and batch_size!=sampler['batch_size'] or seed is not None and seed!=sampler['seed']:raise ValueError('Resume sampler settings differ')
 else:
  model,_=load_model(source,view);defaults={'kind':'sgd','lr':.01,'beta1':.9,'beta2':.999,'epsilon':1e-8,'weight_decay':0.}
  c=optimizers.configuration(**{k:defaults[k] if v is None else v for k,v in requested.items()});opt=optimizers.initialize(model,c);sampler=minibatch.initialize(len(view['rows']),min(8,len(view['rows'])) if batch_size is None else batch_size,17 if seed is None else seed);history=[]
 start=opt['step'];out.mkdir(parents=True);checkpoints=out/'checkpoints';checkpoints.mkdir();saved=[]
 def snapshot():
  folder=checkpoints/f"step-{opt['step']:06d}";save_checkpoint(folder,model,opt,sampler,view,history);entry={'step':opt['step'],'directory':str(folder.relative_to(out)),'model_sha256':sha(folder/'model.safetensors'),'training_state_sha256':sha(folder/'training-state.json')};saved.append(entry)
 snapshot();status='completed_requested_steps';failure=None;first_update=None
 for _ in range(steps):
  indices,next_sampler,batch=minibatch.next_batch(sampler);rows=[view['rows'][i] for i in indices]
  try:
   # Each call allocates fresh gradient accumulators. No accidental carry-over.
   result=loss_gradient(rows,model)
   if result['loss']>1e8:raise ValueError('Batch loss exceeds declared 1e8 numerical budget')
   candidate,next_opt,trace=optimizers.update(model,result['gradient'],opt)
   # Validate before committing model/optimizer/sampler; failed updates leave all three unchanged.
   after=loss_gradient(rows,candidate)['loss']
   if after>1e8:raise ValueError('Candidate batch loss exceeds declared 1e8 numerical budget')
  except (ValueError,OverflowError) as error:
   status='update_rejected';failure={'attempted_step':opt['step']+1,'batch':batch,'reason':str(error)};break
  if first_update is None:first_update={'step':next_opt['step'],'batch':batch,'loss_before':result['loss'],'loss_after_on_same_batch':after,'all_parameter_updates':trace}
  model,opt,sampler=candidate,next_opt,next_sampler
  history.append({'step':opt['step'],'epoch':batch['epoch'],'start_cursor':batch['start_cursor'],'end_cursor':batch['end_cursor'],'batch_count':len(indices),'batch_loss_before':result['loss'],'batch_loss_after_same_batch':after,'denominator':result['denominator'],'frames':[{k:view['rows'][i][k] for k in ('episode_id','attempt_id','frame_index')} for i in indices]})
  if (opt['step']-start)%checkpoint_every==0:snapshot()
 if saved[-1]['step']!=opt['step']:snapshot()
 dump(out/'checkpoints.json',saved);dump(out/'latest.json',saved[-1]);dump(out/'first-update.json',first_update);dump(out/'worked-optimizer-table.json',optimizers.worked_table())
 with (out/'train-loss.csv').open('x',newline='') as f:
  keys=['step','epoch','batch_count','batch_loss_before','batch_loss_after_same_batch','denominator'];writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader();writer.writerows({k:r[k] for k in keys} for r in history)
 report={'schema':'aloha.minibatch-run.v1','source':identity(view),'status':status,'requested_additional_steps':steps,'start_step':start,'end_step':opt['step'],'completed_additional_steps':opt['step']-start,'resume':resume,'source_directory':str(source),'optimizer':opt['config'],'sampler_rule':sampler['shuffle_rule'],'failure':failure,'validation_opened':False,'test_opened':False,'hardware_command':False};dump(out/'run.json',report)
 dump(out/'environment.json',{'python':sys.version,'platform':platform.platform(),'packages':{name:importlib.metadata.version(name) for name in ('torch','safetensors')},'code_sha256':code_identity(),'upstream_lock_sha256':sha(lock),'scope':'offline explicit arithmetic, checkpoint I/O; not full hardware/ACT training validation'});(out/'upstream-uv.lock').write_bytes(lock.read_bytes())
 # Load latest checkpoint and assert exact model, optimizer and sampler values.
 restored=load_checkpoint(out/saved[-1]['directory'],view)
 if (model,opt,sampler,history)!=restored:raise ValueError('Checkpoint roundtrip changed training state')
 return {**report,'state_roundtrip_exact':True,'checkpoint_count':len(saved)}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('package');p.add_argument('normalization');p.add_argument('source');p.add_argument('--out',required=True);p.add_argument('--steps',type=int,default=20);p.add_argument('--checkpoint-every',type=int,default=5);p.add_argument('--resume',action='store_true');p.add_argument('--optimizer',dest='kind',choices=['sgd','adam','adamw']);p.add_argument('--lr',type=float);p.add_argument('--batch-size',type=int);p.add_argument('--seed',type=int)
 for key in ('beta1','beta2','epsilon','weight-decay'):p.add_argument('--'+key,type=float)
 p.add_argument('--allow-synthetic',action='store_true');p.add_argument('--lock-file');a=p.parse_args()
 try:
  r=training_run(a.package,a.normalization,a.source,a.out,a.steps,a.checkpoint_every,a.resume,a.kind,a.lr,a.batch_size,a.seed,a.beta1,a.beta2,a.epsilon,a.weight_decay,a.allow_synthetic,a.lock_file);print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['status']=='completed_requested_steps' else 1
 except (OSError,ValueError,KeyError,TypeError,ImportError,OverflowError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':raise SystemExit(main())
