#!/usr/bin/env python3
"""Optional offline ACT inference error evaluation; requires pinned LeRobot environment.

Uses saved training processors. No cameras, motors, or upload calls. Run on validation
before checkpoint selection; run test only once after selection is frozen.
"""
import argparse
import hashlib
import json
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint',required=True);p.add_argument('--dataset-root',required=True)
    p.add_argument('--repo-id',required=True);p.add_argument('--device',default='cpu',choices=['cpu','cuda','mps'])
    p.add_argument('--output',required=True);p.add_argument('--batch-size',type=int,default=4)
    a=p.parse_args();checkpoint=Path(a.checkpoint);out=Path(a.output)
    if not checkpoint.is_dir() or not (Path(a.dataset_root)/'meta'/'info.json').is_file():p.error('Existing local checkpoint and local LeRobot dataset required')
    if out.exists():p.error('Use a new output filename; never overwrite evidence')
    if a.batch_size<1:p.error('batch-size must be positive')
    # Optional heavy dependencies are deliberately imported only here.
    import torch
    from torch.utils.data import DataLoader
    from lerobot.datasets.lerobot_dataset import LeRobotDataset
    from lerobot.policies.act.modeling_act import ACTPolicy
    from lerobot.policies.act.configuration_act import ACTConfig
    from lerobot.policies.factory import make_pre_post_processors
    info=json.loads((Path(a.dataset_root)/'meta'/'info.json').read_text())
    config=ACTConfig.from_pretrained(str(checkpoint));config.device=a.device
    policy=ACTPolicy.from_pretrained(str(checkpoint),config=config,local_files_only=True).eval()
    pre,_=make_pre_post_processors(policy.config,pretrained_path=str(checkpoint),
                                  preprocessor_overrides={'device_processor':{'device':a.device}})
    dataset=LeRobotDataset(a.repo_id,root=a.dataset_root,
                         delta_timestamps={'action':[i/info['fps'] for i in range(policy.config.chunk_size)]})
    loader=DataLoader(dataset,batch_size=a.batch_size,shuffle=False,num_workers=0)
    total_absolute=None;count=0;frames=0
    with torch.inference_mode():
        for batch in loader:
            processed=pre(batch)
            # Gold future actions only enter the metric, never the inference inputs.
            observation={k:v for k,v in processed.items() if k.startswith('observation.')}
            predicted=policy.predict_action_chunk(observation)
            target=processed['action']
            mask=(~processed['action_is_pad']).unsqueeze(-1)
            error=(predicted-target).abs()*mask
            summed=error.sum(dim=(0,1)).cpu()
            total_absolute=summed if total_absolute is None else total_absolute+summed
            count+=int(mask.sum().item());frames+=target.shape[0]
    if count==0:p.error('No unpadded future actions')
    per_joint=(total_absolute/count).tolist()
    digest=hashlib.sha256()
    for path in sorted(checkpoint.rglob('*')):
        if path.is_file():
            digest.update(str(path.relative_to(checkpoint)).encode());digest.update(path.read_bytes())
    report={'scope':'Offline inference chunk error in saved training-normalized action coordinates; not task success or ACT training loss.',
            'dataset_root':str(Path(a.dataset_root).resolve()),'repo_id':a.repo_id,'checkpoint':str(checkpoint.resolve()),
            'checkpoint_tree_sha256':digest.hexdigest(),'frames':frames,'valid_future_steps':count,
            'mean_normalized_mae':sum(per_joint)/len(per_joint),'per_action_dimension_normalized_mae':per_joint,
            'feature_names':info['features']['action'].get('names'),
            'future_action_input_to_policy':False}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
