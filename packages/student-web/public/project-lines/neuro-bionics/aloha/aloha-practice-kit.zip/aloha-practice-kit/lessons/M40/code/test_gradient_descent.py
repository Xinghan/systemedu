import copy,json,math,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from gradient_descent import statistics,difference_check,train,loss_svg

def fixture(pairs):
    return {'provenance':{'kind':'synthetic','dataset_source':'unit-test-only'},'feature':{'unit':'standardized'},
            'target':{'unit':'standardized'},'normalization_sha256':'synthetic-test',
            'rows':[{'episode_id':'synthetic-episode','attempt_id':'synthetic-attempt','frame_index':i,
                     'split':'train','x':x,'target':y} for i,(x,y) in enumerate(pairs)]}

class GradientTests(unittest.TestCase):
    def test_numerical_square_and_two_directions(self):
        d=fixture([(2,3)]);s=statistics(d,0,0);self.assertEqual((s['loss'],s['gradient_weight'],s['gradient_bias']),(9,-12,-6))
        c=difference_check(d,0,0,.1)['coordinates'];self.assertAlmostEqual(c['weight']['plus_loss'],7.84);self.assertAlmostEqual(c['weight']['minus_loss'],10.24)
        self.assertAlmostEqual(c['weight']['central_difference'],-12);self.assertAlmostEqual(c['bias']['central_difference'],-6)
    def test_simultaneous_update_not_sequential(self):
        r=train(fixture([(2,3)]),0,0,.05,1);a=r['trace'][1]
        self.assertAlmostEqual(a['weight'],.6);self.assertAlmostEqual(a['bias'],.3);self.assertAlmostEqual(a['loss'],2.25)
    def test_too_large_rate_increases_loss(self):
        r=train(fixture([(2,3)]),0,0,.3,2)
        self.assertAlmostEqual(r['trace'][1]['loss'],36);self.assertAlmostEqual(r['trace'][2]['loss'],144)
    def test_full_batch_mean_and_positive_negative_cancellation(self):
        s=statistics(fixture([(-1,-1),(1,3)]),0,0)
        self.assertEqual(s['loss'],5);self.assertEqual(s['gradient_weight'],-4);self.assertEqual(s['gradient_bias'],-2)
        a=statistics(fixture([(-1,-1),(1,1)]),0,0);self.assertEqual(a['gradient_bias'],0);self.assertEqual(a['gradient_weight'],-2)
    def test_zero_input_has_zero_weight_direction(self):
        s=statistics(fixture([(0,3)]),1,0);self.assertEqual(s['gradient_weight'],0);self.assertEqual(s['gradient_bias'],-6)
    def test_mean_has_no_half_factor(self):
        s=statistics(fixture([(1,1)]),0,0);self.assertEqual(s['loss'],1);self.assertEqual(s['gradient_weight'],-2)
    def test_nontrain_bool_nonfinite_refused(self):
        for field,value in [('split','test'),('x',True),('target',float('nan'))]:
            d=fixture([(2,3)]);d['rows'][0][field]=value
            with self.assertRaises(ValueError):statistics(d,0,0)
    def test_budget_preserves_bad_curve_and_status(self):
        r=train(fixture([(2,3)]),0,0,.3,20,max_loss=100)
        self.assertEqual(r['status'],'loss_budget_stop');self.assertEqual(r['completed_updates'],2);self.assertAlmostEqual(r['trace'][-1]['loss'],144)
        self.assertIn('144',loss_svg([r]));json.dumps(r,allow_nan=False)
    def test_initial_state_and_input_are_unchanged(self):
        d=fixture([(2,3)]);before=copy.deepcopy(d);r=train(d,0,0,.05,0)
        self.assertEqual(r['completed_updates'],0);self.assertEqual(d,before);self.assertEqual(r['trace'][0]['loss'],9)
    def test_bad_hyperparameters_rejected(self):
        for rate,steps in [(0,3),(-1,3),(.1,True),(.1,-1),(.1,2001)]:
            with self.assertRaises(ValueError):train(fixture([(2,3)]),0,0,rate,steps)
        with self.assertRaises(ValueError):difference_check(fixture([(2,3)]),0,0,0)
    def test_difference_equals_scalar_expansion_for_several_points(self):
        c=difference_check(fixture([(-2,1),(.5,-3),(1,4)]),.7,-.2,.001)
        for v in c['coordinates'].values():self.assertLess(v['scaled_error'],1e-10)
if __name__=='__main__':unittest.main()
