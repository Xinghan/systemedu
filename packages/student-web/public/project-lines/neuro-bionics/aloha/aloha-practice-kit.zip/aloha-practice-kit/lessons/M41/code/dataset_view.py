"""Named, standardized 12-to-12 teaching views through the M35/M37 contract."""
import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'M37/code'))
from normalize import FIELDS,UNITS,read_package,verify_config,forward,inverse

def load_view(package,normalization,split='train',allow_synthetic=False):
    if split not in ('train','validation'):raise ValueError('Sealed test data cannot enter this teaching view')
    manifest,train=read_package(package,'train',allow_synthetic)
    raw=Path(normalization).read_bytes();config=json.loads(raw);verify_config(config,manifest,train)
    if split=='train':selected=train
    else:
        second,selected=read_package(package,'validation',allow_synthetic)
        if second!=manifest:raise ValueError('Manifest changed while reading views')
    return {'schema':'aloha.multichannel-view.v1','split':split,'provenance':manifest['provenance'],
            'dataset_source':manifest['dataset_source'],'hardware_revision':manifest['hardware_revision'],
            'frames_sha256':manifest['sha256'],'normalization_sha256':hashlib.sha256(raw).hexdigest(),
            'fields':list(FIELDS),'units':list(UNITS),'action_semantics':'teleop_processor_action',
            'statistics':config['statistics'],
            'rows':[{'episode_id':r['episode_id'],'attempt_id':r['attempt_id'],'frame_index':r['frame_index'],
                     'x':[forward(v,config['statistics']['observation_state'][j]) for j,v in enumerate(r['observation_state'])],
                     'y':[forward(v,config['statistics']['action'][j]) for j,v in enumerate(r['action'])],
                     'raw_observation':r['observation_state'],'raw_target':r['action']} for r in selected]}

def assert_compatible(first,second):
    for key in ('provenance','dataset_source','hardware_revision','frames_sha256','normalization_sha256','fields','units','action_semantics'):
        if first[key]!=second[key]:raise ValueError('View differs in '+key)

def physical_report(view,predictions):
    if len(predictions)!=len(view['rows']) or not predictions:raise ValueError('Prediction count differs')
    import math
    per=[]
    for j,field in enumerate(FIELDS):
        z_errors=[];errors=[]
        for row,p in zip(view['rows'],predictions):
            if len(p)!=12 or any(type(v) not in (int,float) or not math.isfinite(v) for v in p):raise ValueError('Expected 12 finite predictions')
            z_errors.append(p[j]-row['y'][j]);errors.append(inverse(p[j],view['statistics']['action'][j])-row['raw_target'][j])
        n=len(errors)
        per.append({'field':field,'unit':UNITS[j],'physical_mae_unit':UNITS[j],'physical_mse_unit':f'({UNITS[j]})^2','count':n,'physical_mae':math.fsum(abs(e) for e in errors)/n,
                    'physical_mse':math.fsum(e*e for e in errors)/n,
                    'standardized_mse':math.fsum(e*e for e in z_errors)/n})
    return {'split':view['split'],'provenance':view['provenance'],'frame_count':len(predictions),
            'standardized_mse_all_cells':math.fsum(p['standardized_mse'] for p in per)/12,
            'per_channel':per,'reduction':'equal weight per frame-channel cell; raw units never averaged across channels',
            'task_success_assessed':False,'hardware_executed':False}
