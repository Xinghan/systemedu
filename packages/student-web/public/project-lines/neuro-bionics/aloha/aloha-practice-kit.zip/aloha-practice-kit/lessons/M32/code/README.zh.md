# M32 · 采集覆盖审计

这是独立 CSV 审计器，不是 LeRobot 原生解析器，也不向设备发命令。Python 3.12 标准库即可。

先运行 `python coverage.py cells.synthetic.json attempts.synthetic.csv`，再运行 `python -m unittest -v`。所有 synthetic 文件是虚构示意，不能作为本人实采交付。

本人使用时复制空白 CSV，依据 M04 已批准工作区重新建立 cells.json，写明实际单位、坐标边界、角色与 known/unknown。known 表示明确审计过现有采集记录，因此零次可写零；未查清应写 unknown，输出为 null。封存测试条件不能填入开发采集记录。切勿套用示意格子当作真实安全范围。

每次尝试独占一行。training_candidate 来自 M31 已复核的标签表，不由本脚本自动判断；来源填 learner_recording，evidence_ref 指向本人原件。批次、日期、操作者和工位版本都保留。候选与失败都计尝试。同一批覆盖图不能混合 synthetic 与本人材料。

运行 `python coverage.py cells.json attempts.csv > coverage-report.json`，返回码非零时先修复错误，不能使用其中的覆盖结论。脚本只核对结构，不验证视频真实性，不推测模型成功率。图形与下一批决策由你依据 JSON 制作，保留每格回合身份。
