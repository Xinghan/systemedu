"""Deterministic data figure: real selected frame, no generated robot imagery."""
from html import escape
def render(evidence):
 t=evidence['network'];z=t['preactivation'];h=t['activation'];count=len(z);height=235+count*39+12*27
 left=50;zero=300;scale=205/max(1,max(abs(v) for v in z));top=130
 parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="{height}" viewBox="0 0 1100 {height}">', '<rect width="100%" height="100%" fill="#FAF9F5"/>','<style>text{font:16px system-ui,sans-serif;fill:#191814}.small{font-size:13px;fill:#6B6557}.title{font-size:24px;font-weight:bold}</style>']
 def text(x,y,value,css=''):parts.append(f'<text x="{x}" y="{y}" class="{css}">{escape(str(value))}</text>')
 text(35,40,'M42 · 所选帧的隐藏轨迹 / selected-frame hidden trace','title');text(35,68,'INITIALIZED / UNTRAINED · 前向计算；不是训练后的性能报告','small')
 frame=evidence['frame'];text(35,92,f"episode={frame['episode_id']} · frame={frame['frame_index']} · {evidence['source']['provenance']}",'small');text(35,115,'同一横轴：蓝色=开关前 z，橙色=ReLU 后 h；零值用点表示','small')
 parts.append(f'<line x1="{zero}" x2="{zero}" y1="{top-8}" y2="{top+count*39}" stroke="#6B6557"/>');text(zero-4,top+count*39+18,'0','small')
 for j,(v,a) in enumerate(zip(z,h)):
  y=top+j*39;text(left,y+12,f'h{j}')
  for k,(value,color) in enumerate(((v,'#5d8aa8'),(a,'#D97757'))):
   end=zero+value*scale;yy=y+k*12
   if value:parts.append(f'<rect x="{min(zero,end):.3f}" y="{yy}" width="{abs(end-zero):.3f}" height="8" fill="{color}"/>')
   else:parts.append(f'<circle cx="{zero}" cy="{yy+4}" r="3" fill="{color}"/>')
  text(550,y+15,f'z={v:.7g} → h={a:.7g}')
 y=top+count*39+50;text(35,y,'输出字段 / output');text(470,y,'目标 / target');text(670,y,'ReLU（未训练）');text(885,y,'相同参数无开关')
 for j,field in enumerate(t['second_layer_terms']):
  yy=y+27*(j+1);text(35,yy,field['output_field'],'small');text(470,yy,f"{evidence['target_standardized'][j]:.7g}");text(670,yy,f"{t['prediction'][j]:.7g}");text(885,yy,f"{evidence['same_parameters_identity_hidden']['prediction'][j]:.7g}")
 text(35,height-14,'全部输出为各自目标标准分数；隐藏值是计算中间量，无直接关节物理单位。','small');parts.append('</svg>');return ''.join(parts)
