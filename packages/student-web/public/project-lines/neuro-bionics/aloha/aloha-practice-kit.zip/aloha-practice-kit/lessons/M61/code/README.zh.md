# M61：实际 ACT 核心机制检查

本组命令均从实践包根目录运行。先激活 M14／M16 记录的固定环境。作者的受限 CPU 机制核验使用 Python 3.12、torch 2.11.0、torchvision 0.26.0、numpy 2.5.3、Pillow 与 einops 0.8.1；它没有安装完整 LeRobot，也没有驱动四臂。这个版本清单记录实际核验范围，不替代固定 LeRobot 全包的依赖锁定。导师应先核对本机导入记录，再运行夹具。

以下隔离后端仍需要 torch、torchvision、numpy、Pillow、einops，但不需要下载预训练权重；配置为 resnet18、pretrained_backbone_weights=None、dim_model=32、单层编码器/解码器/后验、latent_dim=2、dropout=0、n_action_steps=1、kl_weight=.1。它使用固定文件中的原样 ACT 类与函数，替代包配置及基础类接入；无法证明正式配置序列化、数据集加载、训练CLI或设备链路可用。

固定 Git revision：`b64fe1ed9f11eeac53ee821356d2797601701054`。模型源 SHA256：`8d622935319af7d03f1efd95d51e726af2921010f7e4f5ec3742f62280493111`。正式安装可将 `--isolated-source research/lerobot/src/lerobot/policies/act/modeling_act.py` 换成 `--checkout /实际/固定/lerobot`，程序会核对 Git 版本、源摘要与导入位置；该正式安装路径尚未由作者实际运行。

先生成一次明确标注 synthetic 的随机像素与数值夹具，已有目录不覆盖：

```sh
python3 lessons/M66/code/make_synthetic.py M66-synthetic-input
python3 lessons/M61/code/posterior_probe.py M66-synthetic-input/batch.npz M66-synthetic-input/manifest.json M61-posterior.json --isolated-source research/lerobot/src/lerobot/policies/act/modeling_act.py
```

输出后验token长度、CLS/state/action的mask、原始输出头、均值、对数方差、方差与标准差；把图像加扰动而保持状态/动作相同时，后验应不变。工具确实调用固定后验模块，但没有做优化器更新，随机权重尚无任务能力。本人批次可由M66准备器生成后替换前两个路径；需要同时携带M66/code，不可单独拷贝本脚本而丢失依赖。

不上传任何图像或文件，不连接电机。本人来源需人工审计；synthetic通过与真实数据通过分别记录。失败保留原始输入和日志，修复后换新输出路径。
