"""Local byte/identity checks. This module does not authenticate evidence truth."""
import hashlib,json,re
from pathlib import Path

def text(value,label):
    if not isinstance(value,str) or not value.strip():raise ValueError(f'{label}: nonempty text required')
    return value

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def contained(root,relative):
    text(relative,'path');p=Path(relative)
    if p.is_absolute() or '..' in p.parts:raise ValueError('Evidence path must be relative and stay inside artifact root')
    root=Path(root).resolve();p=(root/p).resolve()
    if not p.is_relative_to(root) or not p.is_file():raise ValueError(f'Missing or outside evidence: {relative}')
    return p

def verify_file(root,item):
    if not isinstance(item,dict):raise ValueError('Evidence reference must be an object')
    expected=item.get('sha256')
    if not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected):raise ValueError('Invalid SHA256')
    p=contained(root,item.get('path'))
    if sha(p)!=expected:raise ValueError(f'Content changed: {item["path"]}')
    return p

def inventory(root,rows):
    if not isinstance(rows,list) or not rows:raise ValueError('Nonempty evidence inventory required')
    out={}
    for row in rows:
        key=text(row.get('id'),'evidence id')
        if key in out:raise ValueError(f'Duplicate evidence id: {key}')
        verify_file(root,row);out[key]=row
    return out

def references(ids,files,label):
    if not isinstance(ids,list) or not ids:raise ValueError(f'{label}: evidence IDs required')
    if any(not isinstance(i,str) or i not in files for i in ids):raise ValueError(f'{label}: unknown evidence ID')

def read(path):return json.loads(Path(path).read_text())

def run_cli(function):
    import argparse
    p=argparse.ArgumentParser();p.add_argument('document');p.add_argument('--root',required=True);p.add_argument('--output')
    args=p.parse_args()
    try:result=function(args.document,args.root)
    except (ValueError,KeyError,TypeError,FileNotFoundError,json.JSONDecodeError) as e:
        result={'structural_complete':False,'errors':[str(e)],'truth_certified':False}
    rendered=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.output:
        with open(args.output,'x') as f:f.write(rendered)
    print(rendered,end='')
    raise SystemExit(0 if result.get('structural_complete') else 2)
