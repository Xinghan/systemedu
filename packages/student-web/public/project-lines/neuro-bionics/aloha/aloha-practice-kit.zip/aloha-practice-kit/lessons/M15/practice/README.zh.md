# 本节实践文件

这些 CSV 只有字段表头，故意没有伪造样本。用本人记录填写，未执行写 `not_executed`，未知写 `unknown`。示意计算和浏览器实验数据必须与本人记录分开。

- [power_check.csv](power_check.csv)：填写实际记录；原始照片、日志路径保留可追溯关系。
- [cutoff_test.csv](cutoff_test.csv)：填写实际记录；原始照片、日志路径保留可追溯关系。

具体操作顺序、成人分工和验收边界见本节 assignment.md。保存版本，不覆盖失败记录。本目录不声称已有任何真实打印、通电或实机测试结果。
