"""Synthetic contract tests, not native dataset decode/full LeRobot/GPU execution."""
import copy,json,sys,tempfile,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
for n in (68,69,70):sys.path.insert(0,str(BASE/f'M{n}'/'code'))
from course_contract import *
from benchmark import summarize
from resource_budget import assess
from export_predictions import score_rows,validation_rows,validate_rule
from select_candidate import select
from reload_bundle import package

class Contracts(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def put(self,name,d):
  p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d));return p
 def request(self):
  d=read(BASE/'M67/code/training_request.example.json');d['dataset'].update(root='/tmp/train',repo_id='local/train',source_dataset='frozen-source',split_manifest='/tmp/splits.json',split_sha256='a'*64,subset_audit_note='mentor checked only training episodes');d['checkout']='/tmp/lerobot';d['training']['output_dir']='/tmp/future-run';return d
 def test_request_valid_without_files(self):validate_request(self.request(),files=False)
 def test_executed_receipt_is_not_generation_only(self):
  from unittest.mock import patch
  import training_run
  # Only the receipt flag is mocked here; no trainer execution claim.
  command={'generated_only':True,'synthetic_fixture':True};out=self.root/'receipt'
  with patch.object(training_run,'generate',return_value=command),patch.object(training_run,'execute_command',side_effect=lambda c,r:read(r/'command.json')):
   result=training_run.run('synthetic-request',out,True)
  self.assertIs(result['generated_only'],False)
 def test_boolean_batch_rejected(self):
  d=self.request();d['training']['batch_size']=True
  with self.assertRaises(ValueError):validate_request(d,files=False)
 def test_wrong_units_rejected(self):
  d=self.request();d['action_units']=['degree']*12
  with self.assertRaises(ValueError):validate_request(d,files=False)
 def test_unknown_policy_flag_rejected(self):
  d=self.request();d['policy']['invented_fast_mode']=True
  with self.assertRaises(ValueError):validate_request(d,files=False)
 def test_ensemble_requires_one(self):
  d=self.request();d['policy'].update(temporal_ensemble_coeff=.1,n_action_steps=2)
  with self.assertRaises(ValueError):validate_request(d,files=False)
 def test_measured_percentile(self):self.assertEqual(summarize([1,2,3,4,5,6,7,8,9,10])['p90_s'],9)
 def test_nonfinite_timing(self):
  with self.assertRaises(ValueError):summarize([1,float('nan')])
 def test_synthetic_budget(self):
  m=read(BASE/'M67/code/measurement.synthetic.json');p=read(BASE/'M67/code/budget.synthetic.json');a=assess(m,p);self.assertEqual(a['estimated_required_seconds'],700);self.assertTrue(a['planning_ready'])
 def test_cpu_has_no_gpu_claim(self):
  m=read(BASE/'M67/code/measurement.synthetic.json');m['memory']['cuda_peak_reserved_bytes']=None;a=assess(m,read(BASE/'M67/code/budget.synthetic.json'));self.assertFalse(a['planning_ready']);self.assertIsNone(a['memory_fits'])
 def test_changed_candidate_cannot_reuse_timing(self):
  m=read(BASE/'M67/code/measurement.synthetic.json');p=read(BASE/'M67/code/budget.synthetic.json');p['request_sha256']='2'*64
  with self.assertRaises(ValueError):assess(m,p)
 def test_inventory_detects_change(self):
  p=self.put('x.json',{'a':1});rows=inventory(self.root);verify_inventory(self.root,rows);p.write_text('changed')
  with self.assertRaises(ValueError):verify_inventory(self.root,rows)
 def test_path_traversal(self):
  with self.assertRaises(ValueError):child(self.root,'../not-here')
 def fixture(self):
  rows=[{'episode_id':'V','attempt_id':'A','native_episode_index':2,'frame_index':i,'split':'validation','state':[0]*12,'action':[1]*12}for i in range(2)]
  view={'schema':'aloha.vision-teaching-view.v1','source_kind':'synthetic','dataset_source':{'identity':'synthetic'},'state_fields':VIEW_FIELDS,'action_fields':VIEW_FIELDS,'action_semantics':'teleop_action_processor target','episode_lengths':{'V':2},'episode_length_sources':{'V':'explicit synthetic length'},'rows':rows}
  split={'episodes':[{'episode_id':'V','attempt_id':'A','native_episode_index':2,'split':'validation'}]};return view,split
 def test_whole_validation(self):
  v,s=self.fixture();self.assertEqual(len(validation_rows(v,s)),2)
 def test_missing_tail_not_valid(self):
  v,s=self.fixture();v['rows'].pop()
  with self.assertRaises(ValueError):validation_rows(v,s)
 def test_attempt_substitution(self):
  v,s=self.fixture();v['rows'][0]['attempt_id']='OTHER'
  with self.assertRaises(ValueError):validation_rows(v,s)
 def test_episode_equal_weight(self):
  rows=[{'episode_id':e,'frame_index':i,'joint':FIELDS[0],'unit':UNITS[0],'target':0,'prediction':v}for e,i,v in [('A',0,2),('B',0,0),('B',1,0),('B',2,0)]]
  self.assertEqual(score_rows(rows,[1]*12)['score'],1)
 def selection_fixture(self):
  v,s=self.fixture();vp=self.put('view.json',v);sp=self.put('split.json',s);rule=read(BASE/'M69/code/selection_rule.example.json');rule.update(validation_view_path=str(vp),validation_view_sha256=sha(vp),split_manifest_path=str(sp),split_sha256=sha(sp),registered_at='2026-09-23T00:00:00+00:00',rationale='synthetic test scales',candidates=['a','b'],training_steps={'a':10,'b':20});rp=self.put('rule.json',rule)
  base={'schema':'aloha.offline-action-pairs.v1','purpose':'development','selection_rule_sha256':sha(rp),'validation_view_sha256':sha(vp),'split_sha256':sha(sp),'source_kind':'synthetic_fixture'};reports=[]
  for c in ('a','b'):
   d={**base,'candidate_id':c,'training_step':rule['training_steps'][c],'model_manifest_sha256':c*64,'rows':[{'episode_id':'V','frame_index':i,'joint':FIELDS[j],'unit':UNITS[j],'target':1,'prediction':2}for i in range(2)for j in range(12)]};reports.append(self.put(c+'.json',d))
  return rp,reports
 def test_predeclared_tie_break(self):
  rp,paths=self.selection_fixture();d=select(rp,paths,self.root/'out.json');self.assertEqual(d['selected']['candidate_id'],'a')
 def test_deleted_frame_from_all_reports_rejected(self):
  rp,paths=self.selection_fixture()
  for p in paths:
   d=read(p);d['rows']=d['rows'][:12];p.write_text(json.dumps(d))
  with self.assertRaises(ValueError):select(rp,paths,self.root/'out.json')
 def test_missing_candidate_rejected(self):
  rp,paths=self.selection_fixture()
  with self.assertRaises(ValueError):select(rp,paths[:1],self.root/'out.json')
 def test_test_role_rejected(self):
  rp,paths=self.selection_fixture();d=read(paths[0]);d['purpose']='test';paths[0].write_text(json.dumps(d))
  with self.assertRaises(ValueError):select(rp,paths,self.root/'out.json')
 def test_absolute_error_overflow(self):
  rows=[{'episode_id':'V','frame_index':0,'joint':FIELDS[0],'unit':UNITS[0],'target':-1e308,'prediction':1e308}]
  with self.assertRaises(ValueError):score_rows(rows,[1]*12)
 def test_scale_overflow(self):
  rows=[{'episode_id':'V','frame_index':0,'joint':FIELDS[0],'unit':UNITS[0],'target':0,'prediction':1e308}]
  with self.assertRaises(ValueError):score_rows(rows,[1e-308]*12)
 def test_registration_keeps_candidate_identity(self):
  # Synthetic byte fixtures validate provenance glue, NOT native model validity.
  from training_run import generate
  from register_candidate import register
  req=self.request();native=self.root/'native';native.mkdir();(native/'meta').mkdir()
  info={'total_episodes':1,'features':{'observation.state':{'names':FIELDS},'action':{'names':FIELDS},**{k:{'shape':[32,32,3]}for k in CAMERAS}}}
  self.put('native/meta/info.json',info);self.put('native/meta/stats.json',{'synthetic':True})
  split={'source_dataset':'frozen-source','held_out_conditions':'synthetic','near_duplicate_review_ref':'synthetic','seed':0,'episodes':[{'episode_id':str(i),'attempt_id':'a'+str(i),'batch_id':'b'+str(i),'lineage_id':'l'+str(i),'content_sha256':str(i)*64,'split':role,'evidence_ref':'synthetic','native_episode_index':i}for i,role in enumerate(('train','validation','test'))]}
  sp=self.put('splits.json',split);req['dataset'].update(root=str(native),split_manifest=str(sp),split_sha256=sha(sp),original_train_indices=[0]);req['training']['output_dir']=str(self.root/'train-run');rp=self.put('request.json',req)
  command=generate(rp);cp=self.put('receipt/command.json',command);log=self.root/'receipt/stdout-stderr.log';log.write_text('SYNTHETIC LOG: no real trainer invoked')
  self.put('receipt/result.json',{'returncode':0,'request_sha256':sha(rp),'command_sha256':sha(cp),'log_sha256':sha(log)})
  pre=self.root/'train-run/checkpoints/000010/pretrained_model';pre.mkdir(parents=True)
  self.put('train-run/checkpoints/000010/training_state/training_step.json',{'step':10})
  for name,data in [('config.json',{'type':'act',**req['policy']}),('train_config.json',{'dataset':{'root':str(native)}}),('policy_preprocessor.json',{'synthetic':True}),('policy_postprocessor.json',{'synthetic':True})]:self.put(str((pre/name).relative_to(self.root)),data)
  (pre/'model.safetensors').write_bytes(b'SYNTHETIC invalid model bytes, glue test only')
  result=register(pre,rp,self.root/'receipt',self.root,'candidate-step10')
  self.assertEqual(result['candidate_id'],'candidate-step10');self.assertEqual(result['training_step'],10)
 def test_package_reloads_identical_bytes(self):
  p=self.put('candidate/pretrained_model/config.json',{'synthetic':True});m=self.put('candidate/model_manifest.json',{'candidate_id':'A','source_kind':'synthetic_fixture','files':[{'path':'candidate/pretrained_model/config.json','sha256':sha(p)}]});s=self.put('selection.json',{'schema':'aloha.selection-result.v1','final_test_used':False,'selected':{'candidate_id':'A','model_manifest_sha256':sha(m)}})
  env=self.put('environment.json',{'python':'synthetic interpreter metadata','packages':[{'name':'synthetic','version':'0'}],'manual_fields':{'lerobot_git_rev_parse_HEAD':REVISION}})
  refs={k:'context/'+k+'.json'for k in ('hardware_manifest_ref','camera_manifest_ref','calibration_ref','measured_limits_ref','environment_lock_ref')}
  files=[]
  for key,name in refs.items():
   f=self.put(name,{'synthetic':True,'not_physical':True});files.append({'path':name,'sha256':sha(f)})
  context=self.put('context.json',{'schema':'aloha.deployment-context.v1','source_kind':'synthetic_fixture','action_fields':FIELDS,'action_units':UNITS,'camera_keys':CAMERAS,'power_authorization':'not_granted_by_this_package','files':files,**refs})
  out=self.root/'portable';result=package(s,m,self.root,out,environment_manifest=env,interface_manifest=context);verify_inventory(out,result['files']);self.assertEqual(sha(out/'candidate/model_manifest.json'),sha(m))
if __name__=='__main__':unittest.main(verbosity=2)
