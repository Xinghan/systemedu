#!/usr/bin/env python3
"""Generate an inspectable fixed-replay command. Never import LeRobot, open a device or execute it."""
import argparse,hashlib,json,math,shlex,sys
from pathlib import Path
HERE=Path(__file__).resolve()
for candidate in (HERE.parents[3],HERE.parents[3]/'practice-kit'):
    if (candidate/'act_commands.py').is_file():sys.path.insert(0,str(candidate));break
sys.path.insert(0,str(HERE.parents[2]/'M33/code'))
from act_commands import REVISION,generate as course_command,required_string
from audit_split import audit
JOINTS=('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')
FIELDS=[f'{side}_{j}.pos' for side in ('left','right') for j in JOINTS]

def generate(config,split_document,review):
    if not isinstance(review,dict):raise ValueError('review must be an object')
    if review.get('provenance')!='learner_recorded':raise ValueError('Review must refer to learner_recorded evidence; synthetic cannot authorize replay')
    required=('source_episode_id','source_dataset','hardware_revision','m22_stop_evidence_ref','m28_station_evidence_ref','mentor_review_ref','start_state_check_ref','clearance_check_ref','continuous_video_plan_ref','development_conditions_ref')
    for key in required:required_string(review.get(key),key)
    if review.get('development_only') is not True:raise ValueError('Only declared development conditions may be used')
    if review.get('recorded_slow_motion_reviewed') is not True:raise ValueError('Review a previously accepted slow recording; replay fps flag does not slow this pinned implementation')
    result=audit(split_document)
    if not result['valid']:raise ValueError('M33 split audit failed: '+'; '.join(result['errors']))
    if review['source_dataset']!=split_document['source_dataset']:raise ValueError('Review and split source identities differ')
    matches=[r for r in split_document['episodes'] if r['episode_id']==review['source_episode_id']]
    if len(matches)!=1 or matches[0]['split']!='train':raise ValueError('Choose exactly one original training episode, not validation/test')
    episode=matches[0]['native_episode_index']
    original=Path(config['dataset_root']).resolve()
    if Path(review.get('native_dataset_root','')).resolve()!=original:raise ValueError('Original native dataset root must match reviewed mapping')
    info_path=original/'meta/info.json'
    if not info_path.is_file():raise ValueError('Original local native dataset metadata missing; no download will be attempted')
    info=json.loads(info_path.read_text());fps=info.get('fps')
    if type(fps) not in (int,float) or not math.isfinite(fps) or fps<=0:raise ValueError('Dataset metadata requires a positive finite fps')
    names=info.get('features',{}).get('action',{}).get('names')
    if not isinstance(names,list) or len(names)!=12 or set(names)!=set(FIELDS):raise ValueError('Native action names must match the fixed 12 course joint fields')
    total=info.get('total_episodes')
    if type(total) is not int or episode>=total:raise ValueError('Native episode index is outside original dataset metadata')
    # Validate the existing complete workstation configuration without executing its generated recording command.
    checked=course_command(config,'record')
    robot=[a for a in checked['argv'] if a.startswith('--robot.') and not a.startswith('--robot.cameras=')]
    argv=['lerobot-replay']+robot+[f'--dataset.repo_id={config["dataset_repo_id"]}',f'--dataset.root={original}',f'--dataset.episode={episode}','--play_sounds=false']
    return {'revision':REVISION,'provenance':'command derived from declared learner records; generator does not verify physical truth',
            'generated_only':True,'hardware_executed':False,'source_episode_id':review['source_episode_id'],'native_episode_index':episode,
            'source_dataset':review['source_dataset'],'native_dataset_root':str(original),'split_manifest_sha256':result['canonical_manifest_sha256'],
            'native_info_sha256':hashlib.sha256(info_path.read_bytes()).hexdigest(),'review':review,
            'argv':argv,'environment':{'HF_HUB_OFFLINE':'1','HF_DATASETS_OFFLINE':'1'},
            'shell_preview':'HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 '+shlex.join(argv),
            'dataset_fps_used_by_pinned_source':fps,'dataset_fps_override_provided':False,
            'camera_inputs_enabled':False,'visual_task_feedback':False,
            'notes':['Manually executing shell_preview moves hardware; this generator never executes it.',
                     'Replay uses dataset.fps, despite an unused dataset.fps configuration field in this revision.',
                     'Recorded targets are fixed; driver relative limits and motor feedback remain active. Actual trajectories may differ.',
                     'No first-target interpolation or automatic state matching is provided by replay. Mentor must check start state and clearance first.',
                     'Pinned replay discards send_action return values and does not record this run. Capture continuous independent evidence; do not claim requested targets equal observed or sent positions.',
                     'Camera configuration is deliberately omitted. Replay does not select actions from images. A separate camera may record evidence.']}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('config');p.add_argument('split_manifest');p.add_argument('review');p.add_argument('--out',required=True);a=p.parse_args()
    try:
        load=lambda p:json.loads(Path(p).read_text())
        r=generate(load(a.config),load(a.split_manifest),load(a.review))
        with Path(a.out).open('x') as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    except (OSError,ValueError,TypeError,KeyError) as e:p.exit(2,f'ERROR: {e}\n')
if __name__=='__main__':main()
