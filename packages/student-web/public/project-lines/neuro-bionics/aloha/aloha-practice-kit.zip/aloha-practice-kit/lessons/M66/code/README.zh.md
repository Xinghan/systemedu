# M66：实际 ACT 核心机制检查

本组命令均从实践包根目录运行。先激活 M14／M16 记录的固定环境。作者的受限 CPU 机制核验使用 Python 3.12、torch 2.11.0、torchvision 0.26.0、numpy 2.5.3、Pillow 与 einops 0.8.1；它没有安装完整 LeRobot，也没有驱动四臂。这个版本清单记录实际核验范围，不替代固定 LeRobot 全包的依赖锁定。导师应先核对本机导入记录，再运行夹具。

以下隔离后端仍需要 torch、torchvision、numpy、Pillow、einops，但不需要下载预训练权重；配置为 resnet18、pretrained_backbone_weights=None、dim_model=32、单层编码器/解码器/后验、latent_dim=2、dropout=0、n_action_steps=1、kl_weight=.1。它使用固定文件中的原样 ACT 类与函数，替代包配置及基础类接入；无法证明正式配置序列化、数据集加载、训练CLI或设备链路可用。

固定 Git revision：`b64fe1ed9f11eeac53ee821356d2797601701054`。模型源 SHA256：`8d622935319af7d03f1efd95d51e726af2921010f7e4f5ec3742f62280493111`。正式安装可将 `--isolated-source research/lerobot/src/lerobot/policies/act/modeling_act.py` 换成 `--checkout /实际/固定/lerobot`，程序会核对 Git 版本、源摘要与导入位置；该正式安装路径尚未由作者实际运行。

先生成一次明确标注 synthetic 的随机像素与数值夹具，已有目录不覆盖：

```sh
python3 lessons/M66/code/make_synthetic.py M66-synthetic-input
python3 lessons/M66/code/act_step.py M66-synthetic-input/batch.npz M66-synthetic-input/manifest.json M66-synthetic-run --isolated-source research/lerobot/src/lerobot/policies/act/modeling_act.py
```

受限核验实际得到 loss约0.5265909433→0.5089345574、L1分母48；五类模块有有限非零梯度，补齐目标污染不改变预测和损失，新实例重载后无标签输出逐元素相同。这些仅是作者随机夹具结果，不是本人训练成绩。不同受支持设备／版本可能有数值差异，主要核对计算定义与断言，不手填预期数字。

本人数据先从 M47 导出真实像素视图。复制本目录 request.template.json，填写 chunk_size、冻结split_ref与samples，例如每条含实际episode_id和start_frame_index，字段以prepare_batch.py读取为准。不得使用REPLACE占位符。

```sh
python3 lessons/M66/code/prepare_batch.py /实际/M47/manifest.json /实际/request.json M66-real-input
python3 lessons/M66/code/act_step.py M66-real-input/batch.npz M66-real-input/manifest.json M66-real-run --checkout /实际/固定/lerobot
```

如果正式安装暂不可用，本人批次亦可用前述 --isolated-source 做受限核心验证，并明确记录尚缺完整安装检验。prepare_batch默认拒绝synthetic；仅夹具适配测试可加--allow-synthetic。输入是M47含实际RGB图像引用的aloha.vision-teaching-view.v1，绝非M35无像素JSONL。它要求episode_lengths与episode_length_sources（真实完整回合长度及原生来源），缺帧拒绝、真尾部才padding。

准备器只从train行计算十二维状态／动作均值与总体标准差，近零标准差缩放置1；图像双线性缩放32×32、RGB并按ImageNet通道均值／标准差。输出preprocessing.json用于复现。本次32px微型配置只检验机制，不是完整任务训练推荐。

report.json包含逐损失、梯度、mask不变性、无标签推理及checkpoint_reload；step-arrays.npz保存独立算账数组，posterior.json保存后验参数。mechanism-only.pt不含部署处理器、不足以实际任务训练，禁止作为实机rollout检查点。重载使用weights_only=True并严格匹配新实例参数；不要加载来源不明的权重文件。

不上传任何图像或文件，不连接电机。本人来源需人工审计；synthetic通过与真实数据通过分别记录。失败保留原始输入和日志，修复后换新输出路径。
