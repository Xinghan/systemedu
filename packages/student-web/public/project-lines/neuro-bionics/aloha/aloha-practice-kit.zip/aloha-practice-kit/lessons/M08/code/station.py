"""S1 integration of previously learned file, contract, mapping and clock tools."""
import argparse
import json
from pathlib import Path
import sys
import time
from controller import map_targets

def run_station(task,workspace,channels):
    started=time.perf_counter()
    if task.get('schema')!='aloha.course.task.v1' or task.get('mode')!='dry_run':
        raise ValueError('任务必须为已约定的dry_run格式')
    if task.get('provenance') not in ('synthetic','learner_specification'):
        raise ValueError('任务来源需为示例或本人编写的规格')
    if workspace.get('provenance') not in ('synthetic','learner_measurement'):
        raise ValueError('工作区来源需为示例或本人实际测绘')
    if workspace.get('schema')!='aloha.course.workspace.v1' or workspace.get('unit')!='mm':
        raise ValueError('工作区格式或毫米单位不符')
    required=('whole_insert_inside_region','left_holds_tray_during_placement','no_human_intervention','within_time_limit')
    if task.get('success_conditions')!=list(required):
        raise ValueError('任务条件清单与v1接口不符；先回M02核对版本')
    result=map_targets(channels,step=3)
    result['task_id']=task.get('task_id')
    result['workspace_unit']=workspace['unit']
    result['input_provenance']={'task':task['provenance'],'workspace':workspace['provenance'],'targets':channels['provenance']}
    result['process_elapsed_s']=time.perf_counter()-started
    result['clock_provenance']='measured_process_clock'
    result['claim']='offline interface only; task success and physical motion not evaluated'
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--task',type=Path,default=Path('task-spec-example.json'))
    p.add_argument('--workspace',type=Path,default=Path('workspace-example.json'))
    p.add_argument('--channels',type=Path,default=Path('channels-example.json'))
    p.add_argument('--output',type=Path,default=Path('station-result.json'))
    a=p.parse_args()
    try:
        result=run_station(*(json.loads(x.read_text(encoding='utf-8')) for x in (a.task,a.workspace,a.channels)))
        result['input_files']={k:str(getattr(a,k).resolve()) for k in ('task','workspace','channels')}
        a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print('ACCEPT dry_run；无硬件输出；任务本身尚未执行')
    except (ValueError,TypeError,OSError) as exc:
        print('REJECT: '+str(exc),file=sys.stderr);return 2
    return 0

if __name__=='__main__':raise SystemExit(main())
