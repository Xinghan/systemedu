"""Check one exported frame without loading devices or making authenticity claims."""
import argparse
import json
import math
from pathlib import Path

JOINTS=('shoulder_pan','shoulder_lift','elbow_flex','wrist_flex','wrist_roll','gripper')
FIELDS=[f'{side}_{joint}.pos' for side in ('left','right') for joint in JOINTS]
LAYERS=('raw_teleop_action','teleop_processor_action','robot_processor_action_to_send',
        'driver_returned_sent_action','observed_state')

def inspect(data):
    if not isinstance(data,dict):raise ValueError('Frame must be a JSON object')
    origin=data['provenance']
    if not isinstance(origin,dict):raise ValueError('Provenance must be a JSON object')
    if origin.get('kind') not in ('synthetic','learner_recording') or not origin.get('source'):
        raise ValueError('Declare a synthetic fixture or a traceable learner source')
    if data['field_order']!=FIELDS:
        raise ValueError('Field order differs from the explicit two-arm contract')
    units=['normalized_0_100' if 'gripper' in f else 'degree' for f in FIELDS]
    if data['units']!=units:
        raise ValueError('Five rotary joints use degrees; each gripper uses normalized opening')
    for key in ('episode_index','frame_index'):
        if type(data[key]) is not int or data[key]<0: raise ValueError('Invalid '+key)
    if not isinstance(data.get('attempt_id'),str) or not data['attempt_id'].strip(): raise ValueError('Attempt identity missing')
    def finite(value):
        if type(value) not in (int,float) or not math.isfinite(value): raise ValueError('Non-finite or nonnumeric value')
        return float(value)
    fps=finite(data['nominal_fps'])
    if fps<=0: raise ValueError('Nominal FPS must be positive')
    if not math.isclose(finite(data['native_timestamp_s']),data['frame_index']/fps,abs_tol=1e-6):
        raise ValueError('Native timestamp does not follow the declared nominal grid')
    for layer in LAYERS:
        if not isinstance(data[layer],dict):raise ValueError(layer+': expected named-field object')
        if set(data[layer])!=set(FIELDS): raise ValueError(layer+': missing or extra field')
        for f in FIELDS: finite(data[layer][f])
    native=data['native_action']
    if not isinstance(native,list):raise ValueError('Native action must be an ordered list')
    if len(native)!=len(FIELDS): raise ValueError('Native action dimension mismatch')
    if any(not math.isclose(finite(v),data['teleop_processor_action'][f],abs_tol=1e-6)
           for f,v in zip(FIELDS,native)):
        raise ValueError('Native action is not the declared teleop processor target')
    times=[finite(data[k]) for k in ('monotonic_observation_arrival','monotonic_send_start','monotonic_send_end')]
    if times!=sorted(times): raise ValueError('Monotonic events out of order; inspect instrumentation')
    return {'provenance':origin,'attempt_id':data['attempt_id'],'episode_index':data['episode_index'],
            'frame_index':data['frame_index'],'shape':[len(FIELDS)],'units':units,
            'rows':[{'field':f,'unit':u,**{layer:data[layer][f] for layer in LAYERS}}
                    for f,u in zip(FIELDS,units)],
            'native_target_semantics':'teleop_action_processor output',
            'nominal_timestamp_s':data['native_timestamp_s'],'arrival_to_send_end_s':times[2]-times[0],
            'physical_authenticity_verified':False,'exposure_timing_known':False,
            'note':'Structural check only. Open source video and attempt logs to check provenance.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('frame',type=Path)
    args=parser.parse_args()
    try: print(json.dumps(inspect(json.loads(args.frame.read_text())),ensure_ascii=False,indent=2))
    except (ValueError,KeyError,TypeError,OSError) as error: parser.exit(2,f'CHECK FAILED: {error}\n')
