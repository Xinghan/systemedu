# M74 实际输入、操作与恢复

从解压后的实践包根目录运行；保留 lessons/M73–M78 的相邻目录，入口通过同包相对路径复用 M74 的唯一审核。Python 3.12 标准库足够运行本批证据/统计工具；真实 ACT 的加载、处理器与设备环境仍沿用 M69–M72 固定实现，不能用本批轻量环境替代。

所有输出新建、不覆盖。空白模板只说明输入字段，不能直接充当真实成绩。synthetic 仅软件夹具，永不性能达标；learner_recording 是来源声明，摘要一致不认证现场真实性。保存整个证据根目录，相对路径随包移动。单独拷贝一个Python文件会丢失跨节点审核依赖。

## 建立实际文件清单

模型入口必须直接保留M69产生的 `aloha.act-model-manifest.v1` 原件，及其候选目录、pretrained_dir和全部叶文件的相对结构。证据根目录应与M69 `artifact_root` 对应；需要搬运时复制整个根目录并保持相对路径，不能只搬一份manifest。冻结model_manifest_sha256与gateway的policy_artifact_sha256均是这份原始M69模型清单的SHA，不能重新包一层通用清单或改写原件。

另外准备硬件/标定、数据划分、软件清单，以及独立运行配置。清单叶文件都在证据根目录内。下面的通用工具仅示范建立硬件文件清单：

```sh
python lessons/M74/code/make_inventory.py --root work/evidence --file hardware/rig-revision.json --file hardware/calibration.json --output work/evidence/hardware-manifest.json
```

硬件文件名仅示意，需连接本人四臂身份、打印修订、相机与完整标定证据；软件清单连接固定版本与实际运行脚本。模型部分不运行此命令，直接引用M69实际清单；其schema、action字段、单位、处理器及pretrained_dir将由Runtime继续核对。其他清单同样使用实际路径，不能把示意空文件当真实输入。

复制draft.template.json，填五类入口、二十条封存条件、时限和三类门槛。registered_at/frozen_versions由程序生成，结果保持空。每条evidence_requirements包含video、gateway_log、outcome_note。

```sh
python lessons/M74/code/freeze_plan.py work/evidence/draft.json --root work/evidence --output work/evidence/plan.json --seed 37
```

种子37仅示意，可在首次冻结前选择；保存输出的顺序和原始字节SHA。冻结后不要重新排版文件。对副本改一个字节验证拒绝，正式原件不动。后续M76审核复用audit_evaluation(path,root)，不能只用旧通用计数模板宣称完整。
