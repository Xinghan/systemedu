"""Measured local-frame chain. No dimensions or SO101 axis claims are supplied."""
import argparse
import itertools
import json
import math
from pathlib import Path


def identity():
    return [[float(i == j) for j in range(4)] for i in range(4)]


def multiply(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def transform(point, matrix):
    return [sum(matrix[i][k]*([*point, 1][k]) for k in range(4)) for i in range(3)]


def translation(v):
    result = identity()
    for i in range(3):
        result[i][3] = v[i]
    return result


def rotation(axis, degrees):
    if axis not in ('x', 'y', 'z'):
        raise ValueError('Axis must be x, y or z in the current local frame')
    a = math.radians(degrees)
    c, s = math.cos(a), math.sin(a)
    blocks = {'x': [[1,0,0],[0,c,-s],[0,s,c]],
              'y': [[c,0,s],[0,1,0],[-s,0,c]],
              'z': [[c,-s,0],[s,c,0],[0,0,1]]}
    result = identity()
    for i in range(3):
        result[i][:3] = blocks[axis][i]
    return result


def fixed_transform(part):
    # Column vectors: T = Trans * Rz * Ry * Rx (rightmost acts first on a point).
    result = translation(part['translation'])
    for axis, value in zip('zyx', reversed(part['rotation_xyz_deg'])):
        result = multiply(result, rotation(axis, value))
    return result


def validate(model):
    if model.get('provenance') not in ('synthetic', 'learner_measured') or not model.get('unit'):
        raise ValueError('Explicit measured-model provenance and unit required')
    if len(model['joints']) != 5:
        raise ValueError('This course model contains five arm axes; gripper is separate')
    for part in [model['base'], model['tool']] + [j['fixed'] for j in model['joints']]:
        for key in ('translation', 'rotation_xyz_deg'):
            if len(part[key]) != 3 or not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in part[key]):
                raise ValueError('Every fixed transform needs finite 3D vectors')
    for j in model['joints']:
        if j['axis'] not in ('x','y','z') or isinstance(j['sign'],bool) or j['sign'] not in (-1,1):
            raise ValueError('Measured axis and direction required')
        lo, hi = j['limits_deg']
        if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in [lo,hi,j['zero_deg']]) or lo >= hi:
            raise ValueError('Explicit nondegenerate limits required')


def fk(model, joint_deg):
    validate(model)
    if len(joint_deg) != 5 or not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in joint_deg):
        raise ValueError('Five finite joint readings required')
    total = fixed_transform(model['base'])
    trace = []
    for joint, angle in zip(model['joints'], joint_deg):
        lo, hi = joint['limits_deg']
        if not lo <= angle <= hi:
            raise ValueError('Candidate outside declared measured limits')
        total = multiply(total, fixed_transform(joint['fixed']))
        total = multiply(total, rotation(joint['axis'], joint['sign']*(angle-joint['zero_deg'])))
        trace.append({'joint':joint['name'], 'matrix':total, 'origin':transform([0,0,0],total)})
    total = multiply(total, fixed_transform(model['tool']))
    return {'tip':transform([0,0,0], total), 'tool_transform':total, 'trace':trace,
            'provenance':model['provenance'], 'unit':model['unit'], 'hardware_executed':False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('model', type=Path)
    parser.add_argument('--angles', nargs=5, type=float)
    parser.add_argument('--scan', action='store_true', help='Three samples per joint, point cloud only; no collision certification')
    args = parser.parse_args()
    model = json.loads(args.model.read_text())
    validate(model)
    if args.scan:
        grids = [[j['limits_deg'][0],sum(j['limits_deg'])/2,j['limits_deg'][1]] for j in model['joints']]
        output = {'warning':'sparse candidate point cloud, not a certified boundary or collision-free set',
                  'provenance':model['provenance'],'points':[{'angles':q,'tip':fk(model,q)['tip']} for q in itertools.product(*grids)]}
    elif args.angles:
        output = fk(model,args.angles)
    else:
        parser.error('Choose --angles or --scan')
    print(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False))
